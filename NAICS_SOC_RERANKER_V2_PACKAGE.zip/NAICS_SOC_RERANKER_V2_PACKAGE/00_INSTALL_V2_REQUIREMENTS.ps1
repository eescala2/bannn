param([string]$Base="C:\laborshed_autocode_v2")
$ErrorActionPreference="Stop"; Set-Location $Base
$Python=Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Virtual environment missing: $Python" }
& $Python -m pip install --upgrade pip setuptools wheel
& $Python -m pip install -r (Join-Path $Base "requirements_reranker_v2_core.txt")
if ($LASTEXITCODE -ne 0) { throw "Core package installation failed" }
& $Python -c "import torch; print('torch',torch.__version__); print('cuda',torch.cuda.is_available()); print('device',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO CUDA')"
