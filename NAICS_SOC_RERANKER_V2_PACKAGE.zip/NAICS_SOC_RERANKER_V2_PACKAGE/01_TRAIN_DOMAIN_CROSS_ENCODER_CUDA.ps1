param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$FitSav = "",
    [string]$CalibrationSav = "",
    [string]$OutputDir = "",
    [int]$MaxAnchorsPerTarget = 12000,
    [double]$Epochs = 1.0
)
$ErrorActionPreference = "Stop"
Set-Location $Base
if (-not $FitSav) { $FitSav = Join-Path $Base "training_FIT.sav" }
if (-not $CalibrationSav) { $CalibrationSav = Join-Path $Base "training_CALIBRATION.sav" }
if (-not $OutputDir) { $OutputDir = Join-Path $Base "models\domain_cross_encoder" }
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "train_domain_cross_encoder.py"
foreach ($p in @($Python,$Script,$FitSav,$CalibrationSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
$ConsoleLog = Join-Path $Base "console_DOMAIN_RERANKER_TRAIN_live.log"
Write-Host "Training task-specific NAICS/SOC Cross-Encoder..." -ForegroundColor Cyan
Write-Host "Live output: $ConsoleLog" -ForegroundColor Cyan
# Tee-Object keeps the Positron terminal live and writes a durable log.
& $Python -u $Script `
    --fit_sav $FitSav `
    --calibration_sav $CalibrationSav `
    --output_dir $OutputDir `
    --base_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
    --embedding_model "BAAI/bge-large-en-v1.5" `
    --device cuda `
    --embedding_batch_size 16 `
    --train_batch_size 4 `
    --eval_batch_size 32 `
    --gradient_accumulation_steps 8 `
    --epochs $Epochs `
    --max_length 384 `
    --max_anchors_per_target $MaxAnchorsPerTarget `
    --hard_negatives 3 `
    --random_negatives 1 `
    --nearest_candidates 30 `
    --eval_candidates 20 `
    --offline 2>&1 | Tee-Object -FilePath $ConsoleLog
if ($LASTEXITCODE -ne 0) { throw "Domain Cross-Encoder training failed with code $LASTEXITCODE" }
Write-Host "Fine-tuned model: $(Join-Path $OutputDir 'final')" -ForegroundColor Green
