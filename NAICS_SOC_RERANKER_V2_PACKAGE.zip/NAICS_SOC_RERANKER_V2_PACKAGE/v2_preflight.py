#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Preflight for the audited Reranker V2 pipeline."""
from __future__ import annotations
import argparse, importlib, json, os, sys
from pathlib import Path

REQUIRED = [
    ("numpy", "numpy"), ("pandas", "pandas"), ("scipy", "scipy"),
    ("scikit-learn", "sklearn"), ("joblib", "joblib"),
    ("pyreadstat", "pyreadstat"), ("sentence-transformers", "sentence_transformers"),
    ("transformers", "transformers"), ("datasets", "datasets"),
    ("accelerate", "accelerate"), ("rapidfuzz", "rapidfuzz"),
    ("faiss-cpu", "faiss"), ("psutil", "psutil"),
]


def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--base", required=True)
    p.add_argument("--fit_sav", default="")
    p.add_argument("--calibration_sav", default="")
    p.add_argument("--gold_sav", default="")
    p.add_argument("--cross_encoder_model", default="")
    p.add_argument("--out_json", required=True)
    args=p.parse_args()
    base=Path(args.base)
    report={"python":sys.version,"base":str(base),"packages":{},"files":{},"cuda":{},"critical_errors":[],"warnings":[]}
    for package,module in REQUIRED:
        try:
            mod=importlib.import_module(module)
            report["packages"][package]={"ok":True,"version":getattr(mod,"__version__",None)}
        except Exception as exc:
            report["packages"][package]={"ok":False,"error":repr(exc)}
            report["critical_errors"].append(f"Missing required package {package}. Install: python -m pip install {package}")
    try:
        import torch
        report["cuda"]={
            "torch":torch.__version__,"available":bool(torch.cuda.is_available()),
            "cuda_version":torch.version.cuda,
            "device":torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "vram_gb":round(torch.cuda.get_device_properties(0).total_memory/1024**3,2) if torch.cuda.is_available() else None,
        }
        if not torch.cuda.is_available():
            report["critical_errors"].append("CUDA PyTorch is unavailable. The RTX 2050 path requires a CUDA wheel.")
    except Exception as exc:
        report["critical_errors"].append(f"PyTorch import failed: {exc}")
    files={
        "main_script":base/"naics_soc_adaptive_memory_reranker_v2.py",
        "audit_module":base/"autocoder_improvement_audit_v2.py",
        "reranker_trainer":base/"train_domain_cross_encoder.py",
        "fit_sav":Path(args.fit_sav) if args.fit_sav else base/"training_FIT.sav",
        "calibration_sav":Path(args.calibration_sav) if args.calibration_sav else base/"training_CALIBRATION.sav",
        "gold_sav":Path(args.gold_sav) if args.gold_sav else base/"training_EVALUATION_GOLD.sav",
    }
    if args.cross_encoder_model:
        files["cross_encoder_model"]=Path(args.cross_encoder_model)
    for name,path in files.items():
        report["files"][name]={"path":str(path),"exists":path.exists()}
        if not path.exists(): report["critical_errors"].append(f"Required file missing: {path}")
    # Offline model load test when possible.
    ce_path=Path(args.cross_encoder_model) if args.cross_encoder_model else None
    if ce_path and ce_path.exists() and report.get("cuda",{}).get("available"):
        try:
            os.environ["HF_HUB_OFFLINE"]="1"; os.environ["TRANSFORMERS_OFFLINE"]="1"
            from sentence_transformers import CrossEncoder
            CrossEncoder(str(ce_path), device="cuda")
            report["cross_encoder_offline_load"]={"ok":True}
        except Exception as exc:
            report["cross_encoder_offline_load"]={"ok":False,"error":repr(exc)}
            report["critical_errors"].append(f"Fine-tuned Cross-Encoder failed offline load: {exc}")
    report["ok"]=not report["critical_errors"]
    Path(args.out_json).write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
    return 0 if report["ok"] else 2
if __name__=="__main__": raise SystemExit(main())
