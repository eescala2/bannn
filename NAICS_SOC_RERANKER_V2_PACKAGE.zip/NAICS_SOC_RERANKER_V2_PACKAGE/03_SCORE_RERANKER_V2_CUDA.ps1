param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$ModelIn = "",
    [Parameter(Mandatory=$true)][string]$ScoreSav,
    [string]$OutSav = "",
    [string]$RunLabel = "reranker_v2_score"
)
$ErrorActionPreference="Stop"; Set-Location $Base
if (-not $ModelIn) { $ModelIn = Join-Path $Base "models\naics_soc_RERANKER_V2.joblib" }
if (-not $OutSav) { $OutSav = Join-Path $Base "output\scored_RERANKER_V2.sav" }
$Python=Join-Path $Base ".venv\Scripts\python.exe"; $Script=Join-Path $Base "naics_soc_adaptive_memory_reranker_v2.py"
foreach ($p in @($Python,$Script,$ModelIn,$ScoreSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"; $env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
New-Item -ItemType Directory -Force -Path (Split-Path $OutSav),(Join-Path $Base "logs"),(Join-Path $Base "model_audits") | Out-Null
$Log=Join-Path $Base "logs\RERANKER_V2_score_predictions.txt"; $Console=Join-Path $Base "logs\console_RERANKER_V2_score_live.log"
& $Python -u $Script --mode score --model_in $ModelIn --score_sav $ScoreSav --out_sav $OutSav --log_txt $Log `
 --overwrite_existing --fill_all_missing --score_rows_without_text --fallback_fill_missing `
 --embedding_device cuda --embedding_batch_size 16 --embedding_cache_dir (Join-Path $Base "embedding_cache") `
 --max_workers 6 --native_threads 1 --score_batch_size 1000 --console_log $Console `
 --analysis_dir (Join-Path $Base "model_audits") --analysis_run_label $RunLabel --analysis_include_row_details
if ($LASTEXITCODE -ne 0) { throw "Score-only run failed with code $LASTEXITCODE" }
Write-Host "Scored SAV: $OutSav" -ForegroundColor Green
