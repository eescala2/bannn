param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$PythonVersion = "3.14"
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $Base | Out-Null
Set-Location $Base

$Venv = Join-Path $Base ".venv"
$Python = Join-Path $Venv "Scripts\python.exe"

if (-not (Test-Path $Python)) {
    Write-Host "Creating virtual environment in $Venv" -ForegroundColor Cyan
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py "-$PythonVersion" -m venv $Venv
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python -m venv $Venv
    } else {
        throw "Python was not found. Install 64-bit Python first, then rerun this script."
    }
}

& $Python -m pip install --upgrade pip setuptools wheel

if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
    Write-Host "NVIDIA GPU detected. Installing CUDA 12.6 PyTorch." -ForegroundColor Green
    & $Python -m pip install --upgrade torch --index-url https://download.pytorch.org/whl/cu126
} else {
    Write-Warning "No NVIDIA GPU detected. Installing CPU PyTorch. Training will be much slower."
    & $Python -m pip install --upgrade torch
}

$CoreReq = Join-Path $Base "requirements_reranker_v2_core.txt"
if (-not (Test-Path $CoreReq)) { throw "Requirements file not found: $CoreReq" }
& $Python -m pip install --upgrade -r $CoreReq

$Dirs = @("hf_cache", "embedding_cache", "model_audits", "adaptive_memory_rules_v2", "logs", "output", "models")
foreach ($d in $Dirs) { New-Item -ItemType Directory -Force -Path (Join-Path $Base $d) | Out-Null }

Write-Host "\nEnvironment verification:" -ForegroundColor Cyan
& $Python -c "import torch, pyreadstat, sklearn, sentence_transformers, faiss, datasets, accelerate; print('torch=', torch.__version__); print('cuda=', torch.cuda.is_available()); print('device=', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'); print('core imports OK')"
Write-Host "\nSetup complete. Next run 01_CACHE_MODELS_FOR_OFFLINE.ps1." -ForegroundColor Green
