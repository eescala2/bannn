#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create leakage-resistant FIT / CALIBRATION / GOLD SPSS files.

The three partitions have distinct jobs:

* FIT: trains all supervised models, dictionaries, semantic memory, and adaptive
  historical rules.
* CALIBRATION: learns candidate-fusion weights, source confidence mappings, and
  conformal prediction-set thresholds. It is never used to fit base models.
* GOLD: remains sealed for final model comparison and audit reporting.

Preferred split order:
1. Temporal split: oldest records -> FIT, next-newest -> CALIBRATION, newest -> GOLD.
2. Group split by normalized employer + current/unused title so near-duplicate
   institutional patterns do not cross partitions.
3. Random split only as a last resort.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import pyreadstat
from sklearn.model_selection import GroupShuffleSplit


def norm(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = str(value).lower().replace("&", " and ")
    s = re.sub(r"\b(?:incorporated|inc|llc|l\.l\.c|corp(?:oration)?|company|co|limited|ltd)\b", " ", s)
    s = re.sub(r"\b(?:store|branch|location|unit)\s*#?\s*\d+\b", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def filter_meta_dict(d: Optional[Dict[str, Any]], columns: Sequence[str]) -> Optional[Dict[str, Any]]:
    if not d:
        return None
    out = {k: v for k, v in d.items() if k in columns}
    return out or None


def write_sav(df: pd.DataFrame, meta: Any, path: str) -> None:
    cols = list(df.columns)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    pyreadstat.write_sav(
        df,
        path,
        file_label=getattr(meta, "file_label", "") or "",
        column_labels=filter_meta_dict(getattr(meta, "column_names_to_labels", None), cols),
        variable_value_labels=filter_meta_dict(getattr(meta, "variable_value_labels", None), cols),
        missing_ranges=filter_meta_dict(getattr(meta, "missing_ranges", None), cols),
        variable_display_width=filter_meta_dict(getattr(meta, "variable_display_width", None), cols),
        variable_measure=filter_meta_dict(getattr(meta, "variable_measure", None), cols),
        variable_format=filter_meta_dict(getattr(meta, "original_variable_types", None), cols),
        note=getattr(meta, "notes", None),
        compress=False,
    )


def parse_date(series: pd.Series) -> pd.Series:
    if pd.api.types.is_datetime64_any_dtype(series):
        return pd.to_datetime(series, errors="coerce")
    numeric = pd.to_numeric(series, errors="coerce")
    nonmissing = numeric.dropna()
    if len(nonmissing) and nonmissing.between(1900, 2200).mean() > 0.70:
        return pd.to_datetime(numeric.round().astype("Int64").astype(str) + "-07-01", errors="coerce")
    # SPSS date values can be seconds since 1582-10-14. Detect large numeric values.
    if len(nonmissing) and nonmissing.abs().median() > 1e7:
        try:
            origin = pd.Timestamp("1582-10-14")
            return origin + pd.to_timedelta(numeric, unit="s")
        except Exception:
            pass
    return pd.to_datetime(series, errors="coerce")


def label_stats(df: pd.DataFrame, cols: Sequence[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for col in cols:
        if col not in df.columns:
            continue
        s = df[col].dropna().astype(str)
        counts = s.value_counts()
        out[col] = {
            "labeled_n": int(len(s)),
            "classes": int(counts.size),
            "classes_lt_3": int((counts < 3).sum()),
            "classes_lt_10": int((counts < 10).sum()),
            "largest_class_share": float(counts.iloc[0] / counts.sum()) if len(counts) else None,
        }
    return out


def _normalized_keys(df: pd.DataFrame, cols: Sequence[str]) -> np.ndarray:
    available = [c for c in cols if c in df.columns]
    if not available:
        return np.asarray([f"ROW_{i}" for i in range(len(df))], dtype=object)
    keys: list[str] = []
    for pos, (_, row) in enumerate(df[available].iterrows()):
        parts = [norm(row[c]) for c in available]
        key = "||".join(parts).strip("|")
        keys.append(key or f"ROW_{pos}")
    return np.asarray(keys, dtype=object)


def _group_three_way(
    groups: np.ndarray,
    calibration_fraction: float,
    gold_fraction: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(groups)
    fit_mask = np.ones(n, dtype=bool)
    cal_mask = np.zeros(n, dtype=bool)
    gold_mask = np.zeros(n, dtype=bool)

    # First seal GOLD.
    splitter_gold = GroupShuffleSplit(n_splits=1, test_size=gold_fraction, random_state=seed)
    rest_idx, gold_idx = next(splitter_gold.split(np.zeros(n), groups=groups))
    gold_mask[gold_idx] = True
    fit_mask[gold_idx] = False

    # Then split CALIBRATION from the remaining groups. Convert requested total
    # fraction to a proportion of the remaining rows.
    remaining_groups = groups[rest_idx]
    cal_relative = calibration_fraction / max(1e-9, 1.0 - gold_fraction)
    cal_relative = min(0.45, max(0.03, cal_relative))
    splitter_cal = GroupShuffleSplit(n_splits=1, test_size=cal_relative, random_state=seed + 1)
    fit_rel, cal_rel = next(splitter_cal.split(np.zeros(len(rest_idx)), groups=remaining_groups))
    cal_idx = rest_idx[cal_rel]
    fit_idx = rest_idx[fit_rel]
    fit_mask[:] = False
    fit_mask[fit_idx] = True
    cal_mask[cal_idx] = True
    return fit_mask, cal_mask, gold_mask


def _temporal_three_way(
    dates: pd.Series,
    calibration_fraction: float,
    gold_fraction: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(dates)
    filled = dates.fillna(pd.Timestamp.min)
    order = np.argsort(filled.to_numpy(), kind="stable")
    n_gold = max(1, int(round(n * gold_fraction)))
    n_cal = max(1, int(round(n * calibration_fraction)))
    # Guard against pathological tiny datasets.
    if n_gold + n_cal > int(n * 0.45):
        scale = (n * 0.45) / (n_gold + n_cal)
        n_gold = max(1, int(n_gold * scale))
        n_cal = max(1, int(n_cal * scale))
    gold_idx = order[-n_gold:]
    cal_start = max(0, n - n_gold - n_cal)
    cal_idx = order[cal_start : n - n_gold]
    fit_idx = order[:cal_start]
    fit_mask = np.zeros(n, dtype=bool)
    cal_mask = np.zeros(n, dtype=bool)
    gold_mask = np.zeros(n, dtype=bool)
    fit_mask[fit_idx] = True
    cal_mask[cal_idx] = True
    gold_mask[gold_idx] = True
    return fit_mask, cal_mask, gold_mask


def _overlap(reference: pd.DataFrame, other: pd.DataFrame, cols: Sequence[str]) -> Optional[float]:
    available = [c for c in cols if c in reference.columns and c in other.columns]
    if not available:
        return None
    ref = set(_normalized_keys(reference, available).tolist())
    oth = _normalized_keys(other, available).tolist()
    valid = [k for k in oth if not k.startswith("ROW_")]
    return float(np.mean([k in ref for k in valid])) if valid else None


def main() -> int:
    parser = argparse.ArgumentParser(description="Create FIT, CALIBRATION, and sealed GOLD SPSS partitions")
    parser.add_argument("--input_sav", required=True)
    parser.add_argument("--fit_out", required=True)
    parser.add_argument("--calibration_out", required=True)
    parser.add_argument("--gold_out", required=True)
    parser.add_argument("--report_json", required=True)
    parser.add_argument("--calibration_fraction", type=float, default=0.10)
    parser.add_argument("--gold_fraction", type=float, default=0.15)
    parser.add_argument("--date_col", default="")
    parser.add_argument("--employer_col", default="qa20")
    parser.add_argument("--title_col", default="qe4")
    parser.add_argument("--secondary_title_col", default="qe5a")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    df, meta = pyreadstat.read_sav(args.input_sav, user_missing=True, apply_value_formats=False)
    n = len(df)
    if n < 200:
        raise ValueError("At least 200 rows are required for a useful three-way split")
    cal_frac = min(0.25, max(0.05, float(args.calibration_fraction)))
    gold_frac = min(0.30, max(0.05, float(args.gold_fraction)))
    if cal_frac + gold_frac > 0.45:
        raise ValueError("calibration_fraction + gold_fraction must be <= 0.45")

    method = ""
    warning = ""
    date_summary: Dict[str, Any] = {}
    if args.date_col and str(args.date_col).lower() not in {"auto", "none"} and args.date_col in df.columns:
        dates = parse_date(df[args.date_col])
        valid = dates.notna()
        if valid.sum() >= max(100, int(n * 0.60)):
            fit_mask, cal_mask, gold_mask = _temporal_three_way(dates, cal_frac, gold_frac)
            method = "temporal_oldest_fit_middle_calibration_newest_gold"
            date_summary = {
                "column": args.date_col,
                "valid_n": int(valid.sum()),
                "fit_max": str(dates[fit_mask].max()),
                "calibration_min": str(dates[cal_mask].min()),
                "calibration_max": str(dates[cal_mask].max()),
                "gold_min": str(dates[gold_mask].min()),
            }
        else:
            warning = f"Date column {args.date_col!r} had insufficient parseable values; group splitting was used."

    if not method:
        key_cols = [args.employer_col, args.title_col, args.secondary_title_col]
        groups = _normalized_keys(df, key_cols)
        if len(set(groups.tolist())) >= 10:
            fit_mask, cal_mask, gold_mask = _group_three_way(groups, cal_frac, gold_frac, args.seed)
            method = "group_holdout_employer_current_unused_title"
        else:
            rng = np.random.default_rng(args.seed)
            order = rng.permutation(n)
            n_gold = max(1, int(round(n * gold_frac)))
            n_cal = max(1, int(round(n * cal_frac)))
            gold_idx = order[:n_gold]
            cal_idx = order[n_gold : n_gold + n_cal]
            fit_idx = order[n_gold + n_cal :]
            fit_mask = np.zeros(n, dtype=bool); fit_mask[fit_idx] = True
            cal_mask = np.zeros(n, dtype=bool); cal_mask[cal_idx] = True
            gold_mask = np.zeros(n, dtype=bool); gold_mask[gold_idx] = True
            method = "random_three_way_last_resort"
            warning = "Employer/title groups were unavailable or too sparse; random split is more vulnerable to leakage."

    if np.any(fit_mask & cal_mask) or np.any(fit_mask & gold_mask) or np.any(cal_mask & gold_mask):
        raise RuntimeError("Internal split error: partitions overlap")
    if int(fit_mask.sum() + cal_mask.sum() + gold_mask.sum()) != n:
        raise RuntimeError("Internal split error: partitions do not cover every row")

    fit_df = df.loc[fit_mask].copy().reset_index(drop=True)
    cal_df = df.loc[cal_mask].copy().reset_index(drop=True)
    gold_df = df.loc[gold_mask].copy().reset_index(drop=True)
    write_sav(fit_df, meta, args.fit_out)
    write_sav(cal_df, meta, args.calibration_out)
    write_sav(gold_df, meta, args.gold_out)

    overlap_cols = [args.employer_col, args.title_col, args.secondary_title_col]
    report = {
        "method": method,
        "warning": warning,
        "date_summary": date_summary,
        "input_rows": n,
        "fit_rows": len(fit_df),
        "calibration_rows": len(cal_df),
        "gold_rows": len(gold_df),
        "fractions_actual": {
            "fit": len(fit_df) / n,
            "calibration": len(cal_df) / n,
            "gold": len(gold_df) / n,
        },
        "normalized_context_overlap": {
            "fit_to_calibration": _overlap(fit_df, cal_df, overlap_cols),
            "fit_to_gold": _overlap(fit_df, gold_df, overlap_cols),
            "calibration_to_gold": _overlap(cal_df, gold_df, overlap_cols),
        },
        "fit_label_stats": label_stats(fit_df, ["qa20a", "qe4ar", "qe5ar"]),
        "calibration_label_stats": label_stats(cal_df, ["qa20a", "qe4ar", "qe5ar"]),
        "gold_label_stats": label_stats(gold_df, ["qa20a", "qe4ar", "qe5ar"]),
        "files": {
            "fit": args.fit_out,
            "calibration": args.calibration_out,
            "gold": args.gold_out,
        },
        "seed": args.seed,
    }
    Path(args.report_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report_json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print("\nIMPORTANT: Never train on the CALIBRATION or GOLD SAV files.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
