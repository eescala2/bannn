param(
 [string]$Base="C:\laborshed_autocode_clean",
 [string]$ModelSav="",
 [string]$DateCol="",
 [double]$CalibrationFraction=0.12
)
$ErrorActionPreference="Stop"; Set-Location $Base
if (-not $ModelSav) { $ModelSav=Join-Path $Base "training_MODEL.sav" }
$Python=Join-Path $Base ".venv\Scripts\python.exe"; $Script=Join-Path $Base "create_fit_calibration_split.py"
foreach($p in @($Python,$Script,$ModelSav,(Join-Path $Base "training_EVALUATION_GOLD.sav"))) { if(-not(Test-Path $p)){throw "Required file not found: $p"} }
$args=@("-u",$Script,"--model_sav",$ModelSav,"--fit_out",(Join-Path $Base "training_FIT.sav"),"--calibration_out",(Join-Path $Base "training_CALIBRATION.sav"),"--report_json",(Join-Path $Base "fit_calibration_split_report.json"),"--calibration_fraction",[string]$CalibrationFraction)
if($DateCol -and $DateCol.ToLowerInvariant() -ne "auto"){$args+=@("--date_col",$DateCol)}
Write-Host "Splitting existing training_MODEL into FIT + CALIBRATION; existing GOLD remains sealed." -ForegroundColor Cyan
& $Python @args
if($LASTEXITCODE -ne 0){throw "FIT/CALIBRATION split failed with code $LASTEXITCODE"}
Write-Host "Existing training_EVALUATION_GOLD.sav was not modified." -ForegroundColor Green
