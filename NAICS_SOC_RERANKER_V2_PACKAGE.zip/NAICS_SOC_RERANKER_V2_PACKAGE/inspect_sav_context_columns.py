#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inspect an SPSS SAV for likely employer, title, date, wage/hours, and location fields."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Any

import pandas as pd
import pyreadstat

KEYWORDS = {
    "date_or_year": ["date", "year", "wave", "quarter", "month", "interview", "complete", "response"],
    "wage_or_pay": ["wage", "pay", "salary", "earn", "income", "hourly", "rate", "compensation"],
    "hours": ["hour", "hrs", "weekly"],
    "location": ["city", "county", "state", "zip", "location", "place", "workcity", "work city"],
    "employer_or_business": ["employer", "company", "business", "organization", "firm", "workplace", "self employ"],
    "job_or_occupation": ["job", "title", "occupation", "position", "duties", "work performed"],
    "verification": ["verified", "reviewed", "approved", "validated", "human", "coder", "quality"],
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--sav", required=True)
    p.add_argument("--out_txt", default="")
    p.add_argument("--out_json", default="")
    p.add_argument("--sample_rows", type=int, default=2000)
    return p.parse_args()


def main() -> int:
    opt = parse_args()
    df, meta = pyreadstat.read_sav(opt.sav, user_missing=True, apply_value_formats=False, row_limit=max(1, opt.sample_rows))
    labels = getattr(meta, "column_names_to_labels", {}) or {}
    findings: dict[str, list[dict[str, Any]]] = {k: [] for k in KEYWORDS}
    for col in df.columns:
        label = str(labels.get(col, "") or "")
        hay = f"{col} {label}".lower()
        sample = df[col]
        nonmissing = int(sample.notna().sum())
        unique = int(sample.nunique(dropna=True))
        dtype = str(sample.dtype)
        examples = [str(v)[:100] for v in sample.dropna().head(5).tolist()]
        for category, words in KEYWORDS.items():
            score = sum(1 for w in words if w in hay)
            if score:
                findings[category].append({
                    "column": str(col), "label": label, "score": score, "dtype": dtype,
                    "sample_nonmissing": nonmissing, "sample_unique": unique, "examples": examples,
                })
    for rows in findings.values():
        rows.sort(key=lambda r: (r["score"], r["sample_nonmissing"]), reverse=True)
    report = {
        "sav": str(Path(opt.sav).resolve()),
        "sample_rows_read": len(df),
        "columns": len(df.columns),
        "findings": findings,
    }
    lines = [
        "SPSS Context Column Inspection",
        "==============================",
        f"SAV: {report['sav']}",
        f"Sample rows read: {len(df):,}",
        f"Columns: {len(df.columns):,}",
        "",
    ]
    for category, rows in findings.items():
        lines.append(category.upper())
        lines.append("-" * len(category))
        if not rows:
            lines.append("  No likely columns found.")
        for r in rows[:20]:
            lines.append(
                f"  {r['column']} | label={r['label']!r} | dtype={r['dtype']} | "
                f"nonmissing={r['sample_nonmissing']} unique={r['sample_unique']} | examples={r['examples']}"
            )
        lines.append("")
    text = "\n".join(lines)
    print(text)
    if opt.out_txt:
        Path(opt.out_txt).write_text(text + "\n", encoding="utf-8")
    if opt.out_json:
        Path(opt.out_json).write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
