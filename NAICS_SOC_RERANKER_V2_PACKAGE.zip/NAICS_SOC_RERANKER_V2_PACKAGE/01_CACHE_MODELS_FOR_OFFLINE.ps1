param([string]$Base = "C:\laborshed_autocode_v2")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Virtual environment not found. Run 00_SETUP_ENVIRONMENT.ps1 first." }

$env:HF_HOME = Join-Path $Base "hf_cache"
$env:HF_HUB_CACHE = Join-Path $Base "hf_cache\hub"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:TOKENIZERS_PARALLELISM = "false"
$env:CUDA_VISIBLE_DEVICES = "0"
Remove-Item Env:\HF_HUB_OFFLINE -ErrorAction SilentlyContinue
Remove-Item Env:\TRANSFORMERS_OFFLINE -ErrorAction SilentlyContinue

Write-Host "Downloading/caching BGE and Cross-Encoder models..." -ForegroundColor Cyan
& $Python -c "from sentence_transformers import SentenceTransformer, CrossEncoder; import torch; d='cuda' if torch.cuda.is_available() else 'cpu'; print('device',d); SentenceTransformer('BAAI/bge-large-en-v1.5', device=d); CrossEncoder('cross-encoder/ms-marco-MiniLM-L6-v2', device=d); print('models cached')"

$env:HF_HUB_OFFLINE = "1"
$env:TRANSFORMERS_OFFLINE = "1"
Write-Host "Testing cache-only loading..." -ForegroundColor Cyan
& $Python -c "from sentence_transformers import SentenceTransformer, CrossEncoder; import torch; d='cuda' if torch.cuda.is_available() else 'cpu'; SentenceTransformer('BAAI/bge-large-en-v1.5', device=d); CrossEncoder('cross-encoder/ms-marco-MiniLM-L6-v2', device=d); print('offline load ok')"
Write-Host "Model cache is ready." -ForegroundColor Green
