NAICS/SOC AUTOCODER RERANKER V2
================================
Version: 2026-07-14

WHY THIS VERSION EXISTS
-----------------------
The independent Gold audit showed:

  qa20a: top-1 0.8480, top-4 0.9507, ECE 0.1087
  qe4ar: top-1 0.6678, top-4 0.8354
  qe5ar: top-1 0.6987, top-4 0.8341

Exact adaptive-memory and dictionary predictions were already about 95-98%
accurate, while model-only SOC predictions were about 45-46%. The main
remaining problem is therefore candidate ranking, calibration, and uncertainty,
not a lack of additional first-stage classifier families.

V2 TARGETS THAT EVIDENCE DIRECTLY
---------------------------------
1. Reranks the UNION of supervised-ML and semantic candidates. Older versions
   reranked semantic candidates only.
2. Keeps an internal top-24 candidate pool, while the normal output remains
   top-4.
3. Fine-tunes a local Cross-Encoder on historical NAICS/SOC positive pairs,
   same-hierarchy hard negatives, semantic hard negatives, and random negatives.
4. Fits a tiny candidate-level stacking model on a separate CALIBRATION SAV.
5. Fits source-specific top-confidence calibration on CALIBRATION only.
6. Builds APS conformal prediction sets on a held-out portion of CALIBRATION.
7. Keeps the permanent GOLD SAV completely sealed until final audit.
8. Reports top-10/top-20 recall, reranker pre/post delta, candidate-stacker
   diagnostics, conformal coverage/set size, calibration, drift, and weak groups.

FILES
-----
00_SETUP_ENVIRONMENT.ps1
00_INSTALL_V2_REQUIREMENTS.ps1
00A_CREATE_CALIBRATION_KEEP_EXISTING_GOLD.ps1
00_CREATE_THREE_WAY_SPLIT.ps1
01_CACHE_MODELS_FOR_OFFLINE.ps1
01_TRAIN_DOMAIN_CROSS_ENCODER_CUDA.ps1
02_TRAIN_RERANKER_V2_AUDITED_CUDA.ps1
03_SCORE_RERANKER_V2_CUDA.ps1
04_PREFLIGHT_V2.ps1

naics_soc_adaptive_memory_reranker_v2.py
autocoder_improvement_audit_v2.py
train_domain_cross_encoder.py
create_fit_calibration_split.py
create_autocoder_three_way_split.py
v2_preflight.py
requirements_reranker_v2_core.txt
requirements_reranker_v2_optional.txt

RECOMMENDED UPGRADE PATH FOR THE EXISTING AUDITED FOLDER
--------------------------------------------------------
You already have:

  training_MODEL.sav
  training_EVALUATION_GOLD.sav

Keep the same Gold file so V2 is directly comparable with the baseline report.
Extract this package into the existing folder, for example:

  C:\laborshed_autocode_clean

Then use -Base C:\laborshed_autocode_clean on the runners.

1. Install the additional V2 packages:

  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  cd C:\laborshed_autocode_clean
  .\00_INSTALL_V2_REQUIREMENTS.ps1 -Base C:\laborshed_autocode_clean

2. Split the old training_MODEL into FIT and CALIBRATION. The existing Gold is
   not read or modified:

  .\00A_CREATE_CALIBRATION_KEEP_EXISTING_GOLD.ps1 `
    -Base C:\laborshed_autocode_clean `
    -CalibrationFraction 0.12

If a reliable date/year field exists:

  .\00A_CREATE_CALIBRATION_KEEP_EXISTING_GOLD.ps1 `
    -Base C:\laborshed_autocode_clean `
    -DateCol "survey_year" `
    -CalibrationFraction 0.12

Creates:

  training_FIT.sav
  training_CALIBRATION.sav

The original training_EVALUATION_GOLD.sav remains sealed.

3. Fine-tune the task-specific Cross-Encoder:

  .\01_TRAIN_DOMAIN_CROSS_ENCODER_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean

The RTX 2050-safe defaults use batch 4, gradient accumulation 8, fp16, one
training epoch, and visible step/ETA messages. Output:

  models\domain_cross_encoder\final
  models\domain_cross_encoder\domain_reranker_training_report.json
  console_DOMAIN_RERANKER_TRAIN_live.log

4. Run V2 preflight:

  .\04_PREFLIGHT_V2.ps1 -Base C:\laborshed_autocode_clean

5. Train and audit V2 on the SAME Gold file:

  .\02_TRAIN_RERANKER_V2_AUDITED_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean `
    -RunLabel "reranker_v2"

Optional context fields:

  .\02_TRAIN_RERANKER_V2_AUDITED_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean `
    -DateCol "survey_year" `
    -LocationCols "qe2b,county,state" `
    -NumericCols "qe10,hourly_wage" `
    -RunLabel "reranker_v2"

6. Upload the newly created CHAT_UPLOAD_MODEL_IMPROVEMENT.zip from model_audits.
The V2 audit includes direct pre/post reranker measurements, top-10/top-20
candidate recall, and empirical conformal coverage.

FRESH START PATH
----------------
When no prior Gold exists, place training.sav in C:\laborshed_autocode_v2 and:

  .\00_SETUP_ENVIRONMENT.ps1
  .\01_CACHE_MODELS_FOR_OFFLINE.ps1
  .\00_CREATE_THREE_WAY_SPLIT.ps1
  .\01_TRAIN_DOMAIN_CROSS_ENCODER_CUDA.ps1
  .\04_PREFLIGHT_V2.ps1
  .\02_TRAIN_RERANKER_V2_AUDITED_CUDA.ps1

The three-way split creates:

  training_FIT.sav
  training_CALIBRATION.sav
  training_EVALUATION_GOLD.sav

Never train on CALIBRATION or GOLD.

PRODUCTION SCORING
------------------

  .\03_SCORE_RERANKER_V2_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean `
    -ScoreSav "C:\path\to\new_file.sav" `
    -OutSav "C:\path\to\new_file_scored.sav"

The score runner overwrites/fills qa20a, qe4ar, and qe5ar, scores sparse/no-text
rows, preserves the input SAV, and produces a row-level log plus audit files.

LIVE PROGRESS
-------------
All long runs show progress in the Positron terminal and write a durable log.
The domain trainer prints step, elapsed time, ETA, loss, learning rate, and epoch.
The main autocoder prints embedding progress, model candidate/fold progress,
calibration steps, scoring stages, and audit paths.

Watch CUDA:

  nvidia-smi -l 10

WHY NO LIGHTGBM/LOGREG OPTUNA
-----------------------------
The measured laptop runs showed that LinearSVC was stronger and far faster.
V2 spends compute on the evidence-backed bottleneck: candidate reranking and
calibration. Complexity must earn its promotion on the permanent Gold file.

EXPECTED RUNTIME ON THE LATITUDE 5550 / RTX 2050
-------------------------------------------------
Approximate only:

  Domain Cross-Encoder fine-tuning: 4-12 hours
  V2 full model + calibration + Gold audit: 16-32 hours
  Score-only after model save: 1-5 hours, depending on row count

Caches, text length, and thermal/power limits can move these ranges substantially.

PROMOTION RULE
--------------
Promote V2 only if the SAME Gold file shows a worthwhile gain in top-1 accuracy,
macro-F1, weak-group performance, calibration, and review coverage without an
unacceptable runtime increase. A shinier model does not get diplomatic immunity.
