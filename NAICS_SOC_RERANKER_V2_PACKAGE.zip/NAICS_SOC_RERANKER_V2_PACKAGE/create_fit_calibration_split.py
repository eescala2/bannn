#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Split an existing training_MODEL SAV into FIT and CALIBRATION.

This preserves an already sealed training_EVALUATION_GOLD.sav, allowing direct
comparison with prior audited runs on exactly the same Gold records.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from typing import Any, Dict, Optional, Sequence
import numpy as np
import pandas as pd
import pyreadstat
from sklearn.model_selection import GroupShuffleSplit


def norm(v: Any) -> str:
    if v is None: return ""
    try:
        if pd.isna(v): return ""
    except Exception: pass
    s=str(v).lower().replace("&"," and ")
    s=re.sub(r"\b(?:incorporated|inc|llc|corp(?:oration)?|company|co|limited|ltd)\b"," ",s)
    s=re.sub(r"[^a-z0-9]+"," ",s)
    return re.sub(r"\s+"," ",s).strip()

def filter_meta(d: Optional[Dict[str,Any]], cols: Sequence[str]):
    if not d: return None
    out={k:v for k,v in d.items() if k in cols}; return out or None

def write_sav(df,meta,path):
    cols=list(df.columns); Path(path).parent.mkdir(parents=True,exist_ok=True)
    pyreadstat.write_sav(df,path,file_label=getattr(meta,"file_label","") or "",
        column_labels=filter_meta(getattr(meta,"column_names_to_labels",None),cols),
        variable_value_labels=filter_meta(getattr(meta,"variable_value_labels",None),cols),
        missing_ranges=filter_meta(getattr(meta,"missing_ranges",None),cols),
        variable_display_width=filter_meta(getattr(meta,"variable_display_width",None),cols),
        variable_measure=filter_meta(getattr(meta,"variable_measure",None),cols),
        variable_format=filter_meta(getattr(meta,"original_variable_types",None),cols),
        note=getattr(meta,"notes",None),compress=False)

def parse_date(s):
    numeric=pd.to_numeric(s,errors="coerce")
    if len(numeric.dropna()) and numeric.dropna().between(1900,2200).mean()>.7:
        return pd.to_datetime(numeric.round().astype("Int64").astype(str)+"-07-01",errors="coerce")
    return pd.to_datetime(s,errors="coerce")

def stats(df):
    out={}
    for col in ["qa20a","qe4ar","qe5ar"]:
        if col in df:
            c=df[col].dropna().astype(str).value_counts()
            out[col]={"labeled_n":int(c.sum()),"classes":int(len(c)),"classes_lt_3":int((c<3).sum())}
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--model_sav",required=True); p.add_argument("--fit_out",required=True); p.add_argument("--calibration_out",required=True); p.add_argument("--report_json",required=True)
    p.add_argument("--calibration_fraction",type=float,default=.12); p.add_argument("--date_col",default="")
    p.add_argument("--employer_col",default="qa20"); p.add_argument("--title_col",default="qe4"); p.add_argument("--secondary_title_col",default="qe5a"); p.add_argument("--seed",type=int,default=42)
    a=p.parse_args(); df,meta=pyreadstat.read_sav(a.model_sav,user_missing=True,apply_value_formats=False); n=len(df); frac=min(.30,max(.05,a.calibration_fraction))
    method=""; warning=""; cal=np.zeros(n,dtype=bool)
    if a.date_col and a.date_col.lower() not in {"auto","none"} and a.date_col in df:
        d=parse_date(df[a.date_col]); valid=d.notna()
        if valid.sum()>=max(100,int(.6*n)):
            order=np.argsort(d.fillna(pd.Timestamp.min).to_numpy(),kind="stable"); k=max(1,int(round(n*frac))); cal[order[-k:]]=True; method="temporal_newest_calibration"
        else: warning=f"Date column {a.date_col} insufficient; group split used."
    if not method:
        cols=[c for c in [a.employer_col,a.title_col,a.secondary_title_col] if c in df]
        keys=[]
        for pos,(_,row) in enumerate(df[cols].iterrows()):
            key="||".join(norm(row[c]) for c in cols).strip("|"); keys.append(key or f"ROW_{pos}")
        groups=np.asarray(keys)
        tr,cv=next(GroupShuffleSplit(n_splits=1,test_size=frac,random_state=a.seed).split(np.zeros(n),groups=groups)); cal[cv]=True; method="group_holdout_calibration"
    fit_df=df.loc[~cal].copy().reset_index(drop=True); cal_df=df.loc[cal].copy().reset_index(drop=True)
    write_sav(fit_df,meta,a.fit_out); write_sav(cal_df,meta,a.calibration_out)
    report={"method":method,"warning":warning,"input_rows":n,"fit_rows":len(fit_df),"calibration_rows":len(cal_df),"calibration_fraction_actual":len(cal_df)/n,"fit_stats":stats(fit_df),"calibration_stats":stats(cal_df),"gold_preservation_note":"The pre-existing Gold SAV was not read or changed."}
    Path(a.report_json).write_text(json.dumps(report,indent=2),encoding="utf-8"); print(json.dumps(report,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
