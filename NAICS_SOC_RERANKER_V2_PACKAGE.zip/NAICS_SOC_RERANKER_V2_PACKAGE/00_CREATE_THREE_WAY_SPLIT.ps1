param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$InputSav = "",
    [string]$DateCol = "",
    [double]$CalibrationFraction = 0.10,
    [double]$GoldFraction = 0.15,
    [int]$Seed = 42
)
$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($InputSav)) { $InputSav = Join-Path $Base "training.sav" }
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "create_autocoder_three_way_split.py"
foreach ($p in @($Python,$Script,$InputSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$args = @(
    "-u", $Script,
    "--input_sav", $InputSav,
    "--fit_out", (Join-Path $Base "training_FIT.sav"),
    "--calibration_out", (Join-Path $Base "training_CALIBRATION.sav"),
    "--gold_out", (Join-Path $Base "training_EVALUATION_GOLD.sav"),
    "--report_json", (Join-Path $Base "three_way_split_report.json"),
    "--calibration_fraction", [string]$CalibrationFraction,
    "--gold_fraction", [string]$GoldFraction,
    "--seed", [string]$Seed
)
if (-not [string]::IsNullOrWhiteSpace($DateCol) -and $DateCol.ToLowerInvariant() -ne "auto") {
    $args += @("--date_col", $DateCol)
}
Write-Host "Creating sealed FIT / CALIBRATION / GOLD partitions..." -ForegroundColor Cyan
& $Python @args
if ($LASTEXITCODE -ne 0) { throw "Three-way split failed with code $LASTEXITCODE" }
Write-Host "Created:" -ForegroundColor Green
Write-Host "  $(Join-Path $Base 'training_FIT.sav')"
Write-Host "  $(Join-Path $Base 'training_CALIBRATION.sav')"
Write-Host "  $(Join-Path $Base 'training_EVALUATION_GOLD.sav')"
Write-Host "Never train on CALIBRATION or GOLD." -ForegroundColor Yellow
