#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fine-tune a local Cross-Encoder reranker for NAICS and SOC coding.

The audited baseline showed a large top-1 to top-4 gap, while exact historical
memory was already highly accurate. This script targets the remaining ranking
problem: it teaches a compact Cross-Encoder to choose the correct code from
plausible candidates using historical survey context.

Data discipline:
* FIT SAV supplies prototypes and training pairs.
* CALIBRATION SAV supplies development/evaluation pairs.
* GOLD SAV is never read by this script.

Training uses a blend of semantic hard negatives, same-hierarchy negatives,
and random negatives. That combination is deliberate: hard negatives teach
fine distinctions, while random negatives preserve easy-case discrimination.
"""
from __future__ import annotations

import argparse
import gc
import json
import math
import os
import random
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import pyreadstat
import torch

try:
    import faiss
except Exception:
    faiss = None

from datasets import Dataset
from sentence_transformers import CrossEncoder, SentenceTransformer
from sentence_transformers.cross_encoder import CrossEncoderTrainer, CrossEncoderTrainingArguments
from sentence_transformers.cross_encoder.losses import BinaryCrossEntropyLoss
from transformers import TrainerCallback

VERSION = "2026.07.14.domain-cross-encoder-naics-soc-v1"


class VisibleProgressCallback(TrainerCallback):
    """Print step/epoch/loss/ETA so long GPU training never looks frozen."""
    def __init__(self) -> None:
        self.started = 0.0

    def on_train_begin(self, args, state, control, **kwargs):
        self.started = time.time()
        print(f"[RERANKER TRAIN] START max_steps={state.max_steps} epochs={args.num_train_epochs}", flush=True)

    def on_log(self, args, state, control, logs=None, **kwargs):
        logs = logs or {}
        elapsed = max(1e-9, time.time() - self.started)
        step = max(0, int(state.global_step))
        total = max(1, int(state.max_steps))
        rate = step / elapsed if step else 0.0
        eta = (total - step) / rate if rate > 0 else float("nan")
        useful = {k: v for k, v in logs.items() if k in {"loss", "learning_rate", "epoch", "grad_norm", "eval_loss"}}
        print(f"[RERANKER TRAIN] step={step}/{total} elapsed={elapsed/60:.1f}m eta={eta/60:.1f}m metrics={useful}", flush=True)

    def on_train_end(self, args, state, control, **kwargs):
        print(f"[RERANKER TRAIN] DONE steps={state.global_step} elapsed={(time.time()-self.started)/60:.1f}m", flush=True)

ABBREV = [
    (r"\basst\b", "assistant"), (r"\bmgr\b", "manager"),
    (r"\bsvcs\b", "services"), (r"\bsvc\b", "service"),
    (r"\btech\b", "technician"), (r"\badmin\b", "administrative"),
    (r"\bsupv\b", "supervisor"), (r"\bmaint\b", "maintenance"),
    (r"\brn\b", "registered nurse"), (r"\blpn\b", "licensed practical nurse"),
    (r"\bcna\b", "certified nursing assistant"),
]


def eprint(message: str) -> None:
    print(message, flush=True)


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = str(value).lower().strip().replace("&", " and ")
    s = re.sub(r"[^a-z0-9+#/\-\s]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    for pattern, repl in ABBREV:
        s = re.sub(pattern, repl, s)
    return re.sub(r"\s+", " ", s).strip()


def clean_code(value: Any, kind: str) -> Optional[str]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    try:
        number = int(round(float(value)))
        if kind == "soc":
            return f"{number:06d}" if 100000 <= number <= 999999 else None
        return str(number) if number > 0 else None
    except Exception:
        s = str(value).strip()
        return s or None


def make_docs(df: pd.DataFrame, columns: Sequence[Tuple[str, str]], target_tag: str) -> List[str]:
    docs: List[str] = []
    available = [(col, prefix) for col, prefix in columns if col in df.columns]
    for _, row in df.iterrows():
        parts = [f"TASK:{target_tag}"]
        for col, prefix in available:
            text = normalize_text(row.get(col))
            if text:
                parts.append(f"{prefix}:{text}")
        docs.append(" | ".join(parts) if len(parts) > 1 else f"TASK:{target_tag} | __EMPTY__")
    return docs


def field_plans() -> Dict[str, List[Tuple[str, str]]]:
    common = [
        ("qa20", "EMPLOYER"), ("qe1oth", "INDUSTRY_OTHER"),
        ("qe8aoth", "SELFEMP_OTHER"), ("qe2b", "LOCATION"),
        ("qa9a", "ED_FIELD"), ("qa9c1", "CERT"), ("qa9c2", "CERT"),
        ("qa9c3", "CERT"), ("qa9c4", "CERT"), ("qa9g", "LICENSE"),
        ("qe13oth", "PAYTYPE_OTHER"),
    ]
    return {
        "qa20a": [("qa20", "EMPLOYER"), ("qe4", "CURRENT_TITLE"), ("qe5a", "UNUSED_TITLE"),
                  ("qe1oth", "INDUSTRY_OTHER"), ("qe8aoth", "SELFEMP_OTHER"),
                  ("qe2b", "LOCATION"), ("qe1", "INDUSTRY_CATEGORY"),
                  ("qe8a", "SELFEMP_CATEGORY")],
        "qe4ar": [("qe4", "CURRENT_TITLE"), ("qa20a", "NAICS")] + common,
        "qe5ar": [("qe5a", "UNUSED_TITLE"), ("qa20a", "NAICS")] + common,
    }


def hierarchy_prefix(code: str, kind: str) -> str:
    if kind == "soc":
        return code[:2]
    return code[:3] if len(code) >= 3 else code[:2]


def build_prototypes(
    docs: Sequence[str],
    labels: Sequence[Optional[str]],
    target: str,
    examples_per_code: int,
) -> Tuple[Dict[str, str], Counter]:
    groups: Dict[str, List[str]] = defaultdict(list)
    for doc, label in zip(docs, labels):
        if label is not None and "__EMPTY__" not in doc:
            groups[label].append(doc)
    prototypes: Dict[str, str] = {}
    counts = Counter({code: len(rows) for code, rows in groups.items()})
    for code, rows in groups.items():
        # Prefer diverse lengths and avoid duplicate normalized documents.
        unique = list(dict.fromkeys(rows))
        unique.sort(key=len)
        if len(unique) <= examples_per_code:
            chosen = unique
        else:
            positions = np.linspace(0, len(unique) - 1, examples_per_code).round().astype(int)
            chosen = [unique[int(pos)] for pos in positions]
        prototypes[code] = (
            f"TARGET:{target} | CODE:{code} | SUPPORT:{len(rows)} | "
            f"REPRESENTATIVE HISTORICAL CONTEXT: " + " || ".join(chosen)
        )
    return prototypes, counts


def stratified_anchor_indices(
    labels: Sequence[Optional[str]],
    max_anchors: int,
    seed: int,
    weak_groups: Sequence[str],
    kind: str,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    groups: Dict[str, List[int]] = defaultdict(list)
    for i, label in enumerate(labels):
        if label is not None:
            groups[label].append(i)
    if not groups:
        return np.asarray([], dtype=int)
    per_class = max(2, int(math.ceil(max_anchors / max(1, len(groups)))))
    selected: List[int] = []
    weak = set(str(x) for x in weak_groups)
    for code, idxs in groups.items():
        cap = per_class * (2 if hierarchy_prefix(code, kind) in weak else 1)
        take = min(len(idxs), cap)
        selected.extend(rng.choice(idxs, size=take, replace=False).tolist())
    if len(selected) > max_anchors:
        selected = rng.choice(np.asarray(selected), size=max_anchors, replace=False).tolist()
    elif len(selected) < max_anchors:
        remaining = list(set(i for rows in groups.values() for i in rows) - set(selected))
        if remaining:
            extra = rng.choice(remaining, size=min(max_anchors - len(selected), len(remaining)), replace=False)
            selected.extend(extra.tolist())
    rng.shuffle(selected)
    return np.asarray(selected, dtype=int)


def encode(model: SentenceTransformer, texts: Sequence[str], batch_size: int) -> np.ndarray:
    return model.encode(
        list(texts), batch_size=batch_size, show_progress_bar=True,
        normalize_embeddings=True, convert_to_numpy=True,
    ).astype(np.float32, copy=False)


def nearest_code_map(
    prototype_codes: Sequence[str],
    prototype_embeddings: np.ndarray,
    query_embeddings: np.ndarray,
    k: int,
) -> List[List[str]]:
    if len(prototype_codes) == 0:
        return [[] for _ in range(len(query_embeddings))]
    k = min(k, len(prototype_codes))
    if faiss is not None:
        index = faiss.IndexFlatIP(int(prototype_embeddings.shape[1]))
        index.add(np.ascontiguousarray(prototype_embeddings))
        _, inds = index.search(np.ascontiguousarray(query_embeddings), k)
    else:
        similarity = query_embeddings @ prototype_embeddings.T
        inds = np.argsort(-similarity, axis=1)[:, :k]
    return [[prototype_codes[int(j)] for j in row] for row in inds]


def generate_pairs(
    docs: Sequence[str],
    labels: Sequence[Optional[str]],
    anchor_idx: Sequence[int],
    prototypes: Mapping[str, str],
    nearest: Sequence[Sequence[str]],
    kind: str,
    hard_negatives: int,
    random_negatives: int,
    seed: int,
) -> Dict[str, List[Any]]:
    rng = random.Random(seed)
    all_codes = list(prototypes)
    by_prefix: Dict[str, List[str]] = defaultdict(list)
    for code in all_codes:
        by_prefix[hierarchy_prefix(code, kind)].append(code)
    out: Dict[str, List[Any]] = {"query": [], "candidate": [], "label": []}
    for local_pos, i in enumerate(anchor_idx):
        true = labels[int(i)]
        if true is None or true not in prototypes:
            continue
        query = docs[int(i)]
        out["query"].append(query); out["candidate"].append(prototypes[true]); out["label"].append(1.0)
        chosen: List[str] = []
        # Same-hierarchy codes are especially important for 6-digit SOC errors.
        same = [c for c in by_prefix.get(hierarchy_prefix(true, kind), []) if c != true]
        rng.shuffle(same)
        if same:
            chosen.extend(same[: max(1, hard_negatives // 2)])
        for code in nearest[local_pos] if local_pos < len(nearest) else []:
            if code != true and code not in chosen:
                chosen.append(code)
            if len(chosen) >= hard_negatives:
                break
        if len(chosen) < hard_negatives:
            candidates = [c for c in all_codes if c != true and c not in chosen]
            rng.shuffle(candidates)
            chosen.extend(candidates[: hard_negatives - len(chosen)])
        for code in chosen[:hard_negatives]:
            out["query"].append(query); out["candidate"].append(prototypes[code]); out["label"].append(0.0)
        random_pool = [c for c in all_codes if c != true and c not in chosen and hierarchy_prefix(c, kind) != hierarchy_prefix(true, kind)]
        for code in rng.sample(random_pool, k=min(random_negatives, len(random_pool))):
            out["query"].append(query); out["candidate"].append(prototypes[code]); out["label"].append(0.0)
    return out


def merge_pair_dicts(parts: Sequence[Mapping[str, Sequence[Any]]]) -> Dict[str, List[Any]]:
    out: Dict[str, List[Any]] = {"query": [], "candidate": [], "label": []}
    for part in parts:
        for key in out:
            out[key].extend(part[key])
    return out


def evaluate_reranker(
    model: CrossEncoder,
    tasks: Sequence[Tuple[str, str, Sequence[str], Sequence[Optional[str]], Mapping[str, str], Sequence[Sequence[str]]]],
    max_rows: int,
    candidates: int,
    batch_size: int,
    seed: int,
) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    result: Dict[str, Any] = {}
    for target, kind, docs, labels, prototypes, nearest in tasks:
        valid = [i for i, label in enumerate(labels) if label is not None and label in prototypes]
        if len(valid) > max_rows:
            valid = rng.choice(valid, size=max_rows, replace=False).tolist()
        pairs: List[Tuple[str, str]] = []
        row_candidates: List[List[str]] = []
        truths: List[str] = []
        for local_i, i in enumerate(valid):
            true = labels[i]
            cand = [c for c in nearest[local_i] if c in prototypes][:candidates]
            if true not in cand:
                cand = [true] + cand[: max(0, candidates - 1)]
            row_candidates.append(cand)
            truths.append(str(true))
            pairs.extend((docs[i], prototypes[c]) for c in cand)
        if not pairs:
            continue
        scores = np.asarray(model.predict(pairs, batch_size=batch_size, show_progress_bar=True), dtype=float).reshape(-1)
        cursor = 0
        top1: List[bool] = []
        reciprocal: List[float] = []
        top4: List[bool] = []
        for true, cand in zip(truths, row_candidates):
            row = scores[cursor: cursor + len(cand)]; cursor += len(cand)
            order = np.argsort(-row)
            ranked = [cand[int(j)] for j in order]
            rank = ranked.index(true) + 1 if true in ranked else 10**6
            top1.append(rank == 1); top4.append(rank <= 4); reciprocal.append(1.0 / rank if rank < 10**6 else 0.0)
        result[target] = {
            "n": len(truths), "top1": float(np.mean(top1)), "top4": float(np.mean(top4)),
            "mrr": float(np.mean(reciprocal)), "candidates": candidates,
        }
    return result


def parse_groups(value: str) -> List[str]:
    return [x.strip() for x in str(value).split(",") if x.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Fine-tune a domain Cross-Encoder for NAICS/SOC candidate reranking")
    parser.add_argument("--fit_sav", required=True)
    parser.add_argument("--calibration_sav", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", default="cross-encoder/ms-marco-MiniLM-L6-v2")
    parser.add_argument("--embedding_model", default="BAAI/bge-large-en-v1.5")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--embedding_batch_size", type=int, default=16)
    parser.add_argument("--train_batch_size", type=int, default=4)
    parser.add_argument("--eval_batch_size", type=int, default=32)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--epochs", type=float, default=1.0)
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--max_length", type=int, default=384)
    parser.add_argument("--max_anchors_per_target", type=int, default=12000)
    parser.add_argument("--hard_negatives", type=int, default=3)
    parser.add_argument("--random_negatives", type=int, default=1)
    parser.add_argument("--prototype_examples", type=int, default=3)
    parser.add_argument("--nearest_candidates", type=int, default=30)
    parser.add_argument("--eval_rows_per_target", type=int, default=1500)
    parser.add_argument("--eval_candidates", type=int, default=20)
    parser.add_argument("--weak_qe4_groups", default="15,17,25,51,55")
    parser.add_argument("--weak_qe5_groups", default="15,17,45,51,53,55")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()

    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
    np.random.seed(args.seed); random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    eprint(f"Domain reranker trainer {VERSION}")
    eprint(f"CUDA available={torch.cuda.is_available()} device={args.device}")
    eprint("Reading FIT and CALIBRATION SAV files...")
    fit_df, _ = pyreadstat.read_sav(args.fit_sav, user_missing=True, apply_value_formats=False)
    cal_df, _ = pyreadstat.read_sav(args.calibration_sav, user_missing=True, apply_value_formats=False)
    plans = field_plans()
    target_info = [("qa20a", "naics"), ("qe4ar", "soc"), ("qe5ar", "soc")]

    embedder = SentenceTransformer(args.embedding_model, device=args.device)
    train_parts: List[Mapping[str, Sequence[Any]]] = []
    eval_tasks_before: List[Tuple[str, str, Sequence[str], Sequence[Optional[str]], Mapping[str, str], Sequence[Sequence[str]]]] = []
    artifacts: Dict[str, Any] = {"version": VERSION, "targets": {}}
    prototypes_by_target: Dict[str, Dict[str, str]] = {}

    for offset, (target, kind) in enumerate(target_info):
        if target not in fit_df.columns or target not in cal_df.columns:
            eprint(f"[{target}] skipped: target column missing")
            continue
        train_docs = make_docs(fit_df, plans[target], target)
        cal_docs = make_docs(cal_df, plans[target], target)
        train_labels = [clean_code(v, kind) for v in fit_df[target].tolist()]
        cal_labels = [clean_code(v, kind) for v in cal_df[target].tolist()]
        prototypes, counts = build_prototypes(train_docs, train_labels, target, args.prototype_examples)
        prototypes_by_target[target] = prototypes
        codes = sorted(prototypes)
        eprint(f"[{target}] prototypes={len(codes):,}; labeled_fit={sum(v is not None for v in train_labels):,}")
        if len(codes) < 2:
            continue
        proto_emb = encode(embedder, [prototypes[c] for c in codes], args.embedding_batch_size)
        weak = [] if target == "qa20a" else parse_groups(args.weak_qe4_groups if target == "qe4ar" else args.weak_qe5_groups)
        anchor_idx = stratified_anchor_indices(
            train_labels, args.max_anchors_per_target, args.seed + offset, weak, kind,
        )
        query_emb = encode(embedder, [train_docs[int(i)] for i in anchor_idx], args.embedding_batch_size)
        nearest = nearest_code_map(codes, proto_emb, query_emb, args.nearest_candidates)
        pairs = generate_pairs(
            train_docs, train_labels, anchor_idx, prototypes, nearest, kind,
            args.hard_negatives, args.random_negatives, args.seed + 100 + offset,
        )
        train_parts.append(pairs)

        valid_cal_idx = [i for i, label in enumerate(cal_labels) if label in prototypes]
        if len(valid_cal_idx) > args.eval_rows_per_target:
            rng = np.random.default_rng(args.seed + 200 + offset)
            valid_cal_idx = rng.choice(valid_cal_idx, size=args.eval_rows_per_target, replace=False).tolist()
        cal_eval_docs = [cal_docs[i] for i in valid_cal_idx]
        cal_eval_labels = [cal_labels[i] for i in valid_cal_idx]
        cal_emb = encode(embedder, cal_eval_docs, args.embedding_batch_size) if cal_eval_docs else np.zeros((0, proto_emb.shape[1]), dtype=np.float32)
        cal_nearest = nearest_code_map(codes, proto_emb, cal_emb, args.eval_candidates)
        eval_tasks_before.append((target, kind, cal_eval_docs, cal_eval_labels, prototypes, cal_nearest))
        artifacts["targets"][target] = {
            "prototype_codes": len(codes), "anchor_rows": int(len(anchor_idx)),
            "training_pairs": int(len(pairs["label"])), "class_counts": dict(counts),
        }
        del proto_emb, query_emb, cal_emb
        gc.collect()

    del embedder
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    all_pairs = merge_pair_dicts(train_parts)
    if not all_pairs["label"]:
        raise RuntimeError("No domain reranker training pairs were generated")
    rng = np.random.default_rng(args.seed)
    order = rng.permutation(len(all_pairs["label"]))
    all_pairs = {k: [v[int(i)] for i in order] for k, v in all_pairs.items()}
    train_dataset = Dataset.from_dict(all_pairs)
    eprint(f"Training pairs={len(train_dataset):,}; positives={sum(all_pairs['label']):,.0f}; negatives={len(train_dataset)-sum(all_pairs['label']):,.0f}")

    try:
        base_model = CrossEncoder(args.base_model, device=args.device, num_labels=1, max_length=args.max_length)
    except TypeError:
        base_model = CrossEncoder(args.base_model, device=args.device, num_labels=1)
        try:
            base_model.max_length = int(args.max_length)
        except Exception:
            pass
    eprint("Evaluating base Cross-Encoder on CALIBRATION candidate sets...")
    base_metrics = evaluate_reranker(base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates, args.eval_batch_size, args.seed)
    eprint(json.dumps(base_metrics, indent=2))

    neg_per_pos = max(1.0, float(args.hard_negatives + args.random_negatives))
    loss = BinaryCrossEntropyLoss(model=base_model, pos_weight=torch.tensor(neg_per_pos))
    checkpoint_dir = output / "checkpoints"
    training_args = CrossEncoderTrainingArguments(
        output_dir=str(checkpoint_dir),
        num_train_epochs=float(args.epochs),
        per_device_train_batch_size=int(args.train_batch_size),
        per_device_eval_batch_size=int(args.eval_batch_size),
        gradient_accumulation_steps=int(args.gradient_accumulation_steps),
        learning_rate=float(args.learning_rate),
        warmup_ratio=0.10,
        fp16=bool(torch.cuda.is_available()),
        bf16=False,
        dataloader_num_workers=0,
        save_strategy="steps",
        save_steps=500,
        save_total_limit=2,
        logging_steps=50,
        logging_first_step=True,
        report_to="none",
        seed=int(args.seed),
        run_name="naics-soc-domain-cross-encoder",
    )
    trainer = CrossEncoderTrainer(
        model=base_model, args=training_args, train_dataset=train_dataset, loss=loss,
        callbacks=[VisibleProgressCallback()],
    )
    eprint("Starting domain Cross-Encoder training. Progress will appear below...")
    started = time.time()
    trainer.train()
    train_seconds = time.time() - started
    final_dir = output / "final"
    base_model.save_pretrained(str(final_dir))
    eprint(f"Saved fine-tuned reranker to: {final_dir}")

    eprint("Evaluating fine-tuned Cross-Encoder on CALIBRATION candidate sets...")
    tuned_metrics = evaluate_reranker(base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates, args.eval_batch_size, args.seed)
    eprint(json.dumps(tuned_metrics, indent=2))
    artifacts.update({
        "base_model": args.base_model,
        "embedding_model": args.embedding_model,
        "output_model": str(final_dir),
        "training_pairs_total": len(train_dataset),
        "training_seconds": train_seconds,
        "base_metrics": base_metrics,
        "tuned_metrics": tuned_metrics,
        "settings": vars(args),
    })
    (output / "domain_reranker_training_report.json").write_text(json.dumps(artifacts, indent=2, default=str), encoding="utf-8")
    eprint(f"Training report: {output / 'domain_reranker_training_report.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
