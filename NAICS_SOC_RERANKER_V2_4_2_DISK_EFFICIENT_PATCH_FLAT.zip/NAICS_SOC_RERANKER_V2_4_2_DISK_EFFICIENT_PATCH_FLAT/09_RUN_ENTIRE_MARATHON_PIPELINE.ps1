param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [switch]$IncludeOptionalModels,
    [string]$ScreenSeeds = "42,43,44,45,46",
    [string]$ConfirmSeeds = "101,102,103,104,105",
    [int]$TopRecipesPerTarget = 2,
    [ValidateSet("metrics_only","final_only","full")]
    [string]$ArtifactPolicy = "metrics_only"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
Write-Host "STEP 1/5: Preflight" -ForegroundColor Cyan
& (Join-Path $Base "00_BATTERY_PREFLIGHT.ps1") -Base $Base -CheckOptionalModels:$IncludeOptionalModels
Write-Host "STEP 2/5: Marathon screening battery" -ForegroundColor Cyan
& (Join-Path $Base "01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1") -Base $Base -Profile marathon -Seeds $ScreenSeeds -IncludeOptionalModels:$IncludeOptionalModels -ArtifactPolicy $ArtifactPolicy
Write-Host "STEP 3/5: Screen summary" -ForegroundColor Cyan
& (Join-Path $Base "04_SUMMARIZE_RERANKER_BATTERY.ps1") -Base $Base -Profile marathon
Write-Host "STEP 4/5: Confirmatory winners" -ForegroundColor Cyan
& (Join-Path $Base "07_RUN_CONFIRMATORY_WINNERS.ps1") -Base $Base -Profile marathon -Seeds $ConfirmSeeds -TopRecipesPerTarget $TopRecipesPerTarget -ArtifactPolicy $ArtifactPolicy
Write-Host "STEP 5/5: Confirmatory summary" -ForegroundColor Cyan
& (Join-Path $Base "08_SUMMARIZE_CONFIRMATORY_WINNERS.ps1") -Base $Base -Profile marathon
Write-Host "Marathon pipeline complete. Upload the confirmatory CHAT_UPLOAD_RERANKER_BATTERY.zip." -ForegroundColor Green
