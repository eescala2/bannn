param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [Parameter(Mandatory=$true)]
    [string]$Stage,
    [string]$Seeds = "42,43,44,45,46",
    [switch]$IncludeOptionalModels,
    [ValidateSet("metrics_only","final_only","full")]
    [string]$ArtifactPolicy = "metrics_only"
)
& (Join-Path $Base "01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1") `
  -Base $Base -Profile $Profile -Seeds $Seeds -OnlyStage $Stage -IncludeOptionalModels:$IncludeOptionalModels -ArtifactPolicy $ArtifactPolicy
