param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("smoke","standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [string]$Seeds = "42,43,44,45,46",
    [switch]$IncludeOptionalModels,
    [int]$MaxExperiments = 0,
    [string]$OnlyStage = "",
    [ValidateSet("metrics_only","final_only","full")]
    [string]$ArtifactPolicy = "metrics_only"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "run_reranker_experiment_battery.py"
foreach ($p in @($Python,$Script,(Join-Path $Base "training_FIT.sav"),(Join-Path $Base "training_CALIBRATION.sav"))) {
    if (-not (Test-Path $p)) { throw "Required file not found: $p" }
}
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
$args = @("-u",$Script,"--base",$Base,"--profile",$Profile,"--seeds",$Seeds,"--resume","--artifact_policy",$ArtifactPolicy)
if ($IncludeOptionalModels) { $args += "--include_optional_models" }
if ($MaxExperiments -gt 0) { $args += @("--max_experiments",[string]$MaxExperiments) }
if (-not [string]::IsNullOrWhiteSpace($OnlyStage)) { $args += @("--only_stage",$OnlyStage) }
Write-Host "Starting reranker battery profile=$Profile artifact_policy=$ArtifactPolicy. Completed experiments will be skipped automatically." -ForegroundColor Cyan
Write-Host "Press Ctrl+C once to interrupt. Rerun the same command to resume." -ForegroundColor Yellow
$old = $ErrorActionPreference; $ErrorActionPreference = "Continue"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) {
    $oldNative = $PSNativeCommandUseErrorActionPreference
    $PSNativeCommandUseErrorActionPreference = $false
}
try {
    & $Python @args
    $code = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $old
    if ($null -ne (Get-Variable oldNative -ErrorAction SilentlyContinue)) {
        $PSNativeCommandUseErrorActionPreference = $oldNative
    }
}
if ($code -ne 0 -and $code -ne 130) { throw "Battery runner exited with code $code" }
if ($code -eq 130) { Write-Host "Battery interrupted safely. Run this same command to resume." -ForegroundColor Yellow }
