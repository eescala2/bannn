param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [string]$Seeds = "101,102,103,104,105",
    [int]$TopRecipesPerTarget = 2,
    [ValidateSet("metrics_only","final_only","full")]
    [string]$ArtifactPolicy = "metrics_only"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "run_confirmatory_winners.py"
& $Python -u $Script --base $Base --profile $Profile --seeds $Seeds --top_recipes_per_target $TopRecipesPerTarget --resume --artifact_policy $ArtifactPolicy
if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne 130) { throw "Confirmatory runner exited with code $LASTEXITCODE" }
