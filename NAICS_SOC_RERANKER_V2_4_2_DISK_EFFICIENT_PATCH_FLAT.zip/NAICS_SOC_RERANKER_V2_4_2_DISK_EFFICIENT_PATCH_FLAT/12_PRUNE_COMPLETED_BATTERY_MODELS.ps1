param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [switch]$Execute,
    [string]$KeepExperimentIds = ""
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "battery_storage_manager.py"
$args = @("-u",$Script,"--base",$Base,"--action","prune_completed","--keep_experiment_ids",$KeepExperimentIds)
if ($Execute) { $args += "--execute" }
Write-Host "Completed experiment weights/checkpoints will be archived as metadata, then pruned only when -Execute is supplied." -ForegroundColor Cyan
& $Python @args
if ($LASTEXITCODE -ne 0) { throw "Storage pruner exited with code $LASTEXITCODE" }
