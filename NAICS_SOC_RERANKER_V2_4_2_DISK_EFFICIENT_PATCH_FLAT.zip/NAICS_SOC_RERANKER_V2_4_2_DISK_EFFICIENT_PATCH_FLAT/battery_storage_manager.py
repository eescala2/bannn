#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Report and safely prune large reranker-battery artifacts.

Completed screening experiments only need their aggregate report, recipe/config,
and log for later comparison. Checkpoints and final model weights can be removed
and the winning recipe can be retrained later from experiment_config.json.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sys
import time
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

VERSION = "2026.07.15.reranker-battery-storage-manager-v4.2"
REPORT_NAME = "domain_reranker_training_report.json"
CONFIG_NAME = "experiment_config.json"
MANIFEST_NAME = "artifact_prune_manifest.json"
HEAVY_DIR_NAMES = {"checkpoints", "final", "runs", "wandb", "tensorboard", "lightning_logs"}
HEAVY_SUFFIXES = {".safetensors", ".bin", ".pt", ".pth", ".ckpt", ".onnx", ".h5", ".pb"}


def file_bytes(path: Path) -> int:
    try:
        return int(path.stat().st_size)
    except OSError:
        return 0


def tree_bytes(path: Path) -> int:
    if not path.exists():
        return 0
    if path.is_file():
        return file_bytes(path)
    total = 0
    for child in path.rglob("*"):
        if child.is_file():
            total += file_bytes(child)
    return total


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def human_bytes(n: int) -> str:
    value = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(value) < 1024.0 or unit == "TB":
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{n} B"


def discover_roots(base: Path) -> List[Path]:
    models = base / "models"
    if not models.exists():
        return []
    return sorted(p for p in models.glob("reranker_battery_*") if p.is_dir())


def experiment_dirs(root: Path) -> Iterable[Path]:
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        if (child / REPORT_NAME).exists() or (child / CONFIG_NAME).exists() or (child / "checkpoints").exists() or (child / "final").exists():
            yield child


def candidate_heavy_paths(exp: Path) -> List[Path]:
    paths: List[Path] = []
    for name in sorted(HEAVY_DIR_NAMES):
        p = exp / name
        if p.exists():
            paths.append(p)
    # Defensive cleanup for weight files written directly under the experiment.
    for p in exp.rglob("*"):
        if not p.is_file():
            continue
        if p.name in {REPORT_NAME, CONFIG_NAME, MANIFEST_NAME}:
            continue
        if p.suffix.lower() in HEAVY_SUFFIXES and not any(parent.name in HEAVY_DIR_NAMES for parent in p.parents if parent != exp):
            paths.append(p)
    # Deduplicate and suppress files already contained in a heavy directory.
    unique: List[Path] = []
    for p in sorted(set(paths), key=lambda x: (len(x.parts), str(x))):
        if any(parent in unique for parent in p.parents):
            continue
        unique.append(p)
    return unique


@dataclass
class ExperimentStorage:
    root: str
    experiment_id: str
    complete: bool
    total_bytes: int
    report_bytes: int
    config_bytes: int
    heavy_bytes: int
    heavy_paths: List[str]
    artifact_policy: str
    keep: bool = False


def read_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def inventory(base: Path, keep_ids: Set[str]) -> List[ExperimentStorage]:
    rows: List[ExperimentStorage] = []
    for root in discover_roots(base):
        for exp in experiment_dirs(root):
            report = exp / REPORT_NAME
            config = exp / CONFIG_NAME
            heavy_paths = candidate_heavy_paths(exp)
            report_obj = read_json(report) if report.exists() else {}
            rows.append(ExperimentStorage(
                root=root.name,
                experiment_id=exp.name,
                complete=report.exists(),
                total_bytes=tree_bytes(exp),
                report_bytes=file_bytes(report),
                config_bytes=file_bytes(config),
                heavy_bytes=sum(tree_bytes(p) for p in heavy_paths),
                heavy_paths=[str(p) for p in heavy_paths],
                artifact_policy=str(report_obj.get("artifact_policy") or read_json(config).get("artifact_policy") or "legacy/full"),
                keep=exp.name in keep_ids,
            ))
    return rows


def print_inventory(rows: Sequence[ExperimentStorage]) -> None:
    print(f"Battery storage manager {VERSION}")
    print(f"Experiments found: {len(rows)}")
    print(f"Total experiment storage: {human_bytes(sum(r.total_bytes for r in rows))}")
    print(f"Potential completed-artifact savings: {human_bytes(sum(r.heavy_bytes for r in rows if r.complete and not r.keep))}")
    print()
    print(f"{'Complete':<9} {'Keep':<5} {'Total':>10} {'Heavy':>10}  Experiment")
    print("-" * 100)
    for r in sorted(rows, key=lambda x: x.heavy_bytes, reverse=True):
        print(f"{str(r.complete):<9} {str(r.keep):<5} {human_bytes(r.total_bytes):>10} {human_bytes(r.heavy_bytes):>10}  {r.root}\\{r.experiment_id}")


def archive_metadata(base: Path, rows: Sequence[ExperimentStorage], include_logs: bool) -> Optional[Path]:
    selected = [r for r in rows if r.complete and not r.keep]
    if not selected:
        return None
    archive_dir = base / "reranker_battery_archives"
    archive_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    archive_path = archive_dir / f"battery_metrics_before_prune_{stamp}.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for r in selected:
            exp = base / "models" / r.root / r.experiment_id
            for name in (REPORT_NAME, CONFIG_NAME, MANIFEST_NAME):
                p = exp / name
                if p.exists():
                    zf.write(p, arcname=str(p.relative_to(base)))
            if include_logs:
                log_root = base / "logs" / r.root
                log = log_root / f"{r.experiment_id}.log"
                if log.exists():
                    zf.write(log, arcname=str(log.relative_to(base)))
        manifest = {
            "version": VERSION,
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "experiments": [asdict(r) for r in selected],
        }
        zf.writestr("archive_manifest.json", json.dumps(manifest, indent=2))
    return archive_path


def prune_completed(base: Path, rows: Sequence[ExperimentStorage], execute: bool) -> Tuple[int, List[Dict[str, Any]]]:
    freed = 0
    details: List[Dict[str, Any]] = []
    for r in rows:
        if not r.complete or r.keep or r.heavy_bytes <= 0:
            continue
        exp = base / "models" / r.root / r.experiment_id
        report_path = exp / REPORT_NAME
        config_path = exp / CONFIG_NAME
        record: Dict[str, Any] = {
            "version": VERSION,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "experiment_id": r.experiment_id,
            "root": r.root,
            "execute": execute,
            "bytes_planned": r.heavy_bytes,
            "paths": r.heavy_paths,
            "report_sha256": sha256(report_path) if report_path.exists() else None,
            "config_sha256": sha256(config_path) if config_path.exists() else None,
            "errors": [],
        }
        deleted = 0
        if execute:
            for raw in r.heavy_paths:
                p = Path(raw)
                if not p.exists():
                    continue
                size = tree_bytes(p)
                try:
                    if p.is_dir():
                        shutil.rmtree(p)
                    else:
                        p.unlink()
                    deleted += size
                except Exception as exc:
                    record["errors"].append(f"{p}: {exc}")
            record["bytes_deleted"] = deleted
            (exp / MANIFEST_NAME).write_text(json.dumps(record, indent=2), encoding="utf-8")
            # Update the report so future tooling knows weights were intentionally pruned.
            report = read_json(report_path)
            report["artifact_policy"] = "metrics_only_pruned"
            report["output_model"] = None
            report["artifact_cleanup"] = {
                "policy": "metrics_only_pruned",
                "bytes_freed": deleted,
                "manifest": str(exp / MANIFEST_NAME),
            }
            report_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
            freed += deleted
        else:
            record["bytes_deleted"] = 0
        details.append(record)
    return freed, details


def write_csv(path: Path, rows: Sequence[ExperimentStorage]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(ExperimentStorage.__dataclass_fields__.keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            d = asdict(row)
            d["heavy_paths"] = " | ".join(d["heavy_paths"])
            writer.writerow(d)


def main() -> int:
    ap = argparse.ArgumentParser(description="Report/prune large completed Cross-Encoder battery artifacts")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--action", choices=["report", "prune_completed"], default="report")
    ap.add_argument("--execute", action="store_true", help="Actually delete. Without this flag, prune_completed is a dry run.")
    ap.add_argument("--keep_experiment_ids", default="", help="Comma-separated experiment directory names whose weights must be retained")
    ap.add_argument("--include_logs_in_archive", action=argparse.BooleanOptionalAction, default=True)
    args = ap.parse_args()

    base = Path(args.base)
    keep_ids = {x.strip() for x in args.keep_experiment_ids.split(",") if x.strip()}
    rows = inventory(base, keep_ids)
    report_dir = base / "reranker_battery_storage"
    report_dir.mkdir(parents=True, exist_ok=True)
    write_csv(report_dir / "battery_storage_inventory.csv", rows)
    (report_dir / "battery_storage_inventory.json").write_text(
        json.dumps({"version": VERSION, "rows": [asdict(r) for r in rows]}, indent=2), encoding="utf-8"
    )
    print_inventory(rows)
    if args.action == "report":
        print(f"\nInventory written to: {report_dir}")
        return 0

    archive = archive_metadata(base, rows, args.include_logs_in_archive)
    if archive:
        print(f"Metadata archive: {archive}")
    freed, details = prune_completed(base, rows, args.execute)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    action_report = report_dir / f"prune_{'executed' if args.execute else 'dry_run'}_{stamp}.json"
    action_report.write_text(json.dumps({"version": VERSION, "execute": args.execute, "bytes_freed": freed, "details": details}, indent=2), encoding="utf-8")
    if args.execute:
        print(f"\nPrune complete. Freed: {human_bytes(freed)}")
    else:
        planned = sum(int(d.get("bytes_planned", 0)) for d in details)
        print(f"\nDRY RUN only. Would free: {human_bytes(planned)}")
        print("Rerun with --execute after reviewing the inventory/archive.")
    print(f"Action report: {action_report}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted by user.", flush=True)
        raise SystemExit(130)
