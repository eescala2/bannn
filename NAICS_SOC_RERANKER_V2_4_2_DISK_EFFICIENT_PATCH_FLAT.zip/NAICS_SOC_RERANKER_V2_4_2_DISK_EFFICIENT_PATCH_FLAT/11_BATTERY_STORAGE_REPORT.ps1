param(
    [string]$Base = "C:\laborshed_autocode_clean"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "battery_storage_manager.py"
& $Python -u $Script --base $Base --action report
if ($LASTEXITCODE -ne 0) { throw "Storage report exited with code $LASTEXITCODE" }
