param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("smoke","standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [Parameter(Mandatory=$true)]
    [string]$ExperimentId,
    [string]$OutputDir = "",
    [switch]$Force
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "retrain_selected_battery_experiment.py"
$args = @("-u",$Script,"--base",$Base,"--profile",$Profile,"--experiment_id",$ExperimentId,"--resume")
if (-not [string]::IsNullOrWhiteSpace($OutputDir)) { $args += @("--output_dir",$OutputDir) }
if ($Force) { $args += "--force" }
& $Python @args
if ($LASTEXITCODE -ne 0) { throw "Selected-model retraining exited with code $LASTEXITCODE" }
