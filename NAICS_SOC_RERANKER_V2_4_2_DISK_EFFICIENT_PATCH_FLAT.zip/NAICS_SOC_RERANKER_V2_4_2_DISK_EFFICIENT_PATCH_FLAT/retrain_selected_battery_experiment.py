#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Recreate one selected battery model from its preserved experiment config."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List

VERSION = "2026.07.15.reranker-battery-materializer-v4.2"


def remove_option(command: List[str], option: str, takes_value: bool = True) -> List[str]:
    out: List[str] = []
    i = 0
    while i < len(command):
        if command[i] == option:
            i += 2 if takes_value and i + 1 < len(command) else 1
            continue
        out.append(command[i])
        i += 1
    return out


def replace_option(command: List[str], option: str, value: str) -> List[str]:
    command = remove_option(command, option, True)
    command.extend([option, value])
    return command


def main() -> int:
    ap = argparse.ArgumentParser(description="Retrain a chosen battery experiment and retain only its final model")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--profile", default="standard")
    ap.add_argument("--experiment_id", required=True)
    ap.add_argument("--output_dir", default="")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    args = ap.parse_args()

    base = Path(args.base)
    source = base / "models" / f"reranker_battery_{args.profile}" / args.experiment_id
    config_path = source / "experiment_config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"Experiment config not found: {config_path}")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    command = [str(x) for x in config.get("command", [])]
    if not command:
        raise RuntimeError(f"No reproducible command stored in {config_path}")

    output = Path(args.output_dir) if args.output_dir else base / "models" / "selected_rerankers" / args.experiment_id
    if output.exists() and args.force:
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    # Rebind executable and trainer to the current clean project.
    command[0] = str(base / ".venv" / "Scripts" / "python.exe")
    if len(command) >= 3:
        command[2] = str(base / "train_domain_cross_encoder_battery.py")
    command = replace_option(command, "--fit_sav", str(base / "training_FIT.sav"))
    command = replace_option(command, "--calibration_sav", str(base / "training_CALIBRATION.sav"))
    command = replace_option(command, "--output_dir", str(output))
    command = replace_option(command, "--artifact_policy", "final_only")
    command = replace_option(command, "--checkpoint_keep", "1")
    command = remove_option(command, "--resume_from_checkpoint", True)
    if args.resume and (output / "checkpoints").exists():
        command.extend(["--resume_from_checkpoint", "auto"])

    materialization = {
        "version": VERSION,
        "source_experiment": str(source),
        "source_config": str(config_path),
        "output_dir": str(output),
        "command": command,
    }
    (output / "materialization_manifest.json").write_text(json.dumps(materialization, indent=2), encoding="utf-8")

    env = os.environ.copy()
    env.update({
        "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
        "HF_HOME": str(base / "hf_cache"), "HF_HUB_CACHE": str(base / "hf_cache" / "hub"),
        "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_HUB_DISABLE_PROGRESS_BARS": "1",
        "CUDA_VISIBLE_DEVICES": "0", "TOKENIZERS_PARALLELISM": "false",
        "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
    })
    print(f"Materializing selected experiment: {args.experiment_id}", flush=True)
    print(f"Output: {output}", flush=True)
    print(" ".join(command), flush=True)
    completed = subprocess.run(command, env=env)
    if completed.returncode != 0:
        print(f"Selected experiment retraining failed with code {completed.returncode}", file=sys.stderr, flush=True)
        return int(completed.returncode)
    final = output / "final"
    if not final.exists():
        raise RuntimeError(f"Training completed but final model was not found: {final}")
    print(f"Selected model retained at: {final}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
