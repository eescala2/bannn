NAICS/SOC Reranker Battery V2.4.2: Disk-Efficient Screening
============================================================

Problem fixed
-------------
Earlier battery experiments retained two full optimizer checkpoints plus a
final Cross-Encoder model for every screening recipe.  Those files are useful
for resuming one unfinished experiment, but they are not needed after a
completed experiment has written its metrics and reproducible configuration.

The V2.4.2 default is now:

    --artifact_policy metrics_only

During an active experiment, at most one resumable checkpoint is retained.
After the tuned model has been evaluated and domain_reranker_training_report.json
has been written, the checkpoint and final model weights are removed.  The
experiment keeps:

    domain_reranker_training_report.json
    experiment_config.json
    the per-experiment console log
    artifact_prune_manifest.json, when legacy files are pruned

This is sufficient to compare recipes, summarize the battery, run confirmatory
experiments, and reproduce any recipe later.

Artifact policies
-----------------

metrics_only  Recommended for screening and multi-seed confirmation.  Keeps
              metrics/config/logs; removes checkpoints and final weights after
              a successful run.

final_only    Recommended when deliberately materializing one selected winner.
              Keeps the final model; removes optimizer checkpoints.

full          Keeps final model and checkpoint(s).  Use only when there is a
              specific debugging reason.

Immediate cleanup of existing experiments
-----------------------------------------

1. Inventory only:

    .\11_BATTERY_STORAGE_REPORT.ps1

2. Safe dry run.  It creates a ZIP archive of metrics/config/logs, but does not
   delete anything:

    .\12_PRUNE_COMPLETED_BATTERY_MODELS.ps1

3. Execute after reviewing the printed savings and archive path:

    .\12_PRUNE_COMPLETED_BATTERY_MODELS.ps1 -Execute

To retain the weights for specific experiment directories:

    .\12_PRUNE_COMPLETED_BATTERY_MODELS.ps1 `
      -Execute `
      -KeepExperimentIds "experiment_id_1,experiment_id_2"

Only completed experiments containing domain_reranker_training_report.json are
pruned.  The active/unfinished experiment is not touched.

Future battery runs
-------------------

The PowerShell wrappers now default to metrics_only:

    .\01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1 -Profile standard

The same applies to resume, one-stage, marathon, and confirmatory launchers.

Recreate one selected model later
---------------------------------

The exact recipe and command are stored in experiment_config.json.  To retrain
and retain a chosen winner:

    .\13_RETRAIN_SELECTED_EXPERIMENT_KEEP_MODEL.ps1 `
      -Profile standard `
      -ExperimentId "05_loss__bce__qa20a__seed42"

The recreated production model is written under:

    models\selected_rerankers\<experiment_id>\final

Use -OutputDir to choose another destination.  This means screening weights do
not need to remain on disk merely so a recipe can be recalled later.

Files that should normally remain
---------------------------------

Keep:

    training_FIT.sav
    training_CALIBRATION.sav
    training_EVALUATION_GOLD.sav
    hf_cache (shared base models)
    embedding_cache, if present and reused
    logs
    domain_reranker_training_report.json
    experiment_config.json
    battery summaries and upload ZIPs
    only the final selected production reranker(s)

Do not casually delete hf_cache while running offline.  It contains the shared
base models used by every experiment.  It is not duplicated once per recipe.
