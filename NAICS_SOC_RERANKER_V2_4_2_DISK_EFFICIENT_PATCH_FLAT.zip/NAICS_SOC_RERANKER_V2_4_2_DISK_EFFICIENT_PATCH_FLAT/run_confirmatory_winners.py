#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import os
import sys
import hashlib
from pathlib import Path
from typing import Any, Dict, List

from run_reranker_experiment_battery import Experiment, run_experiment

VERSION = "2026.07.15.reranker-battery-confirmatory-v4.2-disk-efficient"


def num(row: Dict[str, str], key: str, cast, default):
    try:
        return cast(row.get(key, ""))
    except Exception:
        return default


def load_candidates(path: Path, top_n: int) -> Dict[str, List[Dict[str, str]]]:
    by_target: Dict[str, List[Dict[str, str]]] = {}
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            by_target.setdefault(row["target"], []).append(row)
    out: Dict[str, List[Dict[str, str]]] = {}
    for target, rows in by_target.items():
        rows.sort(key=lambda r: float(r.get("mean_selection_score", "-999") or -999), reverse=True)
        promising = [r for r in rows if r.get("decision") == "PROMISING"]
        out[target] = (promising or rows)[:top_n]
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--profile", choices=["standard", "exhaustive", "marathon"], default="standard")
    ap.add_argument("--seeds", default="101,102,103,104,105")
    ap.add_argument("--top_recipes_per_target", type=int, default=2)
    ap.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--artifact_policy", choices=["metrics_only", "final_only", "full"], default="metrics_only")
    args = ap.parse_args()
    base = Path(args.base)
    summary_csv = base / "reranker_battery_reports" / args.profile / "battery_recipe_summary.csv"
    if not summary_csv.exists():
        raise FileNotFoundError(f"Run the battery summarizer first; missing {summary_csv}")
    candidates = load_candidates(summary_csv, args.top_recipes_per_target)
    seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]

    python_exe = base / ".venv" / "Scripts" / "python.exe"
    trainer = base / "train_domain_cross_encoder_battery.py"
    fit_sav = base / "training_FIT.sav"
    cal_sav = base / "training_CALIBRATION.sav"
    root = base / "models" / f"reranker_battery_confirmatory_{args.profile}"
    logs = base / "logs" / f"reranker_battery_confirmatory_{args.profile}"
    root.mkdir(parents=True, exist_ok=True); logs.mkdir(parents=True, exist_ok=True)

    total = sum(len(v) for v in candidates.values()) * len(seeds)
    count = 0
    for target, recipes in candidates.items():
        for rank, row in enumerate(recipes, 1):
            for seed in seeds:
                count += 1
                anchors_orig = num(row, "anchors", int, 1500 if target == "qa20a" else 3000)
                steps_orig = num(row, "steps", int, 100 if target == "qa20a" else 200)
                recipe_hash = hashlib.sha1((row.get("recipe_key") or str(row)).encode("utf-8")).hexdigest()[:8]
                exp = Experiment(
                    stage="20_confirmatory",
                    name=f"rank{rank}_{row.get('name','recipe')}_{recipe_hash}",
                    targets=target,
                    seed=seed,
                    base_model=row.get("base_model") or "cross-encoder/ms-marco-MiniLM-L6-v2",
                    loss_type=row.get("loss_type") or "bce",
                    anchors=max(5000 if target == "qa20a" else 8000, anchors_orig * 2),
                    steps=max(300 if target == "qa20a" else 500, steps_orig * 2),
                    learning_rate=num(row, "learning_rate", float, 1e-5),
                    hard_negatives=num(row, "hard_negatives", int, 3),
                    random_negatives=num(row, "random_negatives", int, 1),
                    hard_negative_strategy=row.get("hard_negative_strategy") or "hybrid",
                    prototype_examples=num(row, "prototype_examples", int, 3),
                    nearest_candidates=num(row, "nearest_candidates", int, 30),
                    context_profile=row.get("context_profile") or "full",
                    anchor_sampling=row.get("anchor_sampling") or "balanced",
                    weak_group_multiplier=num(row, "weak_group_multiplier", int, 2),
                    max_length=num(row, "max_length", int, 384),
                    eval_rows=4000,
                    eval_candidates=20,
                    train_batch_size=1 if (row.get("loss_type") or "bce") != "bce" else 4,
                    gradient_accumulation_steps=32 if (row.get("loss_type") or "bce") != "bce" else 8,
                    listwise_mini_batch_size=4,
                    bootstrap_samples=5000,
                    tags=("confirmatory", f"source_profile={args.profile}"),
                )
                print(f"[CONFIRMATORY] {count}/{total} target={target} recipe_rank={rank} seed={seed}", flush=True)
                run_experiment(exp, python_exe, trainer, fit_sav, cal_sav, root, logs, args.resume, args.artifact_policy)
    print(f"Confirmatory runs complete. Root: {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
