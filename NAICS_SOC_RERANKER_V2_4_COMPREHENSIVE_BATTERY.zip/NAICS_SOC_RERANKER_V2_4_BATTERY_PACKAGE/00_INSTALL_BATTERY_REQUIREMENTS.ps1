param(
    [string]$Base = "C:\laborshed_autocode_clean"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Requirements = Join-Path $Base "requirements_reranker_battery.txt"
if (-not (Test-Path $Python)) { throw "Python not found: $Python" }
if (-not (Test-Path $Requirements)) { throw "Requirements file not found: $Requirements" }
& $Python -m pip install --upgrade pip setuptools wheel
& $Python -m pip install -r $Requirements
if ($LASTEXITCODE -ne 0) { throw "Battery requirements installation failed." }
Write-Host "Battery requirements installed. Run 00_BATTERY_PREFLIGHT.ps1 next." -ForegroundColor Green
