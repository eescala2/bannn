param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("standard","exhaustive","marathon")]
    [string]$Profile = "standard"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "summarize_reranker_battery.py"
$Root = Join-Path $Base ("models\reranker_battery_confirmatory_{0}" -f $Profile)
& $Python -u $Script --base $Base --profile $Profile --root $Root --output_label ("confirmatory_{0}" -f $Profile)
if ($LASTEXITCODE -ne 0) { throw "Confirmatory summarizer failed with code $LASTEXITCODE" }
