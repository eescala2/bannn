param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [Parameter(Mandatory=$true)]
    [string]$Stage,
    [string]$Seeds = "42,43,44,45,46",
    [switch]$IncludeOptionalModels
)
& (Join-Path $Base "01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1") `
  -Base $Base -Profile $Profile -Seeds $Seeds -OnlyStage $Stage -IncludeOptionalModels:$IncludeOptionalModels
