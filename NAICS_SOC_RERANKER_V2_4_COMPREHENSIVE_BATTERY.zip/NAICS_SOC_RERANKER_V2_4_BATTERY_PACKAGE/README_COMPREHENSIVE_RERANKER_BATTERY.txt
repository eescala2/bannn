NAICS/SOC Comprehensive Cross-Encoder Experiment Battery V2.4
===============================================================

Purpose
-------
This package runs a resumable, sequential battery of controlled experiments
against training_FIT.sav and training_CALIBRATION.sav. It does NOT read the
sealed training_EVALUATION_GOLD.sav. The Gold file remains reserved for the
final end-to-end audited model comparison.

The battery tests the main remaining reranker avenues:

1. random-seed stability;
2. learning rate;
3. hard-versus-random negative composition;
4. semantic, hierarchy, and hybrid negative mining;
5. context-field ablations;
6. pairwise BCE versus RankNet, ListNet, and LambdaLoss;
7. anchor count and optimizer-step budget;
8. maximum input length;
9. number of historical prototype examples per code;
10. semantic candidate-pool size;
11. balanced versus production-frequency anchor sampling;
12. weak-SOC-group oversampling;
13. shared versus target-specific rerankers;
14. optional alternative base reranker models;
15. repeated-seed confirmatory tests of the best recipes.

Each experiment reports both:

- ORACLE reranking metrics, where the correct code is inserted into the
  candidate list. These isolate ranking quality.
- RETRIEVAL-PIPELINE metrics, where the correct code is not inserted. These
  reflect candidate-generation plus reranking quality.

Candidate recall is reported at 1, 4, 10, 20, and 40 candidates. This separates
retrieval failure from reranking failure.

Files
-----

train_domain_cross_encoder_battery.py
    Enhanced target-specific Cross-Encoder trainer.

run_reranker_experiment_battery.py
    Resumable experiment orchestrator with visible heartbeats, per-run logs,
    checkpoint resume, failure continuation, and experiment manifests.

summarize_reranker_battery.py
    Aggregates all experiments, compares seeds, ranks recipes, diagnoses
    retrieval versus ranking, and creates CHAT_UPLOAD_RERANKER_BATTERY.zip.

battery_preflight.py
    Checks required files, packages, CUDA, losses, and offline model cache.

00_INSTALL_BATTERY_REQUIREMENTS.ps1
    Installs/updates the battery dependencies without replacing CUDA PyTorch.

00_BATTERY_PREFLIGHT.ps1
    Runs the preflight.

00A_CACHE_OPTIONAL_BASE_MODELS.ps1
    Optionally caches MiniLM-L12 and BGE reranker base models for offline tests.

01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1
    Starts or resumes the selected profile.

02_RESUME_COMPREHENSIVE_RERANKER_BATTERY.ps1
    Convenience resume wrapper.

03_RERANKER_BATTERY_STATUS.ps1
    Shows completed/failed counts, active processes, GPU status, and latest log.

04_SUMMARIZE_RERANKER_BATTERY.ps1
    Creates the aggregate report and upload ZIP.

05_DRY_RUN_BATTERY_MANIFEST.ps1
    Lists scheduled experiments without running them.

06_RUN_ONE_BATTERY_STAGE.ps1
    Runs one specific stage only.

07_RUN_CONFIRMATORY_WINNERS.ps1
    After summary, reruns the top recipes at larger budgets across five new
    seeds.

08_SUMMARIZE_CONFIRMATORY_WINNERS.ps1
    Summarizes the confirmatory runs separately.

09_RUN_ENTIRE_MARATHON_PIPELINE.ps1
    One-command preflight, marathon screening, summary, confirmation, and final summary.

Profiles and approximate size
-----------------------------

smoke
    9 experiments. Three target-specific baseline seeds.
    Planning estimate: several hours to about one day.

standard
    About 101 experiments. Covers every major avenue except optional base
    models and the deepest budget variants.
    Planning estimate on the RTX 2050: roughly 4 to 10 days, depending on text
    lengths, loss type, and thermal throttling.

exhaustive
    About 131 experiments when optional models are included. Adds deeper
    learning-rate, negative, budget, and base-model tests.
    Planning estimate: roughly 7 to 16 days.

marathon
    About 152 experiments. Adds five-seed sensitivity and larger listwise
    tests. Confirmatory winners are a separate final phase.
    Planning estimate: roughly 10 to 24 days.

These are planning ranges, not promises. The suite is deliberately resumable.
You can interrupt it, use the laptop, and restart the same command later.

Install patch
-------------
Extract this flat package into:

C:\laborshed_autocode_clean

Do not recreate or modify:

training_FIT.sav
training_CALIBRATION.sav
training_EVALUATION_GOLD.sav

The battery never reads Gold.

Step 1: preflight
-----------------

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd C:\laborshed_autocode_clean
.\00_BATTERY_PREFLIGHT.ps1

For exhaustive/marathon optional model tests, first log into Hugging Face while
online, then run:

.\00A_CACHE_OPTIONAL_BASE_MODELS.ps1
.\00_BATTERY_PREFLIGHT.ps1 -CheckOptionalModels

Step 2: inspect the schedule
----------------------------

.\05_DRY_RUN_BATTERY_MANIFEST.ps1 -Profile standard

Step 3: run a profile
---------------------

Recommended first full battery:

.\01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1 -Profile standard

Longest available battery:

.\01_RUN_COMPREHENSIVE_RERANKER_BATTERY.ps1 `
  -Profile marathon `
  -IncludeOptionalModels

The suite runs one GPU experiment at a time. Do not start a second battery.

Resume
------
Press Ctrl+C once. The active experiment will stop, and completed experiments
remain complete. Rerun the same command:

.\02_RESUME_COMPREHENSIVE_RERANKER_BATTERY.ps1 -Profile standard

A completed report is skipped. An interrupted experiment resumes from its
latest checkpoint when possible.

Status
------

.\03_RERANKER_BATTERY_STATUS.ps1 -Profile standard

The orchestrator also prints a heartbeat at least once per minute, including:

experiment ID
elapsed time
minutes since last trainer output
GPU utilization and VRAM
Python RSS and CPU activity

Run one avenue only
-------------------
Examples:

.\06_RUN_ONE_BATTERY_STAGE.ps1 -Profile standard -Stage 05_loss
.\06_RUN_ONE_BATTERY_STAGE.ps1 -Profile standard -Stage 04_context
.\06_RUN_ONE_BATTERY_STAGE.ps1 -Profile exhaustive -Stage 12_base_model -IncludeOptionalModels

Stage names are visible in the dry-run manifest.

Summarize
---------

.\04_SUMMARIZE_RERANKER_BATTERY.ps1 -Profile standard

Outputs:

C:\laborshed_autocode_clean\reranker_battery_reports\standard\
    battery_summary.md
    battery_summary.json
    battery_run_results.csv
    battery_recipe_summary.csv
    battery_failures.csv
    CHAT_UPLOAD_RERANKER_BATTERY.zip

Upload CHAT_UPLOAD_RERANKER_BATTERY.zip to ChatGPT. It contains experiment
settings and aggregate metrics, not raw survey text or employer names.

Confirmatory winners
--------------------
After the screening battery is summarized:

.\07_RUN_CONFIRMATORY_WINNERS.ps1 `
  -Profile standard `
  -Seeds "101,102,103,104,105" `
  -TopRecipesPerTarget 2

Then:

.\08_SUMMARIZE_CONFIRMATORY_WINNERS.ps1 -Profile standard

The confirmatory phase doubles the winning recipe's original budget, enforces
at least 5,000 NAICS or 8,000 SOC anchors, uses at least 300/500 update steps,
and evaluates 4,000 calibration rows with 5,000 paired bootstrap samples.

Promotion discipline
--------------------
A recipe is marked PROMISING only when mean top-1 and MRR gains are positive,
at least half of its runs improve those metrics, and top-4 does not fall by
more than 0.5 percentage points.

Do not choose a model from one seed. Use the confirmatory phase before wiring a
winner into the audited Gold end-to-end autocoder.

Interpretation
--------------
High oracle gain + low retrieval recall:
    The reranker works, but candidate generation is the bottleneck.

Low oracle gain + high retrieval recall:
    Candidate ranking/training is the bottleneck.

Context ablation beats full context:
    Some survey fields add noise; use the winning context profile.

Hierarchy negatives beat semantic negatives:
    The model needs finer within-family distinctions.

Semantic negatives beat hierarchy negatives:
    Confusable wording, not just hierarchy, is driving errors.

Listwise loss beats BCE consistently:
    Promote the listwise recipe only after multi-seed confirmation.

Optional base model fails offline:
    Cache it first or rerun without -IncludeOptionalModels.

Hardware safety
---------------
The suite is sequential and uses one GPU job at a time. RTX 2050-safe defaults:

embedding batch size 16
training batch size 4 for BCE
training batch size 1 for listwise losses
gradient accumulation 8 or 32
CUDA device 0
no parallel experiment launches

If CUDA out-of-memory occurs, the experiment is marked failed and the suite
continues. Reduce its batch size or rerun that stage separately after editing
the manifest/runner.

One-command all-avenues marathon
--------------------------------

After optional models are cached, the entire screening and confirmatory pipeline can be run with:

.\09_RUN_ENTIRE_MARATHON_PIPELINE.ps1 -IncludeOptionalModels

It can be interrupted and resumed because every underlying stage skips completed reports and resumes checkpoints.
