param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [switch]$CheckOptionalModels
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "battery_preflight.py"
if (-not (Test-Path $Python)) { throw "Python not found: $Python" }
if (-not (Test-Path $Script)) { throw "Preflight script not found: $Script" }
$args = @("-u", $Script, "--base", $Base)
if ($CheckOptionalModels) { $args += "--check_optional_models" }
& $Python @args
if ($LASTEXITCODE -ne 0) { throw "Battery preflight failed with exit code $LASTEXITCODE" }
