param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("smoke","standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [switch]$IncludeOptionalModels
)
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "run_reranker_experiment_battery.py"
$args = @("-u",$Script,"--base",$Base,"--profile",$Profile,"--dry_run")
if ($IncludeOptionalModels) { $args += "--include_optional_models" }
& $Python @args
