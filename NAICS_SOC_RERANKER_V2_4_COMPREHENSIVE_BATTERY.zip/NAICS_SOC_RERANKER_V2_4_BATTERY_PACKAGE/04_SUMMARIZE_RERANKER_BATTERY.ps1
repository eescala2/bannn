param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("smoke","standard","exhaustive","marathon")]
    [string]$Profile = "standard"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "summarize_reranker_battery.py"
& $Python -u $Script --base $Base --profile $Profile
if ($LASTEXITCODE -ne 0) { throw "Battery summarizer failed with exit code $LASTEXITCODE" }
