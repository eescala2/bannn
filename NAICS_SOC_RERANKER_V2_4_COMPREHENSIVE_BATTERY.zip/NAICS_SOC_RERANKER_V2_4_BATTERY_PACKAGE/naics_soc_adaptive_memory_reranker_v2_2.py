#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAICS-first + SOC ultimate autocoder for SPSS .sav files
============================================================

Pipeline order
--------------
1) Train/predict NAICS first, default target qa20a.
2) Fill/update NAICS in the scoring data.
3) Train/predict SOC qe4ar and qe5ar using the updated NAICS as a feature.
4) Save/load a complete model bundle for future scoring.

Design goals
------------
* Accuracy-first, but safe on a laptop-class workstation.
* Robust fallback if optional packages are not installed.
* Sparse lexical NLP + categorical + numeric + optional semantic embeddings.
* Exact and optional fuzzy dictionary overrides for high-purity repeated answers.
* Hierarchical SOC: major group first, then SOC6 within each major group.
* Ensemble/model selection across multiple families, with optional Optuna tuning.
* SPSS 26-compatible usage via an external modern Python executable.

Recommended full install
------------------------
python -m pip install -r requirements_naics_soc_state_of_art.txt

Example train + score
---------------------
python naics_soc_state_of_art_autocoder.py ^
  --mode train_and_score ^
  --train_sav "C:\\laborshed_autocode\\laborshed_train.sav" ^
  --score_sav "C:\\laborshed_autocode\\laborshed_to_score.sav" ^
  --out_sav   "C:\\laborshed_autocode\\laborshed_scored.sav" ^
  --log_txt   "C:\\laborshed_autocode\\naics_soc_log.txt" ^
  --model_out "C:\\laborshed_autocode\\naics_soc_state_of_art.joblib" ^
  --save_model ^
  --profile accuracy

Example score only
------------------
python naics_soc_state_of_art_autocoder.py ^
  --mode score ^
  --model_in  "C:\\laborshed_autocode\\naics_soc_state_of_art.joblib" ^
  --score_sav "C:\\laborshed_autocode\\new_to_score.sav" ^
  --out_sav   "C:\\laborshed_autocode\\new_scored.sav" ^
  --log_txt   "C:\\laborshed_autocode\\new_naics_soc_log.txt"
"""

from __future__ import annotations

import os

# These must be set before importing NumPy/SciPy/sklearn to avoid nested
# thread storms on Windows laptops. CLI --native_threads overrides the
# actual threadpoolctl context later, but these protect import-time defaults.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("BLIS_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
os.environ.setdefault("PYTHONUTF8", "1")

import argparse
import gc
import hashlib
import json
import math
import platform
import re
import sys
import time
import unicodedata
import warnings
from statistics import NormalDist
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
import pyreadstat
import scipy.sparse as sp
from joblib import Parallel, delayed
from scipy.special import expit, softmax
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.calibration import CalibratedClassifierCV
from sklearn.decomposition import TruncatedSVD
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.metrics import f1_score, log_loss
from sklearn.model_selection import StratifiedKFold
from sklearn.naive_bayes import ComplementNB
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.svm import LinearSVC
from threadpoolctl import threadpool_limits

# Optional packages. The script uses them when present and safely skips them
# when absent.
try:
    import lightgbm as lgb
    HAS_LIGHTGBM = True
except Exception:
    lgb = None
    HAS_LIGHTGBM = False

try:
    import xgboost as xgb
    HAS_XGBOOST = True
except Exception:
    xgb = None
    HAS_XGBOOST = False

try:
    from catboost import CatBoostClassifier
    HAS_CATBOOST = True
except Exception:
    CatBoostClassifier = None
    HAS_CATBOOST = False

try:
    import optuna
    HAS_OPTUNA = True
except Exception:
    optuna = None
    HAS_OPTUNA = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except Exception:
    SentenceTransformer = None
    HAS_SENTENCE_TRANSFORMERS = False

try:
    from sentence_transformers import CrossEncoder
    HAS_CROSS_ENCODER = True
except Exception:
    CrossEncoder = None
    HAS_CROSS_ENCODER = False

try:
    from rapidfuzz import fuzz, process as rf_process
    HAS_RAPIDFUZZ = True
except Exception:
    fuzz = None
    rf_process = None
    HAS_RAPIDFUZZ = False

try:
    import faiss  # type: ignore
    HAS_FAISS = True
except Exception:
    faiss = None
    HAS_FAISS = False

try:
    from llama_cpp import Llama  # type: ignore
    HAS_LLAMA_CPP = True
except Exception:
    Llama = None
    HAS_LLAMA_CPP = False

try:
    import psutil  # type: ignore
    HAS_PSUTIL = True
except Exception:
    psutil = None
    HAS_PSUTIL = False

VERSION = "2026.07.15.adaptive-memory-split-domain-reranker-v2.2"

VALID_SOC_MAJOR_GROUPS = {
    11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33,
    35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55,
}

COMMON_CODE_MISSINGS = {"", "0", "00", "000", "0000", "00000", "000000", "999", "9999", "99999", "999999"}

ABBREV_MAP = [
    (r"\basst\b", "assistant"),
    (r"\bmgr\b", "manager"),
    (r"\bmgmt\b", "management"),
    (r"\bsvcs\b", "services"),
    (r"\bsvc\b", "service"),
    (r"\btech\b", "technician"),
    (r"\badmin\b", "administrative"),
    (r"\bdept\b", "department"),
    (r"\bsupv\b", "supervisor"),
    (r"\bsupvr\b", "supervisor"),
    (r"\bmaint\b", "maintenance"),
    (r"\bdir\b", "director"),
    (r"\bexec\b", "executive"),
    (r"\bceo\b", "chief executive officer"),
    (r"\bcfo\b", "chief financial officer"),
    (r"\bcoo\b", "chief operating officer"),
    (r"\brn\b", "registered nurse"),
    (r"\blpn\b", "licensed practical nurse"),
    (r"\blvn\b", "licensed vocational nurse"),
    (r"\bcna\b", "certified nursing assistant"),
    (r"\bemt\b", "emergency medical technician"),
    (r"\bcdl\b", "commercial drivers license"),
    (r"\ba\+\b", "a plus"),
]

NON_ALNUM_RE = re.compile(r"[^a-z0-9\+\#\/\-\s]+")
SPACE_RE = re.compile(r"\s+")


# ---------------------------------------------------------------------
# Config dataclasses
# ---------------------------------------------------------------------

@dataclass
class ParallelConfig:
    max_workers: int
    native_threads: int


@dataclass
class TrainConfig:
    profile: str
    random_seed: int

    # Dictionary behavior
    dict_purity: float
    dict_min_count: int
    naics_dict_purity: float
    naics_dict_min_count: int
    use_fuzzy_dictionary: bool
    fuzzy_threshold: int
    fuzzy_max_choices_per_bucket: int

    # Adaptive historical rule memory. These rules learn repeated employer/title/
    # location/numeric patterns from verified historical codes and can emit exact
    # codes or high-confidence hierarchical constraints.
    use_adaptive_memory: bool
    memory_employer_col: str
    memory_qe4_col: str
    memory_qe4ar_col: str
    memory_qe5_col: str
    memory_qe5ar_col: str
    memory_naics_col: str
    memory_location_cols: Tuple[str, ...]
    memory_numeric_cols: Tuple[str, ...]
    memory_date_col: str
    memory_reference_date: str
    memory_verified_col: str
    memory_verified_weight: float
    memory_rolling_years: float
    memory_half_life_years: float
    memory_min_count: int
    memory_min_effective_n: float
    memory_confidence_level: float
    memory_exact_wilson_naics: float
    memory_exact_wilson_soc: float
    memory_partial_wilson_min: float
    memory_hard_constraint_min: float
    memory_partial_boost: float
    memory_candidate_pool: int
    memory_numeric_bins: int
    memory_max_rules_per_template: int
    memory_use_partial_constraints: bool
    memory_strip_branch_numbers: bool
    memory_validation_fraction: float
    memory_export_dir: str

    # Semantic vector memory / dense retrieval behavior
    use_semantic_memory: bool
    semantic_backend: str
    semantic_k: int
    semantic_min_similarity: float
    semantic_min_confidence: float
    semantic_fusion_weight: float
    ml_fusion_weight: float
    semantic_reference_weight: float
    naics_reference_csv: str
    soc_reference_csv: str

    # Cross-encoder reranking for semantic-memory candidates. This is the
    # accuracy-first second pass after FAISS / cosine retrieval.
    use_cross_encoder_reranker: bool
    cross_encoder_model: str
    cross_encoder_model_naics: str
    cross_encoder_model_soc: str
    cross_encoder_topn: int
    cross_encoder_batch_size: int
    cross_encoder_fusion_weight: float
    cross_encoder_min_score: float
    # V2: rerank the union of ML and semantic candidates, not semantic-only.
    cross_encoder_union_candidates: bool
    cross_encoder_candidate_pool: int
    cross_encoder_prototype_examples: int

    # Probability calibration for final selected supervised classifiers.
    use_probability_calibration: bool
    calibration_method: str
    calibration_cv: int
    calibration_max_rows: int
    calibration_max_classes: int
    # V2 post-hoc calibration and uncertainty, fitted on a separate calibration SAV.
    use_source_confidence_calibration: bool
    source_calibration_method: str
    source_calibration_min_rows: int
    conformal_alphas: Tuple[float, ...]
    conformal_candidate_pool: int
    use_candidate_meta_ranker: bool
    candidate_meta_ranker_min_rows: int
    calibration_fit_fraction: float

    # Local air-gapped LLM fallback / reranker
    use_local_llm_fallback: bool
    llm_model_path: str
    llm_trigger_confidence_naics: float
    llm_trigger_confidence_soc: float
    llm_max_rows: int
    llm_threads: int
    llm_ctx_size: int
    llm_temperature: float
    llm_top_p: float
    llm_max_tokens: int
    llm_rerank_confidence: float
    llm_allow_free_code: bool
    llm_self_consistency_samples: int
    llm_self_consistency_temperature: float

    # Top-k output
    topk_naics: int
    topk_soc: int
    top_groups: int

    # Rare class thresholds
    min_naics_n: int
    min_soc_n: int

    # CV and search
    nfolds_naics: int
    nfolds_major: int
    nfolds_within: int
    model_search: str
    candidate_models: Tuple[str, ...]
    ensemble_size: int
    ensemble_power: float
    optuna_trials_naics: int
    optuna_trials_major: int
    optuna_trials_within: int
    optuna_timeout_seconds: Optional[int]

    # Feature parameters
    max_word_terms: int
    max_char_terms: int
    word_min_count: int
    char_min_count: int
    doc_prop_max: float
    use_embeddings: bool
    embedding_model: str
    embedding_backend: str
    embedding_batch_size: int
    embedding_device: Optional[str]
    embedding_chunk_size: int
    embedding_progress_every: int
    embedding_cache_dir: str
    svd_components: int

    # Base model parameters
    logreg_C: float
    logreg_max_iter: int
    sgd_alpha: float
    sgd_max_iter: int
    sgd_tol: float
    linearsvc_C: float
    boost_n_estimators: int
    boost_max_classes: int
    boost_max_features: int

    # Scoring/write behavior
    score_batch_size: int
    min_write_confidence_naics: float
    min_write_confidence_soc: float
    # Fill every missing target cell when scoring. Existing non-missing values
    # are still preserved unless overwrite flags are used.
    fill_all_missing: bool
    score_rows_without_text: bool
    fallback_fill_missing: bool
    missing_soc_values: Tuple[int, ...]
    missing_naics_values: Tuple[str, ...]


@dataclass
class CandidateScore:
    name: str
    macro_f1: Optional[float]
    log_loss_value: Optional[float]
    failed: bool
    reason: str = ""
    total_seconds: Optional[float] = None
    fold_seconds: List[float] = field(default_factory=list)
    fold_macro_f1: List[float] = field(default_factory=list)
    fold_log_loss: List[float] = field(default_factory=list)


@dataclass
class FittedClassifier:
    stage_name: str
    model_names: List[str]
    estimators: List[Any]
    weights: List[float]
    classes: np.ndarray
    cv_scores: List[CandidateScore]
    n_rows: int
    n_features: int
    n_classes: int

    @property
    def model_name(self) -> str:
        return "+".join(self.model_names)

    @property
    def cv_macro_f1(self) -> Optional[float]:
        vals = [s.macro_f1 for s in self.cv_scores if s.name in self.model_names and s.macro_f1 is not None]
        if not vals:
            return None
        return float(np.average(vals, weights=self.weights[:len(vals)] if len(vals) == len(self.weights) else None))

    @property
    def cv_log_loss(self) -> Optional[float]:
        vals = [s.log_loss_value for s in self.cv_scores if s.name in self.model_names and s.log_loss_value is not None and np.isfinite(s.log_loss_value)]
        if not vals:
            return None
        return float(np.mean(vals))

    def predict_proba(self, x: sp.spmatrix) -> np.ndarray:
        out = np.zeros((x.shape[0], len(self.classes)), dtype=np.float64)
        total_w = 0.0
        for est, w in zip(self.estimators, self.weights):
            p = estimator_predict_proba(est, x, self.classes)
            out += float(w) * p
            total_w += float(w)
        if total_w <= 0:
            total_w = 1.0
        out /= total_w
        row_sum = out.sum(axis=1)
        bad = row_sum <= 0
        if np.any(bad):
            out[bad, :] = 1.0 / max(1, out.shape[1])
            row_sum = out.sum(axis=1)
        return out / row_sum[:, None]



class BinaryConfidenceCalibrator:
    """Small pickle-safe calibrator for the final, fused top-label confidence."""

    def __init__(self, method: str = "sigmoid") -> None:
        self.method = str(method)
        self.model: Any = None
        self.constant_: Optional[float] = None
        self.n_: int = 0

    @staticmethod
    def _logit(x: np.ndarray) -> np.ndarray:
        x = np.clip(np.asarray(x, dtype=float), 1e-6, 1.0 - 1e-6)
        return np.log(x / (1.0 - x)).reshape(-1, 1)

    def fit(self, confidence: Sequence[float], correct: Sequence[bool]) -> "BinaryConfidenceCalibrator":
        x = np.asarray(confidence, dtype=float)
        y = np.asarray(correct, dtype=int)
        good = np.isfinite(x)
        x = np.clip(x[good], 0.0, 1.0)
        y = y[good]
        self.n_ = int(len(y))
        if len(y) == 0:
            self.constant_ = 0.0
            return self
        if np.unique(y).size < 2 or np.unique(x).size < 3:
            self.constant_ = float(y.mean())
            return self
        method = self.method
        if method == "auto":
            method = "isotonic" if len(y) >= 1000 and np.unique(x).size >= 20 else "sigmoid"
        try:
            if method == "isotonic":
                self.model = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
                self.model.fit(x, y)
                self.method = "isotonic"
            else:
                self.model = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000, random_state=42)
                self.model.fit(self._logit(x), y)
                self.method = "sigmoid"
        except Exception:
            self.model = None
            self.constant_ = float(y.mean())
        return self

    def predict(self, confidence: Sequence[float]) -> np.ndarray:
        x = np.clip(np.asarray(confidence, dtype=float), 0.0, 1.0)
        if self.constant_ is not None:
            return np.full_like(x, float(self.constant_), dtype=float)
        if self.model is None:
            return x
        try:
            if self.method == "isotonic":
                return np.clip(np.asarray(self.model.predict(x), dtype=float), 0.0, 1.0)
            return np.clip(np.asarray(self.model.predict_proba(self._logit(x))[:, 1], dtype=float), 0.0, 1.0)
        except Exception:
            return x


class CandidateFusionRanker:
    """Pickle-safe candidate-level stacking model.

    The Gold audit showed a large gap between top-1 and top-4 accuracy. This
    ranker learns which candidate is correct from the ML, semantic, and
    Cross-Encoder component scores on a sealed calibration partition. It is
    intentionally tiny: the expensive representation learning has already
    happened, so a regularized logistic stacker is less likely to overfit than
    adding another heavyweight classifier.
    """

    def __init__(self, random_seed: int = 42) -> None:
        self.random_seed = int(random_seed)
        self.model: Any = None
        self.n_rows_: int = 0
        self.positive_rate_: float = 0.0
        self.feature_names_: Tuple[str, ...] = (
            "ml", "semantic", "cross_encoder",
            "rr_ml", "rr_semantic", "rr_cross_encoder",
            "component_max", "component_sum", "agreement_count",
            "ml_x_ce", "semantic_x_ce", "ml_x_semantic", "candidate_position",
        )

    @staticmethod
    def _rank_reciprocal(values: np.ndarray) -> np.ndarray:
        if values.size == 0:
            return values
        order = np.argsort(-values, kind="stable")
        ranks = np.empty(len(values), dtype=float)
        ranks[order] = np.arange(1, len(values) + 1, dtype=float)
        return 1.0 / ranks

    def row_features(self, ml: Sequence[float], sem: Sequence[float], ce: Sequence[float]) -> np.ndarray:
        ml_a = np.maximum(np.asarray(ml, dtype=float), 0.0)
        sem_a = np.maximum(np.asarray(sem, dtype=float), 0.0)
        ce_a = np.maximum(np.asarray(ce, dtype=float), 0.0)
        n = min(len(ml_a), len(sem_a), len(ce_a))
        ml_a, sem_a, ce_a = ml_a[:n], sem_a[:n], ce_a[:n]
        rr_ml = self._rank_reciprocal(ml_a)
        rr_sem = self._rank_reciprocal(sem_a)
        rr_ce = self._rank_reciprocal(ce_a)
        agreement = (ml_a > 0).astype(float) + (sem_a > 0).astype(float) + (ce_a > 0).astype(float)
        position = 1.0 / np.arange(1, n + 1, dtype=float)
        return np.column_stack([
            ml_a, sem_a, ce_a,
            rr_ml, rr_sem, rr_ce,
            np.maximum.reduce([ml_a, sem_a, ce_a]), ml_a + sem_a + ce_a, agreement,
            ml_a * ce_a, sem_a * ce_a, ml_a * sem_a, position,
        ]).astype(np.float32, copy=False)

    def fit(self, x: np.ndarray, y: np.ndarray) -> "CandidateFusionRanker":
        x = np.asarray(x, dtype=np.float32)
        y = np.asarray(y, dtype=int)
        self.n_rows_ = int(len(y))
        self.positive_rate_ = float(y.mean()) if len(y) else 0.0
        if len(y) < 100 or np.unique(y).size < 2:
            return self
        try:
            self.model = LogisticRegression(
                C=0.5,
                solver="lbfgs",
                class_weight="balanced",
                max_iter=1000,
                random_state=self.random_seed,
            )
            self.model.fit(x, y)
        except Exception:
            self.model = None
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=np.float32)
        if self.model is None:
            # Smooth fallback that still rewards multi-source agreement.
            if x.size == 0:
                return np.asarray([], dtype=float)
            return np.maximum(1e-9, 0.45 * x[:, 0] + 0.20 * x[:, 1] + 0.35 * x[:, 2] + 0.03 * x[:, 8])
        try:
            return np.asarray(self.model.predict_proba(x)[:, 1], dtype=float)
        except Exception:
            return np.maximum(1e-9, 0.45 * x[:, 0] + 0.20 * x[:, 1] + 0.35 * x[:, 2])


# ---------------------------------------------------------------------
# General helpers
# ---------------------------------------------------------------------

class TeeStream:
    """Mirror stdout/stderr to a file while keeping live terminal output visible."""
    def __init__(self, stream: Any, log_file: Any) -> None:
        self.stream = stream
        self.log_file = log_file

    def write(self, data: str) -> int:
        self.stream.write(data)
        self.log_file.write(data)
        self.flush()
        return len(data)

    def flush(self) -> None:
        try:
            self.stream.flush()
        except Exception:
            pass
        try:
            self.log_file.flush()
        except Exception:
            pass

    def isatty(self) -> bool:
        return bool(getattr(self.stream, "isatty", lambda: False)())

    @property
    def encoding(self) -> str:
        return getattr(self.stream, "encoding", "utf-8") or "utf-8"


def setup_console_log(path: str) -> None:
    if not path:
        return
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    log_file = open(path, "a", encoding="utf-8", buffering=1)
    sys.stdout = TeeStream(sys.stdout, log_file)
    sys.stderr = TeeStream(sys.stderr, log_file)
    print(f"[console_log] Mirroring live terminal output to: {path}", flush=True)


def eprint(msg: str) -> None:
    print(msg, flush=True)


def parse_csv_ints(s: Optional[str]) -> Tuple[int, ...]:
    if s is None or str(s).strip() == "":
        return tuple()
    out: List[int] = []
    for part in str(s).split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(int(float(part)))
        except Exception:
            pass
    return tuple(out)


def parse_csv_strs(s: Optional[str]) -> Tuple[str, ...]:
    if s is None or str(s).strip() == "":
        return tuple()
    return tuple(p.strip() for p in str(s).split(",") if p.strip())


def recommend_max_workers(raw_value: Optional[str]) -> int:
    logical = os.cpu_count() or 1
    raw = "auto" if raw_value is None else str(raw_value).strip().lower()
    if raw == "auto":
        # Designed for the user's Latitude 5550 class machine: 18 logical processors.
        # Keep room for Windows/SPSS/disk cache and avoid nested native thread storms.
        if logical >= 18:
            return 6
        if logical >= 14:
            return 5
        if logical >= 10:
            return 4
        if logical >= 6:
            return 3
        return 1
    val = int(raw)
    return max(1, min(val, logical))


def now_stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def clean_code_value(value: Any) -> Optional[str]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, (np.integer, int)):
        return str(int(value))
    if isinstance(value, (np.floating, float)):
        if not np.isfinite(value):
            return None
        if abs(value - round(value)) < 1e-8:
            return str(int(round(value)))
        return str(value).strip()
    s = str(value).strip()
    if not s:
        return None
    # SPSS numeric values sometimes arrive as "123.0" after conversions.
    if re.fullmatch(r"\d+\.0+", s):
        return str(int(float(s)))
    return s


def clean_code_series(s: pd.Series) -> pd.Series:
    return s.map(clean_code_value).astype("object")


def cat_to_string_series(s: pd.Series) -> pd.Series:
    return clean_code_series(s)


def soc6_to_major2(soc6: Any) -> Optional[int]:
    try:
        x = int(round(float(soc6)))
    except Exception:
        return None
    if x < 100000 or x > 999999:
        return None
    return int(x // 10000)


def format_soc(value: Any) -> str:
    try:
        if value is None or pd.isna(value):
            return "MISSING"
    except Exception:
        pass
    try:
        x = int(round(float(value)))
        if 0 <= x <= 999999:
            return f"{x:06d}"
    except Exception:
        pass
    return str(value)


def format_code(value: Any) -> str:
    cv = clean_code_value(value)
    return cv if cv is not None else "MISSING"


def is_missing_soc_series(s: pd.Series, missing_soc_values: Sequence[int]) -> pd.Series:
    x = pd.to_numeric(s, errors="coerce")
    miss = x.isna() | (x < 100000) | (x > 999999)
    xi = x.fillna(-1).round().astype(np.int64)
    major = xi // 10000
    miss = miss | (~major.isin(list(VALID_SOC_MAJOR_GROUPS)))
    if missing_soc_values:
        miss = miss | x.isin(list(missing_soc_values))
    return miss


def is_missing_code_series(s: pd.Series, missing_values: Sequence[str]) -> pd.Series:
    codes = clean_code_series(s)
    miss = codes.isna() | codes.map(lambda v: str(v).strip() in COMMON_CODE_MISSINGS if v is not None else True)
    if missing_values:
        miss = miss | codes.isin(list(missing_values))
    return miss


def sparse_nbytes(x: sp.spmatrix) -> int:
    x = x.tocsr()
    return int(x.data.nbytes + x.indices.nbytes + x.indptr.nbytes)


def make_one_hot_encoder() -> OneHotEncoder:
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=True, dtype=np.float32)
    except TypeError:
        return OneHotEncoder(handle_unknown="ignore", sparse=True, dtype=np.float32)


def safe_top_indices(row: np.ndarray, k: int) -> np.ndarray:
    k = max(1, min(int(k), row.size))
    if row.size <= k:
        return np.argsort(-row)
    idx = np.argpartition(-row, kth=k - 1)[:k]
    return idx[np.argsort(-row[idx])]


def batched_indices(idxs: np.ndarray, batch_size: int) -> Iterable[np.ndarray]:
    batch_size = max(1, int(batch_size))
    for start in range(0, len(idxs), batch_size):
        yield idxs[start:start + batch_size]


def filter_meta_dict(d: Optional[Dict[str, Any]], columns: Sequence[str]) -> Optional[Dict[str, Any]]:
    if not d:
        return None
    out = {k: v for k, v in d.items() if k in columns}
    return out or None


def has_any_normalized_text(df: pd.DataFrame, cols: Sequence[str]) -> np.ndarray:
    present = np.zeros(len(df), dtype=bool)
    for c in cols:
        if c not in df.columns:
            continue
        present |= df[c].map(lambda v: len(normalize_text(v)) > 0).to_numpy(dtype=bool)
    return present


def sanitize_hf_token_env() -> None:
    """Remove obviously empty or smart-quoted HF_TOKEN values.

    A blank/smart-quoted token such as “ ” can override a valid cached login
    and make Hugging Face model loading fail in surprising ways.
    """
    tok = os.environ.get("HF_TOKEN")
    if tok is None:
        return
    cleaned = tok.strip().strip('"').strip("\'").strip("“").strip("”").strip()
    if cleaned == "" or tok.strip() in {"“”", "\"\"", "''"}:
        os.environ.pop("HF_TOKEN", None)
        eprint("[preflight] Removed empty/smart-quoted HF_TOKEN from this process; cached HF login or public model access will be used.")


def process_memory_gb() -> Optional[float]:
    if not HAS_PSUTIL:
        return None
    try:
        return float(psutil.Process(os.getpid()).memory_info().rss) / (1024 ** 3)
    except Exception:
        return None


def _safe_cache_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name))[:120]


def _embedding_cache_path(cache_dir: str, name: str, model_name: str, backend: str, docs: Sequence[str]) -> Optional[str]:
    if not cache_dir:
        return None
    try:
        os.makedirs(cache_dir, exist_ok=True)
        h = hashlib.sha256()
        h.update(str(model_name).encode("utf-8", errors="ignore"))
        h.update(b"\0")
        h.update(str(backend).encode("utf-8", errors="ignore"))
        h.update(b"\0")
        h.update(str(len(docs)).encode("ascii"))
        for d in docs:
            h.update(b"\0")
            h.update(str(d).encode("utf-8", errors="ignore"))
        return os.path.join(cache_dir, f"{_safe_cache_name(name)}_{h.hexdigest()[:24]}.npy")
    except Exception:
        return None


def encode_docs_chunked(
    model: Any,
    docs: Sequence[str],
    *,
    batch_size: int,
    chunk_size: int,
    progress_every: int,
    cache_dir: str,
    cache_name: str,
    model_name: str,
    backend: str,
) -> np.ndarray:
    """Encode documents in chunks with stdout progress and optional disk cache.

    This avoids silent multi-hour embedding phases and prevents tqdm stderr from
    being mistaken for a PowerShell NativeCommandError.
    """
    docs_list = list(docs)
    n = len(docs_list)
    cache_path = _embedding_cache_path(cache_dir, cache_name, model_name, backend, docs_list)
    if cache_path and os.path.exists(cache_path):
        try:
            eprint(f"[{cache_name}] Loading cached embeddings: {cache_path}")
            return np.load(cache_path).astype(np.float32, copy=False)
        except Exception as exc:
            eprint(f"[{cache_name}] WARNING: could not load embedding cache ({exc}); re-encoding.")
    if n == 0:
        return np.zeros((0, 0), dtype=np.float32)
    chunk_size = int(chunk_size or 0)
    if chunk_size <= 0:
        chunk_size = max(512, int(batch_size) * 32)
    progress_every = max(1, int(progress_every or chunk_size))
    parts: List[np.ndarray] = []
    t0 = time.time()
    next_report = 0
    for start in range(0, n, chunk_size):
        end = min(n, start + chunk_size)
        arr = model.encode(
            docs_list[start:end],
            batch_size=int(batch_size),
            show_progress_bar=False,
            normalize_embeddings=True,
            convert_to_numpy=True,
        ).astype(np.float32, copy=False)
        parts.append(arr)
        if end >= next_report or end == n:
            mem = process_memory_gb()
            mem_txt = f" | RSS={mem:.1f} GB" if mem is not None else ""
            elapsed = max(1e-6, time.time() - t0)
            rate = end / elapsed
            eprint(f"[{cache_name}] Encoded {end:,}/{n:,} texts ({rate:.1f} texts/sec){mem_txt}")
            next_report = end + progress_every
    emb = np.vstack(parts).astype(np.float32, copy=False)
    norms = np.linalg.norm(emb, axis=1, keepdims=True)
    norms[norms <= 0] = 1.0
    emb = emb / norms
    if cache_path:
        try:
            np.save(cache_path, emb)
            eprint(f"[{cache_name}] Saved embedding cache: {cache_path}")
        except Exception as exc:
            eprint(f"[{cache_name}] WARNING: could not save embedding cache ({exc}).")
    return emb


def build_label_baseline(values: Sequence[Any], topn: int = 100, code_kind: str = "code") -> Dict[str, Any]:
    cleaned: List[Any] = []
    for v in values:
        if code_kind == "soc":
            try:
                x = int(round(float(v)))
                if 100000 <= x <= 999999 and soc6_to_major2(x) in VALID_SOC_MAJOR_GROUPS:
                    cleaned.append(x)
            except Exception:
                continue
        else:
            cv = clean_code_value(v)
            if cv is not None and str(cv).strip() not in COMMON_CODE_MISSINGS:
                cleaned.append(str(cv))
    counts = Counter(cleaned)
    total = float(sum(counts.values()))
    if total <= 0:
        return {"codes": [], "prob": [], "n": 0}
    ordered = counts.most_common(max(1, int(topn)))
    return {
        "codes": [code for code, _ in ordered],
        "prob": [float(n / total) for _, n in ordered],
        "n": int(total),
    }


def apply_naics_baseline_fallback(pred: Dict[str, Any], baseline: Optional[Dict[str, Any]], cfg: TrainConfig) -> Dict[str, Any]:
    if not cfg.fallback_fill_missing or not baseline or not baseline.get("codes"):
        return pred
    codes = [str(c) for c in baseline.get("codes", [])]
    probs = [float(p) for p in baseline.get("prob", [])]
    top_code = pred["top_code"]
    top_prob = pred["top_prob"]
    filled = 0
    for i in range(len(top_code)):
        if top_code[i][0] is not None:
            continue
        k = min(cfg.topk_naics, len(codes))
        for r in range(k):
            top_code[i][r] = codes[r]
            top_prob[i, r] = probs[r] if r < len(probs) else 0.0
        filled += 1
    if filled:
        eprint(f"[NAICS] Baseline fallback supplied predictions for {filled} rows with no model/dictionary candidate")
    return pred


def apply_soc_baseline_fallback(pred: Dict[str, Any], baseline: Optional[Dict[str, Any]], cfg: TrainConfig) -> Dict[str, Any]:
    if not cfg.fallback_fill_missing or not baseline or not baseline.get("codes"):
        return pred
    codes = [int(c) for c in baseline.get("codes", [])]
    probs = [float(p) for p in baseline.get("prob", [])]
    top_soc = pred["top_soc"]
    top_prob = pred["top_prob"]
    filled = 0
    for i in range(top_soc.shape[0]):
        if int(top_soc[i, 0]) > 0:
            continue
        k = min(cfg.topk_soc, len(codes))
        for r in range(k):
            top_soc[i, r] = codes[r]
            top_prob[i, r] = probs[r] if r < len(probs) else 0.0
        filled += 1
    if filled:
        eprint(f"[SOC] Baseline fallback supplied predictions for {filled} rows with no model/dictionary candidate")
    return pred


# ---------------------------------------------------------------------
# Adaptive historical rule memory
# ---------------------------------------------------------------------

CORPORATE_SUFFIX_RE = re.compile(
    r"(?:\s+|^)(?:incorporated|inc|llc|l\s*l\s*c|corporation|corp|company|co|limited|ltd|"
    r"plc|llp|lp|p\s*c|pc|professional\s+corporation)\.?$",
    flags=re.IGNORECASE,
)
BRANCH_NUMBER_RE = re.compile(r"\b(?:store|location|branch|unit|site|facility)\s*(?:no\.?|number|#)?\s*\d+[a-z0-9-]*\b", re.IGNORECASE)
DBA_RE = re.compile(r"\b(?:d\s*/?\s*b\s*/?\s*a|doing\s+business\s+as)\b", re.IGNORECASE)
LEADING_ARTICLE_RE = re.compile(r"^(?:the)\s+", re.IGNORECASE)


def _unicode_ascii(value: Any) -> str:
    s = str(value)
    s = unicodedata.normalize("NFKD", s)
    return "".join(ch for ch in s if not unicodedata.combining(ch))


def normalize_text(value: Any) -> str:
    """Deterministic general text normalization used by features and rules."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = _unicode_ascii(value).strip().lower()
    if not s:
        return ""
    s = s.replace("&", " and ")
    s = NON_ALNUM_RE.sub(" ", s)
    s = SPACE_RE.sub(" ", s).strip()
    for pattern, repl in ABBREV_MAP:
        s = re.sub(pattern, repl, s)
    return SPACE_RE.sub(" ", s).strip()


def normalize_employer_text(value: Any, compact: bool = False, strip_branch_numbers: bool = True) -> str:
    """Canonicalize employer names without deleting industry-bearing words."""
    s = normalize_text(value)
    if not s:
        return ""
    s = DBA_RE.sub(" ", s)
    if strip_branch_numbers:
        s = BRANCH_NUMBER_RE.sub(" ", s)
    s = LEADING_ARTICLE_RE.sub("", s)
    # Remove repeated legal suffixes only at the end of the name.
    previous = None
    while s and s != previous:
        previous = s
        s = CORPORATE_SUFFIX_RE.sub("", s).strip()
    s = SPACE_RE.sub(" ", s).strip()
    if compact:
        # Hy-Vee / Hy Vee / HyVee converge to the same employer key.
        return re.sub(r"[^a-z0-9]+", "", s)
    return s


def normalize_location_text(value: Any) -> str:
    s = normalize_text(value)
    if not s:
        return ""
    # Keep city/state semantics while removing common administrative noise.
    s = re.sub(r"\b(?:city\s+of|town\s+of|village\s+of)\b", " ", s)
    return SPACE_RE.sub(" ", s).strip()


def normalize_field_text(value: Any, field_name: str, prefix: str = "") -> str:
    name = str(field_name or "").lower()
    pfx = str(prefix or "").upper()
    if name in {"qa20", "employer", "employer_name"} or "EMPLOYER" in pfx:
        return normalize_employer_text(value, compact=False)
    if name in {"qe2b", "city", "location", "workcity"} or "WORKCITY" in pfx or "LOCATION" in pfx:
        return normalize_location_text(value)
    return normalize_text(value)


def wilson_lower_bound(successes: float, total: float, confidence_level: float = 0.95) -> float:
    """Wilson lower confidence bound for a binomial proportion."""
    if total <= 0:
        return 0.0
    p = min(1.0, max(0.0, float(successes) / float(total)))
    z = NormalDist().inv_cdf(0.5 + float(confidence_level) / 2.0)
    z2 = z * z
    denom = 1.0 + z2 / total
    centre = p + z2 / (2.0 * total)
    margin = z * math.sqrt(max(0.0, (p * (1.0 - p) + z2 / (4.0 * total)) / total))
    return max(0.0, min(1.0, (centre - margin) / denom))


def _parse_memory_dates(series: pd.Series) -> pd.Series:
    if pd.api.types.is_datetime64_any_dtype(series):
        return pd.to_datetime(series, errors="coerce")
    numeric = pd.to_numeric(series, errors="coerce")
    finite = numeric[np.isfinite(numeric)]
    if len(finite) > 0:
        med = float(np.nanmedian(finite))
        # A plain survey year.
        if 1900 <= med <= 2200:
            years = numeric.round().astype("Int64").astype("string")
            return pd.to_datetime(years + "-07-01", errors="coerce")
        # Common YYYYMMDD encoding.
        if 19000101 <= med <= 22001231:
            return pd.to_datetime(numeric.round().astype("Int64").astype("string"), format="%Y%m%d", errors="coerce")
        # SPSS date/time numerics are seconds since 1582-10-14.
        if med > 1_000_000:
            try:
                return pd.to_datetime(numeric, unit="s", origin=pd.Timestamp("1582-10-14"), errors="coerce")
            except Exception:
                pass
    return pd.to_datetime(series, errors="coerce")


def _auto_date_col(df: pd.DataFrame, requested: str) -> Optional[str]:
    requested = str(requested or "").strip()
    if requested and requested.lower() != "auto":
        return requested if requested in df.columns else None
    candidates = [
        "interview_date", "survey_date", "completed_date", "completion_date", "response_date",
        "date", "year", "survey_year", "wave_date", "record_date",
    ]
    lower_map = {str(c).lower(): str(c) for c in df.columns}
    for candidate in candidates:
        if candidate in lower_map:
            return lower_map[candidate]
    return None


def _fit_numeric_memory_bins(df: pd.DataFrame, numeric_cols: Sequence[str], n_bins: int) -> Dict[str, List[float]]:
    bins: Dict[str, List[float]] = {}
    for col in numeric_cols:
        if col not in df.columns:
            continue
        values = pd.to_numeric(df[col], errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
        if len(values) < 20:
            continue
        q = np.linspace(0.0, 1.0, max(2, int(n_bins)) + 1)[1:-1]
        cuts = sorted(set(float(v) for v in np.quantile(values.to_numpy(dtype=float), q) if np.isfinite(v)))
        if cuts:
            bins[col] = cuts
    return bins


def _numeric_memory_value(value: Any, cuts: Sequence[float]) -> str:
    try:
        x = float(value)
        if not np.isfinite(x):
            return "MISSING"
    except Exception:
        return "MISSING"
    return f"bin{int(np.searchsorted(np.asarray(cuts, dtype=float), x, side='right'))}"


def _memory_field_value(
    value: Any,
    field: str,
    field_kind: str,
    numeric_bins: Dict[str, List[float]],
    strip_branch_numbers: bool,
) -> str:
    if field_kind == "employer":
        return normalize_employer_text(value, compact=True, strip_branch_numbers=strip_branch_numbers) or "MISSING"
    if field_kind == "location":
        return normalize_location_text(value) or "MISSING"
    if field_kind == "numeric":
        return _numeric_memory_value(value, numeric_bins.get(field, [])) if field in numeric_bins else (clean_code_value(value) or "MISSING")
    if field_kind == "code":
        return clean_code_value(value) or "MISSING"
    return normalize_text(value) or "MISSING"


def _normalize_target_code(value: Any, kind: str) -> Optional[str]:
    c = clean_code_value(value)
    if c is None:
        return None
    if kind == "soc":
        try:
            x = int(round(float(c)))
        except Exception:
            return None
        if x < 100000 or x > 999999 or x // 10000 not in VALID_SOC_MAJOR_GROUPS:
            return None
        return f"{x:06d}"
    # NAICS partial constraints require digit-only codes; exact rules may retain a clean code.
    if re.fullmatch(r"\d{2,6}", c):
        return c
    return c if c not in COMMON_CODE_MISSINGS else None


def _hierarchy_levels(kind: str, labels: Sequence[str]) -> List[int]:
    if kind == "soc":
        return [2, 3, 5]
    numeric_lengths = [len(v) for v in labels if re.fullmatch(r"\d{2,6}", str(v))]
    max_len = max(numeric_lengths) if numeric_lengths else 0
    return [level for level in [2, 3, 4, 5] if level < max_len]


def _adaptive_templates(target: str, kind: str, cfg: Any) -> List[Tuple[str, List[str]]]:
    employer = str(getattr(cfg, "memory_employer_col", "qa20"))
    q4 = str(getattr(cfg, "memory_qe4_col", "qe4"))
    q5 = str(getattr(cfg, "memory_qe5_col", "qe5a"))
    naics = str(getattr(cfg, "memory_naics_col", "qa20a"))
    locations = list(getattr(cfg, "memory_location_cols", ("qe2b",)))
    numerics = list(getattr(cfg, "memory_numeric_cols", ("qe10",)))
    loc = locations[0] if locations else "qe2b"
    num = numerics[0] if numerics else "qe10"
    if kind == "naics":
        return [
            ("employer_title_location_numeric", [employer, q4, loc, num]),
            ("employer_title_location", [employer, q4, loc]),
            ("employer_title_selfemp", [employer, q4, "qe8aoth"]),
            ("employer_title", [employer, q4]),
            ("selfemp_title_location_numeric", ["qe8aoth", q4, loc, num]),
            ("selfemp_title_location", ["qe8aoth", q4, loc]),
            ("selfemp_title", ["qe8aoth", q4]),
            ("industry_title_location", ["qe1oth", q4, loc]),
            ("industry_title", ["qe1oth", q4]),
            ("employer_location", [employer, loc]),
            ("employer", [employer]),
            ("title_location_numeric", [q4, loc, num]),
            ("title_location", [q4, loc]),
            ("title", [q4]),
            ("selfemp_categorical_location", ["qe8a", "qe1", loc]),
            ("industry_categorical", ["qe1", "qse1", "qe8a"]),
        ]
    title = q4 if target == getattr(cfg, "memory_qe4ar_col", "qe4ar") else q5
    prefix = "soc_qe4" if title == q4 else "soc_qe5"
    return [
        (f"{prefix}_title_employer_naics_location_numeric", [title, employer, naics, loc, num]),
        (f"{prefix}_title_employer_naics_location", [title, employer, naics, loc]),
        (f"{prefix}_title_employer_naics", [title, employer, naics]),
        (f"{prefix}_title_naics_location_numeric", [title, naics, loc, num]),
        (f"{prefix}_title_naics_location", [title, naics, loc]),
        (f"{prefix}_title_employer_location", [title, employer, loc]),
        (f"{prefix}_title_naics", [title, naics]),
        (f"{prefix}_title_employer", [title, employer]),
        (f"{prefix}_title_location_numeric", [title, loc, num]),
        (f"{prefix}_title_location", [title, loc]),
        (f"{prefix}_title", [title]),
        (f"{prefix}_naics_education", [naics, "qa9", "qa9ar"]),
    ]


def _memory_field_kinds(cfg: Any, templates: Sequence[Tuple[str, Sequence[str]]]) -> Dict[str, str]:
    employer = str(getattr(cfg, "memory_employer_col", "qa20"))
    locations = set(getattr(cfg, "memory_location_cols", ("qe2b",)))
    numerics = set(getattr(cfg, "memory_numeric_cols", ("qe10",)))
    code_fields = {
        str(getattr(cfg, "memory_naics_col", "qa20a")), "qe1", "qse1", "qe8a", "wh2", "qe8",
        "qa9", "qa9ar", "qe13", "qa6",
    }
    kinds: Dict[str, str] = {}
    for _, fields in templates:
        for field in fields:
            if field == employer:
                kinds[field] = "employer"
            elif field in locations:
                kinds[field] = "location"
            elif field in numerics:
                kinds[field] = "numeric"
            elif field in code_fields:
                kinds[field] = "code"
            else:
                kinds[field] = "text"
    return kinds


def _memory_weights(df: pd.DataFrame, cfg: Any) -> Tuple[np.ndarray, Optional[pd.Series], Optional[str], Dict[str, Any]]:
    weights = np.ones(len(df), dtype=np.float64)
    date_col = _auto_date_col(df, getattr(cfg, "memory_date_col", "auto"))
    dates: Optional[pd.Series] = None
    diagnostics: Dict[str, Any] = {"date_col": date_col, "temporal_decay": False}
    if date_col is not None:
        dates = _parse_memory_dates(df[date_col])
        valid = dates.notna().to_numpy(dtype=bool)
        if valid.any():
            reference_text = str(getattr(cfg, "memory_reference_date", "") or "").strip()
            reference = pd.to_datetime(reference_text, errors="coerce") if reference_text else dates.max()
            if pd.isna(reference):
                reference = dates.max()
            age_years = ((reference - dates).dt.total_seconds() / (365.25 * 86400.0)).clip(lower=0)
            rolling_years = float(getattr(cfg, "memory_rolling_years", 5.0))
            half_life = float(getattr(cfg, "memory_half_life_years", 2.5))
            eligible = valid.copy()
            if rolling_years > 0:
                eligible &= age_years.fillna(np.inf).to_numpy(dtype=float) <= rolling_years
            weights[:] = 0.0
            if half_life > 0:
                weights[eligible] = np.power(0.5, age_years.fillna(np.inf).to_numpy(dtype=float)[eligible] / half_life)
            else:
                weights[eligible] = 1.0
            diagnostics.update({
                "temporal_decay": True,
                "reference_date": str(pd.Timestamp(reference).date()),
                "rolling_years": rolling_years,
                "half_life_years": half_life,
                "eligible_rows": int(eligible.sum()),
                "invalid_date_rows": int((~valid).sum()),
            })
    verified_col = str(getattr(cfg, "memory_verified_col", "") or "").strip()
    if verified_col and verified_col in df.columns:
        verified = df[verified_col].map(lambda v: str(v).strip().lower() in {"1", "true", "yes", "y", "verified", "reviewed", "approved"}).to_numpy(dtype=bool)
        weights[verified] *= float(getattr(cfg, "memory_verified_weight", 2.0))
        diagnostics["verified_col"] = verified_col
        diagnostics["verified_rows"] = int(verified.sum())
    return weights, dates, date_col, diagnostics


def _effective_n(total_weight: float, sum_weight_sq: float) -> float:
    if total_weight <= 0 or sum_weight_sq <= 0:
        return 0.0
    return float(total_weight * total_weight / sum_weight_sq)


def _mine_variant_rules(
    keys: Sequence[str],
    labels: Sequence[Optional[str]],
    weights: np.ndarray,
    dates: Optional[pd.Series],
    target: str,
    template: str,
    fields: Sequence[str],
    is_exact: bool,
    code_level: int,
    threshold: float,
    cfg: Any,
) -> List[Dict[str, Any]]:
    label_weights: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    label_counts: Dict[str, Counter] = defaultdict(Counter)
    total_wsq: Dict[str, float] = defaultdict(float)
    latest_date: Dict[str, pd.Timestamp] = {}
    raw_total: Counter = Counter()
    for i, (key, label) in enumerate(zip(keys, labels)):
        if not key or label is None:
            continue
        w = float(weights[i])
        if w <= 0:
            continue
        label_weights[key][str(label)] += w
        label_counts[key][str(label)] += 1
        total_wsq[key] += w * w
        raw_total[key] += 1
        if dates is not None and not pd.isna(dates.iloc[i]):
            dt = pd.Timestamp(dates.iloc[i])
            if key not in latest_date or dt > latest_date[key]:
                latest_date[key] = dt
    rules: List[Dict[str, Any]] = []
    min_count = int(getattr(cfg, "memory_min_count", 5))
    min_effective_n = float(getattr(cfg, "memory_min_effective_n", 8.0))
    confidence_level = float(getattr(cfg, "memory_confidence_level", 0.95))
    for key, weighted in label_weights.items():
        total_weight = float(sum(weighted.values()))
        neff = _effective_n(total_weight, total_wsq[key])
        if raw_total[key] < min_count or neff < min_effective_n:
            continue
        ordered = sorted(weighted.items(), key=lambda kv: kv[1], reverse=True)
        top_label, top_weight = ordered[0]
        raw_counts = label_counts[key]
        purity = top_weight / total_weight if total_weight > 0 else 0.0
        lower = wilson_lower_bound(purity * neff, neff, confidence_level)
        if lower < threshold:
            continue
        alternatives = []
        for code, w in ordered[1:6]:
            alternatives.append({
                "code": str(code),
                "weighted_prob": float(w / total_weight),
                "count": int(raw_counts[code]),
            })
        specificity = len(fields)
        priority = specificity * 1_000_000.0 + code_level * 10_000.0 + lower * 1_000.0 + math.log1p(neff) * 10.0
        rules.append({
            "target": target,
            "template": template,
            "fields": list(fields),
            "key": key,
            "prediction": str(top_label),
            "is_exact": bool(is_exact),
            "code_level": int(code_level),
            "specificity": int(specificity),
            "purity": float(purity),
            "wilson_lower": float(lower),
            "weighted_support": float(top_weight),
            "weighted_total": float(total_weight),
            "effective_n": float(neff),
            "support": int(raw_counts[top_label]),
            "total": int(raw_total[key]),
            "latest_date": str(latest_date[key].date()) if key in latest_date else "",
            "alternatives": alternatives,
            "priority": float(priority),
        })
    max_rules = int(getattr(cfg, "memory_max_rules_per_template", 50000))
    rules.sort(key=lambda r: (r["specificity"], r["code_level"], r["wilson_lower"], r["effective_n"], r["weighted_support"]), reverse=True)
    return rules[:max_rules] if max_rules > 0 else rules


def _build_prefix_baselines(labels: Sequence[str], weights: np.ndarray, kind: str) -> Dict[str, Dict[str, List[Any]]]:
    levels = _hierarchy_levels(kind, labels)
    buckets: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for label, w in zip(labels, weights):
        if label is None or w <= 0:
            continue
        label_s = str(label)
        if not label_s.isdigit():
            continue
        for level in levels:
            if len(label_s) >= level:
                buckets[label_s[:level]][label_s] += float(w)
    result: Dict[str, Dict[str, List[Any]]] = {}
    for prefix, counts in buckets.items():
        ordered = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:100]
        total = sum(w for _, w in ordered) or 1.0
        result[prefix] = {
            "codes": [code for code, _ in ordered],
            "prob": [float(w / total) for _, w in ordered],
        }
    return result


def _build_adaptive_rule_memory_core(
    df: pd.DataFrame,
    labels: Sequence[Any],
    target: str,
    kind: str,
    templates: Sequence[Tuple[str, Sequence[str]]],
    cfg: Any,
) -> Dict[str, Any]:
    normalized_labels = [_normalize_target_code(v, kind) for v in labels]
    field_kinds = _memory_field_kinds(cfg, templates)
    numeric_cols = list(getattr(cfg, "memory_numeric_cols", ("qe10",)))
    numeric_bins = _fit_numeric_memory_bins(df, numeric_cols, int(getattr(cfg, "memory_numeric_bins", 6)))
    weights, dates, date_col, temporal_diag = _memory_weights(df, cfg)
    unique_fields = sorted({field for _, fields in templates for field in fields if field in df.columns})
    normalized_fields: Dict[str, pd.Series] = {}
    for field in unique_fields:
        kind_name = field_kinds.get(field, "text")
        normalized_fields[field] = df[field].map(
            lambda v, f=field, k=kind_name: _memory_field_value(
                v, f, k, numeric_bins, bool(getattr(cfg, "memory_strip_branch_numbers", True))
            )
        )
    exact_threshold = float(getattr(cfg, "memory_exact_wilson_naics", 0.80) if kind == "naics" else getattr(cfg, "memory_exact_wilson_soc", 0.82))
    partial_threshold = float(getattr(cfg, "memory_partial_wilson_min", 0.88))
    partial_levels = _hierarchy_levels(kind, [v for v in normalized_labels if v is not None])
    rules: List[Dict[str, Any]] = []
    for template, fields in templates:
        if not all(field in normalized_fields for field in fields):
            continue
        valid = np.ones(len(df), dtype=bool)
        key_series: Optional[pd.Series] = None
        for field in fields:
            vals = normalized_fields[field].astype(str)
            valid &= vals.ne("MISSING").to_numpy(dtype=bool)
            key_series = vals if key_series is None else key_series.str.cat(vals, sep="||")
        if key_series is None:
            continue
        keys = key_series.where(valid, "").tolist()
        exact_rules = _mine_variant_rules(
            keys, normalized_labels, weights, dates, target, template, fields,
            True, 99, exact_threshold, cfg,
        )
        rules.extend(exact_rules)
        if bool(getattr(cfg, "memory_use_partial_constraints", True)):
            for level in partial_levels:
                prefix_labels = [v[:level] if v is not None and v.isdigit() and len(v) >= level else None for v in normalized_labels]
                rules.extend(_mine_variant_rules(
                    keys, prefix_labels, weights, dates, target, template, fields,
                    False, level, partial_threshold, cfg,
                ))
    rules_by_template: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(lambda: defaultdict(list))
    for rule in rules:
        rules_by_template[rule["template"]][rule["key"]].append(rule)
    for template_map in rules_by_template.values():
        for key_rules in template_map.values():
            key_rules.sort(
                key=lambda r: (r["specificity"], r["is_exact"], r["code_level"], r["wilson_lower"], r["effective_n"]),
                reverse=True,
            )
    memory = {
        "version": "2026.07.10.adaptive-rule-memory",
        "target": target,
        "kind": kind,
        "templates": [(name, list(fields)) for name, fields in templates],
        "field_kinds": field_kinds,
        "numeric_bins": numeric_bins,
        "rules": rules,
        "rules_by_template": {t: dict(m) for t, m in rules_by_template.items()},
        "prefix_baselines": _build_prefix_baselines([v for v in normalized_labels if v is not None], weights[np.array([v is not None for v in normalized_labels], dtype=bool)], kind),
        "settings": {
            "exact_wilson_min": exact_threshold,
            "partial_wilson_min": partial_threshold,
            "hard_constraint_min": float(getattr(cfg, "memory_hard_constraint_min", 0.92)),
            "partial_boost": float(getattr(cfg, "memory_partial_boost", 4.0)),
            "candidate_pool": int(getattr(cfg, "memory_candidate_pool", 24)),
            "strip_branch_numbers": bool(getattr(cfg, "memory_strip_branch_numbers", True)),
        },
        "temporal": temporal_diag,
        "rule_counts": {
            "total": len(rules),
            "exact": int(sum(bool(r["is_exact"]) for r in rules)),
            "partial": int(sum(not bool(r["is_exact"]) for r in rules)),
        },
        "validation": {},
    }
    return memory


def _resolve_adaptive_rule_memory(memory: Optional[Dict[str, Any]], df: pd.DataFrame) -> Dict[str, Any]:
    n = len(df)
    empty = {
        "matched": np.zeros(n, dtype=bool),
        "exact": np.zeros(n, dtype=bool),
        "prediction": [None] * n,
        "prefix": [None] * n,
        "confidence": np.zeros(n, dtype=np.float32),
        "wilson_lower": np.zeros(n, dtype=np.float32),
        "template": [""] * n,
        "specificity": np.zeros(n, dtype=np.int16),
        "code_level": np.zeros(n, dtype=np.int16),
        "hard": np.zeros(n, dtype=bool),
        "conflicts": np.zeros(n, dtype=np.int16),
        "alternatives": [[] for _ in range(n)],
    }
    if not memory or not memory.get("rules"):
        return empty
    templates = memory.get("templates", [])
    field_kinds = memory.get("field_kinds", {})
    numeric_bins = memory.get("numeric_bins", {})
    strip_branch = bool(memory.get("settings", {}).get("strip_branch_numbers", True))
    unique_fields = sorted({field for _, fields in templates for field in fields if field in df.columns})
    normalized_fields: Dict[str, pd.Series] = {}
    for field in unique_fields:
        kind_name = field_kinds.get(field, "text")
        normalized_fields[field] = df[field].map(
            lambda v, f=field, k=kind_name: _memory_field_value(v, f, k, numeric_bins, strip_branch)
        )
    matches_by_row: List[List[Dict[str, Any]]] = [[] for _ in range(n)]
    rules_by_template = memory.get("rules_by_template", {})
    for template, fields in templates:
        if template not in rules_by_template or not all(field in normalized_fields for field in fields):
            continue
        valid = np.ones(n, dtype=bool)
        key_series: Optional[pd.Series] = None
        for field in fields:
            vals = normalized_fields[field].astype(str)
            valid &= vals.ne("MISSING").to_numpy(dtype=bool)
            key_series = vals if key_series is None else key_series.str.cat(vals, sep="||")
        if key_series is None:
            continue
        template_rules = rules_by_template[template]
        for pos, (is_valid, key) in enumerate(zip(valid.tolist(), key_series.tolist())):
            if not is_valid:
                continue
            candidates = template_rules.get(key)
            if candidates:
                matches_by_row[pos].extend(candidates)
    hard_min = float(memory.get("settings", {}).get("hard_constraint_min", 0.92))
    for i, matches in enumerate(matches_by_row):
        if not matches:
            continue
        matches.sort(
            key=lambda r: (r["specificity"], r["is_exact"], r["code_level"], r["wilson_lower"], r["effective_n"], r["weighted_support"]),
            reverse=True,
        )
        chosen = matches[0]
        same_specificity = [r for r in matches if r["specificity"] == chosen["specificity"] and r["code_level"] == chosen["code_level"]]
        predictions = {str(r["prediction"]) for r in same_specificity}
        empty["matched"][i] = True
        empty["exact"][i] = bool(chosen["is_exact"])
        empty["prediction"][i] = str(chosen["prediction"]) if chosen["is_exact"] else None
        empty["prefix"][i] = None if chosen["is_exact"] else str(chosen["prediction"])
        empty["confidence"][i] = float(chosen["wilson_lower"])
        empty["wilson_lower"][i] = float(chosen["wilson_lower"])
        empty["template"][i] = str(chosen["template"])
        empty["specificity"][i] = int(chosen["specificity"])
        empty["code_level"][i] = int(chosen["code_level"])
        empty["hard"][i] = (not bool(chosen["is_exact"])) and float(chosen["wilson_lower"]) >= hard_min
        empty["conflicts"][i] = max(0, len(predictions) - 1)
        empty["alternatives"][i] = list(chosen.get("alternatives", []))
    return empty


def _validate_adaptive_memory(
    df: pd.DataFrame,
    labels: Sequence[Any],
    target: str,
    kind: str,
    templates: Sequence[Tuple[str, Sequence[str]]],
    cfg: Any,
) -> Dict[str, Any]:
    fraction = float(getattr(cfg, "memory_validation_fraction", 0.10))
    if fraction <= 0 or len(df) < 200:
        return {}
    normalized = np.asarray([_normalize_target_code(v, kind) for v in labels], dtype=object)
    valid_idx = np.where(pd.notna(normalized))[0]
    if len(valid_idx) < 100:
        return {}
    date_col = _auto_date_col(df, getattr(cfg, "memory_date_col", "auto"))
    if date_col is not None:
        dates = _parse_memory_dates(df[date_col])
        order = np.argsort(dates.fillna(pd.Timestamp.min).to_numpy())
        split = max(1, int(len(order) * (1.0 - fraction)))
        train_idx, val_idx = order[:split], order[split:]
        method = "temporal"
    else:
        rng = np.random.default_rng(int(getattr(cfg, "random_seed", 42)))
        shuffled = valid_idx.copy()
        rng.shuffle(shuffled)
        split = max(1, int(len(shuffled) * (1.0 - fraction)))
        train_idx, val_idx = shuffled[:split], shuffled[split:]
        method = "random"
    if len(val_idx) < 20 or len(train_idx) < 100:
        return {}
    cfg_copy = cfg
    memory = _build_adaptive_rule_memory_core(df.iloc[train_idx].reset_index(drop=True), normalized[train_idx], target, kind, templates, cfg_copy)
    resolved = _resolve_adaptive_rule_memory(memory, df.iloc[val_idx].reset_index(drop=True))
    y_val = normalized[val_idx]
    exact_mask = resolved["exact"]
    partial_mask = resolved["matched"] & (~resolved["exact"])
    exact_correct = [str(resolved["prediction"][i]) == str(y_val[i]) for i in range(len(val_idx)) if exact_mask[i]]
    partial_correct = [str(y_val[i]).startswith(str(resolved["prefix"][i])) for i in range(len(val_idx)) if partial_mask[i] and y_val[i] is not None]
    return {
        "method": method,
        "validation_rows": int(len(val_idx)),
        "exact_coverage": float(np.mean(exact_mask)) if len(val_idx) else 0.0,
        "exact_accuracy": float(np.mean(exact_correct)) if exact_correct else None,
        "partial_coverage": float(np.mean(partial_mask)) if len(val_idx) else 0.0,
        "partial_prefix_accuracy": float(np.mean(partial_correct)) if partial_correct else None,
    }


def build_adaptive_rule_memory(
    df: pd.DataFrame,
    labels: Sequence[Any],
    target: str,
    kind: str,
    cfg: Any,
) -> Optional[Dict[str, Any]]:
    if not bool(getattr(cfg, "use_adaptive_memory", True)):
        return None
    templates = _adaptive_templates(target, kind, cfg)
    eprint(f"[{target} adaptive-memory] Mining specificity/Wilson/temporal rules from {len(df):,} coded rows...")
    validation = _validate_adaptive_memory(df, labels, target, kind, templates, cfg)
    memory = _build_adaptive_rule_memory_core(df.reset_index(drop=True), labels, target, kind, templates, cfg)
    memory["validation"] = validation
    counts = memory.get("rule_counts", {})
    eprint(
        f"[{target} adaptive-memory] rules={counts.get('total', 0):,} "
        f"exact={counts.get('exact', 0):,} partial={counts.get('partial', 0):,} "
        f"temporal={memory.get('temporal', {}).get('temporal_decay', False)}"
    )
    if validation:
        eprint(
            f"[{target} adaptive-memory] holdout method={validation.get('method')} "
            f"exact_coverage={validation.get('exact_coverage', 0):.1%} "
            f"exact_accuracy={validation.get('exact_accuracy')} "
            f"partial_coverage={validation.get('partial_coverage', 0):.1%} "
            f"partial_prefix_accuracy={validation.get('partial_prefix_accuracy')}"
        )
    return memory


def _memory_prefix_candidates(memory: Dict[str, Any], prefix: str, topk: int) -> Tuple[List[Any], List[float]]:
    entry = memory.get("prefix_baselines", {}).get(str(prefix))
    if not entry:
        return [], []
    codes = list(entry.get("codes", []))[:topk]
    probs = list(entry.get("prob", []))[:topk]
    total = sum(float(p) for p in probs) or 1.0
    return codes, [float(p) / total for p in probs]


def _constrain_candidates_by_memory(
    codes: Sequence[Any],
    probs: Sequence[float],
    memory: Dict[str, Any],
    prefix: Optional[str],
    hard: bool,
    confidence: float,
    topk: int,
) -> Tuple[List[Any], List[float], str]:
    if not prefix:
        out_codes = list(codes)[:topk]
        out_probs = list(probs)[:topk]
        return out_codes + [None] * max(0, topk - len(out_codes)), out_probs + [0.0] * max(0, topk - len(out_probs)), ""
    pairs = [(c, float(p)) for c, p in zip(codes, probs) if c is not None]
    matching = [(c, p) for c, p in pairs if str(c).startswith(str(prefix))]
    if hard:
        selected = matching
        mode = "adaptive_partial_hard"
    else:
        boost = float(memory.get("settings", {}).get("partial_boost", 4.0)) * max(0.0, float(confidence))
        selected = [(c, p * (1.0 + boost if str(c).startswith(str(prefix)) else 1.0)) for c, p in pairs]
        mode = "adaptive_partial_soft"
    if not selected:
        base_codes, base_probs = _memory_prefix_candidates(memory, str(prefix), topk)
        selected = list(zip(base_codes, base_probs))
        mode += "_baseline"
    selected.sort(key=lambda cp: cp[1], reverse=True)
    selected = selected[:topk]
    total = sum(p for _, p in selected) or 1.0
    out_codes = [c for c, _ in selected]
    out_probs = [float(p / total) for _, p in selected]
    return out_codes + [None] * max(0, topk - len(out_codes)), out_probs + [0.0] * max(0, topk - len(out_probs)), mode


def apply_adaptive_memory_to_naics_prediction(
    pred: Dict[str, Any], score_df: pd.DataFrame, model_obj: Dict[str, Any], cfg: Any, requested_topk: int
) -> Dict[str, Any]:
    memory = model_obj.get("adaptive_memory")
    resolved = _resolve_adaptive_rule_memory(memory, score_df)
    n = len(score_df)
    old_codes = pred["top_code"]
    old_probs = pred["top_prob"]
    # If a hard partial rule has no match in the ordinary top candidate pool,
    # perform a targeted second pass against every NAICS class under the prefix.
    targeted: Dict[int, Tuple[List[Any], List[float]]] = {}
    hard_missing = [
        i for i in range(n)
        if resolved["hard"][i] and resolved["prefix"][i]
        and not any(c is not None and str(c).startswith(str(resolved["prefix"][i])) for c in old_codes[i])
    ]
    if hard_missing:
        try:
            feat: HybridFeaturizer = model_obj["featurizer"]
            clf: FittedClassifier = model_obj["classifier"]
            classes = np.asarray(clf.classes)
            for batch_idx in batched_indices(np.asarray(hard_missing, dtype=int), max(1, int(cfg.score_batch_size))):
                xs = feat.transform(score_df.iloc[batch_idx])
                p_all = clf.predict_proba(xs)
                for local, global_i in enumerate(batch_idx.tolist()):
                    prefix = str(resolved["prefix"][global_i])
                    mask = np.asarray([str(c).startswith(prefix) for c in classes], dtype=bool)
                    if mask.any():
                        valid_idx = np.where(mask)[0]
                        order = valid_idx[np.argsort(-p_all[local, valid_idx])[:requested_topk]]
                        probs = p_all[local, order].astype(float)
                        total = float(probs.sum()) or 1.0
                        targeted[global_i] = ([str(classes[j]) for j in order.tolist()], (probs / total).tolist())
                del xs
                gc.collect()
        except Exception as exc:
            eprint(f"[NAICS adaptive-memory] Targeted prefix pass skipped after error: {exc}")
    new_codes: List[List[Optional[str]]] = [[None] * requested_topk for _ in range(n)]
    new_probs = np.zeros((n, requested_topk), dtype=np.float32)
    source = ["model"] * n
    for i in range(n):
        if resolved["exact"][i] and resolved["prediction"][i] is not None:
            code = str(resolved["prediction"][i])
            codes = [code]
            probs = [float(resolved["confidence"][i])]
            for alt in resolved["alternatives"][i]:
                alt_code = alt.get("code")
                if alt_code is not None and str(alt_code) != code:
                    codes.append(str(alt_code))
                    probs.append(float(alt.get("weighted_prob", 0.0)))
            codes = codes[:requested_topk]
            probs = probs[:requested_topk]
            source[i] = "adaptive_exact"
        else:
            candidate_codes, candidate_probs = targeted.get(i, (old_codes[i], old_probs[i].tolist()))
            codes, probs, mode = _constrain_candidates_by_memory(
                candidate_codes, candidate_probs, memory or {}, resolved["prefix"][i],
                bool(resolved["hard"][i]), float(resolved["confidence"][i]), requested_topk,
            )
            if i in targeted and mode:
                mode = "adaptive_partial_hard_targeted"
            if mode:
                source[i] = mode
            elif bool(pred.get("dict_used", np.zeros(n, dtype=bool))[i]):
                source[i] = "dictionary"
        for rank in range(requested_topk):
            new_codes[i][rank] = str(codes[rank]) if rank < len(codes) and codes[rank] is not None else None
            new_probs[i, rank] = float(probs[rank]) if rank < len(probs) else 0.0
    pred["top_code"] = new_codes
    pred["top_prob"] = new_probs
    pred["adaptive_memory"] = resolved
    pred["prediction_source"] = source
    eprint(
        f"[NAICS adaptive-memory scoring] exact={int(resolved['exact'].sum()):,} "
        f"partial={int((resolved['matched'] & ~resolved['exact']).sum()):,} "
        f"hard={int(resolved['hard'].sum()):,} conflicts={int((resolved['conflicts'] > 0).sum()):,}"
    )
    return pred


def apply_adaptive_memory_to_soc_prediction(
    pred: Dict[str, Any], score_df: pd.DataFrame, model_obj: Dict[str, Any], cfg: Any, requested_topk: int
) -> Dict[str, Any]:
    memory = model_obj.get("adaptive_memory")
    resolved = _resolve_adaptive_rule_memory(memory, score_df)
    n = len(score_df)
    old_codes = pred["top_soc"]
    old_probs = pred["top_prob"]
    # Hard SOC prefixes trigger a targeted within-major second pass when the
    # ordinary hierarchical top-groups did not return any matching detailed code.
    targeted: Dict[int, Tuple[List[Any], List[float]]] = {}
    hard_missing = [
        i for i in range(n)
        if resolved["hard"][i] and resolved["prefix"][i]
        and not any(int(c) > 0 and str(int(c)).zfill(6).startswith(str(resolved["prefix"][i])) for c in old_codes[i])
    ]
    if hard_missing:
        try:
            feat: HybridFeaturizer = model_obj["featurizer"]
            for batch_idx in batched_indices(np.asarray(hard_missing, dtype=int), max(1, int(cfg.score_batch_size))):
                xs = feat.transform(score_df.iloc[batch_idx])
                for local, global_i in enumerate(batch_idx.tolist()):
                    prefix = str(resolved["prefix"][global_i])
                    major = prefix[:2]
                    wm: Optional[FittedClassifier] = model_obj.get("within_models", {}).get(str(int(major))) if major.isdigit() else None
                    if wm is not None:
                        p_row = wm.predict_proba(xs[local:local+1])[0]
                        classes = np.asarray(wm.classes)
                        mask = np.asarray([str(int(c)).zfill(6).startswith(prefix) for c in classes], dtype=bool)
                        if mask.any():
                            valid_idx = np.where(mask)[0]
                            order = valid_idx[np.argsort(-p_row[valid_idx])[:requested_topk]]
                            probs = p_row[order].astype(float)
                            total = float(probs.sum()) or 1.0
                            targeted[global_i] = ([int(classes[j]) for j in order.tolist()], (probs / total).tolist())
                    if global_i not in targeted:
                        base_codes, base_probs = _memory_prefix_candidates(memory or {}, prefix, requested_topk)
                        if base_codes:
                            targeted[global_i] = ([int(c) for c in base_codes], base_probs)
                del xs
                gc.collect()
        except Exception as exc:
            eprint(f"[{model_obj.get('target_col', 'SOC')} adaptive-memory] Targeted prefix pass skipped after error: {exc}")
    new_codes = np.full((n, requested_topk), -1, dtype=np.int32)
    new_probs = np.zeros((n, requested_topk), dtype=np.float32)
    source = ["model"] * n
    for i in range(n):
        if resolved["exact"][i] and resolved["prediction"][i] is not None:
            codes: List[Any] = [int(resolved["prediction"][i])]
            probs: List[float] = [float(resolved["confidence"][i])]
            for alt in resolved["alternatives"][i]:
                try:
                    alt_code = int(alt.get("code"))
                except Exception:
                    continue
                if alt_code != codes[0]:
                    codes.append(alt_code)
                    probs.append(float(alt.get("weighted_prob", 0.0)))
            codes = codes[:requested_topk]
            probs = probs[:requested_topk]
            source[i] = "adaptive_exact"
        else:
            base_codes = [int(c) if int(c) > 0 else None for c in old_codes[i].tolist()]
            candidate_codes, candidate_probs = targeted.get(i, (base_codes, old_probs[i].tolist()))
            codes, probs, mode = _constrain_candidates_by_memory(
                candidate_codes, candidate_probs, memory or {}, resolved["prefix"][i],
                bool(resolved["hard"][i]), float(resolved["confidence"][i]), requested_topk,
            )
            if i in targeted and mode:
                mode = "adaptive_partial_hard_targeted"
            if mode:
                source[i] = mode
            elif bool(pred.get("dict_used", np.zeros(n, dtype=bool))[i]):
                source[i] = "dictionary"
        for rank in range(requested_topk):
            try:
                new_codes[i, rank] = int(codes[rank]) if rank < len(codes) and codes[rank] is not None else -1
            except Exception:
                new_codes[i, rank] = -1
            new_probs[i, rank] = float(probs[rank]) if rank < len(probs) else 0.0
    pred["top_soc"] = new_codes
    pred["top_prob"] = new_probs
    pred["adaptive_memory"] = resolved
    pred["prediction_source"] = source
    target = str(model_obj.get("target_col", "SOC"))
    eprint(
        f"[{target} adaptive-memory scoring] exact={int(resolved['exact'].sum()):,} "
        f"partial={int((resolved['matched'] & ~resolved['exact']).sum()):,} "
        f"hard={int(resolved['hard'].sum()):,} conflicts={int((resolved['conflicts'] > 0).sum()):,}"
    )
    return pred


def export_adaptive_memory(memory: Optional[Dict[str, Any]], out_dir: str) -> None:
    if not memory or not out_dir:
        return
    os.makedirs(out_dir, exist_ok=True)
    target = re.sub(r"[^A-Za-z0-9_-]+", "_", str(memory.get("target", "target")))
    json_path = os.path.join(out_dir, f"{target}_adaptive_memory.json")
    csv_path = os.path.join(out_dir, f"{target}_adaptive_memory_rules.csv")
    report_path = os.path.join(out_dir, f"{target}_adaptive_memory_report.txt")
    serializable = dict(memory)
    serializable.pop("rules_by_template", None)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2, default=str)
    rows = memory.get("rules", [])
    pd.DataFrame(rows).to_csv(csv_path, index=False, encoding="utf-8-sig")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"Adaptive memory target: {memory.get('target')}\n")
        f.write(json.dumps({
            "rule_counts": memory.get("rule_counts"),
            "temporal": memory.get("temporal"),
            "validation": memory.get("validation"),
            "settings": memory.get("settings"),
        }, indent=2, default=str))
        f.write("\n")
    eprint(f"[{memory.get('target')} adaptive-memory] Exported rules to: {out_dir}")


# ---------------------------------------------------------------------
# Optional estimator wrappers
# ---------------------------------------------------------------------

class XGBLabelEncodedClassifier(BaseEstimator, ClassifierMixin):
    def __init__(
        self,
        n_estimators: int = 250,
        max_depth: int = 5,
        learning_rate: float = 0.05,
        subsample: float = 0.85,
        colsample_bytree: float = 0.85,
        reg_lambda: float = 1.0,
        reg_alpha: float = 0.0,
        n_jobs: int = 1,
        random_state: int = 42,
    ) -> None:
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.subsample = subsample
        self.colsample_bytree = colsample_bytree
        self.reg_lambda = reg_lambda
        self.reg_alpha = reg_alpha
        self.n_jobs = n_jobs
        self.random_state = random_state

    def fit(self, X: sp.spmatrix, y: np.ndarray) -> "XGBLabelEncodedClassifier":
        if not HAS_XGBOOST:
            raise RuntimeError("xgboost is not installed")
        self.encoder_ = LabelEncoder()
        y_enc = self.encoder_.fit_transform(y)
        self.classes_ = self.encoder_.classes_
        self.model_ = xgb.XGBClassifier(
            objective="multi:softprob",
            num_class=len(self.classes_),
            eval_metric="mlogloss",
            tree_method="hist",
            n_estimators=int(self.n_estimators),
            max_depth=int(self.max_depth),
            learning_rate=float(self.learning_rate),
            subsample=float(self.subsample),
            colsample_bytree=float(self.colsample_bytree),
            reg_lambda=float(self.reg_lambda),
            reg_alpha=float(self.reg_alpha),
            n_jobs=int(self.n_jobs),
            random_state=int(self.random_state),
            verbosity=0,
        )
        self.model_.fit(X, y_enc)
        return self

    def predict_proba(self, X: sp.spmatrix) -> np.ndarray:
        return np.asarray(self.model_.predict_proba(X), dtype=np.float64)

    def predict(self, X: sp.spmatrix) -> np.ndarray:
        enc = np.asarray(self.model_.predict(X), dtype=int)
        return self.encoder_.inverse_transform(enc)


class CatBoostLabelEncodedClassifier(BaseEstimator, ClassifierMixin):
    def __init__(
        self,
        iterations: int = 300,
        depth: int = 6,
        learning_rate: float = 0.05,
        l2_leaf_reg: float = 3.0,
        thread_count: int = 1,
        random_state: int = 42,
    ) -> None:
        self.iterations = iterations
        self.depth = depth
        self.learning_rate = learning_rate
        self.l2_leaf_reg = l2_leaf_reg
        self.thread_count = thread_count
        self.random_state = random_state

    def fit(self, X: sp.spmatrix, y: np.ndarray) -> "CatBoostLabelEncodedClassifier":
        if not HAS_CATBOOST:
            raise RuntimeError("catboost is not installed")
        self.encoder_ = LabelEncoder()
        y_enc = self.encoder_.fit_transform(y)
        self.classes_ = self.encoder_.classes_
        self.model_ = CatBoostClassifier(
            loss_function="MultiClass",
            iterations=int(self.iterations),
            depth=int(self.depth),
            learning_rate=float(self.learning_rate),
            l2_leaf_reg=float(self.l2_leaf_reg),
            thread_count=int(self.thread_count),
            random_seed=int(self.random_state),
            verbose=False,
            allow_writing_files=False,
        )
        self.model_.fit(X, y_enc)
        return self

    def predict_proba(self, X: sp.spmatrix) -> np.ndarray:
        return np.asarray(self.model_.predict_proba(X), dtype=np.float64)

    def predict(self, X: sp.spmatrix) -> np.ndarray:
        enc = np.asarray(self.model_.predict(X)).reshape(-1).astype(int)
        return self.encoder_.inverse_transform(enc)


def estimator_predict_proba(estimator: Any, x: sp.spmatrix, expected_classes: np.ndarray) -> np.ndarray:
    expected_classes = np.asarray(expected_classes)
    if hasattr(estimator, "predict_proba"):
        p = np.asarray(estimator.predict_proba(x), dtype=np.float64)
        est_classes = np.asarray(getattr(estimator, "classes_", expected_classes))
        if p.ndim == 1:
            p = p.reshape(-1, 1)
        if len(est_classes) == len(expected_classes) and np.array_equal(est_classes, expected_classes):
            row_sum = p.sum(axis=1)
            bad = row_sum <= 0
            if np.any(bad):
                p[bad, :] = 1.0 / max(1, p.shape[1])
                row_sum = p.sum(axis=1)
            return p / row_sum[:, None]
        out = np.zeros((x.shape[0], len(expected_classes)), dtype=np.float64)
        lookup = {c: i for i, c in enumerate(expected_classes.tolist())}
        for j, c in enumerate(est_classes.tolist()):
            if c in lookup and j < p.shape[1]:
                out[:, lookup[c]] = p[:, j]
        row_sum = out.sum(axis=1)
        bad = row_sum <= 0
        if np.any(bad):
            out[bad, :] = 1.0 / max(1, out.shape[1])
            row_sum = out.sum(axis=1)
        return out / row_sum[:, None]

    if hasattr(estimator, "decision_function"):
        scores = np.asarray(estimator.decision_function(x), dtype=np.float64)
        if scores.ndim == 1:
            p1 = expit(scores)
            p = np.vstack([1.0 - p1, p1]).T
        else:
            p = softmax(scores, axis=1)
        est_classes = np.asarray(getattr(estimator, "classes_", expected_classes))
        out = np.zeros((x.shape[0], len(expected_classes)), dtype=np.float64)
        lookup = {c: i for i, c in enumerate(expected_classes.tolist())}
        for j, c in enumerate(est_classes.tolist()):
            if c in lookup and j < p.shape[1]:
                out[:, lookup[c]] = p[:, j]
        row_sum = out.sum(axis=1)
        bad = row_sum <= 0
        if np.any(bad):
            out[bad, :] = 1.0 / max(1, out.shape[1])
            row_sum = out.sum(axis=1)
        return out / row_sum[:, None]

    pred = estimator.predict(x)
    out = np.zeros((x.shape[0], len(expected_classes)), dtype=np.float64)
    lookup = {c: i for i, c in enumerate(expected_classes.tolist())}
    for i, c in enumerate(pred.tolist()):
        if c in lookup:
            out[i, lookup[c]] = 1.0
        else:
            out[i, :] = 1.0 / max(1, len(expected_classes))
    return out


# ---------------------------------------------------------------------
# Feature creation
# ---------------------------------------------------------------------

class HybridFeaturizer:
    def __init__(
        self,
        text_cols: Sequence[str],
        cat_cols: Sequence[str],
        num_cols: Sequence[str],
        prefixes: Dict[str, str],
        cfg: TrainConfig,
    ) -> None:
        self.text_cols = list(text_cols)
        self.cat_cols = list(cat_cols)
        self.num_cols = list(num_cols)
        self.prefixes = dict(prefixes)
        self.cfg_snapshot = {
            "max_word_terms": int(cfg.max_word_terms),
            "max_char_terms": int(cfg.max_char_terms),
            "word_min_count": int(cfg.word_min_count),
            "char_min_count": int(cfg.char_min_count),
            "doc_prop_max": float(cfg.doc_prop_max),
            "use_embeddings": bool(cfg.use_embeddings),
            "embedding_model": str(cfg.embedding_model),
            "embedding_backend": str(cfg.embedding_backend),
            "embedding_batch_size": int(cfg.embedding_batch_size),
            "embedding_device": cfg.embedding_device,
            "embedding_chunk_size": int(cfg.embedding_chunk_size),
            "embedding_progress_every": int(cfg.embedding_progress_every),
            "embedding_cache_dir": str(cfg.embedding_cache_dir or ""),
            "svd_components": int(cfg.svd_components),
            "random_seed": int(cfg.random_seed),
        }

        self.word_vectorizer: Optional[TfidfVectorizer] = None
        self.char_vectorizer: Optional[TfidfVectorizer] = None
        self.cat_encoder: Optional[OneHotEncoder] = None
        self.num_imputer: Optional[SimpleImputer] = None
        self.num_scaler: Optional[StandardScaler] = None
        self.svd: Optional[TruncatedSVD] = None
        self._sentence_model: Any = None
        self.features_are_nonnegative_: bool = True

    def __getstate__(self) -> Dict[str, Any]:
        state = dict(self.__dict__)
        # Do not pickle the transformer model object. It is large and less stable
        # across machines. The model name/path is saved and lazily reloaded.
        state["_sentence_model"] = None
        return state

    def _make_docs(self, df: pd.DataFrame) -> List[str]:
        docs: List[str] = []
        for _, row in df.iterrows():
            parts: List[str] = []
            for c in self.text_cols:
                if c not in df.columns:
                    continue
                prefix = self.prefixes.get(c, "")
                v = normalize_field_text(row.get(c), c, prefix)
                if not v:
                    continue
                parts.append(f"{prefix} {v}".strip())
            doc = " | ".join(parts).strip()
            docs.append(doc if doc else "__EMPTY__")
        return docs

    def _embed_docs(self, docs: List[str], fit: bool = False) -> sp.csr_matrix:
        if not self.cfg_snapshot["use_embeddings"]:
            return sp.csr_matrix((len(docs), 0), dtype=np.float32)
        if not HAS_SENTENCE_TRANSFORMERS:
            raise RuntimeError("--use_embeddings was requested, but sentence-transformers is not installed")
        if self._sentence_model is None:
            kwargs: Dict[str, Any] = {}
            device = self.cfg_snapshot.get("embedding_device")
            if device:
                kwargs["device"] = device
            backend = str(self.cfg_snapshot.get("embedding_backend", "torch")).lower()
            if backend in {"onnx", "openvino"}:
                try:
                    self._sentence_model = SentenceTransformer(self.cfg_snapshot["embedding_model"], backend=backend, **kwargs)
                except TypeError:
                    eprint(f"WARNING: sentence-transformers backend={backend} is not supported by this install; falling back to torch backend.")
                    self._sentence_model = SentenceTransformer(self.cfg_snapshot["embedding_model"], **kwargs)
                except Exception as exc:
                    eprint(f"WARNING: failed to load embedding backend={backend} ({exc}); falling back to torch backend.")
                    self._sentence_model = SentenceTransformer(self.cfg_snapshot["embedding_model"], **kwargs)
            else:
                self._sentence_model = SentenceTransformer(self.cfg_snapshot["embedding_model"], **kwargs)
        cache_name = "feature_embeddings_fit" if fit else "feature_embeddings_score"
        # Cache only fit-time embeddings. Scoring batches can be many small slices,
        # and caching each slice would create unnecessary cache confetti.
        cache_dir = str(self.cfg_snapshot.get("embedding_cache_dir", "")) if fit else ""
        emb = encode_docs_chunked(
            self._sentence_model,
            docs,
            batch_size=int(self.cfg_snapshot["embedding_batch_size"]),
            chunk_size=int(self.cfg_snapshot.get("embedding_chunk_size", 0)),
            progress_every=int(self.cfg_snapshot.get("embedding_progress_every", 0)),
            cache_dir=cache_dir,
            cache_name=cache_name,
            model_name=str(self.cfg_snapshot["embedding_model"]),
            backend=str(self.cfg_snapshot.get("embedding_backend", "torch")),
        )
        return sp.csr_matrix(emb, dtype=np.float32)

    def fit_transform(self, df: pd.DataFrame) -> sp.csr_matrix:
        df = df.copy()
        docs = self._make_docs(df)

        self.word_vectorizer = TfidfVectorizer(
            lowercase=False,
            ngram_range=(1, 2),
            min_df=int(self.cfg_snapshot["word_min_count"]),
            max_df=float(self.cfg_snapshot["doc_prop_max"]),
            max_features=int(self.cfg_snapshot["max_word_terms"]),
            sublinear_tf=True,
            dtype=np.float32,
        )
        x_word = self.word_vectorizer.fit_transform(docs).astype(np.float32)

        self.char_vectorizer = TfidfVectorizer(
            lowercase=False,
            analyzer="char_wb",
            ngram_range=(3, 5),
            min_df=int(self.cfg_snapshot["char_min_count"]),
            max_df=float(self.cfg_snapshot["doc_prop_max"]),
            max_features=int(self.cfg_snapshot["max_char_terms"]),
            sublinear_tf=True,
            dtype=np.float32,
        )
        x_char = self.char_vectorizer.fit_transform(docs).astype(np.float32)

        if self.cat_cols:
            cat_df = pd.DataFrame(index=df.index)
            for c in self.cat_cols:
                if c in df.columns:
                    cat_df[c] = cat_to_string_series(df[c]).fillna("MISSING").astype(str)
                else:
                    cat_df[c] = "MISSING"
            self.cat_encoder = make_one_hot_encoder()
            x_cat = self.cat_encoder.fit_transform(cat_df).astype(np.float32)
        else:
            x_cat = sp.csr_matrix((len(df), 0), dtype=np.float32)

        if self.num_cols:
            num_df = pd.DataFrame(index=df.index)
            for c in self.num_cols:
                if c in df.columns:
                    num_df[c] = pd.to_numeric(df[c], errors="coerce")
                else:
                    num_df[c] = np.nan
            self.num_imputer = SimpleImputer(strategy="median")
            self.num_scaler = StandardScaler(with_mean=True, with_std=True)
            arr = self.num_imputer.fit_transform(num_df)
            arr = self.num_scaler.fit_transform(arr).astype(np.float32)
            x_num = sp.csr_matrix(arr, dtype=np.float32)
        else:
            x_num = sp.csr_matrix((len(df), 0), dtype=np.float32)

        pieces: List[sp.spmatrix] = [x_word, x_char, x_cat, x_num]

        if int(self.cfg_snapshot["svd_components"]) > 0 and (x_word.shape[1] + x_char.shape[1]) > 2:
            x_text = sp.hstack([x_word, x_char], format="csr", dtype=np.float32)
            n_comp = min(int(self.cfg_snapshot["svd_components"]), max(1, min(x_text.shape) - 1))
            if n_comp > 0:
                self.svd = TruncatedSVD(n_components=n_comp, random_state=int(self.cfg_snapshot["random_seed"]))
                x_svd = self.svd.fit_transform(x_text).astype(np.float32)
                pieces.append(sp.csr_matrix(x_svd, dtype=np.float32))
                self.features_are_nonnegative_ = False

        x_emb = self._embed_docs(docs, fit=True)
        if x_emb.shape[1] > 0:
            pieces.append(x_emb)
            self.features_are_nonnegative_ = False

        return sp.hstack(pieces, format="csr", dtype=np.float32)

    def transform(self, df: pd.DataFrame) -> sp.csr_matrix:
        if self.word_vectorizer is None or self.char_vectorizer is None:
            raise RuntimeError("Featurizer has not been fitted")
        df = df.copy()
        docs = self._make_docs(df)
        x_word = self.word_vectorizer.transform(docs).astype(np.float32)
        x_char = self.char_vectorizer.transform(docs).astype(np.float32)

        if self.cat_cols and self.cat_encoder is not None:
            cat_df = pd.DataFrame(index=df.index)
            for c in self.cat_cols:
                if c in df.columns:
                    cat_df[c] = cat_to_string_series(df[c]).fillna("MISSING").astype(str)
                else:
                    cat_df[c] = "MISSING"
            x_cat = self.cat_encoder.transform(cat_df).astype(np.float32)
        else:
            x_cat = sp.csr_matrix((len(df), 0), dtype=np.float32)

        if self.num_cols and self.num_imputer is not None and self.num_scaler is not None:
            num_df = pd.DataFrame(index=df.index)
            for c in self.num_cols:
                if c in df.columns:
                    num_df[c] = pd.to_numeric(df[c], errors="coerce")
                else:
                    num_df[c] = np.nan
            arr = self.num_imputer.transform(num_df)
            arr = self.num_scaler.transform(arr).astype(np.float32)
            x_num = sp.csr_matrix(arr, dtype=np.float32)
        else:
            x_num = sp.csr_matrix((len(df), 0), dtype=np.float32)

        pieces: List[sp.spmatrix] = [x_word, x_char, x_cat, x_num]
        if self.svd is not None:
            x_text = sp.hstack([x_word, x_char], format="csr", dtype=np.float32)
            x_svd = self.svd.transform(x_text).astype(np.float32)
            pieces.append(sp.csr_matrix(x_svd, dtype=np.float32))
        x_emb = self._embed_docs(docs, fit=False)
        if x_emb.shape[1] > 0:
            pieces.append(x_emb)
        return sp.hstack(pieces, format="csr", dtype=np.float32)


# ---------------------------------------------------------------------
# High-purity dictionaries
# ---------------------------------------------------------------------

def build_exact_dictionary(
    df: pd.DataFrame,
    target_values: Sequence[Any],
    key_specs: Sequence[Tuple[str, Sequence[str]]],
    min_count: int,
) -> Dict[str, Dict[str, Any]]:
    y = [clean_code_value(v) for v in target_values]
    out: Dict[str, Dict[str, Any]] = {}
    for spec_name, cols in key_specs:
        if not all(c in df.columns for c in cols):
            continue
        buckets: Dict[str, List[str]] = defaultdict(list)
        for pos, (_, row) in enumerate(df.iterrows()):
            parts: List[str] = []
            for c in cols:
                val = normalize_text(row.get(c)) if df[c].dtype == "object" else format_code(row.get(c))
                parts.append(val if val else "MISSING")
            key_body = "||".join(parts)
            if not key_body or key_body.replace("MISSING", "").replace("||", "") == "":
                continue
            target = y[pos]
            if target is not None and target not in COMMON_CODE_MISSINGS:
                buckets[f"{spec_name}::{key_body}"].append(target)
        for key, vals in buckets.items():
            if len(vals) < min_count:
                continue
            counts = Counter(vals)
            total = float(sum(counts.values()))
            ordered = counts.most_common()
            out[key] = {
                "top": ordered[0][0],
                "top_prob": float(ordered[0][1] / total),
                "alts": [{"code": code, "prob": float(n / total)} for code, n in ordered[1:6]],
                "n": int(total),
            }
    return out


def exact_dictionary_predict(
    df: pd.DataFrame,
    dictionary: Dict[str, Dict[str, Any]],
    key_specs: Sequence[Tuple[str, Sequence[str]]],
    purity: float,
    min_count: int,
    topk: int,
) -> Dict[str, Any]:
    n = len(df)
    pred: List[Optional[str]] = [None] * n
    conf = np.zeros(n, dtype=np.float32)
    used = np.zeros(n, dtype=bool)
    alts: List[List[Dict[str, Any]]] = [[] for _ in range(n)]
    if not dictionary:
        return {"pred": pred, "conf": conf, "used": used, "alts": alts}

    for pos, (_, row) in enumerate(df.iterrows()):
        for spec_name, cols in key_specs:
            if not all(c in df.columns for c in cols):
                continue
            parts: List[str] = []
            for c in cols:
                val = normalize_text(row.get(c)) if df[c].dtype == "object" else format_code(row.get(c))
                parts.append(val if val else "MISSING")
            key = f"{spec_name}::{'||'.join(parts)}"
            entry = dictionary.get(key)
            if entry and entry["n"] >= min_count and entry["top_prob"] >= purity:
                pred[pos] = str(entry["top"])
                conf[pos] = float(entry["top_prob"])
                used[pos] = True
                alts[pos] = list(entry.get("alts", []))[:max(0, topk - 1)]
                break
    return {"pred": pred, "conf": conf, "used": used, "alts": alts}


def build_soc_title_naics_dictionary(
    df: pd.DataFrame,
    title_col: str,
    naics_col: str,
    y_soc: Sequence[int],
    min_count: int,
    cfg: TrainConfig,
) -> Dict[str, Any]:
    exact: Dict[str, Dict[str, Any]] = {}
    fuzzy_buckets: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(dict)
    if title_col not in df.columns:
        return {"exact": exact, "fuzzy_buckets": {}}

    titles = df[title_col].map(normalize_text).tolist()
    if naics_col in df.columns:
        naics_vals = cat_to_string_series(df[naics_col]).fillna("MISSING").astype(str).tolist()
    else:
        naics_vals = ["MISSING"] * len(df)
    buckets: Dict[str, List[int]] = defaultdict(list)
    title_bucket_counts: Dict[Tuple[str, str], List[int]] = defaultdict(list)

    for t, nv, soc in zip(titles, naics_vals, y_soc):
        if not t:
            continue
        key = f"{t}||{nv}"
        buckets[key].append(int(soc))
        title_bucket_counts[(str(nv), t)].append(int(soc))
        # Also learn a title-only fallback for cases where NAICS is missing/new.
        buckets[f"{t}||MISSING"].append(int(soc))
        title_bucket_counts[("MISSING", t)].append(int(soc))

    for key, vals in buckets.items():
        if len(vals) < min_count:
            continue
        counts = Counter(vals)
        total = float(sum(counts.values()))
        ordered = counts.most_common()
        exact[key] = {
            "top_soc": int(ordered[0][0]),
            "top_prob": float(ordered[0][1] / total),
            "top_alts": [{"soc": int(soc), "prob": float(n / total)} for soc, n in ordered[1:6]],
            "n": int(total),
        }

    if cfg.use_fuzzy_dictionary and HAS_RAPIDFUZZ:
        for (nv, title), vals in title_bucket_counts.items():
            if len(vals) < min_count:
                continue
            counts = Counter(vals)
            total = float(sum(counts.values()))
            ordered = counts.most_common()
            entry = {
                "title": title,
                "top_soc": int(ordered[0][0]),
                "top_prob": float(ordered[0][1] / total),
                "top_alts": [{"soc": int(soc), "prob": float(n / total)} for soc, n in ordered[1:6]],
                "n": int(total),
            }
            if entry["top_prob"] >= cfg.dict_purity:
                fuzzy_buckets[str(nv)][title] = entry
        # Cap each bucket to avoid huge fuzzy scans.
        cap = int(cfg.fuzzy_max_choices_per_bucket)
        if cap > 0:
            for nv in list(fuzzy_buckets.keys()):
                items = sorted(fuzzy_buckets[nv].items(), key=lambda kv: kv[1]["n"], reverse=True)[:cap]
                fuzzy_buckets[nv] = dict(items)

    return {"exact": exact, "fuzzy_buckets": dict(fuzzy_buckets)}


def soc_dictionary_predict(
    df: pd.DataFrame,
    dictionary: Dict[str, Any],
    title_col: str,
    naics_col: str,
    purity: float,
    min_count: int,
    cfg: TrainConfig,
) -> Dict[str, Any]:
    n = len(df)
    pred = np.full(n, -1, dtype=np.int32)
    conf = np.zeros(n, dtype=np.float32)
    used = np.zeros(n, dtype=bool)
    alts: List[List[Dict[str, Any]]] = [[] for _ in range(n)]
    exact = dictionary.get("exact", {}) if dictionary else {}
    fuzzy_buckets = dictionary.get("fuzzy_buckets", {}) if dictionary else {}
    if not exact and not fuzzy_buckets:
        return {"pred": pred, "conf": conf, "used": used, "alts": alts}
    if title_col not in df.columns:
        return {"pred": pred, "conf": conf, "used": used, "alts": alts}

    titles = df[title_col].map(normalize_text).tolist()
    naics_vals = cat_to_string_series(df[naics_col]).fillna("MISSING").astype(str).tolist() if naics_col in df.columns else ["MISSING"] * n
    for i, (t, nv) in enumerate(zip(titles, naics_vals)):
        if not t:
            continue
        entry = exact.get(f"{t}||{nv}") or exact.get(f"{t}||MISSING")
        if entry and entry["n"] >= min_count and entry["top_prob"] >= purity:
            pred[i] = int(entry["top_soc"])
            conf[i] = float(entry["top_prob"])
            used[i] = True
            alts[i] = list(entry.get("top_alts", []))[:max(0, cfg.topk_soc - 1)]
            continue

        if cfg.use_fuzzy_dictionary and HAS_RAPIDFUZZ and fuzzy_buckets:
            choices = fuzzy_buckets.get(str(nv)) or fuzzy_buckets.get("MISSING")
            if choices:
                match = rf_process.extractOne(t, choices.keys(), scorer=fuzz.token_sort_ratio, score_cutoff=int(cfg.fuzzy_threshold))
                if match:
                    matched_title = match[0]
                    entry = choices.get(matched_title)
                    if entry and entry["n"] >= min_count and entry["top_prob"] >= purity:
                        # Penalize confidence slightly by fuzzy similarity.
                        sim = float(match[1]) / 100.0
                        pred[i] = int(entry["top_soc"])
                        conf[i] = float(entry["top_prob"] * sim)
                        used[i] = True
                        alts[i] = list(entry.get("top_alts", []))[:max(0, cfg.topk_soc - 1)]
    return {"pred": pred, "conf": conf, "used": used, "alts": alts}


# ---------------------------------------------------------------------
# Semantic dense-vector memory and local LLM reranking
# ---------------------------------------------------------------------

def make_docs_from_columns(df: pd.DataFrame, text_cols: Sequence[str], prefixes: Dict[str, str]) -> List[str]:
    docs: List[str] = []
    for _, row in df.iterrows():
        parts: List[str] = []
        for c in text_cols:
            if c not in df.columns:
                continue
            prefix = prefixes.get(c, "")
            v = normalize_field_text(row.get(c), c, prefix)
            if not v:
                continue
            parts.append(f"{prefix} {v}".strip())
        docs.append(" | ".join(parts).strip() or "__EMPTY__")
    return docs


def _detect_first_existing(columns: Sequence[str], candidates: Sequence[str]) -> Optional[str]:
    lower_to_orig = {str(c).lower(): c for c in columns}
    for c in candidates:
        if c.lower() in lower_to_orig:
            return lower_to_orig[c.lower()]
    return None


def load_reference_codebook(path: str, kind: str) -> Tuple[List[str], List[Any]]:
    """Load an optional SOC/NAICS reference codebook.

    Accepts CSV/XLSX with flexible column names. Useful columns include:
    code/soc/soc_code/naics/naics_code, title/name/occupation/industry,
    description/definition/tasks/examples.
    """
    if not path:
        return [], []
    if not os.path.exists(path):
        eprint(f"WARNING: reference codebook not found: {path}")
        return [], []
    try:
        if path.lower().endswith(('.xlsx', '.xls')):
            ref = pd.read_excel(path)
        else:
            ref = pd.read_csv(path)
    except Exception as exc:
        eprint(f"WARNING: could not read reference codebook {path}: {exc}")
        return [], []
    if ref.empty:
        return [], []
    if kind.lower() == "soc":
        code_col = _detect_first_existing(ref.columns, ["soc", "soc_code", "soc6", "code", "occupation_code"])
    else:
        code_col = _detect_first_existing(ref.columns, ["naics", "naics_code", "code", "industry_code"])
    if code_col is None:
        eprint(f"WARNING: no code column found in reference codebook {path}")
        return [], []
    text_cols = [c for c in ref.columns if c != code_col]
    docs: List[str] = []
    labels: List[Any] = []
    for _, row in ref.iterrows():
        code = clean_code_value(row.get(code_col))
        if code is None or code in COMMON_CODE_MISSINGS:
            continue
        parts: List[str] = []
        for c in text_cols:
            v = normalize_text(row.get(c))
            if v:
                parts.append(f"{c}: {v}")
        if not parts:
            continue
        docs.append(" | ".join(parts))
        labels.append(int(code) if kind.lower() == "soc" and str(code).isdigit() else str(code))
    eprint(f"[{kind.upper()}] Loaded {len(labels)} reference codebook rows from {path}")
    return docs, labels


class SemanticMemory:
    """Dense vector KNN memory for semantic title/industry matching.

    It stores normalized sentence-transformer embeddings and aggregates nearest
    neighbor labels. FAISS is used when available and requested; otherwise a
    scikit-learn brute-force cosine search is used. This makes the improvement
    air-gapped and laptop-safe.
    """
    def __init__(
        self,
        name: str,
        embedding_model: str,
        embedding_backend: str = "torch",
        embedding_device: Optional[str] = None,
        embedding_batch_size: int = 32,
        backend: str = "auto",
        k: int = 35,
        cache_dir: str = "",
        chunk_size: int = 0,
        progress_every: int = 0,
        random_seed: int = 42,
        prototype_examples: int = 3,
    ) -> None:
        self.name = name
        self.embedding_model = embedding_model
        self.embedding_backend = embedding_backend
        self.embedding_device = embedding_device
        self.embedding_batch_size = int(embedding_batch_size)
        self.backend = backend
        self.k = int(k)
        self.cache_dir = str(cache_dir or "")
        self.chunk_size = int(chunk_size or 0)
        self.progress_every = int(progress_every or 0)
        self.random_seed = int(random_seed)
        self.prototype_examples = max(1, int(prototype_examples))
        self.labels: np.ndarray = np.asarray([], dtype=object)
        self.weights: np.ndarray = np.asarray([], dtype=np.float32)
        self.docs: List[str] = []
        self.embeddings: Optional[np.ndarray] = None
        self.index: Any = None
        self.nn: Any = None
        self._model: Any = None
        self.actual_backend_: str = "none"
        self.label_prototypes: Dict[str, str] = {}

    def __getstate__(self) -> Dict[str, Any]:
        state = dict(self.__dict__)
        state["_model"] = None
        state["index"] = None
        state["nn"] = None
        return state

    def _load_model(self) -> Any:
        if not HAS_SENTENCE_TRANSFORMERS:
            raise RuntimeError("sentence-transformers is required for semantic memory")
        if self._model is None:
            kwargs: Dict[str, Any] = {}
            if self.embedding_device:
                kwargs["device"] = self.embedding_device
            backend = str(self.embedding_backend or "torch").lower()
            if backend in {"onnx", "openvino"}:
                try:
                    self._model = SentenceTransformer(self.embedding_model, backend=backend, **kwargs)
                except TypeError:
                    eprint(f"[{self.name}] WARNING: backend={backend} unsupported; semantic memory falling back to torch.")
                    self._model = SentenceTransformer(self.embedding_model, **kwargs)
                except Exception as exc:
                    eprint(f"[{self.name}] WARNING: backend={backend} failed ({exc}); semantic memory falling back to torch.")
                    self._model = SentenceTransformer(self.embedding_model, **kwargs)
            else:
                self._model = SentenceTransformer(self.embedding_model, **kwargs)
        return self._model

    def encode(self, docs: Sequence[str]) -> np.ndarray:
        model = self._load_model()
        return encode_docs_chunked(
            model,
            docs,
            batch_size=self.embedding_batch_size,
            chunk_size=self.chunk_size,
            progress_every=self.progress_every,
            cache_dir=self.cache_dir,
            cache_name=self.name,
            model_name=self.embedding_model,
            backend=self.embedding_backend,
        )

    def fit(self, docs: Sequence[str], labels: Sequence[Any], weights: Optional[Sequence[float]] = None) -> "SemanticMemory":
        good_docs: List[str] = []
        good_labels: List[Any] = []
        good_weights: List[float] = []
        for i, (doc, label) in enumerate(zip(docs, labels)):
            if label is None:
                continue
            if not str(doc).strip() or str(doc).strip() == "__EMPTY__":
                continue
            good_docs.append(str(doc))
            good_labels.append(label)
            if weights is None:
                good_weights.append(1.0)
            else:
                try:
                    good_weights.append(float(weights[i]))
                except Exception:
                    good_weights.append(1.0)
        self.labels = np.asarray(good_labels, dtype=object)
        self.weights = np.asarray(good_weights, dtype=np.float32)
        self.docs = list(good_docs)
        if not good_docs:
            self.embeddings = np.zeros((0, 0), dtype=np.float32)
            return self
        eprint(f"[{self.name}] Encoding {len(good_docs):,} semantic-memory exemplars with {self.embedding_model} ({self.embedding_backend})...")
        self.embeddings = self.encode(good_docs).astype(np.float32, copy=False)
        self._build_label_prototypes()
        self._build_index()
        return self

    def _build_label_prototypes(self) -> None:
        self.label_prototypes = {}
        if self.embeddings is None or self.embeddings.shape[0] == 0 or len(self.labels) == 0:
            return
        groups: Dict[Any, List[int]] = defaultdict(list)
        for idx, label in enumerate(self.labels.tolist()):
            groups[label].append(idx)
        for label, idxs in groups.items():
            arr_idx = np.asarray(idxs, dtype=int)
            if arr_idx.size == 1:
                chosen = arr_idx.tolist()
            else:
                emb = self.embeddings[arr_idx]
                centroid = np.asarray(emb.mean(axis=0), dtype=np.float32)
                norm = float(np.linalg.norm(centroid))
                if norm > 0:
                    centroid = centroid / norm
                scores = np.asarray(emb @ centroid, dtype=float)
                order = np.argsort(-scores)[: self.prototype_examples]
                chosen = arr_idx[order].tolist()
            snippets: List[str] = []
            seen: set[str] = set()
            for j in chosen:
                doc = str(self.docs[j]).strip()[:900]
                key = doc.lower()
                if doc and key not in seen:
                    snippets.append(doc)
                    seen.add(key)
            if snippets:
                self.label_prototypes[str(label)] = f"CODE {label}. REPRESENTATIVE HISTORICAL CONTEXT: " + " || ".join(snippets)

    def prototype_doc(self, label: Any) -> str:
        return str(self.label_prototypes.get(str(label), f"CODE {label}"))

    def _build_index(self) -> None:
        self.index = None
        self.nn = None
        if self.embeddings is None or self.embeddings.shape[0] == 0:
            return
        requested = str(self.backend or "auto").lower()
        use_faiss = requested in {"auto", "faiss"} and HAS_FAISS
        if use_faiss:
            try:
                self.index = faiss.IndexFlatIP(int(self.embeddings.shape[1]))
                self.index.add(np.ascontiguousarray(self.embeddings.astype(np.float32, copy=False)))
                self.actual_backend_ = "faiss"
                eprint(f"[{self.name}] Semantic-memory backend: FAISS IndexFlatIP, vectors={self.embeddings.shape[0]:,}, dim={self.embeddings.shape[1]}")
                return
            except Exception as exc:
                eprint(f"[{self.name}] WARNING: FAISS index failed ({exc}); falling back to sklearn cosine search.")
        self.nn = None
        try:
            from sklearn.neighbors import NearestNeighbors
            self.nn = NearestNeighbors(metric="cosine", algorithm="brute")
            self.nn.fit(self.embeddings)
            self.actual_backend_ = "sklearn_cosine"
            eprint(f"[{self.name}] Semantic-memory backend: sklearn cosine, vectors={self.embeddings.shape[0]:,}, dim={self.embeddings.shape[1]}")
        except Exception as exc:
            self.actual_backend_ = "none"
            eprint(f"[{self.name}] WARNING: semantic-memory index failed: {exc}")

    def ensure_index(self) -> None:
        if (self.index is None and self.nn is None) and self.embeddings is not None and self.embeddings.shape[0] > 0:
            self._build_index()

    def predict_topk(self, docs: Sequence[str], topk: int = 4, k: Optional[int] = None) -> Dict[str, Any]:
        n = len(docs)
        out_codes: List[List[Any]] = [[None for _ in range(topk)] for _ in range(n)]
        out_prob = np.zeros((n, topk), dtype=np.float32)
        out_max_sim = np.zeros(n, dtype=np.float32)
        out_conf = np.zeros(n, dtype=np.float32)
        out_candidate_docs: List[List[Dict[str, Any]]] = [[] for _ in range(n)]
        empty = {"codes": out_codes, "prob": out_prob, "max_sim": out_max_sim, "conf": out_conf, "candidate_docs": out_candidate_docs}
        if n == 0 or self.embeddings is None or self.embeddings.shape[0] == 0 or len(self.labels) == 0:
            return empty
        self.ensure_index()
        q = self.encode(docs)
        nn_k = max(1, min(int(k or self.k), int(self.embeddings.shape[0])))
        if self.index is not None:
            sims, idxs = self.index.search(np.ascontiguousarray(q.astype(np.float32, copy=False)), nn_k)
        elif self.nn is not None:
            distances, idxs = self.nn.kneighbors(q, n_neighbors=nn_k, return_distance=True)
            sims = 1.0 - distances
        else:
            return empty
        sims = np.asarray(sims, dtype=np.float32)
        idxs = np.asarray(idxs, dtype=np.int64)
        for i in range(n):
            agg: Dict[Any, float] = defaultdict(float)
            best_sim = 0.0
            best_doc_by_label: Dict[Any, Tuple[float, str]] = {}
            for sim, idx in zip(sims[i], idxs[i]):
                if idx < 0 or idx >= len(self.labels):
                    continue
                # Inner product of normalized embeddings equals cosine similarity.
                sim_float = max(0.0, float(sim))
                best_sim = max(best_sim, sim_float)
                label = self.labels[int(idx)]
                exemplar_weight = float(self.weights[int(idx)]) if len(self.weights) > int(idx) else 1.0
                # Square the similarity to reward truly close semantic neighbors.
                agg[label] += (sim_float ** 2) * exemplar_weight
                doc_text = self.docs[int(idx)] if int(idx) < len(self.docs) else ""
                prev_sim = best_doc_by_label.get(label, (-1.0, ""))[0]
                if sim_float > prev_sim:
                    best_doc_by_label[label] = (sim_float, doc_text)
            total = float(sum(agg.values()))
            if total <= 0:
                continue
            ordered = sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:topk]
            out_max_sim[i] = float(best_sim)
            out_conf[i] = float(ordered[0][1] / total) if ordered else 0.0
            candidate_docs: List[Dict[str, Any]] = []
            for rank, (label, val) in enumerate(ordered):
                out_codes[i][rank] = label
                out_prob[i, rank] = float(val / total)
                sim_doc = best_doc_by_label.get(label, (0.0, ""))
                candidate_docs.append({
                    "code": label,
                    "doc": sim_doc[1],
                    "similarity": float(sim_doc[0]),
                    "semantic_prob": float(val / total),
                })
            out_candidate_docs[i] = candidate_docs
        return {"codes": out_codes, "prob": out_prob, "max_sim": out_max_sim, "conf": out_conf, "candidate_docs": out_candidate_docs}


_CROSS_ENCODER_CACHE: Dict[Tuple[str, Optional[str]], Any] = {}


def get_cross_encoder(cfg: TrainConfig, kind: str = "") -> Any:
    """Load the target-appropriate CrossEncoder lazily and cache it.

    V2.2 supports separate NAICS and SOC rerankers to prevent negative transfer
    between the industry-coding and occupation-coding tasks. If a target-specific
    path is blank, the shared --cross_encoder_model path remains the fallback.
    """
    if not cfg.use_cross_encoder_reranker:
        return None
    if not HAS_SENTENCE_TRANSFORMERS or CrossEncoder is None:
        eprint("WARNING: --use_cross_encoder_reranker requested but CrossEncoder is unavailable; skipping reranker.")
        return None
    kind_norm = str(kind or "").strip().lower()
    model_path = str(cfg.cross_encoder_model)
    if kind_norm == "naics" and str(cfg.cross_encoder_model_naics or "").strip():
        model_path = str(cfg.cross_encoder_model_naics)
    elif kind_norm == "soc" and str(cfg.cross_encoder_model_soc or "").strip():
        model_path = str(cfg.cross_encoder_model_soc)
    key = (model_path, cfg.embedding_device)
    if key not in _CROSS_ENCODER_CACHE:
        kwargs: Dict[str, Any] = {}
        if cfg.embedding_device:
            kwargs["device"] = cfg.embedding_device
        eprint(f"Loading {kind_norm or 'shared'} CrossEncoder reranker: {model_path}")
        _CROSS_ENCODER_CACHE[key] = CrossEncoder(model_path, **kwargs)
    return _CROSS_ENCODER_CACHE[key]


def _softmax_1d(vals: Sequence[float]) -> List[float]:
    arr = np.asarray([float(v) for v in vals], dtype=np.float64)
    if arr.size == 0:
        return []
    arr = arr - np.max(arr)
    exp = np.exp(arr)
    denom = float(exp.sum())
    if denom <= 0 or not np.isfinite(denom):
        return [1.0 / arr.size for _ in range(arr.size)]
    return (exp / denom).astype(float).tolist()


def rerank_semantic_with_cross_encoder(
    query_docs: Sequence[str],
    sem: Dict[str, Any],
    cfg: TrainConfig,
    topk: int,
    kind: str,
) -> Dict[str, Any]:
    """Re-rank semantic-memory candidates with a CrossEncoder.

    The input `sem` is the bi-encoder/FAISS candidate list. This function keeps
    the same output shape but replaces the candidate order/probabilities for rows
    where cross-encoder scoring succeeds.
    """
    if not cfg.use_cross_encoder_reranker:
        return sem
    model = get_cross_encoder(cfg, kind)
    if model is None:
        return sem
    candidate_docs_all = sem.get("candidate_docs", [])
    if not candidate_docs_all:
        return sem

    new_codes: List[List[Any]] = [[None for _ in range(topk)] for _ in range(len(query_docs))]
    new_prob = np.zeros((len(query_docs), topk), dtype=np.float32)
    new_conf = np.zeros(len(query_docs), dtype=np.float32)
    new_max_sim = np.asarray(sem.get("max_sim", np.zeros(len(query_docs))), dtype=np.float32).copy()
    any_changed = False

    for i, qdoc in enumerate(query_docs):
        cand_rows = list(candidate_docs_all[i]) if i < len(candidate_docs_all) else []
        cand_rows = [c for c in cand_rows if c.get("code") is not None and str(c.get("doc", "")).strip()]
        cand_rows = cand_rows[:max(1, int(cfg.cross_encoder_topn))]
        if not cand_rows:
            # Preserve original semantic candidates.
            orig_codes = sem["codes"][i][:topk]
            orig_probs = sem["prob"][i][:topk]
            for r in range(min(topk, len(orig_codes))):
                new_codes[i][r] = orig_codes[r]
                new_prob[i, r] = float(orig_probs[r])
            new_conf[i] = float(sem.get("conf", np.zeros(len(query_docs)))[i])
            continue
        pairs = [(str(qdoc), str(c["doc"])) for c in cand_rows]
        try:
            scores = model.predict(
                pairs,
                batch_size=int(cfg.cross_encoder_batch_size),
                show_progress_bar=False,
                convert_to_numpy=True,
            )
        except TypeError:
            scores = model.predict(pairs, batch_size=int(cfg.cross_encoder_batch_size), show_progress_bar=False)
        except Exception as exc:
            eprint(f"[{kind.upper()}] CrossEncoder rerank skipped for one batch after error: {exc}")
            return sem
        raw = np.asarray(scores, dtype=np.float64).reshape(-1)
        if raw.size == 0:
            continue
        # Some rerankers output logits in roughly [-10, 10]; others output [0, 1].
        # Softmax makes a local ranking distribution regardless of score scale.
        ce_probs = _softmax_1d(raw.tolist())
        max_raw = float(np.max(raw))
        # If a user sets a positive threshold and the reranker is clearly not
        # confident, keep the original semantic order for that row.
        if float(cfg.cross_encoder_min_score) > 0 and max_raw < float(cfg.cross_encoder_min_score):
            orig_codes = sem["codes"][i][:topk]
            orig_probs = sem["prob"][i][:topk]
            for r in range(min(topk, len(orig_codes))):
                new_codes[i][r] = orig_codes[r]
                new_prob[i, r] = float(orig_probs[r])
            new_conf[i] = float(sem.get("conf", np.zeros(len(query_docs)))[i])
            continue
        merged: Dict[Any, float] = defaultdict(float)
        ce_w = max(0.0, min(1.0, float(cfg.cross_encoder_fusion_weight)))
        for c, ce_p in zip(cand_rows, ce_probs):
            sem_p = float(c.get("semantic_prob", 0.0))
            merged[c["code"]] += ce_w * float(ce_p) + (1.0 - ce_w) * sem_p
        ordered = sorted(merged.items(), key=lambda kv: kv[1], reverse=True)[:topk]
        denom = max(1e-12, float(sum(v for _, v in ordered)))
        for r, (code, val) in enumerate(ordered):
            new_codes[i][r] = code
            new_prob[i, r] = float(val / denom)
        new_conf[i] = float(new_prob[i, 0]) if ordered else 0.0
        any_changed = True

    if not any_changed:
        return sem
    return {"codes": new_codes, "prob": new_prob, "max_sim": new_max_sim, "conf": new_conf, "candidate_docs": candidate_docs_all}



def _normalize_component(values: Sequence[float]) -> np.ndarray:
    arr = np.asarray([max(0.0, float(v)) for v in values], dtype=float)
    total = float(arr.sum())
    if total <= 0:
        return np.zeros_like(arr)
    return arr / total


def rerank_union_candidates_with_cross_encoder(
    query_docs: Sequence[str],
    ml_code_rows: Sequence[Sequence[Any]],
    ml_prob_rows: Sequence[Sequence[float]],
    sem_rows: Sequence[Optional[Dict[str, Any]]],
    sem_mem: Optional[SemanticMemory],
    cfg: TrainConfig,
    topk: int,
    kind: str,
    fusion_weights: Optional[Mapping[str, float]] = None,
) -> Dict[str, Any]:
    """Rerank the union of ML and semantic candidates.

    Earlier versions cross-encoded semantic candidates only. The Gold audit
    showed that the correct code is often in the first-stage candidate list, so
    V2 combines the ML and semantic pools and scores every union candidate
    against a representative historical/codebook prototype.
    """
    n = len(query_docs)
    out_codes: List[List[Any]] = [[None for _ in range(topk)] for _ in range(n)]
    out_prob = np.zeros((n, topk), dtype=np.float32)
    out_ml = np.zeros((n, topk), dtype=np.float32)
    out_sem = np.zeros((n, topk), dtype=np.float32)
    out_ce = np.zeros((n, topk), dtype=np.float32)
    pre_top: List[Any] = [None] * n
    rerank_used = np.zeros(n, dtype=bool)

    model = get_cross_encoder(cfg, kind) if cfg.use_cross_encoder_reranker and cfg.cross_encoder_union_candidates else None
    fw = dict(fusion_weights or {})
    if fw:
        w_ml = max(0.0, float(fw.get("ml", 0.0)))
        w_sem = max(0.0, float(fw.get("semantic", 0.0)))
        w_ce = max(0.0, float(fw.get("cross_encoder", 0.0)))
    else:
        w_ce = max(0.0, min(1.0, float(cfg.cross_encoder_fusion_weight))) if model is not None else 0.0
        base_ml = max(0.0, float(cfg.ml_fusion_weight))
        base_sem = max(0.0, float(cfg.semantic_fusion_weight))
        denom = base_ml + base_sem or 1.0
        w_ml = (1.0 - w_ce) * base_ml / denom
        w_sem = (1.0 - w_ce) * base_sem / denom
    w_total = w_ml + w_sem + w_ce
    if w_total <= 0:
        w_ml = 1.0
        w_sem = w_ce = 0.0
    else:
        w_ml, w_sem, w_ce = w_ml / w_total, w_sem / w_total, w_ce / w_total

    row_candidates: List[List[Dict[str, Any]]] = []
    for i in range(n):
        cmap: Dict[str, Dict[str, Any]] = {}
        for rank, (code, prob) in enumerate(zip(ml_code_rows[i], ml_prob_rows[i])):
            if code is None:
                continue
            key = str(code)
            entry = cmap.setdefault(key, {"code": code, "ml": 0.0, "sem": 0.0, "doc": "", "sim": 0.0})
            entry["ml"] = max(float(entry["ml"]), max(0.0, float(prob)))
            entry["ml_rank"] = rank + 1
        sem_row = sem_rows[i] if i < len(sem_rows) else None
        if sem_row:
            for rank, cand in enumerate(sem_row.get("candidate_docs", [])):
                code = cand.get("code")
                if code is None:
                    continue
                key = str(code)
                entry = cmap.setdefault(key, {"code": code, "ml": 0.0, "sem": 0.0, "doc": "", "sim": 0.0})
                entry["sem"] = max(float(entry["sem"]), max(0.0, float(cand.get("semantic_prob", 0.0))))
                if float(cand.get("similarity", 0.0)) >= float(entry.get("sim", 0.0)):
                    entry["doc"] = str(cand.get("doc", ""))
                    entry["sim"] = float(cand.get("similarity", 0.0))
                entry["sem_rank"] = rank + 1
        candidates = list(cmap.values())
        for c in candidates:
            c["retrieval_score"] = max(float(c.get("ml", 0.0)), float(c.get("sem", 0.0)), 0.5 * (float(c.get("ml", 0.0)) + float(c.get("sem", 0.0))))
            proto = sem_mem.prototype_doc(c["code"]) if sem_mem is not None else f"CODE {c['code']}"
            close = str(c.get("doc", "")).strip()
            c["candidate_text"] = proto if not close else f"{proto} | CLOSE HISTORICAL EXAMPLE: {close[:900]}"
        candidates.sort(key=lambda c: float(c.get("retrieval_score", 0.0)), reverse=True)
        candidates = candidates[: max(topk, int(cfg.cross_encoder_candidate_pool))]
        row_candidates.append(candidates)
        if candidates:
            pre_top[i] = candidates[0]["code"]

    if model is not None:
        chunk_rows = 128
        for start in range(0, n, chunk_rows):
            stop = min(n, start + chunk_rows)
            pairs: List[Tuple[str, str]] = []
            locations: List[Tuple[int, int]] = []
            for i in range(start, stop):
                for j, cand in enumerate(row_candidates[i]):
                    pairs.append((str(query_docs[i]), str(cand.get("candidate_text", ""))))
                    locations.append((i, j))
            if not pairs:
                continue
            try:
                raw = model.predict(pairs, batch_size=int(cfg.cross_encoder_batch_size), show_progress_bar=False, convert_to_numpy=True)
            except TypeError:
                raw = model.predict(pairs, batch_size=int(cfg.cross_encoder_batch_size), show_progress_bar=False)
            except Exception as exc:
                eprint(f"[{kind.upper()}] Union CrossEncoder rerank failed for rows {start}:{stop}: {exc}")
                raw = np.zeros(len(pairs), dtype=float)
            for score, (i, j) in zip(np.asarray(raw, dtype=float).reshape(-1), locations):
                row_candidates[i][j]["ce_raw"] = float(score)

    for i, candidates in enumerate(row_candidates):
        if not candidates:
            continue
        ml = _normalize_component([c.get("ml", 0.0) for c in candidates])
        sem = _normalize_component([c.get("sem", 0.0) for c in candidates])
        if model is not None and any("ce_raw" in c for c in candidates):
            ce = np.asarray(_softmax_1d([float(c.get("ce_raw", 0.0)) for c in candidates]), dtype=float)
            rerank_used[i] = True
        else:
            ce = np.zeros(len(candidates), dtype=float)
        final = w_ml * ml + w_sem * sem + w_ce * ce
        if final.sum() <= 0:
            final = ml if ml.sum() > 0 else sem
        if final.sum() <= 0:
            final = np.ones(len(candidates), dtype=float) / len(candidates)
        else:
            final = final / final.sum()
        order = np.argsort(-final)[:topk]
        chosen = [candidates[j] for j in order]
        for rank, (j, cand) in enumerate(zip(order.tolist(), chosen)):
            code = cand["code"]
            if kind == "soc":
                try:
                    code = int(code)
                except Exception:
                    code = None
            else:
                code = str(code) if code is not None else None
            out_codes[i][rank] = code
            out_prob[i, rank] = float(final[j])
            out_ml[i, rank] = float(ml[j])
            out_sem[i, rank] = float(sem[j])
            out_ce[i, rank] = float(ce[j])
    return {
        "codes": out_codes,
        "prob": out_prob,
        "ml_component": out_ml,
        "semantic_component": out_sem,
        "cross_encoder_component": out_ce,
        "pre_rerank_top": pre_top,
        "rerank_used": rerank_used,
        "weights": {"ml": w_ml, "semantic": w_sem, "cross_encoder": w_ce},
    }


def build_semantic_memory(
    name: str,
    df: pd.DataFrame,
    labels: Sequence[Any],
    text_cols: Sequence[str],
    prefixes: Dict[str, str],
    cfg: TrainConfig,
    kind: str,
    reference_csv: str = "",
) -> Optional[SemanticMemory]:
    if not cfg.use_semantic_memory:
        return None
    if not HAS_SENTENCE_TRANSFORMERS:
        eprint(f"[{name}] Semantic memory requested but sentence-transformers is unavailable; skipping.")
        return None
    docs = make_docs_from_columns(df, text_cols, prefixes)
    clean_labels: List[Any] = []
    clean_docs: List[str] = []
    weights: List[float] = []
    for doc, label in zip(docs, labels):
        cv = clean_code_value(label)
        if cv is None or cv in COMMON_CODE_MISSINGS:
            continue
        clean_docs.append(doc)
        clean_labels.append(int(cv) if kind.lower() == "soc" and str(cv).isdigit() else str(cv))
        weights.append(1.0)
    ref_docs, ref_labels = load_reference_codebook(reference_csv, kind) if reference_csv else ([], [])
    for doc, label in zip(ref_docs, ref_labels):
        clean_docs.append(doc)
        clean_labels.append(label)
        weights.append(float(cfg.semantic_reference_weight))
    if len(clean_docs) < 5:
        eprint(f"[{name}] Too few semantic-memory exemplars ({len(clean_docs)}); skipping.")
        return None
    mem = SemanticMemory(
        name=name,
        embedding_model=cfg.embedding_model,
        embedding_backend=cfg.embedding_backend,
        embedding_device=cfg.embedding_device,
        embedding_batch_size=cfg.embedding_batch_size,
        backend=cfg.semantic_backend,
        k=cfg.semantic_k,
        cache_dir=cfg.embedding_cache_dir,
        chunk_size=cfg.embedding_chunk_size,
        progress_every=cfg.embedding_progress_every,
        random_seed=cfg.random_seed,
        prototype_examples=cfg.cross_encoder_prototype_examples,
    )
    mem.fit(clean_docs, clean_labels, weights=weights)
    return mem


def merge_ranked_candidates(
    ml_codes: Sequence[Any],
    ml_probs: Sequence[float],
    sem_codes: Optional[Sequence[Any]],
    sem_probs: Optional[Sequence[float]],
    sem_conf: float,
    sem_sim: float,
    cfg: TrainConfig,
    topk: int,
    code_kind: str,
) -> Tuple[List[Any], List[float]]:
    merged: Dict[Any, float] = defaultdict(float)
    ml_factor = max(0.0, float(cfg.ml_fusion_weight))
    sem_factor = 0.0
    for code, prob in zip(ml_codes, ml_probs):
        if code is None:
            continue
        try:
            p = float(prob)
        except Exception:
            continue
        if p <= 0:
            continue
        merged[code] += ml_factor * p
    if sem_codes is not None and sem_probs is not None:
        if float(sem_sim) >= float(cfg.semantic_min_similarity) and float(sem_conf) >= float(cfg.semantic_min_confidence):
            sem_factor = max(0.0, float(cfg.semantic_fusion_weight)) * max(0.25, float(sem_sim))
            for code, prob in zip(sem_codes, sem_probs):
                if code is None:
                    continue
                try:
                    p = float(prob)
                except Exception:
                    continue
                if p <= 0:
                    continue
                merged[code] += sem_factor * p
    if not merged:
        return [None for _ in range(topk)], [0.0 for _ in range(topk)]
    ordered = sorted(merged.items(), key=lambda kv: kv[1], reverse=True)[:topk]
    denom = max(1e-9, ml_factor + sem_factor)
    codes = [c for c, _ in ordered]
    probs = [float(max(0.0, min(1.0, v / denom))) for _, v in ordered]
    while len(codes) < topk:
        codes.append(None)
        probs.append(0.0)
    if code_kind == "soc":
        fixed_codes: List[Any] = []
        for c in codes:
            try:
                fixed_codes.append(int(c) if c is not None else None)
            except Exception:
                fixed_codes.append(None)
        codes = fixed_codes
    else:
        codes = [str(c) if c is not None else None for c in codes]
    return codes, probs


_LLM_CACHE: Dict[Tuple[str, int, int, int], Any] = {}


def get_local_llm(cfg: TrainConfig) -> Any:
    if not cfg.use_local_llm_fallback:
        return None
    if not HAS_LLAMA_CPP:
        eprint("WARNING: --use_local_llm_fallback requested but llama-cpp-python is unavailable; skipping LLM reranker.")
        return None
    if not cfg.llm_model_path or not os.path.exists(cfg.llm_model_path):
        eprint("WARNING: --use_local_llm_fallback requested but --llm_model_path is missing/not found; skipping LLM reranker.")
        return None
    key = (cfg.llm_model_path, int(cfg.llm_ctx_size), int(cfg.llm_threads), int(cfg.random_seed))
    if key not in _LLM_CACHE:
        eprint(f"Loading local LLM reranker from {cfg.llm_model_path}")
        _LLM_CACHE[key] = Llama(
            model_path=cfg.llm_model_path,
            n_ctx=int(cfg.llm_ctx_size),
            n_threads=int(cfg.llm_threads),
            n_gpu_layers=0,
            seed=int(cfg.random_seed),
            verbose=False,
        )
    return _LLM_CACHE[key]


def _parse_llm_candidate_text(text: str, allowed: Sequence[str], kind: str, allow_free: bool) -> Tuple[Optional[Any], float]:
    code: Optional[str] = None
    conf = 0.5
    m = re.search(r'"code"\s*:\s*"?([0-9A-Za-z\-]+)"?', text)
    if m:
        code = m.group(1)
    if code is None:
        m2 = re.search(r"\b\d{2,6}\b", text)
        code = m2.group(0) if m2 else None
    mconf = re.search(r'"confidence"\s*:\s*([0-9]*\.?[0-9]+)', text)
    if mconf:
        try:
            conf = max(0.0, min(1.0, float(mconf.group(1))))
        except Exception:
            conf = 0.5
    if code is None:
        return None, 0.0
    if code in allowed or allow_free:
        return (int(code) if kind.lower() == "soc" and code.isdigit() else code), conf
    return None, 0.0


def llm_choose_candidate(
    cfg: TrainConfig,
    kind: str,
    row_context: str,
    candidates: Sequence[Any],
) -> Optional[Any]:
    llm = get_local_llm(cfg)
    if llm is None:
        return None
    allowed = [str(c) for c in candidates if c is not None]
    if not allowed:
        return None
    user_prompt = (
        f"Task: select the best {kind.upper()} code for this labor-market survey response.\n"
        f"Survey context:\n{row_context}\n\n"
        f"Allowed candidate codes: {', '.join(allowed)}\n\n"
        "Use the survey context and the allowed candidates only. Do not invent a code. "
        "Use your internal reasoning silently, then return compact JSON only: "
        "{\"code\":\"123456\",\"confidence\":0.73,\"evidence\":\"short phrase\"}."
    )
    system_msg = "You are an expert NAICS/SOC survey coder. You must choose exactly one allowed code and output valid JSON only."
    samples = max(1, int(cfg.llm_self_consistency_samples))
    votes: Dict[str, int] = defaultdict(int)
    conf_sum: Dict[str, float] = defaultdict(float)
    order = {c: i for i, c in enumerate(allowed)}
    for sample_i in range(samples):
        temp = float(cfg.llm_temperature if samples == 1 else cfg.llm_self_consistency_temperature)
        text = ""
        try:
            if hasattr(llm, "create_chat_completion"):
                out = llm.create_chat_completion(
                    messages=[{"role": "system", "content": system_msg}, {"role": "user", "content": user_prompt}],
                    max_tokens=int(cfg.llm_max_tokens),
                    temperature=temp,
                    top_p=float(cfg.llm_top_p),
                    response_format={"type": "json_object"},
                )
                text = str(out.get("choices", [{}])[0].get("message", {}).get("content", ""))
            else:
                prompt = system_msg + "\n\n" + user_prompt
                out = llm(prompt, max_tokens=int(cfg.llm_max_tokens), temperature=temp, top_p=float(cfg.llm_top_p), stop=["\n\n"])
                text = str(out.get("choices", [{}])[0].get("text", ""))
        except Exception as exc:
            if sample_i == 0:
                eprint(f"WARNING: local LLM rerank failed: {exc}")
            continue
        chosen, conf = _parse_llm_candidate_text(text, allowed, kind, cfg.llm_allow_free_code)
        if chosen is None:
            continue
        chosen_s = str(chosen)
        votes[chosen_s] += 1
        conf_sum[chosen_s] += float(conf)
    if not votes:
        return None
    # Majority vote first, confidence second, original candidate order third.
    chosen_s = sorted(votes.keys(), key=lambda c: (votes[c], conf_sum[c], -order.get(c, 10**9)), reverse=True)[0]
    return int(chosen_s) if kind.lower() == "soc" and chosen_s.isdigit() else chosen_s


def row_context_for_llm(df: pd.DataFrame, row_pos: int, cols: Sequence[str]) -> str:
    if row_pos < 0 or row_pos >= len(df):
        return ""
    row = df.iloc[row_pos]
    parts: List[str] = []
    for c in cols:
        if c not in df.columns:
            continue
        val = row.get(c)
        norm = normalize_text(val)
        if norm:
            parts.append(f"{c}: {norm}")
    return "\n".join(parts)[:3000]


def maybe_llm_rerank_naics(pred: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig, text_cols: Sequence[str]) -> Dict[str, Any]:
    if not cfg.use_local_llm_fallback:
        return pred
    n = len(score_df)
    used = 0
    for i in range(n):
        if used >= int(cfg.llm_max_rows):
            break
        if pred["top_prob"][i, 0] >= float(cfg.llm_trigger_confidence_naics):
            continue
        candidates = [c for c in pred["top_code"][i] if c is not None]
        if not candidates:
            continue
        ctx = row_context_for_llm(score_df, i, text_cols)
        if not ctx:
            continue
        chosen = llm_choose_candidate(cfg, "naics", ctx, candidates)
        if chosen is None:
            continue
        # Move chosen to rank 1 and keep the remaining candidates in order.
        old_codes = [c for c in pred["top_code"][i] if c is not None and str(c) != str(chosen)]
        new_codes = [str(chosen)] + old_codes
        for k in range(pred["top_prob"].shape[1]):
            pred["top_code"][i][k] = new_codes[k] if k < len(new_codes) else None
            pred["top_prob"][i, k] = float(cfg.llm_rerank_confidence) if k == 0 else max(0.0, float(pred["top_prob"][i, k]) * 0.75)
        used += 1
    if used:
        eprint(f"[LLM] Reranked {used} low-confidence NAICS rows with local llama.cpp model")
    return pred


def maybe_llm_rerank_soc(pred: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig, text_cols: Sequence[str]) -> Dict[str, Any]:
    if not cfg.use_local_llm_fallback:
        return pred
    n = len(score_df)
    used = 0
    for i in range(n):
        if used >= int(cfg.llm_max_rows):
            break
        if pred["top_prob"][i, 0] >= float(cfg.llm_trigger_confidence_soc):
            continue
        candidates = [int(c) for c in pred["top_soc"][i].tolist() if int(c) > 0]
        if not candidates:
            continue
        ctx = row_context_for_llm(score_df, i, text_cols)
        if not ctx:
            continue
        chosen = llm_choose_candidate(cfg, "soc", ctx, candidates)
        if chosen is None:
            continue
        chosen_int = int(chosen)
        old_codes = [int(c) for c in candidates if int(c) != chosen_int]
        new_codes = [chosen_int] + old_codes
        for k in range(pred["top_prob"].shape[1]):
            pred["top_soc"][i, k] = new_codes[k] if k < len(new_codes) else -1
            pred["top_prob"][i, k] = float(cfg.llm_rerank_confidence) if k == 0 else max(0.0, float(pred["top_prob"][i, k]) * 0.75)
        used += 1
    if used:
        eprint(f"[LLM] Reranked {used} low-confidence SOC rows with local llama.cpp model")
    return pred



# ---------------------------------------------------------------------
# Model selection and ensembling
# ---------------------------------------------------------------------

def choose_penalty(alpha: float) -> Tuple[str, Optional[float]]:
    alpha = float(alpha)
    if alpha <= 0:
        return "l2", None
    if alpha >= 1:
        return "l1", None
    return "elasticnet", alpha


def choose_cv_splits(y: np.ndarray, requested_folds: int) -> int:
    counts = Counter(y.tolist())
    if not counts:
        return 0
    min_class_n = min(counts.values())
    if min_class_n < 2:
        return 0
    return max(2, min(int(requested_folds), int(min_class_n)))


def can_use_boosters(stage_name: str, n_rows: int, n_features: int, n_classes: int, cfg: TrainConfig) -> bool:
    if cfg.model_search not in {"robust", "max"}:
        return False
    if n_classes > int(cfg.boost_max_classes):
        return False
    if n_features > int(cfg.boost_max_features):
        # High-dimensional TF-IDF + multiclass boosted trees can become a hedgehog made of RAM.
        return False
    if stage_name.startswith("within") and n_rows < 80:
        return False
    return True


def candidate_estimators(
    cfg: TrainConfig,
    stage_name: str,
    n_rows: int,
    n_features: int,
    n_classes: int,
    features_nonnegative: bool,
    parallel_cfg: ParallelConfig,
) -> List[Tuple[str, Any]]:
    candidates: List[Tuple[str, Any]] = []
    l1_ratio = 0.25 if cfg.profile == "accuracy" else 0.15

    allowed = set(cfg.candidate_models or ("auto",))
    use_auto = (not allowed) or ("auto" in allowed) or ("all" in allowed)

    def want(short_name: str) -> bool:
        return use_auto or short_name in allowed

    # Strong sparse linear workhorse. This is the fastest reliable supervised
    # model on the user's laptop diagnostics.
    if want("sgd"):
        candidates.append((
            "sgd_log_elasticnet",
            SGDClassifier(
                loss="log_loss",
                penalty="elasticnet",
                l1_ratio=float(l1_ratio),
                alpha=float(cfg.sgd_alpha),
                max_iter=int(cfg.sgd_max_iter),
                tol=float(cfg.sgd_tol),
                class_weight="balanced",
                random_state=int(cfg.random_seed),
            ),
        ))

    # More expensive but often stronger on text when rows/classes are not huge.
    include_logreg = want("logreg")
    if stage_name.startswith("within") and (n_rows > 70000 or n_classes > 180):
        include_logreg = False
    if stage_name.startswith("naics") and (n_rows > 100000 or n_classes > 250):
        include_logreg = False
    if include_logreg:
        penalty, chosen_l1 = choose_penalty(l1_ratio)
        kwargs: Dict[str, Any] = dict(
            solver="saga",
            max_iter=int(cfg.logreg_max_iter),
            C=float(cfg.logreg_C),
            class_weight="balanced",
            random_state=int(cfg.random_seed),
            n_jobs=1,
        )
        if penalty == "elasticnet":
            kwargs.update(penalty="elasticnet", l1_ratio=float(chosen_l1))
        else:
            kwargs.update(penalty=penalty)
        candidates.append(("logreg_saga_balanced", LogisticRegression(**kwargs)))

    # Linear SVM has excellent high-dimensional text behavior. Probabilities are
    # approximated from decision scores for ranking and ensembling.
    if want("linear_svc") and cfg.model_search in {"robust", "max"} and n_classes <= 120 and n_rows <= 90000:
        try:
            candidates.append((
                "linear_svc_balanced",
                LinearSVC(C=float(cfg.linearsvc_C), class_weight="balanced", max_iter=6000, dual="auto", random_state=int(cfg.random_seed)),
            ))
        except TypeError:
            candidates.append((
                "linear_svc_balanced",
                LinearSVC(C=float(cfg.linearsvc_C), class_weight="balanced", max_iter=6000, random_state=int(cfg.random_seed)),
            ))

    # ComplementNB is very strong for pure non-negative count/TF-IDF style data.
    if want("complement_nb") and features_nonnegative and cfg.model_search in {"light", "robust", "max"}:
        candidates.append(("complement_nb", ComplementNB(alpha=0.5)))

    use_boost = can_use_boosters(stage_name, n_rows, n_features, n_classes, cfg)
    if want("lightgbm") and use_boost and HAS_LIGHTGBM:
        candidates.append((
            "lightgbm_multiclass",
            lgb.LGBMClassifier(
                objective="multiclass",
                n_estimators=int(cfg.boost_n_estimators),
                learning_rate=0.05,
                num_leaves=31,
                max_depth=-1,
                subsample=0.85,
                colsample_bytree=0.85,
                reg_lambda=2.0,
                class_weight="balanced",
                n_jobs=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
                verbose=-1,
            ),
        ))
    if want("xgboost") and use_boost and HAS_XGBOOST and cfg.model_search == "max":
        candidates.append((
            "xgboost_hist",
            XGBLabelEncodedClassifier(
                n_estimators=max(150, int(cfg.boost_n_estimators)),
                max_depth=5,
                learning_rate=0.045,
                subsample=0.85,
                colsample_bytree=0.85,
                reg_lambda=2.0,
                n_jobs=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
            ),
        ))
    if want("catboost") and use_boost and HAS_CATBOOST and cfg.model_search == "max" and n_rows <= 50000:
        candidates.append((
            "catboost_sparse",
            CatBoostLabelEncodedClassifier(
                iterations=max(180, int(cfg.boost_n_estimators)),
                depth=6,
                learning_rate=0.045,
                l2_leaf_reg=5.0,
                thread_count=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
            ),
        ))

    return candidates


def evaluate_candidate_cv(
    name: str,
    proto: Any,
    x: sp.csr_matrix,
    y: np.ndarray,
    classes: np.ndarray,
    splits: int,
    cfg: TrainConfig,
) -> CandidateScore:
    t0_total = time.time()
    if splits < 2:
        return CandidateScore(name=name, macro_f1=None, log_loss_value=None, failed=False, total_seconds=0.0)
    splitter = StratifiedKFold(n_splits=splits, shuffle=True, random_state=int(cfg.random_seed))
    fold_f1: List[float] = []
    fold_ll: List[float] = []
    fold_seconds: List[float] = []
    try:
        fold_no = 0
        for tr_idx, va_idx in splitter.split(np.zeros(len(y)), y):
            fold_no += 1
            eprint(f"    [{name}] CV fold {fold_no}/{splits} START rows_train={len(tr_idx)} rows_valid={len(va_idx)} classes={len(classes)}")
            est = clone(proto)
            t0_fold = time.time()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", ConvergenceWarning)
                warnings.simplefilter("ignore", FutureWarning)
                est.fit(x[tr_idx], y[tr_idx])
            pred = est.predict(x[va_idx])
            f1_val = float(f1_score(y[va_idx], pred, average="macro", zero_division=0))
            fold_f1.append(f1_val)
            try:
                p = estimator_predict_proba(est, x[va_idx], classes)
                ll_val = float(log_loss(y[va_idx], p, labels=classes))
                fold_ll.append(ll_val)
            except Exception:
                ll_val = float("inf")
                fold_ll.append(ll_val)
            elapsed = time.time() - t0_fold
            fold_seconds.append(float(elapsed))
            ll_s = "inf" if not np.isfinite(ll_val) else f"{ll_val:.4f}"
            eprint(f"    [{name}] CV fold {fold_no}/{splits} DONE seconds={elapsed:.1f} macro-F1={f1_val:.4f} logloss={ll_s}")
    except Exception as exc:
        return CandidateScore(
            name=name,
            macro_f1=None,
            log_loss_value=None,
            failed=True,
            reason=str(exc)[:500],
            total_seconds=float(time.time() - t0_total),
            fold_seconds=fold_seconds,
            fold_macro_f1=fold_f1,
            fold_log_loss=fold_ll,
        )
    return CandidateScore(
        name=name,
        macro_f1=float(np.mean(fold_f1)) if fold_f1 else None,
        log_loss_value=float(np.mean(fold_ll)) if fold_ll else None,
        failed=False,
        total_seconds=float(time.time() - t0_total),
        fold_seconds=fold_seconds,
        fold_macro_f1=fold_f1,
        fold_log_loss=fold_ll,
    )


def _calibration_method_for_stage(cfg: TrainConfig, n_rows: int, n_classes: int) -> str:
    method = str(cfg.calibration_method or "auto").lower()
    if method == "auto":
        # Isotonic is flexible but can overfit on small calibration sets. Sigmoid
        # is the safer default for rare SOC/NAICS class distributions.
        if n_rows >= 4000 and n_classes <= 50:
            return "isotonic"
        return "sigmoid"
    if method not in {"sigmoid", "isotonic", "temperature"}:
        return "sigmoid"
    return method


def fit_final_estimator(
    proto: Any,
    x: sp.csr_matrix,
    y: np.ndarray,
    cfg: TrainConfig,
    stage_name: str,
    name: str,
    splits: int,
) -> Any:
    """Fit a selected estimator, optionally with probability calibration."""
    n_rows = int(x.shape[0])
    n_classes = int(len(np.unique(y)))
    cal_cv = choose_cv_splits(y, min(int(cfg.calibration_cv), max(2, int(splits))))
    use_cal = (
        bool(cfg.use_probability_calibration)
        and cal_cv >= 2
        and n_rows >= max(60, cal_cv * n_classes)
        and n_rows <= int(cfg.calibration_max_rows)
        and n_classes <= int(cfg.calibration_max_classes)
        and name not in {"complement_nb"}
    )
    if use_cal:
        method = _calibration_method_for_stage(cfg, n_rows, n_classes)
        try:
            try:
                cal = CalibratedClassifierCV(estimator=clone(proto), method=method, cv=cal_cv, ensemble=False, n_jobs=1)
            except TypeError:
                # Older scikit-learn used base_estimator instead of estimator.
                cal = CalibratedClassifierCV(base_estimator=clone(proto), method=method, cv=cal_cv, ensemble=False, n_jobs=1)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", ConvergenceWarning)
                warnings.simplefilter("ignore", FutureWarning)
                cal.fit(x, y)
            eprint(f"[{stage_name}] Final fit calibrated {name} with method={method}, cv={cal_cv}")
            return cal
        except Exception as exc:
            eprint(f"[{stage_name}] Calibration failed for {name}; fitting uncalibrated model. Reason: {str(exc)[:300]}")
    est = clone(proto)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        warnings.simplefilter("ignore", FutureWarning)
        est.fit(x, y)
    return est


def make_optuna_candidate(
    x: sp.csr_matrix,
    y: np.ndarray,
    classes: np.ndarray,
    cfg: TrainConfig,
    stage_name: str,
    trials: int,
    parallel_cfg: ParallelConfig,
    features_nonnegative: bool,
    base_splits: int,
) -> Optional[Tuple[str, Any]]:
    if trials <= 0 or not HAS_OPTUNA or cfg.model_search != "max" or base_splits < 2:
        return None

    allowed = set(cfg.candidate_models or ("auto",))
    use_auto = (not allowed) or ("auto" in allowed) or ("all" in allowed)

    def want(short_name: str) -> bool:
        return use_auto or short_name in allowed

    use_boost = can_use_boosters(stage_name, x.shape[0], x.shape[1], len(classes), cfg)
    families: List[str] = []
    if want("sgd"):
        families.append("sgd")
    if want("logreg"):
        families.append("logreg")
    if want("lightgbm") and use_boost and HAS_LIGHTGBM:
        families.append("lightgbm")
    if want("xgboost") and use_boost and HAS_XGBOOST and len(classes) <= min(80, cfg.boost_max_classes):
        families.append("xgboost")
    if want("catboost") and use_boost and HAS_CATBOOST and x.shape[0] <= 50000:
        families.append("catboost")

    if not families:
        eprint(f"[{stage_name}] Optuna skipped: no eligible families after applying --candidate_models={','.join(cfg.candidate_models)}")
        return None

    eprint(f"[{stage_name}] Optuna enabled for families: {', '.join(families)} | trials={int(trials)}")
    eval_splits = min(base_splits, 3)

    def build_from_trial(trial: Any) -> Tuple[str, Any]:
        fam = trial.suggest_categorical("family", families)
        if fam == "sgd":
            return "optuna_sgd", SGDClassifier(
                loss="log_loss",
                penalty="elasticnet",
                l1_ratio=trial.suggest_float("sgd_l1_ratio", 0.01, 0.7),
                alpha=trial.suggest_float("sgd_alpha", 1e-6, 5e-3, log=True),
                max_iter=int(cfg.sgd_max_iter),
                tol=float(cfg.sgd_tol),
                class_weight="balanced",
                random_state=int(cfg.random_seed),
            )
        if fam == "logreg":
            return "optuna_logreg", LogisticRegression(
                solver="saga",
                penalty="elasticnet",
                l1_ratio=trial.suggest_float("lr_l1_ratio", 0.01, 0.6),
                C=trial.suggest_float("lr_C", 0.05, 8.0, log=True),
                max_iter=int(cfg.logreg_max_iter),
                class_weight="balanced",
                random_state=int(cfg.random_seed),
                n_jobs=1,
            )
        if fam == "lightgbm":
            return "optuna_lightgbm", lgb.LGBMClassifier(
                objective="multiclass",
                n_estimators=trial.suggest_int("lgb_estimators", 120, max(160, cfg.boost_n_estimators * 2)),
                learning_rate=trial.suggest_float("lgb_lr", 0.015, 0.12, log=True),
                num_leaves=trial.suggest_int("lgb_leaves", 15, 95),
                max_depth=trial.suggest_int("lgb_depth", -1, 12),
                subsample=trial.suggest_float("lgb_subsample", 0.65, 1.0),
                colsample_bytree=trial.suggest_float("lgb_colsample", 0.55, 1.0),
                reg_lambda=trial.suggest_float("lgb_lambda", 0.1, 10.0, log=True),
                class_weight="balanced",
                n_jobs=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
                verbose=-1,
            )
        if fam == "xgboost":
            return "optuna_xgboost", XGBLabelEncodedClassifier(
                n_estimators=trial.suggest_int("xgb_estimators", 120, max(160, cfg.boost_n_estimators * 2)),
                max_depth=trial.suggest_int("xgb_depth", 3, 8),
                learning_rate=trial.suggest_float("xgb_lr", 0.015, 0.12, log=True),
                subsample=trial.suggest_float("xgb_subsample", 0.65, 1.0),
                colsample_bytree=trial.suggest_float("xgb_colsample", 0.55, 1.0),
                reg_lambda=trial.suggest_float("xgb_lambda", 0.1, 10.0, log=True),
                reg_alpha=trial.suggest_float("xgb_alpha", 1e-8, 2.0, log=True),
                n_jobs=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
            )
        if fam == "catboost":
            return "optuna_catboost", CatBoostLabelEncodedClassifier(
                iterations=trial.suggest_int("cat_iterations", 120, max(160, cfg.boost_n_estimators * 2)),
                depth=trial.suggest_int("cat_depth", 4, 8),
                learning_rate=trial.suggest_float("cat_lr", 0.015, 0.12, log=True),
                l2_leaf_reg=trial.suggest_float("cat_l2", 1.0, 15.0, log=True),
                thread_count=int(parallel_cfg.native_threads),
                random_state=int(cfg.random_seed),
            )
        raise RuntimeError(f"Unsupported Optuna family: {fam}")

    def objective(trial: Any) -> float:
        nm, est = build_from_trial(trial)
        fam = trial.params.get("family", "?")
        eprint(f"[{stage_name}] Optuna trial {trial.number + 1}/{int(trials)} START family={fam} model={nm}")
        score = evaluate_candidate_cv(nm, est, x, y, classes, eval_splits, cfg)
        if score.failed or score.macro_f1 is None:
            return -1.0
        # Macro-F1 is primary. Log-loss nudges the model toward better confidence.
        ll_penalty = 0.0 if score.log_loss_value is None or not np.isfinite(score.log_loss_value) else min(score.log_loss_value, 5.0) * 0.005
        return float(score.macro_f1 - ll_penalty)

    try:
        sampler = optuna.samplers.TPESampler(seed=int(cfg.random_seed))
        study = optuna.create_study(direction="maximize", sampler=sampler)

        def _optuna_progress_callback(study_obj: Any, trial_obj: Any) -> None:
            try:
                val = trial_obj.value
                fam = trial_obj.params.get("family", "?")
                best = study_obj.best_value if study_obj.best_trial is not None else None
                val_s = "NA" if val is None else f"{float(val):.4f}"
                best_s = "NA" if best is None else f"{float(best):.4f}"
                eprint(f"[{stage_name}] Optuna trial {trial_obj.number + 1}/{int(trials)} family={fam} value={val_s} best={best_s}")
            except Exception:
                pass

        study.optimize(
            objective,
            n_trials=int(trials),
            timeout=cfg.optuna_timeout_seconds,
            n_jobs=1,
            show_progress_bar=False,
            callbacks=[_optuna_progress_callback],
        )
        if study.best_trial is None or study.best_value < 0:
            return None
        # Rebuild best estimator using the saved best trial object.
        nm, est = build_from_trial(study.best_trial)
        return (nm, est)
    except Exception as exc:
        eprint(f"[{stage_name}] Optuna skipped after error: {exc}")
        return None


def fit_best_classifier(
    x: sp.csr_matrix,
    y: np.ndarray,
    cfg: TrainConfig,
    stage_name: str,
    nfolds: int,
    features_nonnegative: bool,
    parallel_cfg: ParallelConfig,
    optuna_trials: int = 0,
) -> FittedClassifier:
    y = np.asarray(y)
    classes = np.sort(np.unique(y))
    if classes.size < 2:
        raise ValueError(f"{stage_name}: need at least 2 classes to train, got {classes.size}")

    candidates = candidate_estimators(cfg, stage_name, x.shape[0], x.shape[1], len(classes), features_nonnegative, parallel_cfg)
    splits = choose_cv_splits(y, nfolds)

    tuned = make_optuna_candidate(x, y, classes, cfg, stage_name, optuna_trials, parallel_cfg, features_nonnegative, splits)
    if tuned is not None:
        candidates.insert(0, tuned)

    if not candidates:
        raise RuntimeError(f"{stage_name}: no model candidates are available")

    cv_scores: List[CandidateScore] = []
    if splits >= 2 and cfg.model_search != "none":
        for name, proto in candidates:
            eprint(f"[{stage_name}] CV candidate: {name}")
            score = evaluate_candidate_cv(name, proto, x, y, classes, splits, cfg)
            cv_scores.append(score)
            if score.failed:
                eprint(f"[{stage_name}]   failed: {score.reason}")
            else:
                f1s = "NA" if score.macro_f1 is None else f"{score.macro_f1:.4f}"
                lls = "NA" if score.log_loss_value is None or not np.isfinite(score.log_loss_value) else f"{score.log_loss_value:.4f}"
                eprint(f"[{stage_name}]   macro-F1={f1s} logloss={lls}")
    else:
        cv_scores = [CandidateScore(name=candidates[0][0], macro_f1=None, log_loss_value=None, failed=False)]

    usable = [s for s in cv_scores if not s.failed]
    if usable and any(s.macro_f1 is not None for s in usable):
        def sort_key(s: CandidateScore) -> Tuple[float, float]:
            f1 = -1.0 if s.macro_f1 is None else float(s.macro_f1)
            ll = 999.0 if s.log_loss_value is None or not np.isfinite(s.log_loss_value) else float(s.log_loss_value)
            return (f1, -ll)
        usable_sorted = sorted(usable, key=sort_key, reverse=True)
        chosen_names = [s.name for s in usable_sorted[:max(1, int(cfg.ensemble_size))]]
    else:
        chosen_names = [candidates[0][0]]

    # Fit selected models on the full training matrix.
    proto_by_name = {name: proto for name, proto in candidates}
    score_by_name = {s.name: s for s in cv_scores}
    estimators: List[Any] = []
    model_names: List[str] = []
    weights: List[float] = []
    for name in chosen_names:
        proto = proto_by_name.get(name)
        if proto is None:
            continue
        try:
            est = fit_final_estimator(proto, x, y, cfg, stage_name, name, splits)
            estimators.append(est)
            model_names.append(name)
            sc = score_by_name.get(name)
            if sc and sc.macro_f1 is not None and sc.macro_f1 > 0:
                weights.append(float(sc.macro_f1) ** float(cfg.ensemble_power))
            else:
                weights.append(1.0)
        except Exception as exc:
            eprint(f"[{stage_name}] Final fit failed for {name}: {exc}")

    if not estimators:
        # Last-ditch fallback: fit first candidate.
        name, proto = candidates[0]
        est = clone(proto)
        est.fit(x, y)
        estimators = [est]
        model_names = [name]
        weights = [1.0]

    return FittedClassifier(
        stage_name=stage_name,
        model_names=model_names,
        estimators=estimators,
        weights=weights,
        classes=classes,
        cv_scores=cv_scores,
        n_rows=int(x.shape[0]),
        n_features=int(x.shape[1]),
        n_classes=int(len(classes)),
    )


# ---------------------------------------------------------------------
# NAICS model
# ---------------------------------------------------------------------

def train_naics_target(
    train_df: pd.DataFrame,
    target_col: str,
    text_cols: Sequence[str],
    cat_cols: Sequence[str],
    num_cols: Sequence[str],
    prefixes: Dict[str, str],
    cfg: TrainConfig,
    parallel_cfg: ParallelConfig,
) -> Dict[str, Any]:
    if target_col not in train_df.columns:
        raise ValueError(f"Training data missing NAICS target column: {target_col}")

    y_codes = clean_code_series(train_df[target_col])
    keep = y_codes.notna() & (~y_codes.map(lambda v: str(v).strip() in COMMON_CODE_MISSINGS if v is not None else True))
    if cfg.missing_naics_values:
        keep = keep & (~y_codes.isin(list(cfg.missing_naics_values)))

    df = train_df.loc[keep].copy()
    y_codes = y_codes.loc[keep].astype(str)
    global_baseline = build_label_baseline(y_codes.to_numpy(dtype=object), topn=max(100, cfg.topk_naics), code_kind="naics")

    # Keep only classes with enough support for stable CV. Predictions for classes
    # below this threshold are still represented by the dictionary if they recur.
    counts = y_codes.value_counts()
    keep_classes = counts[counts >= cfg.min_naics_n].index
    rare = sorted(set(y_codes.unique()) - set(keep_classes))
    if rare:
        eprint(f"[NAICS] Dropping {len(rare)} rare NAICS classes with <{cfg.min_naics_n} rows for ML training")
    keep2 = y_codes.isin(keep_classes)
    df_ml = df.loc[keep2].copy()
    y_ml = y_codes.loc[keep2].to_numpy(dtype=object)

    if len(df_ml) < 50 or len(np.unique(y_ml)) < 2:
        raise ValueError(f"Not enough labeled NAICS rows/classes after filtering: rows={len(df_ml)}, classes={len(np.unique(y_ml))}")

    eprint(f"\n[NAICS] Labeled rows used for ML training: {len(df_ml)}")
    eprint(f"[NAICS] Unique classes used for ML: {len(np.unique(y_ml))}")

    key_specs = [
        ("employer", ["qa20"]),
        ("employer_title", ["qa20", "qe4"]),
        ("industry_other", ["qe1oth"]),
        ("selfemp_other", ["qe8aoth"]),
        ("title_industry", ["qe4", "qe1oth"]),
    ]
    dictionary = build_exact_dictionary(df, y_codes.to_numpy(dtype=object), key_specs, cfg.naics_dict_min_count)
    eprint(f"[NAICS] Dictionary entries: {len(dictionary)}")

    adaptive_memory = build_adaptive_rule_memory(
        df=df,
        labels=y_codes.to_numpy(dtype=object),
        target=target_col,
        kind="naics",
        cfg=cfg,
    )

    semantic_memory = build_semantic_memory(
        name="NAICS_semantic_memory",
        df=df,
        labels=y_codes.to_numpy(dtype=object),
        text_cols=text_cols,
        prefixes=prefixes,
        cfg=cfg,
        kind="naics",
        reference_csv=cfg.naics_reference_csv,
    )

    feat = HybridFeaturizer(
        text_cols=[c for c in text_cols if c in df_ml.columns],
        cat_cols=[c for c in cat_cols if c in df_ml.columns and c != target_col],
        num_cols=[c for c in num_cols if c in df_ml.columns],
        prefixes=prefixes,
        cfg=cfg,
    )
    eprint("[NAICS] Building features...")
    x = feat.fit_transform(df_ml)
    eprint(f"[NAICS] Feature matrix: {x.shape[0]} rows x {x.shape[1]} cols | nnz={x.nnz:,} | approx_mem={sparse_nbytes(x)/1024**3:.2f} GB")

    with threadpool_limits(limits=parallel_cfg.native_threads):
        clf = fit_best_classifier(
            x=x,
            y=y_ml,
            cfg=cfg,
            stage_name="naics",
            nfolds=cfg.nfolds_naics,
            features_nonnegative=feat.features_are_nonnegative_,
            parallel_cfg=parallel_cfg,
            optuna_trials=cfg.optuna_trials_naics,
        )
    eprint(f"[NAICS] Selected model(s): {clf.model_name}")

    del x
    gc.collect()
    return {
        "version": VERSION,
        "kind": "naics_flat",
        "target_col": target_col,
        "dictionary": dictionary,
        "dictionary_key_specs": key_specs,
        "adaptive_memory": adaptive_memory,
        "global_baseline": global_baseline,
        "semantic_memory": semantic_memory,
        "featurizer": feat,
        "classifier": clf,
        "text_cols": list(text_cols),
        "cat_cols": list(cat_cols),
        "num_cols": list(num_cols),
    }


def _predict_naics_topk_base(model_obj: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig) -> Dict[str, Any]:
    n = len(score_df)
    top_code: List[List[Optional[str]]] = [[None for _ in range(cfg.topk_naics)] for _ in range(n)]
    top_prob = np.zeros((n, cfg.topk_naics), dtype=np.float32)

    d = exact_dictionary_predict(
        df=score_df,
        dictionary=model_obj.get("dictionary", {}),
        key_specs=model_obj.get("dictionary_key_specs", []),
        purity=cfg.naics_dict_purity,
        min_count=cfg.naics_dict_min_count,
        topk=cfg.topk_naics,
    )
    for i in np.where(d["used"])[0].tolist():
        top_code[i][0] = d["pred"][i]
        top_prob[i, 0] = float(d["conf"][i])
        for j, alt in enumerate(d["alts"][i][:max(0, cfg.topk_naics - 1)]):
            top_code[i][j + 1] = str(alt["code"])
            top_prob[i, j + 1] = float(alt["prob"])

    title_cols = model_obj.get("text_cols", [])
    text_present = has_any_normalized_text(score_df, title_cols)
    if cfg.score_rows_without_text:
        rows_model = np.where(~d["used"])[0]
    else:
        rows_model = np.where((~d["used"]) & text_present)[0]
    if rows_model.size == 0:
        pred = {"top_code": top_code, "top_prob": top_prob, "dict_used": d["used"], "text_present": text_present}
        pred = apply_naics_baseline_fallback(pred, model_obj.get("global_baseline"), cfg)
        return maybe_llm_rerank_naics(pred, score_df, cfg, title_cols)

    # Semantic vector memory gives synonym-aware candidates before/fused with ML.
    sem_codes_global: List[Optional[List[Any]]] = [None] * n
    sem_probs_global: List[Optional[List[float]]] = [None] * n
    sem_conf_global = np.zeros(n, dtype=np.float32)
    sem_sim_global = np.zeros(n, dtype=np.float32)
    sem_row_global: List[Optional[Dict[str, Any]]] = [None] * n
    query_doc_global: List[str] = ["__EMPTY__"] * n
    sem_mem: Optional[SemanticMemory] = model_obj.get("semantic_memory")
    if sem_mem is not None:
        try:
            sem_docs = make_docs_from_columns(score_df.iloc[rows_model], title_cols, model_obj.get("featurizer").prefixes if model_obj.get("featurizer") is not None else {})
            sem_topn = max(cfg.topk_naics, int(cfg.cross_encoder_topn) if cfg.use_cross_encoder_reranker else cfg.topk_naics)
            sem_k = max(int(cfg.semantic_k), sem_topn * 2)
            sem = sem_mem.predict_topk(sem_docs, topk=sem_topn, k=sem_k)
            for local_i, global_i in enumerate(rows_model.tolist()):
                sem_codes_global[global_i] = sem["codes"][local_i][:sem_topn]
                sem_probs_global[global_i] = sem["prob"][local_i][:sem_topn].tolist()
                sem_conf_global[global_i] = float(sem["conf"][local_i])
                sem_sim_global[global_i] = float(sem["max_sim"][local_i])
                query_doc_global[global_i] = sem_docs[local_i]
                sem_row_global[global_i] = {
                    "candidate_docs": sem.get("candidate_docs", [])[local_i] if local_i < len(sem.get("candidate_docs", [])) else [],
                    "conf": float(sem["conf"][local_i]),
                    "max_sim": float(sem["max_sim"][local_i]),
                }
        except Exception as exc:
            eprint(f"[NAICS] Semantic memory prediction skipped after error: {exc}")

    feat: HybridFeaturizer = model_obj["featurizer"]
    clf: FittedClassifier = model_obj["classifier"]
    classes = np.asarray(clf.classes)

    fusion_ml = np.zeros((n, cfg.topk_naics), dtype=np.float32)
    fusion_sem = np.zeros((n, cfg.topk_naics), dtype=np.float32)
    fusion_ce = np.zeros((n, cfg.topk_naics), dtype=np.float32)
    pre_rerank_top: List[Any] = [None] * n
    rerank_used = np.zeros(n, dtype=bool)
    fusion_weights = model_obj.get("fusion_weights")
    for batch in batched_indices(rows_model, cfg.score_batch_size):
        xs = feat.transform(score_df.iloc[batch])
        p = clf.predict_proba(xs)
        ml_code_rows: List[List[Any]] = []
        ml_prob_rows: List[List[float]] = []
        sem_rows: List[Optional[Dict[str, Any]]] = []
        qdocs: List[str] = []
        for local_i, global_i in enumerate(batch.tolist()):
            ord_idx = safe_top_indices(p[local_i], min(cfg.topk_naics, p.shape[1]))
            ml_code_rows.append([str(classes[j]) for j in ord_idx.tolist()])
            ml_prob_rows.append([float(p[local_i, j]) for j in ord_idx.tolist()])
            sem_rows.append(sem_row_global[global_i])
            if query_doc_global[global_i] == "__EMPTY__":
                query_doc_global[global_i] = make_docs_from_columns(score_df.iloc[[global_i]], title_cols, feat.prefixes)[0]
            qdocs.append(query_doc_global[global_i])
        fused = rerank_union_candidates_with_cross_encoder(
            qdocs, ml_code_rows, ml_prob_rows, sem_rows, sem_mem, cfg, cfg.topk_naics, "naics", fusion_weights
        )
        for local_i, global_i in enumerate(batch.tolist()):
            for rank in range(cfg.topk_naics):
                top_code[global_i][rank] = fused["codes"][local_i][rank]
                top_prob[global_i, rank] = float(fused["prob"][local_i, rank])
                fusion_ml[global_i, rank] = float(fused["ml_component"][local_i, rank])
                fusion_sem[global_i, rank] = float(fused["semantic_component"][local_i, rank])
                fusion_ce[global_i, rank] = float(fused["cross_encoder_component"][local_i, rank])
            pre_rerank_top[global_i] = fused["pre_rerank_top"][local_i]
            rerank_used[global_i] = bool(fused["rerank_used"][local_i])
        del xs
        gc.collect()

    pred = {
        "top_code": top_code, "top_prob": top_prob, "dict_used": d["used"], "text_present": text_present,
        "fusion_ml": fusion_ml, "fusion_semantic": fusion_sem, "fusion_cross_encoder": fusion_ce,
        "pre_rerank_top_code": pre_rerank_top, "reranker_used": rerank_used,
    }
    pred = apply_naics_baseline_fallback(pred, model_obj.get("global_baseline"), cfg)
    return maybe_llm_rerank_naics(pred, score_df, cfg, title_cols)


# ---------------------------------------------------------------------
# SOC hierarchical model
# ---------------------------------------------------------------------

def train_hierarchical_soc_target(
    train_df: pd.DataFrame,
    y_col: str,
    title_col: str,
    naics_col: str,
    text_cols: Sequence[str],
    cat_cols: Sequence[str],
    num_cols: Sequence[str],
    prefixes: Dict[str, str],
    cfg: TrainConfig,
    parallel_cfg: ParallelConfig,
) -> Dict[str, Any]:
    if y_col not in train_df.columns:
        raise ValueError(f"Training data missing SOC target column: {y_col}")

    y_soc = pd.to_numeric(train_df[y_col], errors="coerce").round().astype("Int64")
    keep = y_soc.notna() & (y_soc >= 100000) & (y_soc <= 999999)
    if cfg.missing_soc_values:
        keep = keep & (~y_soc.isin(list(cfg.missing_soc_values)))

    df = train_df.loc[keep].copy()
    y_soc = y_soc.loc[keep].astype(int)

    if title_col in df.columns:
        has_title = df[title_col].map(lambda v: len(normalize_text(v)) > 0)
        df = df.loc[has_title].copy()
        y_soc = y_soc.loc[has_title].astype(int)

    if len(df) < 100:
        raise ValueError(f"Not enough labeled rows for {y_col}: {len(df)}")

    y_major = y_soc.map(soc6_to_major2)
    keep_major = y_major.notna() & y_major.isin(list(VALID_SOC_MAJOR_GROUPS))
    if (~keep_major).sum():
        eprint(f"[{y_col}] Dropping {int((~keep_major).sum())} rows with invalid SOC major group")
    df = df.loc[keep_major].copy()
    y_soc = y_soc.loc[keep_major].astype(int)
    y_major = y_major.loc[keep_major].astype(int)

    major_counts = y_major.value_counts()
    rare_major = major_counts[major_counts < 3].index.tolist()
    if rare_major:
        eprint(f"[{y_col}] Dropping rare major groups (<3 rows): " + ", ".join(f"{g:02d}" for g in rare_major))
        keep2 = ~y_major.isin(rare_major)
        df = df.loc[keep2].copy()
        y_soc = y_soc.loc[keep2].astype(int)
        y_major = y_major.loc[keep2].astype(int)

    eprint(f"\n[{y_col}] Labeled rows used for SOC training: {len(df)}")
    eprint(f"[{y_col}] Unique major groups: {y_major.nunique()} | Unique SOC6: {y_soc.nunique()}")
    global_baseline = build_label_baseline(y_soc.to_numpy(dtype=np.int32), topn=max(100, cfg.topk_soc), code_kind="soc")

    dictionary = build_soc_title_naics_dictionary(
        df=df,
        title_col=title_col,
        naics_col=naics_col,
        y_soc=y_soc.to_numpy(dtype=np.int32),
        min_count=cfg.dict_min_count,
        cfg=cfg,
    )
    eprint(f"[{y_col}] SOC exact dictionary entries: {len(dictionary.get('exact', {}))}")

    adaptive_memory = build_adaptive_rule_memory(
        df=df,
        labels=y_soc.to_numpy(dtype=np.int32),
        target=y_col,
        kind="soc",
        cfg=cfg,
    )

    semantic_memory = build_semantic_memory(
        name=f"{y_col}_SOC_semantic_memory",
        df=df,
        labels=y_soc.to_numpy(dtype=np.int32),
        text_cols=text_cols,
        prefixes=prefixes,
        cfg=cfg,
        kind="soc",
        reference_csv=cfg.soc_reference_csv,
    )

    feat = HybridFeaturizer(
        text_cols=[c for c in text_cols if c in df.columns],
        cat_cols=[c for c in cat_cols if c in df.columns],
        num_cols=[c for c in num_cols if c in df.columns],
        prefixes=prefixes,
        cfg=cfg,
    )
    eprint(f"[{y_col}] Building features...")
    x = feat.fit_transform(df)
    eprint(f"[{y_col}] Feature matrix: {x.shape[0]} rows x {x.shape[1]} cols | nnz={x.nnz:,} | approx_mem={sparse_nbytes(x)/1024**3:.2f} GB")

    with threadpool_limits(limits=parallel_cfg.native_threads):
        major_model = fit_best_classifier(
            x=x,
            y=y_major.to_numpy(dtype=np.int32),
            cfg=cfg,
            stage_name=f"{y_col}_major",
            nfolds=cfg.nfolds_major,
            features_nonnegative=feat.features_are_nonnegative_,
            parallel_cfg=parallel_cfg,
            optuna_trials=cfg.optuna_trials_major,
        )
    eprint(f"[{y_col}] Major-group selected model(s): {major_model.model_name}")

    within_models: Dict[str, FittedClassifier] = {}
    within_baselines: Dict[str, Dict[str, Any]] = {}
    y_major_np = y_major.to_numpy(dtype=np.int32)
    y_soc_np = y_soc.to_numpy(dtype=np.int32)
    major_classes = sorted(np.unique(y_major_np).tolist())

    def _train_one_group(g: int) -> Tuple[str, str, Any, str]:
        try:
            idx_g = np.where(y_major_np == g)[0]
            y_g = y_soc_np[idx_g]
            counts = Counter(y_g.tolist())
            keep_codes = sorted([soc for soc, n in counts.items() if n >= cfg.min_soc_n])
            if len(keep_codes) < 2:
                ordered = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
                total = float(sum(n for _, n in ordered))
                baseline = {"soc": [int(soc) for soc, _ in ordered[:75]], "prob": [float(n / total) for _, n in ordered[:75]]}
                return str(g), "baseline", baseline, f"[{y_col}] Major {g:02d}: baseline only (unique={len(counts)}, kept={len(keep_codes)})"

            keep_mask = np.isin(y_g, np.array(keep_codes, dtype=np.int32))
            keep_rows = idx_g[keep_mask]
            y_train_g = y_soc_np[keep_rows]
            if len(keep_rows) < 50 or len(np.unique(y_train_g)) < 2:
                ordered = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
                total = float(sum(n for _, n in ordered))
                baseline = {"soc": [int(soc) for soc, _ in ordered[:75]], "prob": [float(n / total) for _, n in ordered[:75]]}
                return str(g), "baseline", baseline, f"[{y_col}] Major {g:02d}: baseline only (too small after filtering)"

            x_g = x[keep_rows]
            model = fit_best_classifier(
                x=x_g,
                y=y_train_g.astype(np.int32),
                cfg=cfg,
                stage_name=f"{y_col}_within_{g:02d}",
                nfolds=cfg.nfolds_within,
                features_nonnegative=feat.features_are_nonnegative_,
                parallel_cfg=parallel_cfg,
                optuna_trials=cfg.optuna_trials_within,
            )
            msg = f"[{y_col}] Major {g:02d}: trained {model.model_name} (rows={x_g.shape[0]}, classes={model.n_classes}"
            if model.cv_macro_f1 is not None:
                msg += f", CV macro-F1={model.cv_macro_f1:.4f}"
            msg += ")"
            return str(g), "model", model, msg
        except Exception as exc:
            return str(g), "error", None, f"[{y_col}] Major {g:02d}: training failed, no baseline/model created: {exc}"

    with threadpool_limits(limits=parallel_cfg.native_threads):
        if parallel_cfg.max_workers > 1 and len(major_classes) > 1:
            results = Parallel(n_jobs=parallel_cfg.max_workers, prefer="threads")(
                delayed(_train_one_group)(g) for g in major_classes
            )
        else:
            results = [_train_one_group(g) for g in major_classes]

    for gkey, kind, payload, msg in results:
        eprint(msg)
        if kind == "model" and payload is not None:
            within_models[gkey] = payload
        elif kind == "baseline" and payload is not None:
            within_baselines[gkey] = payload

    del x
    gc.collect()
    return {
        "version": VERSION,
        "kind": "soc_hierarchical",
        "target_col": y_col,
        "title_col": title_col,
        "naics_col": naics_col,
        "dictionary": dictionary,
        "adaptive_memory": adaptive_memory,
        "global_baseline": global_baseline,
        "semantic_memory": semantic_memory,
        "featurizer": feat,
        "major_model": major_model,
        "within_models": within_models,
        "within_baselines": within_baselines,
        "text_cols": list(text_cols),
        "cat_cols": list(cat_cols),
        "num_cols": list(num_cols),
    }


def _predict_soc_target_topk_base(model_obj: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig) -> Dict[str, Any]:
    n = len(score_df)
    top_soc = np.full((n, cfg.topk_soc), -1, dtype=np.int32)
    top_prob = np.zeros((n, cfg.topk_soc), dtype=np.float32)

    d = soc_dictionary_predict(
        df=score_df,
        dictionary=model_obj.get("dictionary", {}),
        title_col=model_obj["title_col"],
        naics_col=model_obj["naics_col"],
        purity=cfg.dict_purity,
        min_count=cfg.dict_min_count,
        cfg=cfg,
    )
    for i in np.where(d["used"])[0].tolist():
        top_soc[i, 0] = int(d["pred"][i])
        top_prob[i, 0] = float(d["conf"][i])
        for j, alt in enumerate(d["alts"][i][:max(0, cfg.topk_soc - 1)]):
            top_soc[i, j + 1] = int(alt["soc"])
            top_prob[i, j + 1] = float(alt["prob"])

    title_col = model_obj["title_col"]
    if title_col in score_df.columns:
        title_present = score_df[title_col].map(lambda v: len(normalize_text(v)) > 0).to_numpy(dtype=bool)
    else:
        title_present = np.zeros(n, dtype=bool)
    if cfg.score_rows_without_text:
        rows_model = np.where(~d["used"])[0]
    else:
        rows_model = np.where((~d["used"]) & title_present)[0]
    text_cols = model_obj.get("text_cols", [title_col])
    if rows_model.size == 0:
        pred = {"top_soc": top_soc, "top_prob": top_prob, "dict_used": d["used"], "title_present": title_present}
        pred = apply_soc_baseline_fallback(pred, model_obj.get("global_baseline"), cfg)
        return maybe_llm_rerank_soc(pred, score_df, cfg, text_cols)

    # Semantic vector memory for synonym-aware SOC candidates. It is fused with
    # hierarchical ML candidates when close neighbors are found.
    sem_codes_global: List[Optional[List[Any]]] = [None] * n
    sem_probs_global: List[Optional[List[float]]] = [None] * n
    sem_conf_global = np.zeros(n, dtype=np.float32)
    sem_sim_global = np.zeros(n, dtype=np.float32)
    sem_row_global: List[Optional[Dict[str, Any]]] = [None] * n
    query_doc_global: List[str] = ["__EMPTY__"] * n
    sem_mem: Optional[SemanticMemory] = model_obj.get("semantic_memory")
    if sem_mem is not None:
        try:
            sem_docs = make_docs_from_columns(score_df.iloc[rows_model], text_cols, model_obj.get("featurizer").prefixes if model_obj.get("featurizer") is not None else {})
            sem_topn = max(cfg.topk_soc, int(cfg.cross_encoder_topn) if cfg.use_cross_encoder_reranker else cfg.topk_soc)
            sem_k = max(int(cfg.semantic_k), sem_topn * 2)
            sem = sem_mem.predict_topk(sem_docs, topk=sem_topn, k=sem_k)
            for local_i, global_i in enumerate(rows_model.tolist()):
                sem_codes_global[global_i] = sem["codes"][local_i][:sem_topn]
                sem_probs_global[global_i] = sem["prob"][local_i][:sem_topn].tolist()
                sem_conf_global[global_i] = float(sem["conf"][local_i])
                sem_sim_global[global_i] = float(sem["max_sim"][local_i])
                query_doc_global[global_i] = sem_docs[local_i]
                sem_row_global[global_i] = {
                    "candidate_docs": sem.get("candidate_docs", [])[local_i] if local_i < len(sem.get("candidate_docs", [])) else [],
                    "conf": float(sem["conf"][local_i]),
                    "max_sim": float(sem["max_sim"][local_i]),
                }
        except Exception as exc:
            eprint(f"[{model_obj.get('target_col', 'SOC')}] Semantic memory prediction skipped after error: {exc}")

    feat: HybridFeaturizer = model_obj["featurizer"]
    major_model: FittedClassifier = model_obj["major_model"]
    major_classes = np.asarray(major_model.classes)
    kG = min(cfg.top_groups, len(major_classes))

    fusion_ml = np.zeros((n, cfg.topk_soc), dtype=np.float32)
    fusion_sem = np.zeros((n, cfg.topk_soc), dtype=np.float32)
    fusion_ce = np.zeros((n, cfg.topk_soc), dtype=np.float32)
    pre_rerank_top: List[Any] = [None] * n
    rerank_used = np.zeros(n, dtype=bool)
    fusion_weights = model_obj.get("fusion_weights")
    for batch in batched_indices(rows_model, cfg.score_batch_size):
        xs = feat.transform(score_df.iloc[batch])
        major_proba = major_model.predict_proba(xs)
        top_major_idx = np.vstack([safe_top_indices(r, kG) for r in major_proba])
        top_major_codes = major_classes[top_major_idx]

        grouped: Dict[int, List[Tuple[int, float]]] = defaultdict(list)
        for g in np.unique(top_major_codes).tolist():
            local_rows = np.where((top_major_codes == g).any(axis=1))[0]
            if local_rows.size == 0:
                continue
            global_rows = batch[local_rows]
            col_g = int(np.where(major_classes == g)[0][0])
            p_major = major_proba[local_rows, col_g]
            gkey = str(int(g))
            wm: Optional[FittedClassifier] = model_obj["within_models"].get(gkey)
            if wm is not None:
                xg = xs[local_rows]
                p_within = wm.predict_proba(xg)
                codes_g = np.asarray(wm.classes)
                for ridx in range(p_within.shape[0]):
                    ord_idx = safe_top_indices(p_within[ridx], min(cfg.topk_soc, p_within.shape[1]))
                    for o in ord_idx.tolist():
                        grouped[int(global_rows[ridx])].append((int(codes_g[o]), float(p_within[ridx, o] * p_major[ridx])))
            else:
                base = model_obj["within_baselines"].get(gkey)
                if base is None:
                    continue
                m = min(cfg.topk_soc, len(base["soc"]))
                for ridx, global_row in enumerate(global_rows.tolist()):
                    for soc, pr in zip(base["soc"][:m], base["prob"][:m]):
                        grouped[int(global_row)].append((int(soc), float(p_major[ridx] * pr)))

        ml_code_rows: List[List[Any]] = []
        ml_prob_rows: List[List[float]] = []
        sem_rows: List[Optional[Dict[str, Any]]] = []
        qdocs: List[str] = []
        for row in batch.tolist():
            ml_merged: Dict[int, float] = {}
            for soc, pr in grouped.get(int(row), []):
                ml_merged[int(soc)] = max(ml_merged.get(int(soc), 0.0), float(pr))
            ml_ordered = sorted(ml_merged.items(), key=lambda kv: kv[1], reverse=True)[:cfg.topk_soc]
            ml_code_rows.append([soc for soc, _ in ml_ordered])
            ml_prob_rows.append([pr for _, pr in ml_ordered])
            sem_rows.append(sem_row_global[int(row)])
            if query_doc_global[int(row)] == "__EMPTY__":
                query_doc_global[int(row)] = make_docs_from_columns(score_df.iloc[[int(row)]], text_cols, feat.prefixes)[0]
            qdocs.append(query_doc_global[int(row)])
        fused = rerank_union_candidates_with_cross_encoder(
            qdocs, ml_code_rows, ml_prob_rows, sem_rows, sem_mem, cfg, cfg.topk_soc, "soc", fusion_weights
        )
        for local_i, row in enumerate(batch.tolist()):
            for rank in range(cfg.topk_soc):
                code = fused["codes"][local_i][rank]
                top_soc[int(row), rank] = int(code) if code is not None else -1
                top_prob[int(row), rank] = float(fused["prob"][local_i, rank])
                fusion_ml[int(row), rank] = float(fused["ml_component"][local_i, rank])
                fusion_sem[int(row), rank] = float(fused["semantic_component"][local_i, rank])
                fusion_ce[int(row), rank] = float(fused["cross_encoder_component"][local_i, rank])
            pre_rerank_top[int(row)] = fused["pre_rerank_top"][local_i]
            rerank_used[int(row)] = bool(fused["rerank_used"][local_i])
        del xs
        gc.collect()

    pred = {
        "top_soc": top_soc, "top_prob": top_prob, "dict_used": d["used"], "title_present": title_present,
        "fusion_ml": fusion_ml, "fusion_semantic": fusion_sem, "fusion_cross_encoder": fusion_ce,
        "pre_rerank_top_code": pre_rerank_top, "reranker_used": rerank_used,
    }
    pred = apply_soc_baseline_fallback(pred, model_obj.get("global_baseline"), cfg)
    return maybe_llm_rerank_soc(pred, score_df, cfg, text_cols)


def predict_naics_topk(model_obj: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig) -> Dict[str, Any]:
    requested_topk = int(cfg.topk_naics)
    pool = max(
        requested_topk, int(getattr(cfg, "memory_candidate_pool", 24)),
        int(getattr(cfg, "cross_encoder_candidate_pool", 24)),
        int(getattr(cfg, "conformal_candidate_pool", 24)),
    )
    cfg.topk_naics = pool
    try:
        pred = _predict_naics_topk_base(model_obj, score_df, cfg)
    finally:
        cfg.topk_naics = requested_topk
    pred = apply_adaptive_memory_to_naics_prediction(pred, score_df, model_obj, cfg, pool)
    pred["candidate_pool_code"] = [list(r) for r in pred["top_code"]]
    pred["candidate_pool_prob"] = np.asarray(pred["top_prob"], dtype=np.float32).copy()
    pred["top_code"] = [list(r[:requested_topk]) for r in pred["top_code"]]
    pred["top_prob"] = np.asarray(pred["top_prob"][:, :requested_topk], dtype=np.float32)
    return pred


def predict_soc_target_topk(model_obj: Dict[str, Any], score_df: pd.DataFrame, cfg: TrainConfig) -> Dict[str, Any]:
    requested_topk = int(cfg.topk_soc)
    pool = max(
        requested_topk, int(getattr(cfg, "memory_candidate_pool", 24)),
        int(getattr(cfg, "cross_encoder_candidate_pool", 24)),
        int(getattr(cfg, "conformal_candidate_pool", 24)),
    )
    cfg.topk_soc = pool
    try:
        pred = _predict_soc_target_topk_base(model_obj, score_df, cfg)
    finally:
        cfg.topk_soc = requested_topk
    pred = apply_adaptive_memory_to_soc_prediction(pred, score_df, model_obj, cfg, pool)
    pred["candidate_pool_soc"] = np.asarray(pred["top_soc"], dtype=np.int32).copy()
    pred["candidate_pool_prob"] = np.asarray(pred["top_prob"], dtype=np.float32).copy()
    pred["top_soc"] = np.asarray(pred["top_soc"][:, :requested_topk], dtype=np.int32)
    pred["top_prob"] = np.asarray(pred["top_prob"][:, :requested_topk], dtype=np.float32)
    return pred



def _prediction_truth_and_arrays(pred: Dict[str, Any], true_series: pd.Series, kind: str) -> Tuple[np.ndarray, np.ndarray, List[str], List[List[str]], np.ndarray]:
    if kind == "naics":
        truth = np.asarray([clean_code_value(v) for v in true_series.tolist()], dtype=object)
        pool_codes = [[clean_code_value(c) for c in row] for row in pred.get("candidate_pool_code", pred.get("top_code", []))]
    else:
        truth = np.asarray([format_soc(v) if format_soc(v) != "MISSING" else None for v in true_series.tolist()], dtype=object)
        arr = np.asarray(pred.get("candidate_pool_soc", pred.get("top_soc", [])))
        pool_codes = [[format_soc(c) if int(c) > 0 else None for c in row] for row in arr]
    top_probs = np.asarray(pred.get("top_prob", []), dtype=float)
    pool_probs = np.asarray(pred.get("candidate_pool_prob", top_probs), dtype=float)
    top_code = np.asarray([row[0] if row else None for row in pool_codes], dtype=object)
    confidence = np.asarray([float(top_probs[i, 0]) if top_probs.ndim == 2 and i < top_probs.shape[0] else 0.0 for i in range(len(pool_codes))], dtype=float)
    sources = [str(s) for s in pred.get("prediction_source", ["model"] * len(pool_codes))]
    return truth, top_code, sources, pool_codes, pool_probs


def _valid_truth_mask(truth: np.ndarray, kind: str) -> np.ndarray:
    if kind == "naics":
        return np.asarray([v is not None and str(v) not in COMMON_CODE_MISSINGS for v in truth], dtype=bool)
    return np.asarray([v is not None and str(v).isdigit() and len(str(v)) == 6 and int(str(v)[:2]) in VALID_SOC_MAJOR_GROUPS for v in truth], dtype=bool)



def _candidate_component_arrays(pred: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    return (
        np.asarray(pred.get("fusion_ml", []), dtype=float),
        np.asarray(pred.get("fusion_semantic", []), dtype=float),
        np.asarray(pred.get("fusion_cross_encoder", []), dtype=float),
    )


def _fit_candidate_meta_ranker(
    pred: Dict[str, Any],
    true_series: pd.Series,
    kind: str,
    fit_mask: np.ndarray,
    random_seed: int,
    min_rows: int,
) -> Optional[CandidateFusionRanker]:
    ml, sem, ce = _candidate_component_arrays(pred)
    if ml.ndim != 2 or ml.size == 0 or sem.shape != ml.shape or ce.shape != ml.shape:
        return None
    truth, _, sources, pool_codes, _ = _prediction_truth_and_arrays(pred, true_series, kind)
    valid = _valid_truth_mask(truth, kind)
    valid &= np.asarray([s == "model" for s in sources], dtype=bool)
    if fit_mask.size == len(valid):
        valid &= fit_mask
    x_rows: List[np.ndarray] = []
    y_rows: List[np.ndarray] = []
    builder = CandidateFusionRanker(random_seed=random_seed)
    positive_rows = 0
    for i in np.where(valid)[0].tolist():
        codes = pool_codes[i]
        n = min(len(codes), ml.shape[1])
        if n < 2:
            continue
        y = np.asarray([c is not None and str(c) == str(truth[i]) for c in codes[:n]], dtype=int)
        if y.sum() == 0:
            continue
        positive_rows += 1
        x_rows.append(builder.row_features(ml[i, :n], sem[i, :n], ce[i, :n]))
        y_rows.append(y)
    if positive_rows < int(min_rows) or not x_rows:
        return None
    ranker = CandidateFusionRanker(random_seed=random_seed)
    ranker.fit(np.vstack(x_rows), np.concatenate(y_rows))
    return ranker if ranker.model is not None else None


def _apply_candidate_meta_ranker(pred: Dict[str, Any], ranker: Optional[CandidateFusionRanker], kind: str) -> Dict[str, Any]:
    if ranker is None:
        return pred
    ml, sem, ce = _candidate_component_arrays(pred)
    if ml.ndim != 2 or ml.size == 0 or sem.shape != ml.shape or ce.shape != ml.shape:
        return pred
    sources = list(pred.get("prediction_source", ["model"] * ml.shape[0]))
    if kind == "naics":
        codes = [list(row) for row in pred.get("candidate_pool_code", pred.get("top_code", []))]
    else:
        arr = np.asarray(pred.get("candidate_pool_soc", pred.get("top_soc", [])), dtype=np.int32)
        codes = [[int(c) if int(c) > 0 else None for c in row] for row in arr]
    pool_prob = np.asarray(pred.get("candidate_pool_prob", pred.get("top_prob", [])), dtype=float)
    n_public = np.asarray(pred.get("top_prob", [])).shape[1] if np.asarray(pred.get("top_prob", [])).ndim == 2 else 4
    meta_used = np.zeros(len(codes), dtype=bool)
    for i, row_codes in enumerate(codes):
        if i >= ml.shape[0] or sources[i] != "model":
            continue
        n = min(len(row_codes), ml.shape[1])
        valid_idx = [j for j in range(n) if row_codes[j] is not None]
        if len(valid_idx) < 2:
            continue
        x = ranker.row_features(ml[i, valid_idx], sem[i, valid_idx], ce[i, valid_idx])
        score = np.maximum(ranker.predict(x), 1e-12)
        score = score / (score.sum() or 1.0)
        order_local = np.argsort(-score)
        order = [valid_idx[j] for j in order_local.tolist()]
        tail = [j for j in range(n) if j not in order]
        full_order = order + tail + list(range(n, len(row_codes)))
        codes[i] = [row_codes[j] for j in full_order]
        ml[i, :len(full_order)] = ml[i, full_order]
        sem[i, :len(full_order)] = sem[i, full_order]
        ce[i, :len(full_order)] = ce[i, full_order]
        new_prob = np.zeros(len(row_codes), dtype=float)
        new_prob[:len(order)] = score[order_local]
        if len(tail):
            residual = max(0.0, 1.0 - float(new_prob[:len(order)].sum()))
            if residual > 0:
                new_prob[len(order):len(order)+len(tail)] = residual / len(tail)
        pool_prob[i, :len(row_codes)] = new_prob
        meta_used[i] = True
    pred["fusion_ml"] = ml.astype(np.float32)
    pred["fusion_semantic"] = sem.astype(np.float32)
    pred["fusion_cross_encoder"] = ce.astype(np.float32)
    pred["candidate_pool_prob"] = pool_prob.astype(np.float32)
    pred["meta_ranker_used"] = meta_used
    if kind == "naics":
        pred["candidate_pool_code"] = codes
        pred["top_code"] = [row[:n_public] for row in codes]
    else:
        arr = np.asarray([[int(c) if c is not None else -1 for c in row] for row in codes], dtype=np.int32)
        pred["candidate_pool_soc"] = arr
        pred["top_soc"] = arr[:, :n_public]
    pred["top_prob"] = pool_prob[:, :n_public].astype(np.float32)
    return pred


def _grid_fusion_weights(pred: Dict[str, Any], true_series: pd.Series, kind: str, fit_mask: Optional[np.ndarray] = None) -> Dict[str, float]:
    ml = np.asarray(pred.get("fusion_ml", []), dtype=float)
    sem = np.asarray(pred.get("fusion_semantic", []), dtype=float)
    ce = np.asarray(pred.get("fusion_cross_encoder", []), dtype=float)
    if ml.ndim != 2 or ml.size == 0 or sem.shape != ml.shape or ce.shape != ml.shape:
        return {}
    truth, _, sources, pool_codes, _ = _prediction_truth_and_arrays(pred, true_series, kind)
    valid = _valid_truth_mask(truth, kind)
    valid &= np.asarray([s == "model" for s in sources], dtype=bool)
    if fit_mask is not None and len(fit_mask) == len(valid):
        valid &= np.asarray(fit_mask, dtype=bool)
    idx = np.where(valid)[0]
    if idx.size < 100:
        return {}
    class_counts = Counter(str(truth[i]) for i in idx)
    row_weights = np.asarray([1.0 / max(1, class_counts[str(truth[i])]) for i in idx], dtype=float)
    row_weights /= row_weights.sum() or 1.0
    best = {"ml": 0.5, "semantic": 0.2, "cross_encoder": 0.3, "score": -1.0}
    grid = np.linspace(0.0, 1.0, 11)
    for w_ce in grid:
        for w_sem in grid:
            if w_ce + w_sem > 1.000001:
                continue
            w_ml = 1.0 - w_ce - w_sem
            scores = w_ml * ml[idx] + w_sem * sem[idx] + w_ce * ce[idx]
            choices = np.argmax(scores, axis=1)
            hits = np.asarray([
                pool_codes[row_i][int(choice)] is not None and str(pool_codes[row_i][int(choice)]) == str(truth[row_i])
                for row_i, choice in zip(idx.tolist(), choices.tolist())
            ], dtype=float)
            balanced_hit = float(np.sum(hits * row_weights))
            raw_hit = float(hits.mean())
            objective = 0.65 * raw_hit + 0.35 * balanced_hit
            if objective > best["score"]:
                best = {"ml": float(w_ml), "semantic": float(w_sem), "cross_encoder": float(w_ce), "score": objective, "raw_accuracy": raw_hit, "balanced_hit": balanced_hit}
    return best


def _aps_quantile(scores: Sequence[float], alpha: float) -> float:
    arr = np.sort(np.asarray(scores, dtype=float))
    if arr.size == 0:
        return 1.0
    rank = int(math.ceil((arr.size + 1) * (1.0 - float(alpha))))
    rank = max(1, min(rank, arr.size))
    return float(arr[rank - 1])


def fit_posthoc_calibration_and_conformal(bundle: Dict[str, Any], calibration_df: pd.DataFrame, opt: argparse.Namespace, cfg: TrainConfig) -> Dict[str, Any]:
    """Fit stacking, source confidence maps, and APS thresholds on CALIBRATION.

    The calibration SAV is split internally: one portion learns fusion/meta
    ranking and confidence mappings; the held-out portion estimates conformal
    thresholds. GOLD remains untouched until the final audit.
    """
    n_cal = len(calibration_df)
    eprint(f"\n[CALIBRATION] Scoring {n_cal:,} calibration rows with default fusion...")
    rng = np.random.default_rng(int(cfg.random_seed) + 1701)
    perm = rng.permutation(n_cal)
    fit_n = max(1, min(n_cal - 1, int(round(n_cal * float(cfg.calibration_fit_fraction))))) if n_cal > 1 else n_cal
    fit_mask = np.zeros(n_cal, dtype=bool)
    fit_mask[perm[:fit_n]] = True
    conformal_mask = ~fit_mask
    if conformal_mask.sum() < 100:
        conformal_mask = fit_mask.copy()
    eprint(f"[CALIBRATION] internal split: fusion/calibration={fit_mask.sum():,}, conformal={conformal_mask.sum():,}")

    cal_opt = argparse.Namespace(**vars(opt))
    cal_opt.overwrite_existing = True
    cal_opt.overwrite_existing_naics = True
    cal_opt.overwrite_existing_soc = True
    cal_opt.fill_all_missing = True
    cal_opt.score_rows_without_text = True
    cal_opt.fallback_fill_missing = True
    bundle.pop("posthoc_calibration", None)
    _, details = score_with_bundle(calibration_df, bundle, cal_opt, cfg)
    targets = [
        ("qa20a", "naics", opt.naics_col, details["pred_naics"], bundle["naics_model"]),
        ("qe4ar", "soc", opt.qe4ar_col, details["pred4"], bundle["soc_qe4_model"]),
        ("qe5ar", "soc", opt.qe5ar_col, details["pred5"], bundle["soc_qe5_model"]),
    ]
    result: Dict[str, Any] = {"created_at": now_stamp(), "targets": {}, "internal_split": {"fit_rows": int(fit_mask.sum()), "conformal_rows": int(conformal_mask.sum())}}

    # Learn coarse fusion weights only on the fit half.
    for target, kind, col, pred, model_obj in targets:
        if col not in calibration_df.columns:
            continue
        fw = _grid_fusion_weights(pred, calibration_df[col], kind, fit_mask=fit_mask)
        if fw:
            model_obj["fusion_weights"] = {k: fw[k] for k in ["ml", "semantic", "cross_encoder"]}
            eprint(f"[CALIBRATION] {target} optimized fusion: ml={fw['ml']:.2f} semantic={fw['semantic']:.2f} cross_encoder={fw['cross_encoder']:.2f} fit_accuracy={fw.get('raw_accuracy', 0):.4f}")

    # Rescore with optimized coarse fusion, then fit the candidate-level stacker.
    _, details = score_with_bundle(calibration_df, bundle, cal_opt, cfg)
    targets = [
        ("qa20a", "naics", opt.naics_col, details["pred_naics"], bundle["naics_model"]),
        ("qe4ar", "soc", opt.qe4ar_col, details["pred4"], bundle["soc_qe4_model"]),
        ("qe5ar", "soc", opt.qe5ar_col, details["pred5"], bundle["soc_qe5_model"]),
    ]
    for target, kind, col, pred, model_obj in targets:
        if col not in calibration_df.columns:
            continue
        ranker = None
        if bool(cfg.use_candidate_meta_ranker):
            ranker = _fit_candidate_meta_ranker(
                pred, calibration_df[col], kind, fit_mask,
                random_seed=int(cfg.random_seed), min_rows=int(cfg.candidate_meta_ranker_min_rows),
            )
            if ranker is not None:
                _apply_candidate_meta_ranker(pred, ranker, kind)
                eprint(f"[CALIBRATION] {target} candidate stacker fitted: pair_rows={ranker.n_rows_:,}, positive_rate={ranker.positive_rate_:.4f}")
            else:
                eprint(f"[CALIBRATION] {target} candidate stacker skipped: insufficient eligible calibration rows")

        truth, top_code, sources, pool_codes, pool_probs = _prediction_truth_and_arrays(pred, calibration_df[col], kind)
        valid = _valid_truth_mask(truth, kind)
        correct = np.asarray([str(a) == str(b) for a, b in zip(truth, top_code)], dtype=bool)
        conf = np.asarray(pred["top_prob"][:, 0], dtype=float)
        calibrators: Dict[str, BinaryConfidenceCalibrator] = {}
        method = str(cfg.source_calibration_method)
        calibrator_idx = np.where(valid & fit_mask)[0]
        if bool(cfg.use_source_confidence_calibration) and calibrator_idx.size >= int(cfg.source_calibration_min_rows):
            calibrators["__global__"] = BinaryConfidenceCalibrator(method).fit(conf[calibrator_idx], correct[calibrator_idx])
            for source in sorted(set(sources)):
                source_mask = np.asarray([s == source for s in sources], dtype=bool)
                idx = np.where(valid & fit_mask & source_mask)[0]
                if idx.size >= int(cfg.source_calibration_min_rows):
                    calibrators[source] = BinaryConfidenceCalibrator(method).fit(conf[idx], correct[idx])

        # Apply the fitted confidence mappings before creating APS scores.
        calibrated_conf = conf.copy()
        for source in sorted(set(sources)):
            idx = np.where(np.asarray([s == source for s in sources], dtype=bool))[0]
            cal = calibrators.get(source) or calibrators.get("__global__")
            if cal is not None and idx.size:
                calibrated_conf[idx] = cal.predict(conf[idx])
        calibrated_pool = np.asarray(pool_probs, dtype=float).copy()
        for i in range(len(calibrated_conf)):
            calibrated_pool[i] = _renormalize_top_confidence(calibrated_pool[i], calibrated_conf[i])

        aps_scores: List[float] = []
        conformal_idx = np.where(valid & conformal_mask)[0]
        for i in conformal_idx.tolist():
            probs = np.maximum(np.asarray(calibrated_pool[i], dtype=float), 0.0)
            probs = probs / (probs.sum() or 1.0)
            true = str(truth[i])
            cumulative = 0.0
            found = False
            for code, pr in zip(pool_codes[i], probs.tolist()):
                cumulative += float(pr)
                if code is not None and str(code) == true:
                    found = True
                    break
            aps_scores.append(float(cumulative if found else 1.0))
        qhats = {str(alpha): _aps_quantile(aps_scores, alpha) for alpha in cfg.conformal_alphas}
        target_result = {
            "calibrators": calibrators,
            "candidate_meta_ranker": ranker,
            "conformal_qhat": qhats,
            "calibration_rows": int(calibrator_idx.size),
            "conformal_rows": int(conformal_idx.size),
            "fusion_weights": model_obj.get("fusion_weights", {}),
        }
        result["targets"][target] = target_result
        eprint(f"[CALIBRATION] {target}: calibration_rows={calibrator_idx.size:,} conformal_rows={conformal_idx.size:,} source_calibrators={len(calibrators)} APS={qhats}")
    bundle["posthoc_calibration"] = result
    return result


def _renormalize_top_confidence(prob_row: np.ndarray, new_top: float) -> np.ndarray:
    row = np.maximum(np.asarray(prob_row, dtype=float), 0.0)
    if row.size == 0:
        return row
    old_rest = float(row[1:].sum())
    new_top = float(np.clip(new_top, 0.0, 1.0))
    row[0] = new_top
    if row.size > 1:
        if old_rest > 0:
            row[1:] = row[1:] * ((1.0 - new_top) / old_rest)
        else:
            row[1:] = (1.0 - new_top) / (row.size - 1)
    return row


def apply_posthoc_calibration_and_conformal(pred: Dict[str, Any], target: str, bundle: Dict[str, Any], kind: str) -> Dict[str, Any]:
    info = bundle.get("posthoc_calibration", {}).get("targets", {}).get(target)
    if not info:
        return pred
    pred = _apply_candidate_meta_ranker(pred, info.get("candidate_meta_ranker"), kind)
    sources = list(pred.get("prediction_source", ["model"] * len(pred.get("top_prob", []))))
    top_prob = np.asarray(pred.get("top_prob", []), dtype=float)
    pool_prob = np.asarray(pred.get("candidate_pool_prob", top_prob), dtype=float)
    calibrators = info.get("calibrators", {})
    old_conf = top_prob[:, 0].copy() if top_prob.ndim == 2 and top_prob.shape[1] else np.zeros(len(sources))
    new_conf = old_conf.copy()
    for source in sorted(set(sources)):
        idx = np.where(np.asarray([s == source for s in sources], dtype=bool))[0]
        cal = calibrators.get(source) or calibrators.get("__global__")
        if cal is not None and idx.size:
            new_conf[idx] = cal.predict(old_conf[idx])
    for i in range(len(new_conf)):
        top_prob[i] = _renormalize_top_confidence(top_prob[i], float(new_conf[i]))
        if pool_prob.ndim == 2 and i < pool_prob.shape[0]:
            pool_prob[i] = _renormalize_top_confidence(pool_prob[i], float(new_conf[i]))
    pred["top_prob"] = top_prob.astype(np.float32)
    pred["candidate_pool_prob"] = pool_prob.astype(np.float32)
    pred["uncalibrated_top_confidence"] = old_conf.astype(np.float32)
    qhats = info.get("conformal_qhat", {})
    if kind == "naics":
        codes = pred.get("candidate_pool_code", pred.get("top_code", []))
    else:
        arr = np.asarray(pred.get("candidate_pool_soc", pred.get("top_soc", [])))
        codes = [[int(c) if int(c) > 0 else None for c in row] for row in arr]
    conformal_sets: Dict[str, List[List[Any]]] = {}
    conformal_sizes: Dict[str, np.ndarray] = {}
    for alpha_s, qhat in qhats.items():
        sets: List[List[Any]] = []
        sizes = np.zeros(len(codes), dtype=np.int32)
        for i, row_codes in enumerate(codes):
            probs = np.maximum(pool_prob[i], 0.0)
            probs = probs / (probs.sum() or 1.0)
            chosen: List[Any] = []
            cumulative = 0.0
            for code, pr in zip(row_codes, probs.tolist()):
                if code is None:
                    continue
                chosen.append(code)
                cumulative += float(pr)
                if cumulative >= float(qhat):
                    break
            if not chosen and row_codes:
                chosen = [row_codes[0]] if row_codes[0] is not None else []
            sets.append(chosen)
            sizes[i] = len(chosen)
        conformal_sets[alpha_s] = sets
        conformal_sizes[alpha_s] = sizes
    pred["conformal_sets"] = conformal_sets
    pred["conformal_set_sizes"] = conformal_sizes
    return pred


# ---------------------------------------------------------------------
# SPSS helpers
# ---------------------------------------------------------------------

def read_sav_with_meta(path: str) -> Tuple[pd.DataFrame, Any]:
    return pyreadstat.read_sav(path, user_missing=True, apply_value_formats=False)


def write_sav_preserving_metadata(df: pd.DataFrame, meta: Any, path: str) -> None:
    cols = list(df.columns)
    pyreadstat.write_sav(
        df,
        path,
        file_label=getattr(meta, "file_label", "") or "",
        column_labels=filter_meta_dict(getattr(meta, "column_names_to_labels", None), cols),
        variable_value_labels=filter_meta_dict(getattr(meta, "variable_value_labels", None), cols),
        missing_ranges=filter_meta_dict(getattr(meta, "missing_ranges", None), cols),
        variable_display_width=filter_meta_dict(getattr(meta, "variable_display_width", None), cols),
        variable_measure=filter_meta_dict(getattr(meta, "variable_measure", None), cols),
        variable_format=filter_meta_dict(getattr(meta, "original_variable_types", None), cols),
        note=getattr(meta, "notes", None),
        compress=False,
    )


def assign_code_predictions(out_df: pd.DataFrame, col: str, apply_mask: np.ndarray, preds: Sequence[Optional[str]]) -> None:
    if col not in out_df.columns:
        return
    idx = np.where(apply_mask)[0]
    if len(idx) == 0:
        return
    if pd.api.types.is_numeric_dtype(out_df[col]):
        vals = pd.to_numeric(pd.Series([preds[i] for i in idx]), errors="coerce").to_numpy()
        out_df.loc[out_df.index[idx], col] = vals
    else:
        vals = ["" if preds[i] is None else str(preds[i]) for i in idx]
        out_df.loc[out_df.index[idx], col] = vals


def assign_soc_predictions(out_df: pd.DataFrame, col: str, apply_mask: np.ndarray, preds: np.ndarray) -> None:
    if col not in out_df.columns:
        return
    idx = np.where(apply_mask)[0]
    if len(idx) == 0:
        return
    out_df.loc[out_df.index[idx], col] = preds[idx].astype(float)


# ---------------------------------------------------------------------
# Column plan and logging
# ---------------------------------------------------------------------

def build_prefixes(opt: argparse.Namespace) -> Dict[str, str]:
    prefixes: Dict[str, str] = {
        opt.qe4_col: "JOBTITLE:",
        opt.qe5_col: "UNUSEDSKILL_TITLE:",
        "qa20": "EMPLOYER:",
        opt.naics_col: "NAICS:",
        "qe1oth": "INDUSTRY_OTHER:",
        "qe8aoth": "SELFEMP_OTHER:",
        "qe2b": "WORKCITY:",
        "qa9a": "ED_FIELD:",
        "qa9c1": "CERT:",
        "qa9c2": "CERT:",
        "qa9c3": "CERT:",
        "qa9c4": "CERT:",
        "qa9g": "LICENSE:",
        "qe13oth": "PAYTYPE_OTHER:",
    }
    return prefixes


def column_plan(opt: argparse.Namespace) -> Dict[str, List[str]]:
    common_text_cols = ["qa20", "qe1oth", "qe8aoth", "qe2b", "qa9a", "qa9c1", "qa9c2", "qa9c3", "qa9c4", "qa9g", "qe13oth"]
    plan = {
        "naics_text": ["qa20", opt.qe4_col, opt.qe5_col, "qe1oth", "qe8aoth", "qe2b"],
        "naics_cat": ["qe1", "qse1", "qe8a", "wh2", "qe8", "qa9", "qa9ar", "qe13", "qa6"],
        "naics_num": ["qe10"],
        "qe4_text": [opt.qe4_col] + common_text_cols + [opt.naics_col],
        "qe4_cat": [opt.naics_col, "qe1", "qse1", "qe8a", "wh2", "qe8", "qa9", "qa9ar", "qe13", "qa6"],
        "qe4_num": ["qe10"],
        "qe5_text": [opt.qe5_col] + common_text_cols + [opt.naics_col],
        "qe5_cat": [opt.naics_col, "qe1", "qa9", "qa9ar"],
        "qe5_num": ["qe10"],
    }
    return plan


def classifier_summary(clf: FittedClassifier) -> Dict[str, Any]:
    return {
        "stage": clf.stage_name,
        "models": clf.model_names,
        "weights": clf.weights,
        "classes": int(clf.n_classes),
        "rows": int(clf.n_rows),
        "features": int(clf.n_features),
        "cv_macro_f1": clf.cv_macro_f1,
        "cv_log_loss": clf.cv_log_loss,
        "candidate_scores": [asdict(s) for s in clf.cv_scores],
    }


def bundle_summary(bundle: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "version": bundle.get("version"),
        "created_at": bundle.get("created_at"),
        "platform": bundle.get("platform"),
        "package_availability": bundle.get("package_availability"),
        "config": bundle.get("config"),
    }
    if "naics_model" in bundle:
        out["naics"] = classifier_summary(bundle["naics_model"]["classifier"])
        mem = bundle["naics_model"].get("adaptive_memory")
        if mem:
            out["naics"]["adaptive_memory"] = {
                "rule_counts": mem.get("rule_counts"),
                "temporal": mem.get("temporal"),
                "validation": mem.get("validation"),
            }
    if bundle.get("posthoc_calibration"):
        out["posthoc_calibration"] = {
            "created_at": bundle["posthoc_calibration"].get("created_at"),
            "targets": {
                k: {
                    "calibration_rows": v.get("calibration_rows"),
                    "fusion_weights": v.get("fusion_weights"),
                    "conformal_qhat": v.get("conformal_qhat"),
                    "source_calibrator_count": len(v.get("calibrators", {})),
                } for k, v in bundle["posthoc_calibration"].get("targets", {}).items()
            },
        }
    for key in ["soc_qe4_model", "soc_qe5_model"]:
        if key in bundle:
            m = bundle[key]
            out[key] = {
                "major": classifier_summary(m["major_model"]),
                "within_model_count": len(m.get("within_models", {})),
                "within_baseline_count": len(m.get("within_baselines", {})),
            }
            mem = m.get("adaptive_memory")
            if mem:
                out[key]["adaptive_memory"] = {
                    "rule_counts": mem.get("rule_counts"),
                    "temporal": mem.get("temporal"),
                    "validation": mem.get("validation"),
                }
    return out


def write_log(
    path: str,
    opt: argparse.Namespace,
    cfg: TrainConfig,
    bundle: Dict[str, Any],
    score_df: pd.DataFrame,
    before_naics: pd.Series,
    after_naics: pd.Series,
    pred_naics: Dict[str, Any],
    apply_naics: np.ndarray,
    before4: pd.Series,
    after4: pd.Series,
    pred4: Dict[str, Any],
    apply4: np.ndarray,
    before5: pd.Series,
    after5: pd.Series,
    pred5: Dict[str, Any],
    apply5: np.ndarray,
) -> None:
    n = len(score_df)
    id_vec = score_df[opt.id_col].tolist() if opt.id_col in score_df.columns else list(range(1, n + 1))
    lines: List[str] = []
    lines.append("NAICS-first SOC Autocode Log (state-of-art ensemble)")
    lines.append("====================================================")
    lines.append(f"Created: {now_stamp()}")
    lines.append(f"Script version: {VERSION}")
    lines.append(f"Mode: {opt.mode}")
    lines.append(f"Profile: {cfg.profile}")
    lines.append(f"Package availability: {bundle.get('package_availability')}")
    lines.append(f"Output .sav: {opt.out_sav}")
    lines.append("")
    lines.append("Model summary:")
    lines.append(json.dumps(bundle_summary(bundle), indent=2, default=str))
    lines.append("")
    lines.append("Row-level predictions:")

    top_naics = pred_naics["top_code"]
    prob_naics = pred_naics["top_prob"]
    top4 = pred4["top_soc"]
    pr4 = pred4["top_prob"]
    top5 = pred5["top_soc"]
    pr5 = pred5["top_prob"]

    for i in range(n):
        naics_alts: List[str] = []
        for k in range(1, cfg.topk_naics):
            code = top_naics[i][k]
            if code is not None:
                naics_alts.append(f"{code} ({prob_naics[i, k] * 100:.1f}%)")
        soc4_alts: List[str] = []
        for k in range(1, cfg.topk_soc):
            if top4[i, k] > 0:
                soc4_alts.append(f"{top4[i, k]:06d} ({pr4[i, k] * 100:.1f}%)")
        soc5_alts: List[str] = []
        for k in range(1, cfg.topk_soc):
            if top5[i, k] > 0:
                soc5_alts.append(f"{top5[i, k]:06d} ({pr5[i, k] * 100:.1f}%)")

        source_naics = pred_naics.get("prediction_source", ["model"] * n)[i]
        source4 = pred4.get("prediction_source", ["model"] * n)[i]
        source5 = pred5.get("prediction_source", ["model"] * n)[i]
        mem_naics = pred_naics.get("adaptive_memory", {})
        mem4 = pred4.get("adaptive_memory", {})
        mem5 = pred5.get("adaptive_memory", {})
        rule_naics = mem_naics.get("template", [""] * n)[i] if mem_naics else ""
        rule4 = mem4.get("template", [""] * n)[i] if mem4 else ""
        rule5 = mem5.get("template", [""] * n)[i] if mem5 else ""
        prefix_naics = mem_naics.get("prefix", [None] * n)[i] if mem_naics else None
        prefix4 = mem4.get("prefix", [None] * n)[i] if mem4 else None
        prefix5 = mem5.get("prefix", [None] * n)[i] if mem5 else None

        cset_naics = pred_naics.get("conformal_set_sizes", {}).get("0.1", np.ones(n, dtype=int))[i] if pred_naics.get("conformal_set_sizes") else 1
        cset4 = pred4.get("conformal_set_sizes", {}).get("0.1", np.ones(n, dtype=int))[i] if pred4.get("conformal_set_sizes") else 1
        cset5 = pred5.get("conformal_set_sizes", {}).get("0.1", np.ones(n, dtype=int))[i] if pred5.get("conformal_set_sizes") else 1
        line = (
            f"id={id_vec[i]} | "
            f"{opt.naics_col}: {format_code(before_naics.iloc[i])} -> {format_code(after_naics.iloc[i])} "
            f"(model_top={top_naics[i][0] or 'MISSING'} conf={prob_naics[i,0]*100:.1f}% applied={'YES' if apply_naics[i] else 'NO'} source={source_naics} rule={rule_naics or '-'} prefix={prefix_naics or '-'} aps90_set={cset_naics}) "
            f"[alts: {', '.join(naics_alts)}] | "
            f"{opt.qe4ar_col}: {format_soc(before4.iloc[i])} -> {format_soc(after4.iloc[i])} "
            f"(model_top={format_soc(top4[i,0]) if top4[i,0] > 0 else 'MISSING'} conf={pr4[i,0]*100:.1f}% applied={'YES' if apply4[i] else 'NO'} source={source4} rule={rule4 or '-'} prefix={prefix4 or '-'} aps90_set={cset4}) "
            f"[alts: {', '.join(soc4_alts)}] | "
            f"{opt.qe5ar_col}: {format_soc(before5.iloc[i])} -> {format_soc(after5.iloc[i])} "
            f"(model_top={format_soc(top5[i,0]) if top5[i,0] > 0 else 'MISSING'} conf={pr5[i,0]*100:.1f}% applied={'YES' if apply5[i] else 'NO'} source={source5} rule={rule5 or '-'} prefix={prefix5 or '-'} aps90_set={cset5}) "
            f"[alts: {', '.join(soc5_alts)}]"
        )
        lines.append(line)

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
        f.write("\n")


# ---------------------------------------------------------------------
# Training and scoring orchestration
# ---------------------------------------------------------------------

def package_availability() -> Dict[str, bool]:
    return {
        "lightgbm": HAS_LIGHTGBM,
        "xgboost": HAS_XGBOOST,
        "catboost": HAS_CATBOOST,
        "optuna": HAS_OPTUNA,
        "sentence_transformers": HAS_SENTENCE_TRANSFORMERS,
        "cross_encoder": HAS_SENTENCE_TRANSFORMERS and CrossEncoder is not None,
        "rapidfuzz": HAS_RAPIDFUZZ,
        "faiss": HAS_FAISS,
        "llama_cpp": HAS_LLAMA_CPP,
        "psutil": HAS_PSUTIL,
    }


def train_full_bundle(train_df: pd.DataFrame, opt: argparse.Namespace, cfg: TrainConfig, parallel_cfg: ParallelConfig) -> Dict[str, Any]:
    prefixes = build_prefixes(opt)
    plan = column_plan(opt)

    eprint("\nTraining NAICS model first...")
    naics_model = train_naics_target(
        train_df=train_df,
        target_col=opt.naics_col,
        text_cols=plan["naics_text"],
        cat_cols=plan["naics_cat"],
        num_cols=plan["naics_num"],
        prefixes=prefixes,
        cfg=cfg,
        parallel_cfg=parallel_cfg,
    )

    # Fill missing NAICS in training data before SOC model training. This makes
    # SOC training mimic production scoring: NAICS is available first.
    train_for_soc = train_df.copy()
    # Do not spend local-LLM cycles on the internal training-data NAICS fill.
    _llm_flag = cfg.use_local_llm_fallback
    cfg.use_local_llm_fallback = False
    try:
        train_naics_pred = predict_naics_topk(naics_model, train_for_soc, cfg)
    finally:
        cfg.use_local_llm_fallback = _llm_flag
    before_train_naics = train_for_soc[opt.naics_col] if opt.naics_col in train_for_soc.columns else pd.Series([np.nan] * len(train_for_soc))
    train_naics_missing = is_missing_code_series(before_train_naics, cfg.missing_naics_values).to_numpy(dtype=bool)
    train_naics_top = [row[0] for row in train_naics_pred["top_code"]]
    train_naics_conf = train_naics_pred["top_prob"][:, 0]
    fill_train_naics = train_naics_missing & np.array([c is not None for c in train_naics_top]) & (train_naics_conf >= cfg.min_write_confidence_naics)
    assign_code_predictions(train_for_soc, opt.naics_col, fill_train_naics, train_naics_top)
    eprint(f"[NAICS] Filled {int(fill_train_naics.sum())} missing training NAICS values for SOC training context")

    eprint("\nTraining SOC model for qe4ar...")
    soc_qe4_model = train_hierarchical_soc_target(
        train_df=train_for_soc,
        y_col=opt.qe4ar_col,
        title_col=opt.qe4_col,
        naics_col=opt.naics_col,
        text_cols=plan["qe4_text"],
        cat_cols=plan["qe4_cat"],
        num_cols=plan["qe4_num"],
        prefixes=prefixes,
        cfg=cfg,
        parallel_cfg=parallel_cfg,
    )

    eprint("\nTraining SOC model for qe5ar...")
    soc_qe5_model = train_hierarchical_soc_target(
        train_df=train_for_soc,
        y_col=opt.qe5ar_col,
        title_col=opt.qe5_col,
        naics_col=opt.naics_col,
        text_cols=plan["qe5_text"],
        cat_cols=plan["qe5_cat"],
        num_cols=plan["qe5_num"],
        prefixes=prefixes,
        cfg=cfg,
        parallel_cfg=parallel_cfg,
    )

    if cfg.memory_export_dir:
        export_adaptive_memory(naics_model.get("adaptive_memory"), cfg.memory_export_dir)
        export_adaptive_memory(soc_qe4_model.get("adaptive_memory"), cfg.memory_export_dir)
        export_adaptive_memory(soc_qe5_model.get("adaptive_memory"), cfg.memory_export_dir)

    bundle = {
        "version": VERSION,
        "created_at": now_stamp(),
        "platform": {
            "python": sys.version,
            "platform": platform.platform(),
            "processor": platform.processor(),
            "logical_cpus": os.cpu_count(),
        },
        "package_availability": package_availability(),
        "config": asdict(cfg),
        "columns": vars(opt),
        "naics_model": naics_model,
        "soc_qe4_model": soc_qe4_model,
        "soc_qe5_model": soc_qe5_model,
    }
    return bundle


def score_with_bundle(score_df: pd.DataFrame, bundle: Dict[str, Any], opt: argparse.Namespace, cfg: TrainConfig) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    out_df = score_df.copy()
    n = len(out_df)

    eprint("\nScoring NAICS first...")
    pred_naics = predict_naics_topk(bundle["naics_model"], out_df, cfg)
    pred_naics = apply_posthoc_calibration_and_conformal(pred_naics, "qa20a", bundle, "naics")
    before_naics = out_df[opt.naics_col].copy() if opt.naics_col in out_df.columns else pd.Series([np.nan] * n)
    top_naics = [row[0] for row in pred_naics["top_code"]]
    conf_naics = pred_naics["top_prob"][:, 0]
    has_naics_pred = np.array([c is not None for c in top_naics], dtype=bool)
    threshold_ok_naics = (conf_naics >= cfg.min_write_confidence_naics) | bool(cfg.fill_all_missing)
    before_naics_missing_mask = is_missing_code_series(before_naics, cfg.missing_naics_values).to_numpy(dtype=bool)
    if opt.overwrite_existing or opt.overwrite_existing_naics:
        apply_naics = has_naics_pred & threshold_ok_naics
    else:
        apply_naics = before_naics_missing_mask & has_naics_pred & threshold_ok_naics
    assign_code_predictions(out_df, opt.naics_col, apply_naics, top_naics)
    after_naics = out_df[opt.naics_col].copy() if opt.naics_col in out_df.columns else before_naics
    after_naics_missing = int(is_missing_code_series(after_naics, cfg.missing_naics_values).sum()) if opt.naics_col in out_df.columns else int(before_naics_missing_mask.sum())
    eprint(f"[NAICS] Applied predictions to {int(apply_naics.sum())} rows | missing before={int(before_naics_missing_mask.sum())} missing after={after_naics_missing}")

    eprint("\nScoring qe4ar SOC using updated NAICS...")
    pred4 = predict_soc_target_topk(bundle["soc_qe4_model"], out_df, cfg)
    pred4 = apply_posthoc_calibration_and_conformal(pred4, "qe4ar", bundle, "soc")
    before4 = score_df[opt.qe4ar_col].copy() if opt.qe4ar_col in score_df.columns else pd.Series([np.nan] * n)
    pred4_top = pred4["top_soc"][:, 0]
    conf4_top = pred4["top_prob"][:, 0]
    has4 = pred4_top > 0
    threshold_ok4 = (conf4_top >= cfg.min_write_confidence_soc) | bool(cfg.fill_all_missing)
    before4_missing_mask = is_missing_soc_series(before4, cfg.missing_soc_values).to_numpy(dtype=bool)
    if opt.overwrite_existing or opt.overwrite_existing_soc:
        apply4 = has4 & threshold_ok4
    else:
        apply4 = before4_missing_mask & has4 & threshold_ok4
    assign_soc_predictions(out_df, opt.qe4ar_col, apply4, pred4_top)
    after4 = out_df[opt.qe4ar_col].copy() if opt.qe4ar_col in out_df.columns else before4
    after4_missing = int(is_missing_soc_series(after4, cfg.missing_soc_values).sum()) if opt.qe4ar_col in out_df.columns else int(before4_missing_mask.sum())
    eprint(f"[{opt.qe4ar_col}] Applied predictions to {int(apply4.sum())} rows | missing before={int(before4_missing_mask.sum())} missing after={after4_missing}")

    eprint("\nScoring qe5ar SOC using updated NAICS...")
    pred5 = predict_soc_target_topk(bundle["soc_qe5_model"], out_df, cfg)
    pred5 = apply_posthoc_calibration_and_conformal(pred5, "qe5ar", bundle, "soc")
    before5 = score_df[opt.qe5ar_col].copy() if opt.qe5ar_col in score_df.columns else pd.Series([np.nan] * n)
    pred5_top = pred5["top_soc"][:, 0]
    conf5_top = pred5["top_prob"][:, 0]
    has5 = pred5_top > 0
    threshold_ok5 = (conf5_top >= cfg.min_write_confidence_soc) | bool(cfg.fill_all_missing)
    before5_missing_mask = is_missing_soc_series(before5, cfg.missing_soc_values).to_numpy(dtype=bool)
    if opt.overwrite_existing or opt.overwrite_existing_soc:
        apply5 = has5 & threshold_ok5
    else:
        apply5 = before5_missing_mask & has5 & threshold_ok5
    assign_soc_predictions(out_df, opt.qe5ar_col, apply5, pred5_top)
    after5 = out_df[opt.qe5ar_col].copy() if opt.qe5ar_col in out_df.columns else before5
    after5_missing = int(is_missing_soc_series(after5, cfg.missing_soc_values).sum()) if opt.qe5ar_col in out_df.columns else int(before5_missing_mask.sum())
    eprint(f"[{opt.qe5ar_col}] Applied predictions to {int(apply5.sum())} rows | missing before={int(before5_missing_mask.sum())} missing after={after5_missing}")

    details = {
        "before_naics": before_naics,
        "after_naics": after_naics,
        "pred_naics": pred_naics,
        "apply_naics": apply_naics,
        "before4": before4,
        "after4": after4,
        "pred4": pred4,
        "apply4": apply4,
        "before5": before5,
        "after5": after5,
        "pred5": pred5,
        "apply5": apply5,
    }
    return out_df, details


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

def apply_profile_defaults(opt: argparse.Namespace) -> argparse.Namespace:
    # Only fill unset values. argparse sets explicit defaults, so this function
    # is mostly used to harmonize profile-level choices after parsing.
    if opt.profile == "fast":
        opt.model_search = opt.model_search or "light"
        opt.use_embeddings = False if opt.use_embeddings is None else opt.use_embeddings
        opt.use_semantic_memory = False if opt.use_semantic_memory is None else opt.use_semantic_memory
        opt.use_cross_encoder_reranker = False if opt.use_cross_encoder_reranker is None else opt.use_cross_encoder_reranker
        opt.use_probability_calibration = False if opt.use_probability_calibration is None else opt.use_probability_calibration
        opt.cross_encoder_union_candidates = False if opt.cross_encoder_union_candidates is None else opt.cross_encoder_union_candidates
        opt.use_source_confidence_calibration = False if opt.use_source_confidence_calibration is None else opt.use_source_confidence_calibration
        opt.svd_components = 0 if opt.svd_components is None else opt.svd_components
        opt.ensemble_size = min(opt.ensemble_size, 1)
        opt.optuna_trials_naics = 0
        opt.optuna_trials_major = 0
        opt.optuna_trials_within = 0
    elif opt.profile == "robust":
        opt.model_search = opt.model_search or "robust"
        if opt.svd_components is None:
            opt.svd_components = 64
        if opt.use_embeddings is None:
            opt.use_embeddings = False
        if opt.use_semantic_memory is None:
            opt.use_semantic_memory = True
        if opt.use_cross_encoder_reranker is None:
            opt.use_cross_encoder_reranker = False
        if opt.use_probability_calibration is None:
            opt.use_probability_calibration = True
        if opt.cross_encoder_union_candidates is None:
            opt.cross_encoder_union_candidates = True
        if opt.use_source_confidence_calibration is None:
            opt.use_source_confidence_calibration = True
    else:  # accuracy
        opt.model_search = opt.model_search or "max"
        if opt.svd_components is None:
            opt.svd_components = 128
        if opt.use_embeddings is None:
            opt.use_embeddings = True
        if opt.use_semantic_memory is None:
            opt.use_semantic_memory = True
        if opt.use_cross_encoder_reranker is None:
            opt.use_cross_encoder_reranker = True
        if opt.use_probability_calibration is None:
            opt.use_probability_calibration = True
        if opt.cross_encoder_union_candidates is None:
            opt.cross_encoder_union_candidates = True
        if opt.use_source_confidence_calibration is None:
            opt.use_source_confidence_calibration = True
        if opt.optuna_trials_naics is None:
            opt.optuna_trials_naics = 12
        if opt.optuna_trials_major is None:
            opt.optuna_trials_major = 8
        if opt.optuna_trials_within is None:
            # Usually too costly to tune every SOC major group. Set higher only if
            # the machine will be left to chew overnight.
            opt.optuna_trials_within = 0
    if getattr(opt, "fill_all_missing", False):
        opt.score_rows_without_text = True
        opt.fallback_fill_missing = True
    return opt


def build_config(opt: argparse.Namespace) -> Tuple[TrainConfig, ParallelConfig]:
    opt = apply_profile_defaults(opt)
    parallel_cfg = ParallelConfig(
        max_workers=recommend_max_workers(opt.max_workers),
        native_threads=max(1, int(opt.native_threads)),
    )
    cfg = TrainConfig(
        profile=str(opt.profile),
        random_seed=int(opt.random_seed),
        dict_purity=float(opt.dict_purity),
        dict_min_count=int(opt.dict_min_count),
        naics_dict_purity=float(opt.naics_dict_purity),
        naics_dict_min_count=int(opt.naics_dict_min_count),
        use_fuzzy_dictionary=bool(opt.use_fuzzy_dictionary),
        fuzzy_threshold=int(opt.fuzzy_threshold),
        fuzzy_max_choices_per_bucket=int(opt.fuzzy_max_choices_per_bucket),
        use_adaptive_memory=bool(opt.use_adaptive_memory),
        memory_employer_col=str(opt.memory_employer_col),
        memory_qe4_col=str(opt.qe4_col),
        memory_qe4ar_col=str(opt.qe4ar_col),
        memory_qe5_col=str(opt.qe5_col),
        memory_qe5ar_col=str(opt.qe5ar_col),
        memory_naics_col=str(opt.naics_col),
        memory_location_cols=tuple(p.strip() for p in str(opt.memory_location_cols).split(",") if p.strip()),
        memory_numeric_cols=tuple(p.strip() for p in str(opt.memory_numeric_cols).split(",") if p.strip()),
        memory_date_col=str(opt.memory_date_col),
        memory_reference_date=str(opt.memory_reference_date or ""),
        memory_verified_col=str(opt.memory_verified_col or ""),
        memory_verified_weight=float(opt.memory_verified_weight),
        memory_rolling_years=float(opt.memory_rolling_years),
        memory_half_life_years=float(opt.memory_half_life_years),
        memory_min_count=int(opt.memory_min_count),
        memory_min_effective_n=float(opt.memory_min_effective_n),
        memory_confidence_level=float(opt.memory_confidence_level),
        memory_exact_wilson_naics=float(opt.memory_exact_wilson_naics),
        memory_exact_wilson_soc=float(opt.memory_exact_wilson_soc),
        memory_partial_wilson_min=float(opt.memory_partial_wilson_min),
        memory_hard_constraint_min=float(opt.memory_hard_constraint_min),
        memory_partial_boost=float(opt.memory_partial_boost),
        memory_candidate_pool=int(opt.memory_candidate_pool),
        memory_numeric_bins=int(opt.memory_numeric_bins),
        memory_max_rules_per_template=int(opt.memory_max_rules_per_template),
        memory_use_partial_constraints=bool(opt.memory_use_partial_constraints),
        memory_strip_branch_numbers=bool(opt.memory_strip_branch_numbers),
        memory_validation_fraction=float(opt.memory_validation_fraction),
        memory_export_dir=str(opt.memory_export_dir or ""),
        use_semantic_memory=bool(opt.use_semantic_memory),
        semantic_backend=str(opt.semantic_backend),
        semantic_k=int(opt.semantic_k),
        semantic_min_similarity=float(opt.semantic_min_similarity),
        semantic_min_confidence=float(opt.semantic_min_confidence),
        semantic_fusion_weight=float(opt.semantic_fusion_weight),
        ml_fusion_weight=float(opt.ml_fusion_weight),
        semantic_reference_weight=float(opt.semantic_reference_weight),
        naics_reference_csv=str(opt.naics_reference_csv or ""),
        soc_reference_csv=str(opt.soc_reference_csv or ""),
        use_cross_encoder_reranker=bool(opt.use_cross_encoder_reranker),
        cross_encoder_model=str(opt.cross_encoder_model),
        cross_encoder_model_naics=str(opt.cross_encoder_model_naics or ""),
        cross_encoder_model_soc=str(opt.cross_encoder_model_soc or ""),
        cross_encoder_topn=int(opt.cross_encoder_topn),
        cross_encoder_batch_size=int(opt.cross_encoder_batch_size),
        cross_encoder_fusion_weight=float(opt.cross_encoder_fusion_weight),
        cross_encoder_min_score=float(opt.cross_encoder_min_score),
        cross_encoder_union_candidates=bool(opt.cross_encoder_union_candidates),
        cross_encoder_candidate_pool=int(opt.cross_encoder_candidate_pool),
        cross_encoder_prototype_examples=int(opt.cross_encoder_prototype_examples),
        use_probability_calibration=bool(opt.use_probability_calibration),
        calibration_method=str(opt.calibration_method),
        calibration_cv=int(opt.calibration_cv),
        calibration_max_rows=int(opt.calibration_max_rows),
        calibration_max_classes=int(opt.calibration_max_classes),
        use_source_confidence_calibration=bool(opt.use_source_confidence_calibration),
        source_calibration_method=str(opt.source_calibration_method),
        source_calibration_min_rows=int(opt.source_calibration_min_rows),
        conformal_alphas=tuple(float(x) for x in parse_csv_strs(opt.conformal_alphas)),
        conformal_candidate_pool=int(opt.conformal_candidate_pool),
        use_candidate_meta_ranker=bool(opt.use_candidate_meta_ranker),
        candidate_meta_ranker_min_rows=int(opt.candidate_meta_ranker_min_rows),
        calibration_fit_fraction=float(opt.calibration_fit_fraction),
        use_local_llm_fallback=bool(opt.use_local_llm_fallback),
        llm_model_path=str(opt.llm_model_path or ""),
        llm_trigger_confidence_naics=float(opt.llm_trigger_confidence_naics),
        llm_trigger_confidence_soc=float(opt.llm_trigger_confidence_soc),
        llm_max_rows=int(opt.llm_max_rows),
        llm_threads=int(opt.llm_threads),
        llm_ctx_size=int(opt.llm_ctx_size),
        llm_temperature=float(opt.llm_temperature),
        llm_top_p=float(opt.llm_top_p),
        llm_max_tokens=int(opt.llm_max_tokens),
        llm_rerank_confidence=float(opt.llm_rerank_confidence),
        llm_allow_free_code=bool(opt.llm_allow_free_code),
        llm_self_consistency_samples=int(opt.llm_self_consistency_samples),
        llm_self_consistency_temperature=float(opt.llm_self_consistency_temperature),
        topk_naics=int(opt.topk_naics),
        topk_soc=int(opt.topk_soc),
        top_groups=int(opt.top_groups),
        min_naics_n=int(opt.min_naics_n),
        min_soc_n=int(opt.min_soc_n),
        nfolds_naics=int(opt.nfolds_naics),
        nfolds_major=int(opt.nfolds_major),
        nfolds_within=int(opt.nfolds_within),
        model_search=str(opt.model_search),
        candidate_models=tuple(p.strip() for p in str(opt.candidate_models or "auto").split(",") if p.strip()),
        ensemble_size=int(opt.ensemble_size),
        ensemble_power=float(opt.ensemble_power),
        optuna_trials_naics=int(opt.optuna_trials_naics or 0),
        optuna_trials_major=int(opt.optuna_trials_major or 0),
        optuna_trials_within=int(opt.optuna_trials_within or 0),
        optuna_timeout_seconds=opt.optuna_timeout_seconds,
        max_word_terms=int(opt.max_word_terms),
        max_char_terms=int(opt.max_char_terms),
        word_min_count=int(opt.word_min_count),
        char_min_count=int(opt.char_min_count),
        doc_prop_max=float(opt.doc_prop_max),
        use_embeddings=bool(opt.use_embeddings),
        embedding_model=str(opt.embedding_model),
        embedding_backend=str(opt.embedding_backend),
        embedding_batch_size=int(opt.embedding_batch_size),
        embedding_device=opt.embedding_device,
        embedding_chunk_size=int(opt.embedding_chunk_size),
        embedding_progress_every=int(opt.embedding_progress_every),
        embedding_cache_dir=str(opt.embedding_cache_dir or ""),
        svd_components=int(opt.svd_components or 0),
        logreg_C=float(opt.logreg_C),
        logreg_max_iter=int(opt.logreg_max_iter),
        sgd_alpha=float(opt.sgd_alpha),
        sgd_max_iter=int(opt.sgd_max_iter),
        sgd_tol=float(opt.sgd_tol),
        linearsvc_C=float(opt.linearsvc_C),
        boost_n_estimators=int(opt.boost_n_estimators),
        boost_max_classes=int(opt.boost_max_classes),
        boost_max_features=int(opt.boost_max_features),
        score_batch_size=int(opt.score_batch_size),
        min_write_confidence_naics=float(opt.min_write_confidence_naics),
        min_write_confidence_soc=float(opt.min_write_confidence_soc),
        fill_all_missing=bool(opt.fill_all_missing),
        score_rows_without_text=bool(opt.score_rows_without_text),
        fallback_fill_missing=bool(opt.fallback_fill_missing),
        missing_soc_values=parse_csv_ints(opt.missing_soc_values),
        missing_naics_values=parse_csv_strs(opt.missing_naics_values),
    )
    if cfg.use_embeddings and not HAS_SENTENCE_TRANSFORMERS:
        eprint("WARNING: --use_embeddings requested but sentence-transformers is unavailable. Disabling embeddings.")
        cfg.use_embeddings = False
    if cfg.use_semantic_memory and not HAS_SENTENCE_TRANSFORMERS:
        eprint("WARNING: --use_semantic_memory requested but sentence-transformers is unavailable. Disabling semantic memory.")
        cfg.use_semantic_memory = False
    if cfg.semantic_backend == "faiss" and not HAS_FAISS:
        eprint("WARNING: --semantic_backend faiss requested but faiss is unavailable. Falling back to sklearn cosine search.")
        cfg.semantic_backend = "sklearn"
    if cfg.use_cross_encoder_reranker and (not HAS_SENTENCE_TRANSFORMERS or CrossEncoder is None):
        eprint("WARNING: --use_cross_encoder_reranker requested but CrossEncoder is unavailable. Disabling cross-encoder reranking.")
        cfg.use_cross_encoder_reranker = False
    if cfg.use_local_llm_fallback and not HAS_LLAMA_CPP:
        eprint("WARNING: --use_local_llm_fallback requested but llama-cpp-python is unavailable. Disabling local LLM fallback.")
        cfg.use_local_llm_fallback = False
    if cfg.use_fuzzy_dictionary and not HAS_RAPIDFUZZ:
        eprint("WARNING: --use_fuzzy_dictionary requested but rapidfuzz is unavailable. Disabling fuzzy dictionary.")
        cfg.use_fuzzy_dictionary = False
    if cfg.model_search == "max" and not any([HAS_LIGHTGBM, HAS_XGBOOST, HAS_CATBOOST]):
        eprint("WARNING: model_search=max requested, but no gradient boosting packages were found. Sparse linear models will still be used.")
    return cfg, parallel_cfg


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="NAICS-first + SOC state-of-art autocoder for SPSS .sav files")
    p.add_argument("--mode", choices=["train", "score", "train_and_score"], default="train_and_score")
    p.add_argument("--train_sav", type=str, default="")
    p.add_argument("--score_sav", type=str, default="")
    p.add_argument("--out_sav", type=str, default="")
    p.add_argument("--log_txt", type=str, default="")
    p.add_argument("--model_out", type=str, default="")
    p.add_argument("--model_in", type=str, default="")
    p.add_argument("--save_model", action="store_true", default=False)

    # Columns
    p.add_argument("--id_col", type=str, default="id")
    p.add_argument("--naics_col", type=str, default="qa20a")
    p.add_argument("--qe4_col", type=str, default="qe4")
    p.add_argument("--qe4ar_col", type=str, default="qe4ar")
    p.add_argument("--qe5_col", type=str, default="qe5a")
    p.add_argument("--qe5ar_col", type=str, default="qe5ar")

    # Write behavior
    p.add_argument("--overwrite_existing", action="store_true", default=False)
    p.add_argument("--overwrite_existing_naics", action="store_true", default=False)
    p.add_argument("--overwrite_existing_soc", action="store_true", default=False)
    p.add_argument("--missing_soc_values", type=str, default="")
    p.add_argument("--missing_naics_values", type=str, default="")
    p.add_argument("--min_write_confidence_naics", type=float, default=0.0)
    p.add_argument("--min_write_confidence_soc", type=float, default=0.0)
    p.add_argument("--fill_all_missing", action="store_true", default=False, help="Fill every missing qa20a/qe4ar/qe5ar cell. Forces empty-text scoring and baseline fallback for rows with no model candidate. Existing non-missing values are preserved unless overwrite flags are used.")
    p.add_argument("--score_rows_without_text", action=argparse.BooleanOptionalAction, default=False, help="Score rows even if the title/text gate is empty; categorical/numeric features and fallback baselines still contribute.")
    p.add_argument("--fallback_fill_missing", action=argparse.BooleanOptionalAction, default=False, help="If model/dictionary/semantic layers produce no candidate, fill from the training-set baseline distribution.")
    p.add_argument("--console_log", type=str, default="", help="Optional file to mirror all live terminal stdout/stderr while still displaying progress in Positron.")

    # Profiles/search
    p.add_argument("--profile", choices=["fast", "robust", "accuracy"], default="accuracy")
    p.add_argument("--model_search", choices=["none", "light", "robust", "max"], default=None)
    p.add_argument("--candidate_models", type=str, default="auto", help="Comma-separated supervised model families to try: auto/all, sgd,logreg,linear_svc,complement_nb,lightgbm,xgboost,catboost. Use this to keep CPU runs bounded.")
    p.add_argument("--ensemble_size", type=int, default=3)
    p.add_argument("--ensemble_power", type=float, default=2.0)
    p.add_argument("--optuna_trials_naics", type=int, default=None)
    p.add_argument("--optuna_trials_major", type=int, default=None)
    p.add_argument("--optuna_trials_within", type=int, default=None)
    p.add_argument("--optuna_timeout_seconds", type=int, default=None)

    # Dictionaries
    p.add_argument("--dict_purity", type=float, default=0.90)
    p.add_argument("--dict_min_count", type=int, default=5)
    p.add_argument("--naics_dict_purity", type=float, default=0.90)
    p.add_argument("--naics_dict_min_count", type=int, default=5)
    p.add_argument("--use_fuzzy_dictionary", action="store_true", default=False)
    p.add_argument("--fuzzy_threshold", type=int, default=93)
    p.add_argument("--fuzzy_max_choices_per_bucket", type=int, default=25000)

    # Adaptive historical rule memory. Rules use employer/title/location/numeric
    # combinations, strict specificity, Wilson lower bounds, and optional recency decay.
    p.add_argument("--use_adaptive_memory", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--memory_employer_col", type=str, default="qa20")
    p.add_argument("--memory_location_cols", type=str, default="qe2b", help="Comma-separated location fields used by historical rules.")
    p.add_argument("--memory_numeric_cols", type=str, default="qe10", help="Comma-separated numeric fields such as hours or wage; quantile bins are learned from training data.")
    p.add_argument("--memory_date_col", type=str, default="auto", help="Historical coding/interview date column, or auto. Enables rolling-window temporal decay when found.")
    p.add_argument("--memory_reference_date", type=str, default="", help="Optional YYYY-MM-DD reference date; default is latest valid training date.")
    p.add_argument("--memory_verified_col", type=str, default="", help="Optional flag identifying human-reviewed historical codes.")
    p.add_argument("--memory_verified_weight", type=float, default=2.0)
    p.add_argument("--memory_rolling_years", type=float, default=5.0)
    p.add_argument("--memory_half_life_years", type=float, default=2.5)
    p.add_argument("--memory_min_count", type=int, default=5)
    p.add_argument("--memory_min_effective_n", type=float, default=8.0)
    p.add_argument("--memory_confidence_level", type=float, default=0.95)
    p.add_argument("--memory_exact_wilson_naics", type=float, default=0.80)
    p.add_argument("--memory_exact_wilson_soc", type=float, default=0.82)
    p.add_argument("--memory_partial_wilson_min", type=float, default=0.88)
    p.add_argument("--memory_hard_constraint_min", type=float, default=0.92)
    p.add_argument("--memory_partial_boost", type=float, default=4.0)
    p.add_argument("--memory_candidate_pool", type=int, default=24)
    p.add_argument("--memory_numeric_bins", type=int, default=6)
    p.add_argument("--memory_max_rules_per_template", type=int, default=50000)
    p.add_argument("--memory_use_partial_constraints", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--memory_strip_branch_numbers", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--memory_validation_fraction", type=float, default=0.10)
    p.add_argument("--memory_export_dir", type=str, default="", help="Optional directory for readable JSON/CSV/report exports of mined adaptive rules.")

    # Semantic vector memory / dense retrieval
    p.add_argument("--use_semantic_memory", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--semantic_backend", choices=["auto", "faiss", "sklearn"], default="auto")
    p.add_argument("--semantic_k", type=int, default=35)
    p.add_argument("--semantic_min_similarity", type=float, default=0.42)
    p.add_argument("--semantic_min_confidence", type=float, default=0.25)
    p.add_argument("--semantic_fusion_weight", type=float, default=0.85)
    p.add_argument("--ml_fusion_weight", type=float, default=1.0)
    p.add_argument("--semantic_reference_weight", type=float, default=0.60)
    p.add_argument("--naics_reference_csv", type=str, default="")
    p.add_argument("--soc_reference_csv", type=str, default="")

    # Optional cross-encoder reranking of semantic-memory candidates.
    p.add_argument("--use_cross_encoder_reranker", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--cross_encoder_model", type=str, default="cross-encoder/ms-marco-MiniLM-L6-v2",
                   help="Shared fallback CrossEncoder model used when a target-specific model is not supplied.")
    p.add_argument("--cross_encoder_model_naics", type=str, default="",
                   help="Optional NAICS-only CrossEncoder model path.")
    p.add_argument("--cross_encoder_model_soc", type=str, default="",
                   help="Optional SOC-only CrossEncoder model path used for qe4ar and qe5ar.")
    p.add_argument("--cross_encoder_topn", type=int, default=20)
    p.add_argument("--cross_encoder_batch_size", type=int, default=32)
    p.add_argument("--cross_encoder_fusion_weight", type=float, default=0.75)
    p.add_argument("--cross_encoder_min_score", type=float, default=0.0)
    p.add_argument("--cross_encoder_union_candidates", action=argparse.BooleanOptionalAction, default=None, help="Rerank the union of ML and semantic candidates rather than semantic candidates only.")
    p.add_argument("--cross_encoder_candidate_pool", type=int, default=24)
    p.add_argument("--cross_encoder_prototype_examples", type=int, default=3)

    # Optional local, air-gapped LLM candidate reranker via llama-cpp-python
    p.add_argument("--use_local_llm_fallback", action="store_true", default=False)
    p.add_argument("--llm_model_path", type=str, default="")
    p.add_argument("--llm_trigger_confidence_naics", type=float, default=0.55)
    p.add_argument("--llm_trigger_confidence_soc", type=float, default=0.55)
    p.add_argument("--llm_max_rows", type=int, default=250)
    p.add_argument("--llm_threads", type=int, default=6)
    p.add_argument("--llm_ctx_size", type=int, default=4096)
    p.add_argument("--llm_temperature", type=float, default=0.0)
    p.add_argument("--llm_top_p", type=float, default=0.90)
    p.add_argument("--llm_max_tokens", type=int, default=48)
    p.add_argument("--llm_rerank_confidence", type=float, default=0.72)
    p.add_argument("--llm_allow_free_code", action="store_true", default=False)
    p.add_argument("--llm_self_consistency_samples", type=int, default=1)
    p.add_argument("--llm_self_consistency_temperature", type=float, default=0.45)

    # Top-k and rare class filters
    p.add_argument("--top_groups", type=int, default=3)
    p.add_argument("--topk_soc", type=int, default=4)
    p.add_argument("--topk_naics", type=int, default=4)
    p.add_argument("--min_soc_n", type=int, default=3)
    p.add_argument("--min_naics_n", type=int, default=3)
    p.add_argument("--nfolds_naics", type=int, default=5)
    p.add_argument("--nfolds_major", type=int, default=5)
    p.add_argument("--nfolds_within", type=int, default=3)

    # Feature settings
    p.add_argument("--max_word_terms", type=int, default=120000)
    p.add_argument("--max_char_terms", type=int, default=120000)
    p.add_argument("--word_min_count", type=int, default=2)
    p.add_argument("--char_min_count", type=int, default=5)
    p.add_argument("--doc_prop_max", type=float, default=0.80)
    p.add_argument("--use_embeddings", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--embedding_model", type=str, default="BAAI/bge-large-en-v1.5")
    p.add_argument("--embedding_backend", choices=["torch", "onnx", "openvino"], default="torch")
    p.add_argument("--embedding_batch_size", type=int, default=32)
    p.add_argument("--embedding_device", type=str, default=None)
    p.add_argument("--embedding_chunk_size", type=int, default=1024)
    p.add_argument("--embedding_progress_every", type=int, default=2048)
    p.add_argument("--embedding_cache_dir", type=str, default="")
    p.add_argument("--svd_components", type=int, default=None)

    # Model settings
    p.add_argument("--logreg_C", type=float, default=1.0)
    p.add_argument("--logreg_max_iter", type=int, default=1500)
    p.add_argument("--sgd_alpha", type=float, default=1e-5)
    p.add_argument("--sgd_max_iter", type=int, default=2500)
    p.add_argument("--sgd_tol", type=float, default=1e-4)
    p.add_argument("--linearsvc_C", type=float, default=1.0)
    p.add_argument("--boost_n_estimators", type=int, default=300)
    p.add_argument("--boost_max_classes", type=int, default=120)
    p.add_argument("--boost_max_features", type=int, default=180000)

    # Optional probability calibration. Calibration can improve confidence
    # reliability when ML scores are fused with semantic memory.
    p.add_argument("--use_probability_calibration", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--calibration_method", choices=["auto", "sigmoid", "isotonic", "temperature"], default="auto")
    p.add_argument("--calibration_cv", type=int, default=3)
    p.add_argument("--calibration_max_rows", type=int, default=120000)
    p.add_argument("--calibration_max_classes", type=int, default=160)
    p.add_argument("--calibration_sav", type=str, default="", help="Independent calibration SAV used to learn fusion weights, final confidence maps, and APS sets. Must not be the Gold evaluation SAV.")
    p.add_argument("--use_source_confidence_calibration", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--source_calibration_method", choices=["auto", "sigmoid", "isotonic"], default="auto")
    p.add_argument("--source_calibration_min_rows", type=int, default=100)
    p.add_argument("--conformal_alphas", type=str, default="0.05,0.10,0.20")
    p.add_argument("--conformal_candidate_pool", type=int, default=24)
    p.add_argument("--use_candidate_meta_ranker", action=argparse.BooleanOptionalAction, default=True, help="Fit a small candidate-level stacking model on the separate calibration SAV.")
    p.add_argument("--candidate_meta_ranker_min_rows", type=int, default=250)
    p.add_argument("--calibration_fit_fraction", type=float, default=0.60, help="Fraction of CALIBRATION used for fusion/confidence fitting; the remainder estimates conformal thresholds.")

    # Comprehensive post-run audit and chat-ready improvement bundle.
    p.add_argument("--analysis_dir", type=str, default="", help="Directory where a comprehensive model-improvement audit will be written after the run.")
    p.add_argument("--analysis_run_label", type=str, default="", help="Optional stable label for comparing this run in run_registry.csv.")
    p.add_argument("--analysis_include_row_details", action=argparse.BooleanOptionalAction, default=True, help="Write local row-ID error details. The chat-safe ZIP never includes them.")
    p.add_argument("--analysis_min_class_support", type=int, default=10)
    p.add_argument("--analysis_confidence_bins", type=int, default=10)
    p.add_argument("--analysis_top_confusions", type=int, default=100)
    p.add_argument("--evaluation_sav", type=str, default="", help="Optional independent labeled SAV scored after training for end-to-end evaluation. Strongly preferred over training-set metrics.")

    # Hardware/scoring
    p.add_argument("--max_workers", type=str, default="auto")
    p.add_argument("--native_threads", type=int, default=1)
    p.add_argument("--score_batch_size", type=int, default=5000)
    p.add_argument("--random_seed", type=int, default=42)
    p.add_argument("--joblib_compress", type=int, default=3)
    return p


def validate_args(opt: argparse.Namespace) -> None:
    if opt.mode in {"train", "train_and_score"} and not opt.train_sav:
        raise ValueError("--train_sav is required for train/train_and_score mode")
    if opt.mode in {"score", "train_and_score"} and not opt.score_sav:
        raise ValueError("--score_sav is required for score/train_and_score mode")
    if opt.mode == "score" and not opt.model_in:
        raise ValueError("--model_in is required for score mode")
    if opt.mode in {"score", "train_and_score"} and (not opt.out_sav or not opt.log_txt):
        raise ValueError("--out_sav and --log_txt are required when scoring")
    if getattr(opt, "calibration_sav", "") and getattr(opt, "evaluation_sav", ""):
        if os.path.abspath(opt.calibration_sav) == os.path.abspath(opt.evaluation_sav):
            raise ValueError("--calibration_sav and --evaluation_sav must be different files. The Gold evaluation set may never be used for calibration.")
    if opt.save_model and not opt.model_out:
        raise ValueError("--model_out is required when --save_model is used")
    if opt.mode == "train" and not opt.model_out:
        raise ValueError("--model_out is required for train mode")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    opt = parser.parse_args(argv)
    if getattr(opt, "console_log", ""):
        setup_console_log(opt.console_log)
    validate_args(opt)
    cfg, parallel_cfg = build_config(opt)
    sanitize_hf_token_env()

    run_started = time.time()
    runtime_events: List[Dict[str, Any]] = []

    def timed_event(name: str, started: float, **extra: Any) -> None:
        runtime_events.append({
            "stage": name,
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started)),
            "ended_at": now_stamp(),
            "seconds": float(time.time() - started),
            **extra,
        })

    eprint("NAICS-first SOC state-of-art autocoder")
    eprint(f"Version: {VERSION}")
    eprint(f"Profile={cfg.profile} | model_search={cfg.model_search} | candidate_models={','.join(cfg.candidate_models)} | max_workers={parallel_cfg.max_workers} | native_threads={parallel_cfg.native_threads}")
    eprint(f"Optional package availability: {package_availability()}")

    bundle: Optional[Dict[str, Any]] = None
    train_meta = None
    score_meta = None
    train_df: Optional[pd.DataFrame] = None
    score_df: Optional[pd.DataFrame] = None
    out_df: Optional[pd.DataFrame] = None
    details: Optional[Dict[str, Any]] = None
    evaluation_df: Optional[pd.DataFrame] = None
    evaluation_details: Optional[Dict[str, Any]] = None
    calibration_df: Optional[pd.DataFrame] = None

    with threadpool_limits(limits=parallel_cfg.native_threads):
        if opt.mode in {"train", "train_and_score"}:
            eprint("\nReading training .sav...")
            t0 = time.time()
            train_df, train_meta = read_sav_with_meta(opt.train_sav)
            timed_event("read_training_sav", t0, rows=len(train_df), columns=train_df.shape[1])

            t0 = time.time()
            bundle = train_full_bundle(train_df, opt, cfg, parallel_cfg)
            timed_event("train_full_bundle", t0)
            bundle["runtime_events"] = runtime_events

            if getattr(opt, "calibration_sav", ""):
                eprint(f"\n[CALIBRATION] Reading independent calibration SAV: {opt.calibration_sav}")
                tcal = time.time()
                calibration_df, _ = read_sav_with_meta(opt.calibration_sav)
                timed_event("read_calibration_sav", tcal, rows=len(calibration_df), columns=calibration_df.shape[1])
                tcal = time.time()
                fit_posthoc_calibration_and_conformal(bundle, calibration_df, opt, cfg)
                timed_event("fit_posthoc_calibration", tcal, rows=len(calibration_df))
                bundle["config"] = asdict(cfg)
                bundle["runtime_events"] = runtime_events

            if opt.save_model or opt.mode == "train":
                eprint(f"\nSaving model bundle to: {opt.model_out}")
                t0 = time.time()
                joblib.dump(bundle, opt.model_out, compress=int(opt.joblib_compress))
                summary_path = opt.model_out + ".summary.json"
                with open(summary_path, "w", encoding="utf-8") as f:
                    json.dump(bundle_summary(bundle), f, indent=2, default=str)
                timed_event("save_model_bundle", t0, path=opt.model_out)
                eprint(f"Saved model summary to: {summary_path}")

        if opt.mode == "score":
            eprint(f"\nLoading model bundle from: {opt.model_in}")
            t0 = time.time()
            bundle = joblib.load(opt.model_in)
            timed_event("load_model_bundle", t0, path=opt.model_in)
            saved_cfg = bundle.get("config")
            if isinstance(saved_cfg, dict):
                runtime_write = {
                    "min_write_confidence_naics": cfg.min_write_confidence_naics,
                    "min_write_confidence_soc": cfg.min_write_confidence_soc,
                    "missing_soc_values": cfg.missing_soc_values,
                    "missing_naics_values": cfg.missing_naics_values,
                    "score_batch_size": cfg.score_batch_size,
                    "fill_all_missing": cfg.fill_all_missing,
                    "score_rows_without_text": cfg.score_rows_without_text,
                    "fallback_fill_missing": cfg.fallback_fill_missing,
                    "use_local_llm_fallback": cfg.use_local_llm_fallback,
                    "llm_model_path": cfg.llm_model_path,
                    "llm_max_rows": cfg.llm_max_rows,
                    "llm_self_consistency_samples": cfg.llm_self_consistency_samples,
                    "llm_self_consistency_temperature": cfg.llm_self_consistency_temperature,
                    "cross_encoder_model": cfg.cross_encoder_model,
                    "cross_encoder_batch_size": cfg.cross_encoder_batch_size,
                    "cross_encoder_candidate_pool": cfg.cross_encoder_candidate_pool,
                    "conformal_candidate_pool": cfg.conformal_candidate_pool,
                }
                if str(cfg.cross_encoder_model_naics or "").strip():
                    runtime_write["cross_encoder_model_naics"] = cfg.cross_encoder_model_naics
                if str(cfg.cross_encoder_model_soc or "").strip():
                    runtime_write["cross_encoder_model_soc"] = cfg.cross_encoder_model_soc
                merged_cfg = asdict(cfg)
                merged_cfg.update(saved_cfg)
                merged_cfg.update(runtime_write)
                cfg = TrainConfig(**merged_cfg)

        if opt.mode in {"score", "train_and_score"}:
            if bundle is None:
                raise RuntimeError("No model bundle is available for scoring")
            eprint("\nReading scoring .sav...")
            t0 = time.time()
            score_df, score_meta = read_sav_with_meta(opt.score_sav)
            timed_event("read_scoring_sav", t0, rows=len(score_df), columns=score_df.shape[1])

            t0 = time.time()
            out_df, details = score_with_bundle(score_df, bundle, opt, cfg)
            timed_event("score_production_sav", t0, rows=len(score_df))

            eprint(f"\nWriting scored .sav to: {opt.out_sav}")
            t0 = time.time()
            write_sav_preserving_metadata(out_df, score_meta, opt.out_sav)
            timed_event("write_scored_sav", t0, path=opt.out_sav)

            eprint(f"Writing log to: {opt.log_txt}")
            t0 = time.time()
            write_log(
                path=opt.log_txt,
                opt=opt,
                cfg=cfg,
                bundle=bundle,
                score_df=score_df,
                before_naics=details["before_naics"],
                after_naics=details["after_naics"],
                pred_naics=details["pred_naics"],
                apply_naics=details["apply_naics"],
                before4=details["before4"],
                after4=details["after4"],
                pred4=details["pred4"],
                apply4=details["apply4"],
                before5=details["before5"],
                after5=details["after5"],
                pred5=details["pred5"],
                apply5=details["apply5"],
            )
            timed_event("write_row_prediction_log", t0, path=opt.log_txt)

        # Optional independent end-to-end evaluation. This is deliberately after
        # production scoring so a diagnostic failure cannot block the scored SAV.
        if bundle is not None and getattr(opt, "evaluation_sav", ""):
            eprint(f"\n[AUDIT] Reading independent evaluation SAV: {opt.evaluation_sav}")
            t0 = time.time()
            evaluation_df, _ = read_sav_with_meta(opt.evaluation_sav)
            timed_event("read_evaluation_sav", t0, rows=len(evaluation_df), columns=evaluation_df.shape[1])
            eval_opt = argparse.Namespace(**vars(opt))
            eval_opt.overwrite_existing = True
            eval_opt.overwrite_existing_naics = True
            eval_opt.overwrite_existing_soc = True
            eval_opt.fill_all_missing = True
            eval_opt.score_rows_without_text = True
            eval_opt.fallback_fill_missing = True
            t0 = time.time()
            _, evaluation_details = score_with_bundle(evaluation_df, bundle, eval_opt, cfg)
            timed_event("score_evaluation_sav", t0, rows=len(evaluation_df))

    runtime_events.append({
        "stage": "total_before_audit",
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(run_started)),
        "ended_at": now_stamp(),
        "seconds": float(time.time() - run_started),
    })

    if bundle is not None and getattr(opt, "analysis_dir", ""):
        eprint("\n[AUDIT] Generating comprehensive model-improvement package...")
        t0 = time.time()
        try:
            from autocoder_improvement_audit_v2 import generate_run_audit
            result = generate_run_audit(
                analysis_dir=opt.analysis_dir,
                bundle=bundle,
                opt=opt,
                cfg=cfg,
                train_df=train_df,
                score_df=score_df,
                out_df=out_df,
                details=details,
                evaluation_df=evaluation_df,
                evaluation_details=evaluation_details,
                runtime_events=runtime_events,
                run_label=opt.analysis_run_label,
                include_row_details=bool(opt.analysis_include_row_details),
                min_class_support=int(opt.analysis_min_class_support),
                confidence_bins=int(opt.analysis_confidence_bins),
                top_confusions=int(opt.analysis_top_confusions),
            )
            timed_event("generate_model_improvement_audit", t0, run_dir=result.get("run_dir"))
            eprint(f"[AUDIT] Chat-ready report: {result.get('chat_report')}")
            eprint(f"[AUDIT] Upload-ready ZIP: {result.get('chat_zip')}")
            eprint(f"[AUDIT] Full local audit: {result.get('full_zip')}")
        except Exception as exc:
            timed_event("generate_model_improvement_audit_failed", t0, error=str(exc)[:500])
            eprint(f"[AUDIT] WARNING: audit generation failed but the model/scored SAV remain valid: {exc}")
            import traceback
            traceback.print_exc()

    eprint("\nDone.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        eprint("Interrupted by user.")
        raise SystemExit(130)
