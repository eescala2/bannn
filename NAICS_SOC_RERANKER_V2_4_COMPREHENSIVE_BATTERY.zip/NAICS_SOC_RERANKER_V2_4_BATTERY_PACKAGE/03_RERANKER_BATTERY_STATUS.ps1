param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [ValidateSet("smoke","standard","exhaustive","marathon")]
    [string]$Profile = "standard",
    [int]$Tail = 60
)
$Root = Join-Path $Base ("models\reranker_battery_{0}" -f $Profile)
$Logs = Join-Path $Base ("logs\reranker_battery_{0}" -f $Profile)
Write-Host "Battery root: $Root" -ForegroundColor Cyan
$Manifest = Join-Path $Root "battery_manifest.json"
$Status = Join-Path $Root "battery_status.json"
if (Test-Path $Manifest) {
    $m = Get-Content $Manifest -Raw | ConvertFrom-Json
    Write-Host ("Scheduled experiments: {0}" -f $m.experiment_count)
}
if (Test-Path $Status) {
    $s = Get-Content $Status -Raw | ConvertFrom-Json
    $groups = $s.experiments | Group-Object state
    foreach ($g in $groups) { Write-Host ("{0}: {1}" -f $g.Name,$g.Count) }
    $last = $s.experiments | Select-Object -Last 1
    if ($last) { Write-Host ("Last processed: {0} state={1}" -f $last.experiment_id,$last.state) }
}
Write-Host ""; Write-Host "Active battery processes:" -ForegroundColor Cyan
Get-CimInstance Win32_Process |
  Where-Object { $_.Name -like "python*" -and ($_.CommandLine -like "*reranker_experiment_battery*" -or $_.CommandLine -like "*train_domain_cross_encoder_battery*") } |
  Select-Object ProcessId,CreationDate,CommandLine | Format-List
Write-Host ""; Write-Host "GPU:" -ForegroundColor Cyan
try { nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw --format=csv,noheader } catch { Write-Host "nvidia-smi unavailable" }
if (Test-Path $Logs) {
    $latest = Get-ChildItem $Logs -Filter *.log | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latest) {
        Write-Host ""; Write-Host ("Latest log: {0}" -f $latest.FullName) -ForegroundColor Cyan
        Get-Content $latest.FullName -Tail $Tail
    }
}
