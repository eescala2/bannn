#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Comprehensive post-run audit for the NAICS-first/SOC autocoder.

The module is intentionally dependency-light. It produces two bundles:
1) a full local audit with row identifiers and detailed tables;
2) a privacy-safer chat bundle containing aggregate metrics only.

It does not claim a training-set score is a true generalization estimate. Metrics are
labelled according to their source: independent evaluation file, pre-existing codes in
the scoring file (shadow evaluation), or model-stage cross-validation.
"""
from __future__ import annotations

import hashlib
import importlib.metadata as metadata
import json
import math
import os
import platform
import re
import shutil
import statistics
import sys
import time
import zipfile
from collections import Counter, defaultdict
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    cohen_kappa_score,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)

AUDIT_VERSION = "2026.07.14.reranker-calibration-conformal-audit-v2"
MISSING_STRINGS = {"", "0", "00", "000", "0000", "00000", "000000", "999", "9999", "99999", "999999", "nan", "none"}


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(value: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "run")).strip("_")
    return s or "run"


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_jsonable(data), indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(list(rows)).to_csv(path, index=False, encoding="utf-8-sig")


def _write_df(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def _clean_code(value: Any) -> Optional[str]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, (int, np.integer)):
        s = str(int(value))
    elif isinstance(value, (float, np.floating)):
        if not np.isfinite(value):
            return None
        s = str(int(round(float(value)))) if abs(float(value) - round(float(value))) < 1e-8 else str(value)
    else:
        s = str(value).strip()
        if re.fullmatch(r"\d+\.0+", s):
            s = str(int(float(s)))
    s = s.strip()
    return None if s.lower() in MISSING_STRINGS else s


def _valid_naics(value: Any) -> bool:
    s = _clean_code(value)
    return bool(s and s.isdigit() and 2 <= len(s) <= 6)


def _valid_soc(value: Any) -> bool:
    s = _clean_code(value)
    if not s or not s.isdigit():
        return False
    try:
        x = int(s)
    except Exception:
        return False
    return 100000 <= x <= 999999


def _norm_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = str(value).lower().strip()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _safe_div(a: float, b: float) -> Optional[float]:
    return None if b == 0 else float(a / b)


def _entropy_from_counts(counts: Sequence[float]) -> float:
    arr = np.asarray(counts, dtype=float)
    arr = arr[arr > 0]
    if arr.size == 0:
        return 0.0
    p = arr / arr.sum()
    return float(-(p * np.log2(p)).sum())


def _effective_num_classes(counts: Sequence[float]) -> float:
    return float(2 ** _entropy_from_counts(counts))


def _js_divergence(a: pd.Series, b: pd.Series) -> Optional[float]:
    av = a.dropna().astype(str).value_counts(normalize=True)
    bv = b.dropna().astype(str).value_counts(normalize=True)
    keys = sorted(set(av.index) | set(bv.index))
    if not keys:
        return None
    p = np.array([av.get(k, 0.0) for k in keys], dtype=float)
    q = np.array([bv.get(k, 0.0) for k in keys], dtype=float)
    # scipy returns sqrt(JS); square it for divergence.
    return float(jensenshannon(p, q, base=2.0) ** 2)


def _psi(train: pd.Series, score: pd.Series, bins: int = 10) -> Optional[float]:
    tr = pd.to_numeric(train, errors="coerce").dropna().to_numpy(dtype=float)
    sc = pd.to_numeric(score, errors="coerce").dropna().to_numpy(dtype=float)
    if tr.size < 20 or sc.size < 20:
        return None
    edges = np.unique(np.quantile(tr, np.linspace(0, 1, bins + 1)))
    if edges.size < 3:
        return 0.0
    edges[0] = -np.inf
    edges[-1] = np.inf
    tr_c, _ = np.histogram(tr, bins=edges)
    sc_c, _ = np.histogram(sc, bins=edges)
    tr_p = np.clip(tr_c / max(1, tr_c.sum()), 1e-6, None)
    sc_p = np.clip(sc_c / max(1, sc_c.sum()), 1e-6, None)
    return float(np.sum((sc_p - tr_p) * np.log(sc_p / tr_p)))


def _standardized_mean_difference(train: pd.Series, score: pd.Series) -> Optional[float]:
    tr = pd.to_numeric(train, errors="coerce").dropna().to_numpy(dtype=float)
    sc = pd.to_numeric(score, errors="coerce").dropna().to_numpy(dtype=float)
    if tr.size < 2 or sc.size < 2:
        return None
    pooled = math.sqrt((float(np.var(tr, ddof=1)) + float(np.var(sc, ddof=1))) / 2.0)
    return 0.0 if pooled <= 0 else float((np.mean(sc) - np.mean(tr)) / pooled)


def _prefix_metrics(y_true: Sequence[str], y_pred: Sequence[str], kind: str) -> Dict[str, Any]:
    levels = [2, 3, 4, 5, 6] if kind == "naics" else [2, 3, 5, 6]
    names = {2: "sector_or_major", 3: "subsector_or_minor", 4: "industry_group", 5: "industry_or_broad", 6: "full_code"}
    out: Dict[str, Any] = {}
    for length in levels:
        eligible = [(a, b) for a, b in zip(y_true, y_pred) if len(a) >= length and len(b) >= length]
        if not eligible:
            continue
        correct = sum(a[:length] == b[:length] for a, b in eligible)
        out[f"prefix_{length}_{names.get(length, 'level')}_accuracy"] = correct / len(eligible)
        out[f"prefix_{length}_n"] = len(eligible)
    return out


def _calibration_tables(conf: np.ndarray, correct: np.ndarray, bins: int) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if conf.size == 0:
        return [], {"ece": None, "mce": None, "top_label_brier": None}
    conf = np.clip(conf.astype(float), 0, 1)
    correct = correct.astype(float)
    edges = np.linspace(0.0, 1.0, max(2, bins) + 1)
    rows: List[Dict[str, Any]] = []
    ece = 0.0
    mce = 0.0
    for i in range(len(edges) - 1):
        lo, hi = edges[i], edges[i + 1]
        mask = (conf >= lo) & (conf <= hi if i == len(edges) - 2 else conf < hi)
        n = int(mask.sum())
        if n == 0:
            continue
        avg_c = float(conf[mask].mean())
        acc = float(correct[mask].mean())
        gap = abs(acc - avg_c)
        ece += (n / conf.size) * gap
        mce = max(mce, gap)
        rows.append({"bin_low": lo, "bin_high": hi, "n": n, "mean_confidence": avg_c, "accuracy": acc, "calibration_gap": gap})
    return rows, {
        "ece": float(ece),
        "mce": float(mce),
        "top_label_brier": float(np.mean((conf - correct) ** 2)),
        "mean_confidence": float(conf.mean()),
    }


def _selective_tables(conf: np.ndarray, correct: np.ndarray) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    n = len(conf)
    if n == 0:
        return rows
    for threshold in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 0.98]:
        mask = conf >= threshold
        accepted = int(mask.sum())
        rows.append({
            "type": "threshold",
            "threshold_or_coverage": threshold,
            "accepted_n": accepted,
            "coverage": accepted / n,
            "accuracy": float(correct[mask].mean()) if accepted else None,
            "risk": float(1.0 - correct[mask].mean()) if accepted else None,
        })
    order = np.argsort(-conf)
    for coverage in [1.0, 0.95, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]:
        k = max(1, int(round(n * coverage)))
        idx = order[:k]
        rows.append({
            "type": "top_confidence_coverage",
            "threshold_or_coverage": coverage,
            "accepted_n": k,
            "coverage": k / n,
            "accuracy": float(correct[idx].mean()),
            "risk": float(1.0 - correct[idx].mean()),
            "minimum_confidence": float(conf[idx].min()),
        })
    return rows


def _extract_top_predictions(pred: Mapping[str, Any], kind: str) -> Tuple[List[List[Optional[str]]], np.ndarray, List[List[Optional[str]]], np.ndarray]:
    probs = np.asarray(pred.get("top_prob", []), dtype=float)
    if kind == "naics":
        codes = [[_clean_code(c) for c in row] for row in pred.get("top_code", [])]
        pool_codes = [[_clean_code(c) for c in row] for row in pred.get("candidate_pool_code", pred.get("top_code", []))]
    else:
        arr = np.asarray(pred.get("top_soc", []))
        codes = [[_clean_code(c) if int(c) > 0 else None for c in row] for row in arr]
        pool_arr = np.asarray(pred.get("candidate_pool_soc", pred.get("top_soc", [])))
        pool_codes = [[_clean_code(c) if int(c) > 0 else None for c in row] for row in pool_arr]
    pool_probs = np.asarray(pred.get("candidate_pool_prob", probs), dtype=float)
    return codes, probs, pool_codes, pool_probs


def _evaluate_target(
    name: str,
    kind: str,
    y_series: pd.Series,
    pred: Mapping[str, Any],
    df: pd.DataFrame,
    id_col: str,
    min_class_support: int,
    confidence_bins: int,
    top_confusions: int,
    include_row_details: bool,
) -> Dict[str, Any]:
    codes, probs, pool_codes, pool_probs = _extract_top_predictions(pred, kind)
    valid_fn = _valid_naics if kind == "naics" else _valid_soc
    y_all = [_clean_code(v) for v in y_series.tolist()]
    mask = np.array([valid_fn(v) for v in y_all], dtype=bool)
    idx = np.where(mask)[0]
    source_all = list(pred.get("prediction_source", ["model"] * len(y_all)))
    out: Dict[str, Any] = {"target": name, "kind": kind, "labeled_n": int(mask.sum()), "total_rows": len(y_all)}
    if mask.sum() == 0:
        out["warning"] = "No valid pre-existing labels were available for end-to-end evaluation."
        out["source_counts_all_rows"] = dict(Counter(source_all))
        return out

    y_true = [str(y_all[i]) for i in idx]
    top_rows = [codes[i] if i < len(codes) else [] for i in idx]
    pool_rows = [pool_codes[i] if i < len(pool_codes) else [] for i in idx]
    y_pred = [str(row[0]) if row and row[0] is not None else "MISSING" for row in top_rows]
    conf = np.array([float(probs[i, 0]) if probs.ndim == 2 and i < probs.shape[0] else 0.0 for i in idx])
    correct = np.array([a == b for a, b in zip(y_true, y_pred)], dtype=bool)

    labels = sorted(set(y_true) | set(y_pred))
    precision_macro = precision_score(y_true, y_pred, average="macro", zero_division=0)
    recall_macro = recall_score(y_true, y_pred, average="macro", zero_division=0)
    summary = {
        "top1_accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "macro_precision": float(precision_macro),
        "macro_recall": float(recall_macro),
        "cohen_kappa": float(cohen_kappa_score(y_true, y_pred)),
        "matthews_corrcoef": float(matthews_corrcoef(y_true, y_pred)),
        "mean_top1_confidence": float(conf.mean()),
        "median_top1_confidence": float(np.median(conf)),
    }
    max_k = max((len(row) for row in pool_rows), default=1)
    for k in range(1, max_k + 1):
        hits = [truth in {c for c in row[:k] if c is not None} for truth, row in zip(y_true, pool_rows)]
        summary[f"top{k}_accuracy"] = float(np.mean(hits))
    summary["candidate_pool_size"] = int(max_k)
    summary.update(_prefix_metrics(y_true, y_pred, kind))
    out["summary"] = summary

    cal_rows, cal_summary = _calibration_tables(conf, correct, confidence_bins)
    out["calibration_summary"] = cal_summary
    out["calibration_rows"] = cal_rows
    out["selective_rows"] = _selective_tables(conf, correct)

    # Per-class metrics and support.
    p, r, f, support = precision_recall_fscore_support(y_true, y_pred, labels=labels, zero_division=0)
    per_class: List[Dict[str, Any]] = []
    for label, pv, rv, fv, sv in zip(labels, p, r, f, support):
        per_class.append({"target": name, "class": label, "precision": float(pv), "recall": float(rv), "f1": float(fv), "support": int(sv), "low_support": bool(sv < min_class_support)})
    out["per_class_rows"] = per_class

    # Top confusions.
    confusion = Counter((a, b) for a, b in zip(y_true, y_pred) if a != b)
    out["confusion_rows"] = [
        {"target": name, "true_code": a, "predicted_code": b, "count": int(n)}
        for (a, b), n in confusion.most_common(top_confusions)
    ]

    # Prediction source metrics.
    source_rows: List[Dict[str, Any]] = []
    sources = [str(source_all[i]) if i < len(source_all) else "unknown" for i in idx]
    for source in sorted(set(sources)):
        sm = np.array([s == source for s in sources])
        source_rows.append({
            "target": name,
            "source": source,
            "n": int(sm.sum()),
            "coverage_of_labeled": float(sm.mean()),
            "accuracy": float(correct[sm].mean()) if sm.any() else None,
            "mean_confidence": float(conf[sm].mean()) if sm.any() else None,
        })
    out["source_rows"] = source_rows
    out["source_counts_all_rows"] = dict(Counter(source_all))

    # Reranker ablation: compare the pre-rerank top candidate with the final top candidate.
    pre_all = list(pred.get("pre_rerank_top_code", []))
    if pre_all and len(pre_all) >= len(y_all):
        pre = [_clean_code(pre_all[i]) for i in idx]
        pre_correct = np.asarray([str(a) == str(b) for a, b in zip(y_true, pre)], dtype=bool)
        used_all = np.asarray(pred.get("reranker_used", np.zeros(len(y_all), dtype=bool)), dtype=bool)
        used = used_all[idx] if used_all.size >= len(y_all) else np.zeros(len(idx), dtype=bool)
        out["reranker_ablation"] = {
            "evaluated_n": int(len(idx)),
            "used_n": int(used.sum()),
            "pre_rerank_top1": float(pre_correct.mean()),
            "post_rerank_top1": float(correct.mean()),
            "delta": float(correct.mean() - pre_correct.mean()),
            "used_pre_top1": float(pre_correct[used].mean()) if used.any() else None,
            "used_post_top1": float(correct[used].mean()) if used.any() else None,
        }

    # Empirical conformal-set coverage on the independent Gold file.
    conformal_metrics: Dict[str, Any] = {}
    for alpha, sets_all in (pred.get("conformal_sets", {}) or {}).items():
        if len(sets_all) < len(y_all):
            continue
        sets = [sets_all[i] for i in idx]
        hit = np.asarray([truth in {str(_clean_code(c)) for c in row if _clean_code(c) is not None} for truth, row in zip(y_true, sets)], dtype=bool)
        sizes = np.asarray([len(row) for row in sets], dtype=float)
        conformal_metrics[str(alpha)] = {
            "target_coverage": 1.0 - float(alpha),
            "empirical_coverage": float(hit.mean()),
            "mean_set_size": float(sizes.mean()),
            "median_set_size": float(np.median(sizes)),
            "singleton_rate": float((sizes == 1).mean()),
        }
    if conformal_metrics:
        out["conformal_metrics"] = conformal_metrics

    # Context subgroup metrics.
    def present(col: str) -> np.ndarray:
        if col not in df.columns:
            return np.zeros(len(df), dtype=bool)
        return df[col].map(lambda v: bool(_norm_text(v))).to_numpy(dtype=bool)

    employer = present("qa20")
    title4 = present("qe4")
    title5 = present("qe5a")
    selfemp = present("qe8aoth")
    industry = present("qe1oth")
    location = present("qe2b")
    context_masks = {
        "employer_present": employer,
        "employer_missing": ~employer,
        "current_title_present": title4,
        "unused_title_present": title5,
        "self_employment_text_present": selfemp,
        "industry_other_present": industry,
        "location_present": location,
        "no_primary_text_context": ~(employer | title4 | title5 | selfemp | industry | location),
    }
    subgroup_rows: List[Dict[str, Any]] = []
    for group, full_mask in context_masks.items():
        gm = full_mask[idx]
        if gm.sum() == 0:
            continue
        subgroup_rows.append({
            "target": name,
            "subgroup": group,
            "n": int(gm.sum()),
            "accuracy": float(correct[gm].mean()),
            "mean_confidence": float(conf[gm].mean()),
            "macro_f1": float(f1_score(np.asarray(y_true)[gm], np.asarray(y_pred)[gm], average="macro", zero_division=0)),
        })
    out["subgroup_rows"] = subgroup_rows

    # Local-only error details, no raw text by default.
    if include_row_details:
        ids = df[id_col].tolist() if id_col in df.columns else list(range(1, len(df) + 1))
        error_rows = []
        for local_pos, original_i in enumerate(idx):
            if correct[local_pos]:
                continue
            error_rows.append({
                "target": name,
                "row_id": ids[original_i],
                "true_code": y_true[local_pos],
                "predicted_code": y_pred[local_pos],
                "confidence": float(conf[local_pos]),
                "source": sources[local_pos],
                "alternatives": "|".join(c for c in top_rows[local_pos][1:] if c),
            })
        out["error_rows"] = error_rows
    return out


def _model_diagnostics(bundle: Mapping[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {"selected_models": [], "candidate_rows": [], "within_group_rows": [], "memory_rows": [], "posthoc_calibration": {}}

    def classifier(stage: str, clf: Any) -> None:
        if clf is None:
            return
        out["selected_models"].append({
            "stage": stage,
            "models": "+".join(getattr(clf, "model_names", [])),
            "rows": int(getattr(clf, "n_rows", 0)),
            "features": int(getattr(clf, "n_features", 0)),
            "classes": int(getattr(clf, "n_classes", 0)),
            "cv_macro_f1": getattr(clf, "cv_macro_f1", None),
            "cv_log_loss": getattr(clf, "cv_log_loss", None),
        })
        for score in getattr(clf, "cv_scores", []) or []:
            row = {
                "stage": stage,
                "candidate": getattr(score, "name", "unknown"),
                "macro_f1": getattr(score, "macro_f1", None),
                "log_loss": getattr(score, "log_loss_value", None),
                "failed": bool(getattr(score, "failed", False)),
                "reason": getattr(score, "reason", ""),
                "total_seconds": getattr(score, "total_seconds", None),
                "fold_seconds": getattr(score, "fold_seconds", None),
                "fold_macro_f1": getattr(score, "fold_macro_f1", None),
            }
            out["candidate_rows"].append(row)

    naics = bundle.get("naics_model", {})
    classifier("naics", naics.get("classifier"))
    for key, label in [("soc_qe4_model", "qe4ar"), ("soc_qe5_model", "qe5ar")]:
        model = bundle.get(key, {})
        classifier(f"{label}_major", model.get("major_model"))
        for major, clf in sorted((model.get("within_models") or {}).items(), key=lambda kv: str(kv[0])):
            classifier(f"{label}_within_{major}", clf)
            out["within_group_rows"].append({
                "target": label,
                "major": str(major),
                "rows": int(getattr(clf, "n_rows", 0)),
                "classes": int(getattr(clf, "n_classes", 0)),
                "model": getattr(clf, "model_name", ""),
                "cv_macro_f1": getattr(clf, "cv_macro_f1", None),
                "cv_log_loss": getattr(clf, "cv_log_loss", None),
            })

    posthoc = bundle.get("posthoc_calibration", {}) if isinstance(bundle, Mapping) else {}
    if posthoc:
        out["posthoc_calibration"] = {
            "created_at": posthoc.get("created_at"),
            "targets": {
                target: {
                    "calibration_rows": info.get("calibration_rows"),
                    "fusion_weights": info.get("fusion_weights"),
                    "conformal_qhat": info.get("conformal_qhat"),
                    "source_calibrator_count": len(info.get("calibrators", {})),
                    "candidate_meta_ranker_rows": getattr(info.get("candidate_meta_ranker"), "n_rows_", None),
                    "candidate_meta_ranker_positive_rate": getattr(info.get("candidate_meta_ranker"), "positive_rate_", None),
                    "conformal_rows": info.get("conformal_rows"),
                } for target, info in posthoc.get("targets", {}).items()
            },
        }

    for model_name, model in [("qa20a", naics), ("qe4ar", bundle.get("soc_qe4_model", {})), ("qe5ar", bundle.get("soc_qe5_model", {}))]:
        mem = model.get("adaptive_memory") if isinstance(model, Mapping) else None
        if mem:
            out["memory_rows"].append({
                "target": model_name,
                "rule_counts": mem.get("rule_counts"),
                "temporal": mem.get("temporal"),
                "validation": mem.get("validation"),
            })
    return out


def _data_profile(train_df: Optional[pd.DataFrame], score_df: Optional[pd.DataFrame], target_cols: Sequence[str], context_cols: Sequence[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for label, df in [("train", train_df), ("score", score_df)]:
        if df is None:
            continue
        out[label] = {"rows": int(len(df)), "columns": int(df.shape[1]), "missingness": {}, "target_distributions": {}, "text_length": {}}
        for col in list(dict.fromkeys(list(target_cols) + list(context_cols))):
            if col not in df.columns:
                continue
            s = df[col]
            out[label]["missingness"][col] = float(s.isna().mean() + ((s.astype(str).str.strip() == "").mean() if s.dtype == object else 0.0))
            if col in target_cols:
                cleaned = s.map(_clean_code).dropna()
                counts = cleaned.value_counts()
                out[label]["target_distributions"][col] = {
                    "labeled_n": int(cleaned.size),
                    "classes": int(counts.size),
                    "largest_class_share": float(counts.iloc[0] / counts.sum()) if counts.size else None,
                    "entropy_bits": _entropy_from_counts(counts.values),
                    "effective_classes": _effective_num_classes(counts.values),
                    "classes_lt_3": int((counts < 3).sum()),
                    "classes_lt_10": int((counts < 10).sum()),
                }
            if s.dtype == object or col in {"qa20", "qe4", "qe5a", "qe1oth", "qe8aoth", "qe2b"}:
                lengths = s.map(lambda v: len(_norm_text(v).split()))
                out[label]["text_length"][col] = {
                    "mean_words": float(lengths.mean()),
                    "median_words": float(lengths.median()),
                    "p95_words": float(lengths.quantile(0.95)),
                    "empty_share": float((lengths == 0).mean()),
                }
    return out


def _drift_profile(train_df: Optional[pd.DataFrame], score_df: Optional[pd.DataFrame], categorical_cols: Sequence[str], numeric_cols: Sequence[str], text_cols: Sequence[str]) -> Dict[str, Any]:
    if train_df is None or score_df is None:
        return {"warning": "Drift metrics require both training and scoring data."}
    out: Dict[str, Any] = {"categorical": [], "numeric": [], "text": [], "entity_seen_rates": {}}
    for col in categorical_cols:
        if col not in train_df.columns or col not in score_df.columns:
            continue
        tr = train_df[col].map(_clean_code)
        sc = score_df[col].map(_clean_code)
        train_vals = set(tr.dropna().astype(str))
        score_valid = sc.dropna().astype(str)
        unseen = float((~score_valid.isin(train_vals)).mean()) if len(score_valid) else None
        out["categorical"].append({"column": col, "train_unique": len(train_vals), "score_unique": int(score_valid.nunique()), "score_unseen_rate": unseen, "js_divergence": _js_divergence(tr, sc)})
    for col in numeric_cols:
        if col in train_df.columns and col in score_df.columns:
            out["numeric"].append({"column": col, "psi": _psi(train_df[col], score_df[col]), "standardized_mean_difference": _standardized_mean_difference(train_df[col], score_df[col])})
    for col in text_cols:
        if col not in train_df.columns or col not in score_df.columns:
            continue
        tr_len = train_df[col].map(lambda v: len(_norm_text(v).split()))
        sc_len = score_df[col].map(lambda v: len(_norm_text(v).split()))
        out["text"].append({"column": col, "word_length_smd": _standardized_mean_difference(tr_len, sc_len), "train_empty_share": float((tr_len == 0).mean()), "score_empty_share": float((sc_len == 0).mean())})
    for col in ["qa20", "qe4", "qe5a"]:
        if col not in train_df.columns or col not in score_df.columns:
            continue
        train_vals = set(train_df[col].map(_norm_text))
        train_vals.discard("")
        score_vals = score_df[col].map(_norm_text)
        valid = score_vals != ""
        out["entity_seen_rates"][col] = {
            "score_nonempty_n": int(valid.sum()),
            "seen_in_training_rate": float(score_vals[valid].isin(train_vals).mean()) if valid.any() else None,
            "unseen_rate": float((~score_vals[valid].isin(train_vals)).mean()) if valid.any() else None,
        }
    # Pair overlap is useful both for expected memory coverage and leakage detection.
    if all(c in train_df.columns and c in score_df.columns for c in ["qa20", "qe4"]):
        tr_pairs = set(zip(train_df["qa20"].map(_norm_text), train_df["qe4"].map(_norm_text)))
        sc_pairs = list(zip(score_df["qa20"].map(_norm_text), score_df["qe4"].map(_norm_text)))
        valid = np.array([bool(a or b) for a, b in sc_pairs])
        seen = np.array([pair in tr_pairs for pair in sc_pairs])
        out["entity_seen_rates"]["employer_title_pair"] = {
            "score_nonempty_n": int(valid.sum()),
            "seen_in_training_rate": float(seen[valid].mean()) if valid.any() else None,
        }
    return out


def _package_versions() -> Dict[str, Any]:
    names = ["numpy", "pandas", "scipy", "scikit-learn", "pyreadstat", "sentence-transformers", "torch", "faiss-cpu", "rapidfuzz", "optuna", "lightgbm", "xgboost", "catboost", "llama-cpp-python"]
    versions: Dict[str, Any] = {}
    for name in names:
        try:
            versions[name] = metadata.version(name)
        except Exception:
            versions[name] = None
    try:
        import torch
        versions["cuda_available"] = bool(torch.cuda.is_available())
        versions["cuda_version"] = torch.version.cuda
        versions["cuda_device"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception:
        pass
    return versions


def _recommendations(audit: Mapping[str, Any], bundle: Mapping[str, Any]) -> List[Dict[str, str]]:
    recs: List[Dict[str, str]] = []
    evaluations = audit.get("evaluations", {})
    if not evaluations or all((v.get("labeled_n", 0) or 0) < 200 for v in evaluations.values()):
        recs.append({"priority": "critical", "area": "evaluation", "recommendation": "Create a permanently held-out, human-adjudicated evaluation SAV with at least several hundred labeled rows per target. Training CV and pre-existing production codes are not a substitute for an independent benchmark."})
    for target, result in evaluations.items():
        summary = result.get("summary", {})
        if not summary:
            continue
        top1 = summary.get("top1_accuracy")
        top4 = summary.get("top4_accuracy") or summary.get("top3_accuracy")
        ece = result.get("calibration_summary", {}).get("ece")
        if top1 is not None and top4 is not None and top4 - top1 >= 0.10:
            ablation = result.get("reranker_ablation", {})
            delta = ablation.get("delta")
            if delta is None or delta < 0.01:
                recs.append({"priority": "high", "area": target, "recommendation": "The correct code is often already in the candidate pool, but reranking has not closed the gap. Fine-tune the domain Cross-Encoder on hard same-family negatives and keep the candidate-level stacker enabled."})
            else:
                recs.append({"priority": "medium", "area": target, "recommendation": f"Reranking improved top-1 by {delta:.3f}, while candidate recall remains higher. Expand/refresh hard negatives and test a larger union candidate pool on CALIBRATION, not GOLD."})
        if ece is not None and ece > 0.08:
            recs.append({"priority": "high", "area": target, "recommendation": f"Top-label expected calibration error is {ece:.3f}. Refit source-specific calibration on CALIBRATION only and use risk-coverage thresholds for review."})
        conformal = result.get("conformal_metrics", {})
        for alpha, cm in conformal.items():
            if cm.get("empirical_coverage", 0.0) + 0.02 < cm.get("target_coverage", 0.0):
                recs.append({"priority": "high", "area": f"{target}:conformal", "recommendation": f"APS alpha={alpha} under-covered on GOLD ({cm.get('empirical_coverage'):.3f} versus target {cm.get('target_coverage'):.3f}). Increase candidate-pool recall or recalibrate on a larger sealed calibration partition."})
                break
        source_rows = result.get("source_rows", [])
        fallback = next((r for r in source_rows if "fallback" in str(r.get("source", ""))), None)
        if fallback and fallback.get("coverage_of_labeled", 0) > 0.02:
            recs.append({"priority": "high", "area": target, "recommendation": "Fallback predictions cover a material share of rows. Add or improve source fields, mine more reviewed historical rules, and route fallback rows to mandatory review."})
        low_context = next((r for r in result.get("subgroup_rows", []) if r.get("subgroup") == "no_primary_text_context"), None)
        if low_context and low_context.get("n", 0) >= 20 and low_context.get("accuracy", 1.0) < 0.65:
            recs.append({"priority": "high", "area": target, "recommendation": "Rows with no primary text context perform poorly. Do not treat forced-fill codes on these rows as equivalent to model-supported predictions; require review or collect a self-employment/business-description field."})
    drift = audit.get("drift", {})
    for row in drift.get("categorical", []) if isinstance(drift, Mapping) else []:
        if (row.get("score_unseen_rate") or 0) > 0.30:
            recs.append({"priority": "medium", "area": f"drift:{row.get('column')}", "recommendation": "High unseen-category rate. Expand recent training data and rely on normalized memory/semantic features rather than exact one-hot matches alone."})
    for col, row in (drift.get("entity_seen_rates", {}) if isinstance(drift, Mapping) else {}).items():
        if (row.get("unseen_rate") or 0) > 0.40:
            recs.append({"priority": "medium", "area": f"entity:{col}", "recommendation": "Many scoring values were unseen in training. Refresh the historical window and consider domain-adaptive embedding/reranker fine-tuning."})
    model_diag = audit.get("model_diagnostics", {})
    weak = [r for r in model_diag.get("within_group_rows", []) if r.get("cv_macro_f1") is not None and r.get("cv_macro_f1") < 0.40 and r.get("rows", 0) >= 100]
    if weak:
        groups = ", ".join(f"{r['target']}:{r['major']}" for r in weak[:12])
        recs.append({"priority": "high", "area": "weak_SOC_groups", "recommendation": f"Targeted SOC major groups have low within-group CV macro-F1 ({groups}). Perform error clustering and collect/review more labels specifically for those groups rather than globally increasing model complexity."})
    mem_rows = model_diag.get("memory_rows", [])
    if not mem_rows:
        recs.append({"priority": "medium", "area": "adaptive_memory", "recommendation": "Adaptive historical memory metrics are absent. Enable adaptive memory and supply a reliable date field plus a human-reviewed flag where available."})
    cfg = bundle.get("config", {}) if isinstance(bundle, Mapping) else {}
    if not cfg.get("use_cross_encoder_reranker", False):
        recs.append({"priority": "medium", "area": "reranker", "recommendation": "Run an A/B benchmark with the cross-encoder enabled on the same holdout. Keep it only if top-1 accuracy improves enough to justify scoring time."})
    if cfg.get("use_local_llm_fallback", False):
        recs.append({"priority": "medium", "area": "LLM", "recommendation": "Measure the local LLM as a separate candidate-only ablation. Do not promote it unless it improves holdout accuracy over the cross-encoder and never allow unconstrained code generation in production."})
    ce_model = str(cfg.get("cross_encoder_model", ""))
    if not ce_model or "ms-marco" in ce_model.lower():
        recs.append({"priority": "roadmap", "area": "domain_finetuning", "recommendation": "Fine-tune the Cross-Encoder on historical positive pairs plus hard same-hierarchy and random negatives, using CALIBRATION for development and keeping GOLD sealed."})
    if not model_diag.get("posthoc_calibration", {}).get("targets"):
        recs.append({"priority": "roadmap", "area": "uncertainty", "recommendation": "Add APS/RAPS prediction sets on a separate calibration partition so review is controlled by empirical coverage rather than an arbitrary confidence threshold."})
    return recs


def _markdown_report(audit: Mapping[str, Any], chat_safe: bool = True) -> str:
    lines: List[str] = []
    lines.append("# NAICS/SOC Autocoder Model Improvement Report")
    lines.append("")
    lines.append(f"Generated: {audit.get('generated_at')}  ")
    lines.append(f"Audit version: `{audit.get('audit_version')}`  ")
    lines.append(f"Autocoder version: `{audit.get('autocoder_version')}`")
    lines.append("")
    lines.append("## Evaluation provenance")
    lines.append("")
    lines.append(audit.get("evaluation_note", "No evaluation note available."))
    lines.append("")
    lines.append("## Headline metrics")
    lines.append("")
    lines.append("| Target | Labeled N | Top-1 | Top-4 | Top-10 | Top-20 | Macro-F1 | Balanced Acc. | ECE |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for target, result in audit.get("evaluations", {}).items():
        s = result.get("summary", {})
        c = result.get("calibration_summary", {})
        def f(v: Any) -> str:
            return "NA" if v is None else f"{float(v):.4f}"
        lines.append(f"| {target} | {result.get('labeled_n', 0)} | {f(s.get('top1_accuracy'))} | {f(s.get('top4_accuracy'))} | {f(s.get('top10_accuracy'))} | {f(s.get('top20_accuracy'))} | {f(s.get('macro_f1'))} | {f(s.get('balanced_accuracy'))} | {f(c.get('ece'))} |")
    lines.append("")
    lines.append("## Selected model stages")
    lines.append("")
    for row in audit.get("model_diagnostics", {}).get("selected_models", []):
        lines.append(f"- **{row.get('stage')}**: `{row.get('models')}`; rows={row.get('rows'):,}; classes={row.get('classes')}; CV macro-F1={row.get('cv_macro_f1')}")
    lines.append("")
    lines.append("## Prediction-source performance")
    lines.append("")
    for target, result in audit.get("evaluations", {}).items():
        lines.append(f"### {target}")
        for row in sorted(result.get("source_rows", []), key=lambda r: r.get("n", 0), reverse=True):
            acc = row.get("accuracy")
            acc_s = "NA" if acc is None else f"{acc:.4f}"
            lines.append(f"- `{row.get('source')}`: n={row.get('n')}, accuracy={acc_s}, mean confidence={row.get('mean_confidence')}")
        lines.append("")
    lines.append("## Reranker and uncertainty diagnostics")
    lines.append("")
    for target, result in audit.get("evaluations", {}).items():
        ab = result.get("reranker_ablation")
        if ab:
            lines.append(f"- **{target} reranker**: pre={ab.get('pre_rerank_top1'):.4f}, post={ab.get('post_rerank_top1'):.4f}, delta={ab.get('delta'):.4f}, reranked_n={ab.get('used_n')}")
        for alpha, cm in result.get("conformal_metrics", {}).items():
            lines.append(f"- **{target} APS alpha={alpha}**: empirical coverage={cm.get('empirical_coverage'):.4f}, target={cm.get('target_coverage'):.4f}, mean set size={cm.get('mean_set_size'):.2f}, singleton rate={cm.get('singleton_rate'):.4f}")
    lines.append("")
    posthoc = audit.get("model_diagnostics", {}).get("posthoc_calibration", {})
    if posthoc:
        lines.append("### Learned fusion/calibration")
        lines.append("")
        for target, info in posthoc.get("targets", {}).items():
            lines.append(f"- **{target}**: fusion={info.get('fusion_weights')}; calibration rows={info.get('calibration_rows')}; APS qhat={info.get('conformal_qhat')}")
        lines.append("")

    lines.append("## Highest-priority recommendations")
    lines.append("")
    for i, rec in enumerate(audit.get("recommendations", []), 1):
        lines.append(f"{i}. **[{str(rec.get('priority')).upper()}] {rec.get('area')}**: {rec.get('recommendation')}")
    lines.append("")
    lines.append("## Files in the audit bundle")
    lines.append("")
    lines.append("- `analysis_summary_chat_safe.json`: complete machine-readable aggregate metrics")
    lines.append("- `candidate_model_leaderboard.csv`: CV comparison of model families/stages")
    lines.append("- `within_soc_group_metrics.csv`: weak and strong SOC group models")
    lines.append("- `*_per_class_metrics.csv`: precision/recall/F1/support")
    lines.append("- `*_top_confusions.csv`: most frequent code confusions")
    lines.append("- `*_calibration.csv`: reliability bins")
    lines.append("- `*_risk_coverage.csv`: accuracy versus auto-code coverage")
    lines.append("- `analysis_summary_chat_safe.json`: includes reranker delta, top-10/top-20 recall, and conformal coverage/set size")
    lines.append("- `drift_metrics.json`: train-to-score shift and unseen entity rates")
    lines.append("- `run_registry.csv`: one-row comparison record for this run")
    if not chat_safe:
        lines.append("- `local_error_rows.csv`: row IDs for local investigation; omitted from the chat-safe ZIP")
    lines.append("")
    lines.append("## What to upload to ChatGPT")
    lines.append("")
    lines.append("Upload `CHAT_UPLOAD_MODEL_IMPROVEMENT.zip` or this Markdown report. The chat-safe bundle intentionally excludes raw survey text and row-level identifiers.")
    return "\n".join(lines) + "\n"


def _zip_dir(source_dir: Path, zip_path: Path, include: Optional[Iterable[str]] = None) -> None:
    include_set = set(include) if include is not None else None
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in source_dir.rglob("*"):
            if not path.is_file() or path == zip_path:
                continue
            rel = str(path.relative_to(source_dir)).replace("\\", "/")
            if include_set is not None and rel not in include_set:
                continue
            zf.write(path, rel)


def generate_run_audit(
    analysis_dir: str,
    bundle: Mapping[str, Any],
    opt: Any,
    cfg: Any,
    train_df: Optional[pd.DataFrame] = None,
    score_df: Optional[pd.DataFrame] = None,
    out_df: Optional[pd.DataFrame] = None,
    details: Optional[Mapping[str, Any]] = None,
    evaluation_df: Optional[pd.DataFrame] = None,
    evaluation_details: Optional[Mapping[str, Any]] = None,
    runtime_events: Optional[Sequence[Mapping[str, Any]]] = None,
    run_label: str = "",
    include_row_details: bool = True,
    min_class_support: int = 10,
    confidence_bins: int = 10,
    top_confusions: int = 100,
) -> Dict[str, Any]:
    """Generate an improvement-focused audit and upload-safe bundle."""
    root = Path(analysis_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    run_id = _slug(run_label or f"{time.strftime('%Y%m%d_%H%M%S')}_{bundle.get('version', 'autocoder')}")
    run_dir = root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    eval_df = evaluation_df if evaluation_df is not None else score_df
    eval_details = evaluation_details if evaluation_details is not None else details
    evaluation_note = (
        "Metrics are computed on the independent evaluation SAV supplied with `--evaluation_sav`. This is the preferred estimate of generalization."
        if evaluation_df is not None
        else "Metrics are computed only where the scoring SAV already contained valid codes before overwrite. This is a shadow evaluation and may include legacy/model-assisted codes; treat it as diagnostic rather than a definitive benchmark."
    )

    audit: Dict[str, Any] = {
        "audit_version": AUDIT_VERSION,
        "autocoder_version": bundle.get("version"),
        "generated_at": _now(),
        "run_id": run_id,
        "evaluation_note": evaluation_note,
        "platform": {"python": sys.version, "platform": platform.platform(), "logical_cpus": os.cpu_count()},
        "package_versions": _package_versions(),
        "config": bundle.get("config", _jsonable(cfg)),
        "runtime_events": list(runtime_events or []),
        "model_diagnostics": _model_diagnostics(bundle),
    }

    target_cols = [getattr(opt, "naics_col", "qa20a"), getattr(opt, "qe4ar_col", "qe4ar"), getattr(opt, "qe5ar_col", "qe5ar")]
    context_cols = ["qa20", getattr(opt, "qe4_col", "qe4"), getattr(opt, "qe5_col", "qe5a"), "qe1oth", "qe8aoth", "qe2b", "qe10"]
    audit["data_profile"] = _data_profile(train_df, score_df, target_cols, context_cols)
    cat_cols = [getattr(opt, "naics_col", "qa20a"), "qe1", "qse1", "qe8a", "wh2", "qe8", "qa9", "qa9ar", "qe13", "qa6"]
    numeric_cols = list(getattr(cfg, "memory_numeric_cols", ("qe10",))) or ["qe10"]
    audit["drift"] = _drift_profile(train_df, score_df, cat_cols, numeric_cols, context_cols)

    evaluations: Dict[str, Any] = {}
    if eval_df is not None and eval_details is not None:
        specs = [
            (getattr(opt, "naics_col", "qa20a"), "naics", eval_details.get("before_naics", eval_df.get(getattr(opt, "naics_col", "qa20a"), pd.Series(dtype=object))), eval_details.get("pred_naics", {})),
            (getattr(opt, "qe4ar_col", "qe4ar"), "soc", eval_details.get("before4", eval_df.get(getattr(opt, "qe4ar_col", "qe4ar"), pd.Series(dtype=object))), eval_details.get("pred4", {})),
            (getattr(opt, "qe5ar_col", "qe5ar"), "soc", eval_details.get("before5", eval_df.get(getattr(opt, "qe5ar_col", "qe5ar"), pd.Series(dtype=object))), eval_details.get("pred5", {})),
        ]
        for target, kind, y_series, pred in specs:
            if not isinstance(y_series, pd.Series):
                y_series = pd.Series(y_series)
            evaluations[target] = _evaluate_target(target, kind, y_series, pred, eval_df, getattr(opt, "id_col", "id"), min_class_support, confidence_bins, top_confusions, include_row_details)
    audit["evaluations"] = evaluations
    audit["recommendations"] = _recommendations(audit, bundle)

    # Write aggregate outputs. The chat-safe JSON strips row-level error details.
    _write_json(run_dir / "analysis_summary.json", audit)
    chat_audit = json.loads(json.dumps(_jsonable(audit), default=str))
    for _target_result in chat_audit.get("evaluations", {}).values():
        _target_result.pop("error_rows", None)
    _write_json(run_dir / "analysis_summary_chat_safe.json", chat_audit)
    (run_dir / "UPLOAD_THIS_TO_CHAT.md").write_text(_markdown_report(chat_audit, chat_safe=True), encoding="utf-8")
    (run_dir / "MODEL_CARD_AND_IMPROVEMENT_REPORT.md").write_text(_markdown_report(audit, chat_safe=False), encoding="utf-8")
    _write_json(run_dir / "drift_metrics.json", audit.get("drift", {}))
    _write_json(run_dir / "data_profile.json", audit.get("data_profile", {}))
    _write_csv(run_dir / "selected_model_stages.csv", audit["model_diagnostics"].get("selected_models", []))
    _write_csv(run_dir / "candidate_model_leaderboard.csv", audit["model_diagnostics"].get("candidate_rows", []))
    _write_csv(run_dir / "within_soc_group_metrics.csv", audit["model_diagnostics"].get("within_group_rows", []))
    _write_json(run_dir / "adaptive_memory_metrics.json", audit["model_diagnostics"].get("memory_rows", []))
    _write_csv(run_dir / "runtime_events.csv", list(runtime_events or []))

    local_error_rows: List[Mapping[str, Any]] = []
    for target, result in evaluations.items():
        safe = _slug(target)
        _write_csv(run_dir / f"{safe}_per_class_metrics.csv", result.get("per_class_rows", []))
        _write_csv(run_dir / f"{safe}_top_confusions.csv", result.get("confusion_rows", []))
        _write_csv(run_dir / f"{safe}_calibration.csv", result.get("calibration_rows", []))
        _write_csv(run_dir / f"{safe}_risk_coverage.csv", result.get("selective_rows", []))
        _write_csv(run_dir / f"{safe}_source_metrics.csv", result.get("source_rows", []))
        _write_csv(run_dir / f"{safe}_subgroup_metrics.csv", result.get("subgroup_rows", []))
        local_error_rows.extend(result.get("error_rows", []))
    if include_row_details:
        _write_csv(run_dir / "local_error_rows.csv", local_error_rows)

    # A compact registry row makes later versions easy to compare.
    registry_row: Dict[str, Any] = {
        "run_id": run_id,
        "generated_at": audit["generated_at"],
        "autocoder_version": audit["autocoder_version"],
        "evaluation_source": "external" if evaluation_df is not None else "score_existing_labels",
    }
    for target, result in evaluations.items():
        s = result.get("summary", {})
        registry_row[f"{target}_n"] = result.get("labeled_n")
        registry_row[f"{target}_top1"] = s.get("top1_accuracy")
        registry_row[f"{target}_top4"] = s.get("top4_accuracy")
        registry_row[f"{target}_macro_f1"] = s.get("macro_f1")
        registry_row[f"{target}_ece"] = result.get("calibration_summary", {}).get("ece")
    registry_path = root / "run_registry.csv"
    registry_df = pd.DataFrame([registry_row])
    if registry_path.exists():
        try:
            old = pd.read_csv(registry_path)
            registry_df = pd.concat([old, registry_df], ignore_index=True)
        except Exception:
            pass
    registry_df.to_csv(registry_path, index=False, encoding="utf-8-sig")
    shutil.copy2(registry_path, run_dir / "run_registry.csv")

    # Chat bundle excludes row-level identifiers and bulky local-only files.
    chat_files = {
        "UPLOAD_THIS_TO_CHAT.md",
        "analysis_summary_chat_safe.json",
        "candidate_model_leaderboard.csv",
        "within_soc_group_metrics.csv",
        "adaptive_memory_metrics.json",
        "drift_metrics.json",
        "data_profile.json",
        "runtime_events.csv",
        "run_registry.csv",
    }
    for target in evaluations:
        safe = _slug(target)
        chat_files.update({
            f"{safe}_per_class_metrics.csv",
            f"{safe}_top_confusions.csv",
            f"{safe}_calibration.csv",
            f"{safe}_risk_coverage.csv",
            f"{safe}_source_metrics.csv",
            f"{safe}_subgroup_metrics.csv",
        })
    chat_zip = run_dir / "CHAT_UPLOAD_MODEL_IMPROVEMENT.zip"
    _zip_dir(run_dir, chat_zip, include=chat_files)
    full_zip = run_dir / "FULL_LOCAL_MODEL_AUDIT.zip"
    _zip_dir(run_dir, full_zip)

    return {
        "run_dir": str(run_dir),
        "chat_report": str(run_dir / "UPLOAD_THIS_TO_CHAT.md"),
        "chat_zip": str(chat_zip),
        "full_zip": str(full_zip),
        "summary_json": str(run_dir / "analysis_summary.json"),
        "registry": str(registry_path),
        "audit": audit,
    }
