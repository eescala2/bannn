param(
    [string]$Base = "C:\laborshed_autocode_clean"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Python not found: $Python" }
$env:HF_HOME = Join-Path $Base "hf_cache"
$env:HF_HUB_CACHE = Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE = "0"
$env:TRANSFORMERS_OFFLINE = "0"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:TOKENIZERS_PARALLELISM = "false"
Write-Host "Caching optional Cross-Encoder base models..." -ForegroundColor Cyan
& $Python -c @'
from sentence_transformers import CrossEncoder
models = [
    "cross-encoder/ms-marco-MiniLM-L12-v2",
    "BAAI/bge-reranker-base",
]
for model in models:
    print(f"Caching {model}...", flush=True)
    try:
        CrossEncoder(model, device="cpu")
        print(f"  OK: {model}", flush=True)
    except Exception as exc:
        print(f"  FAILED: {model}: {exc}", flush=True)
print("Optional model cache attempt complete.")
'@
