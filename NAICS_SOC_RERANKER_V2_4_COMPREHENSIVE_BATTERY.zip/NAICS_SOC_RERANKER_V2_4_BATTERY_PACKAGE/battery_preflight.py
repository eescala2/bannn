#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

VERSION = "2026.07.15.reranker-battery-preflight-v4"


def check_import(name: str) -> Dict[str, Any]:
    try:
        mod = importlib.import_module(name)
        return {"ok": True, "version": getattr(mod, "__version__", "unknown")}
    except Exception as exc:
        return {"ok": False, "error": repr(exc)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--check_optional_models", action="store_true")
    ap.add_argument("--out_json", default="")
    args = ap.parse_args()
    base = Path(args.base)
    result: Dict[str, Any] = {"version": VERSION, "base": str(base), "python": sys.version, "checks": {}, "critical_errors": [], "warnings": []}

    required_files = [
        base / "training_FIT.sav", base / "training_CALIBRATION.sav",
        base / "train_domain_cross_encoder_battery.py",
        base / "run_reranker_experiment_battery.py",
        base / "summarize_reranker_battery.py",
    ]
    result["checks"]["files"] = {str(p): p.exists() for p in required_files}
    for p in required_files:
        if not p.exists():
            result["critical_errors"].append(f"Missing required file: {p}")

    packages = ["numpy", "pandas", "pyreadstat", "torch", "datasets", "sentence_transformers", "faiss", "scipy", "psutil"]
    result["checks"]["packages"] = {name: check_import(name) for name in packages}
    for name in packages:
        if not result["checks"]["packages"][name]["ok"]:
            result["critical_errors"].append(f"Missing or broken Python package: {name}")

    try:
        import torch
        result["checks"]["cuda"] = {
            "available": bool(torch.cuda.is_available()),
            "version": torch.version.cuda,
            "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "memory_gb": round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 2) if torch.cuda.is_available() else None,
        }
        if not torch.cuda.is_available():
            result["critical_errors"].append("CUDA is not available to PyTorch")
    except Exception as exc:
        result["checks"]["cuda"] = {"available": False, "error": repr(exc)}
        result["critical_errors"].append("PyTorch CUDA check failed")

    try:
        from sentence_transformers.cross_encoder import losses
        available = {name: hasattr(losses, name) for name in ["BinaryCrossEntropyLoss", "RankNetLoss", "ListNetLoss", "LambdaLoss"]}
        result["checks"]["losses"] = available
        for name, ok in available.items():
            if not ok:
                result["warnings"].append(f"Loss unavailable and related battery experiments will fail: {name}")
    except Exception as exc:
        result["checks"]["losses"] = {"error": repr(exc)}

    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    try:
        from sentence_transformers import CrossEncoder, SentenceTransformer
        SentenceTransformer("BAAI/bge-large-en-v1.5", device="cpu")
        CrossEncoder("cross-encoder/ms-marco-MiniLM-L6-v2", device="cpu")
        result["checks"]["default_models_cached"] = True
    except Exception as exc:
        result["checks"]["default_models_cached"] = False
        result["critical_errors"].append(f"Default Hugging Face models are not loadable offline: {exc}")

    if args.check_optional_models:
        optional: Dict[str, Any] = {}
        try:
            from sentence_transformers import CrossEncoder
            for model in ["cross-encoder/ms-marco-MiniLM-L12-v2", "BAAI/bge-reranker-base"]:
                try:
                    CrossEncoder(model, device="cpu")
                    optional[model] = {"ok": True}
                except Exception as exc:
                    optional[model] = {"ok": False, "error": repr(exc)}
                    result["warnings"].append(f"Optional base model not cached: {model}")
        except Exception as exc:
            optional["error"] = repr(exc)
        result["checks"]["optional_models"] = optional

    out = Path(args.out_json) if args.out_json else base / "reranker_battery_preflight.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    print(f"Saved: {out}")
    if result["critical_errors"]:
        print("\nPRECHECK FAILED. Fix critical_errors before starting the battery.")
        return 2
    print("\nPRECHECK PASSED.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
