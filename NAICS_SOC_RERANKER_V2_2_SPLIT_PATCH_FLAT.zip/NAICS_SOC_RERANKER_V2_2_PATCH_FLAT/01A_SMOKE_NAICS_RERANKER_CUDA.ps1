param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [int]$MaxAnchors = 500,
    [double]$Epochs = 0.10
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "train_domain_cross_encoder.py"
$FitSav = Join-Path $Base "training_FIT.sav"
$CalibrationSav = Join-Path $Base "training_CALIBRATION.sav"
$OutputDir = Join-Path $Base "models\domain_cross_encoder_naics_smoke"
$ConsoleLog = Join-Path $Base "console_DOMAIN_RERANKER_NAICS_SMOKE_live.log"
foreach ($p in @($Python,$Script,$FitSav,$CalibrationSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
if (Test-Path $ConsoleLog) { Remove-Item $ConsoleLog -Force }
Write-Host "NAICS-only Cross-Encoder smoke test" -ForegroundColor Cyan
Write-Host "Output: $OutputDir"; Write-Host "Live log: $ConsoleLog"
$old = $ErrorActionPreference; $ErrorActionPreference="Continue"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $oldNative=$PSNativeCommandUseErrorActionPreference; $PSNativeCommandUseErrorActionPreference=$false }
try {
    & $Python -u $Script `
      --fit_sav $FitSav --calibration_sav $CalibrationSav --output_dir $OutputDir `
      --targets "qa20a" --device cuda --embedding_batch_size 16 --train_batch_size 4 `
      --eval_batch_size 32 --gradient_accumulation_steps 8 --epochs $Epochs `
      --max_anchors_per_target $MaxAnchors --max_length 384 --hard_negatives 3 `
      --random_negatives 1 --nearest_candidates 30 --eval_candidates 20 `
      --warmup_fraction 0.10 --progress_every 1024 --offline 2>&1 | Tee-Object -FilePath $ConsoleLog
    $code=$LASTEXITCODE
} finally {
    $ErrorActionPreference=$old
    if ($null -ne (Get-Variable oldNative -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference=$oldNative }
}
if ($code -ne 0) { if (Test-Path $ConsoleLog) { Get-Content $ConsoleLog -Tail 100 }; throw "NAICS smoke test failed with code $code" }
Write-Host "NAICS smoke model: $(Join-Path $OutputDir 'final')" -ForegroundColor Green
