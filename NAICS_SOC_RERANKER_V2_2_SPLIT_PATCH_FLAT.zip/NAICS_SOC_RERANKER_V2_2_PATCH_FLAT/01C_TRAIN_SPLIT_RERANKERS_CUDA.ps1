param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [int]$NaicsAnchors = 12000,
    [int]$SocAnchorsPerTarget = 12000,
    [double]$NaicsEpochs = 1.0,
    [double]$SocEpochs = 1.0
)
$ErrorActionPreference="Stop"
Set-Location $Base
$Python=Join-Path $Base ".venv\Scripts\python.exe"
$Script=Join-Path $Base "train_domain_cross_encoder.py"
$FitSav=Join-Path $Base "training_FIT.sav"
$CalibrationSav=Join-Path $Base "training_CALIBRATION.sav"
foreach ($p in @($Python,$Script,$FitSav,$CalibrationSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
function Run-Reranker([string]$Targets,[string]$Name,[int]$Anchors,[double]$Epochs) {
    $OutputDir=Join-Path $Base "models\$Name"
    $ConsoleLog=Join-Path $Base "console_${Name}_live.log"
    Write-Host "Training $Targets reranker -> $OutputDir" -ForegroundColor Cyan
    $old=$ErrorActionPreference; $ErrorActionPreference="Continue"
    if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $oldNative=$PSNativeCommandUseErrorActionPreference; $PSNativeCommandUseErrorActionPreference=$false }
    try {
        & $Python -u $Script --fit_sav $FitSav --calibration_sav $CalibrationSav `
          --output_dir $OutputDir --targets $Targets --device cuda --embedding_batch_size 16 `
          --train_batch_size 4 --eval_batch_size 32 --gradient_accumulation_steps 8 `
          --epochs $Epochs --max_anchors_per_target $Anchors --max_length 384 `
          --hard_negatives 3 --random_negatives 1 --nearest_candidates 30 `
          --eval_candidates 20 --warmup_fraction 0.10 --progress_every 1024 `
          --resume_from_checkpoint auto --offline 2>&1 | Tee-Object -FilePath $ConsoleLog
        $code=$LASTEXITCODE
    } finally {
        $ErrorActionPreference=$old
        if ($null -ne (Get-Variable oldNative -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference=$oldNative }
    }
    if ($code -ne 0) { if (Test-Path $ConsoleLog) { Get-Content $ConsoleLog -Tail 100 }; throw "$Name training failed with code $code" }
}
Run-Reranker "qa20a" "domain_cross_encoder_naics" $NaicsAnchors $NaicsEpochs
Run-Reranker "qe4ar,qe5ar" "domain_cross_encoder_soc" $SocAnchorsPerTarget $SocEpochs
Write-Host "Split rerankers completed." -ForegroundColor Green
