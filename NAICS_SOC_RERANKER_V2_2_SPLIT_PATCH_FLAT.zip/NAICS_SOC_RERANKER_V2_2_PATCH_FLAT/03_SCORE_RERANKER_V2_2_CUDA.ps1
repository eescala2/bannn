param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [string]$ModelIn = "",
    [Parameter(Mandatory=$true)][string]$ScoreSav,
    [string]$OutSav = "",
    [string]$RunLabel = "reranker_v2_2_score",
    [string]$NaicsCrossEncoderModel = "",
    [string]$SocCrossEncoderModel = ""
)
$ErrorActionPreference="Stop"; if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }; Set-Location $Base
if (-not $ModelIn) { $ModelIn = Join-Path $Base "models\naics_soc_RERANKER_V2_2.joblib" }
if (-not $OutSav) { $OutSav = Join-Path $Base "output\scored_RERANKER_V2_2.sav" }
$Python=Join-Path $Base ".venv\Scripts\python.exe"; $Script=Join-Path $Base "naics_soc_adaptive_memory_reranker_v2_2.py"
foreach ($p in @($Python,$Script,$ModelIn,$ScoreSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"; $env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
New-Item -ItemType Directory -Force -Path (Split-Path $OutSav),(Join-Path $Base "logs"),(Join-Path $Base "model_audits") | Out-Null
$Log=Join-Path $Base "logs\RERANKER_V2_2_score_predictions.txt"; $Console=Join-Path $Base "logs\console_RERANKER_V2_2_score_live.log"
if (-not $NaicsCrossEncoderModel) { $NaicsCrossEncoderModel = Join-Path $Base "models\domain_cross_encoder_naics\final" }
if (-not $SocCrossEncoderModel) { $SocCrossEncoderModel = Join-Path $Base "models\domain_cross_encoder_soc\final" }
$cli = [System.Collections.Generic.List[string]]::new()
function A([string]$n,[object]$v,[switch]$OmitBlank) { if ($OmitBlank -and [string]::IsNullOrWhiteSpace([string]$v)) { return }; $cli.Add($n); if ($null -ne $v) { $cli.Add([string]$v) } }
function S([string]$n) { $cli.Add($n) }
$cli.Add("-u"); $cli.Add($Script); A "--mode" "score"; A "--model_in" $ModelIn; A "--score_sav" $ScoreSav; A "--out_sav" $OutSav; A "--log_txt" $Log
S "--overwrite_existing"; S "--fill_all_missing"; S "--score_rows_without_text"; S "--fallback_fill_missing"
A "--cross_encoder_model_naics" $NaicsCrossEncoderModel -OmitBlank; A "--cross_encoder_model_soc" $SocCrossEncoderModel -OmitBlank
A "--embedding_device" "cuda"; A "--embedding_batch_size" "16"; A "--embedding_cache_dir" (Join-Path $Base "embedding_cache")
A "--max_workers" "6"; A "--native_threads" "1"; A "--score_batch_size" "1000"; A "--console_log" $Console
A "--analysis_dir" (Join-Path $Base "model_audits"); A "--analysis_run_label" $RunLabel; S "--analysis_include_row_details"
& $Python $cli.ToArray()
if ($LASTEXITCODE -ne 0) { throw "Score-only V2.2 run failed with code $LASTEXITCODE" }
Write-Host "Scored SAV: $OutSav" -ForegroundColor Green
