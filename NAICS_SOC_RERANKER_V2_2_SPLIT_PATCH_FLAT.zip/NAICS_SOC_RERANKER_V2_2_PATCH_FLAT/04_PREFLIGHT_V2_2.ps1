param([string]$Base = "C:\laborshed_autocode_clean", [switch]$RequireProductionModels)
$ErrorActionPreference="Stop"
Set-Location $Base
$required = @(
  (Join-Path $Base ".venv\Scripts\python.exe"),
  (Join-Path $Base "train_domain_cross_encoder.py"),
  (Join-Path $Base "naics_soc_adaptive_memory_reranker_v2_2.py"),
  (Join-Path $Base "autocoder_improvement_audit_v2.py"),
  (Join-Path $Base "training_FIT.sav"),
  (Join-Path $Base "training_CALIBRATION.sav"),
  (Join-Path $Base "training_EVALUATION_GOLD.sav")
)
if ($RequireProductionModels) {
  $required += Join-Path $Base "models\domain_cross_encoder_naics\final"
  $required += Join-Path $Base "models\domain_cross_encoder_soc\final"
}
$missing = @($required | Where-Object { -not (Test-Path $_) })
if ($missing.Count -gt 0) { Write-Host "Missing required paths:" -ForegroundColor Red; $missing | ForEach-Object { Write-Host "  $_" }; throw "V2.2 preflight failed" }
$Python=Join-Path $Base ".venv\Scripts\python.exe"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:CUDA_VISIBLE_DEVICES="0"
& $Python -c "import torch, faiss, pyreadstat, sklearn; from sentence_transformers import SentenceTransformer, CrossEncoder; print('torch',torch.__version__); print('cuda',torch.cuda.is_available()); print('device',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO CUDA'); SentenceTransformer('BAAI/bge-large-en-v1.5',device='cuda'); print('embedding model offline OK')"
if ($LASTEXITCODE -ne 0) { throw "Python/CUDA/model-cache preflight failed" }
Write-Host "V2.2 preflight passed." -ForegroundColor Green
