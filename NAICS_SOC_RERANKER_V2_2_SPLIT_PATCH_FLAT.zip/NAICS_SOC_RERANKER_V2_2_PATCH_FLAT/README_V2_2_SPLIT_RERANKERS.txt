NAICS/SOC AUTOCODER V2.2: SPLIT DOMAIN RERANKERS
=================================================

WHY THIS PATCH EXISTS
---------------------
The combined smoke test improved NAICS reranking but reduced both SOC reranking
metrics. That pattern is consistent with negative transfer between the NAICS
industry task and the SOC occupation task. V2.2 trains two compact rerankers:

  models\domain_cross_encoder_naics\final
  models\domain_cross_encoder_soc\final

The production autocoder routes qa20a candidates to the NAICS reranker and
qe4ar/qe5ar candidates to the SOC reranker.

The patch also replaces deprecated warmup_ratio with warmup_steps expressed as
an update-step fraction.

IMPORTANT INTERPRETATION OF SMOKE METRICS
-----------------------------------------
The reranker evaluation always inserts the true code into the 20-candidate test
set when retrieval did not include it. Therefore these metrics measure ranking
quality conditional on candidate availability; they are not end-to-end model
accuracy and are not comparable to the Gold headline top-1 metrics.

STEP 1 - APPLY THE PATCH
------------------------
Extract this package over C:\laborshed_autocode_clean, replacing files where
prompted. Keep training_FIT.sav, training_CALIBRATION.sav, Gold, .venv, caches,
and previous audit folders.

STEP 2 - RUN TARGET-SPECIFIC SMOKE TESTS
----------------------------------------
In Positron PowerShell:

  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  cd C:\laborshed_autocode_clean
  .\01A_SMOKE_NAICS_RERANKER_CUDA.ps1
  .\01B_SMOKE_SOC_RERANKER_CUDA.ps1

Compare base_metrics and tuned_metrics in:

  models\domain_cross_encoder_naics_smoke\domain_reranker_training_report.json
  models\domain_cross_encoder_soc_smoke\domain_reranker_training_report.json

Do not use smoke models in production. They use only 500 anchors per target and
0.10 epoch.

STEP 3 - PROMOTION RULE
-----------------------
Proceed to full split training only when:

  NAICS tuned top-1 or MRR exceeds NAICS base metrics; and
  both qe4ar and qe5ar tuned MRR/top-1 do not materially decline.

Small fluctuations under roughly one percentage point can be sampling noise.
Repeated or larger declines should be treated as a failed experiment.

STEP 4 - TRAIN FULL SPLIT RERANKERS
-----------------------------------

  .\01C_TRAIN_SPLIT_RERANKERS_CUDA.ps1

This trains NAICS first, then SOC, and resumes checkpoints automatically.

STEP 5 - RUN THE AUDITED V2.2 MODEL
-----------------------------------

  .\02_TRAIN_RERANKER_V2_2_AUDITED_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean `
    -RunLabel "reranker_v2_2"

The model uses the existing FIT, CALIBRATION, and sealed Gold files.

STEP 6 - SCORE NEW DATA
-----------------------

  .\03_SCORE_RERANKER_V2_2_CUDA.ps1 `
    -Base C:\laborshed_autocode_clean `
    -ScoreSav "C:\path\to\new_file.sav" `
    -OutSav "C:\path\to\new_file_scored.sav"

LIVE MONITORING
---------------
Each trainer writes live console logs under the project folder. GPU monitoring:

  nvidia-smi -l 10

PRE-FLIGHT
----------

  .\04_PREFLIGHT_V2_2.ps1 -Base C:\laborshed_autocode_clean

After full rerankers exist:

  .\04_PREFLIGHT_V2_2.ps1 -Base C:\laborshed_autocode_clean -RequireProductionModels
