param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Source = Join-Path $Base 'models\v3_production_rerankers\production_reranker_manifest.json'
$DestDir = Join-Path $Base 'models\v32_production_rerankers'
$Dest = Join-Path $DestDir 'production_reranker_manifest.json'
if (-not (Test-Path $Source)) { throw "Missing V3.1 production reranker manifest: $Source. Run 01_BUILD_V32_CONFIRMED_RERANKERS.ps1 instead." }
$data = Get-Content $Source -Raw | ConvertFrom-Json
New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
foreach ($target in @('qa20a','qe4ar','qe5ar')) {
  $sourceModel = [string]$data.targets.$target.model_path
  if ([string]::IsNullOrWhiteSpace($sourceModel) -or -not (Test-Path $sourceModel)) { throw "Missing existing $target reranker at: $sourceModel" }
  $targetDir = Join-Path $DestDir $target
  $destModel = Join-Path $targetDir 'final'
  if (Test-Path $targetDir) { Remove-Item $targetDir -Recurse -Force }
  New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
  Copy-Item -Path $sourceModel -Destination $destModel -Recurse -Force
  $data.targets.$target.model_path = $destModel
}
$data.version = '2026.07.23.v32-adopted-confirmed-rerankers'
$data | ConvertTo-Json -Depth 30 | Set-Content -Path $Dest -Encoding UTF8
Write-Host "Copied and adopted existing confirmed V3.1 rerankers for V3.2 qualification." -ForegroundColor Green
Write-Host "Manifest: $Dest"
