#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, time
from pathlib import Path

VERSION = "2026.07.23.v32-deployment-builder"


def copy_any(src: Path, dst: Path) -> None:
    if src.is_dir():
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--thin", action="store_true", help="Do not copy model weights; create scripts/config only")
    args = ap.parse_args()
    base = Path(args.base)
    decision_path = base / "v32_qualification" / "PROMOTION_DECISION.json"
    if not decision_path.exists(): raise FileNotFoundError(decision_path)
    decision = json.loads(decision_path.read_text(encoding="utf-8"))
    if decision.get("decision") != "PROMOTE" and not args.force:
        raise RuntimeError(f"Deployment blocked: decision={decision.get('decision')}. Use --force only after documented review.")

    deploy = base / "deployment_v32"
    if deploy.exists(): shutil.rmtree(deploy)
    deploy.mkdir(parents=True)
    files = [
        "naics_soc_adaptive_memory_reranker_v3_2.py",
        "autocoder_improvement_audit_v2.py",
        "create_review_queue_from_v32_log.py",
        "v32_preflight.py",
        "00_PREFLIGHT_V32.ps1",
        "04_SCORE_V32_NEW_DATA.ps1",
        "06_SCORE_ACTIVE_DATASET_V32.sps",
        "requirements_v3.txt",
        "BASELINE_GOLD_METRICS.json",
        "CONFIRMED_V31_WINNERS.json",
    ]
    for name in files:
        src = base / name
        if not src.exists(): raise FileNotFoundError(src)
        copy_any(src, deploy / name)

    if not args.thin:
        model = base / "models" / "naics_soc_QUALIFIED_V32.joblib"
        rerankers = base / "models" / "v32_production_rerankers"
        if not model.exists(): raise FileNotFoundError(model)
        if not rerankers.exists(): raise FileNotFoundError(rerankers)
        copy_any(model, deploy / "models" / model.name)
        copied_rerankers = deploy / "models" / "v32_production_rerankers"
        copy_any(rerankers, copied_rerankers)
        # Rewrite absolute training-machine paths so the deployment folder is portable.
        reranker_manifest_path = copied_rerankers / "production_reranker_manifest.json"
        if reranker_manifest_path.exists():
            reranker_manifest = json.loads(reranker_manifest_path.read_text(encoding="utf-8-sig"))
            for target in ("qa20a", "qe4ar", "qe5ar"):
                target_model = copied_rerankers / target / "final"
                if not target_model.exists():
                    raise FileNotFoundError(target_model)
                reranker_manifest["targets"][target]["model_path"] = str(target_model)
            reranker_manifest_path.write_text(json.dumps(reranker_manifest, indent=2, default=str), encoding="utf-8")

    (deploy / "input").mkdir(exist_ok=True)
    (deploy / "output").mkdir(exist_ok=True)
    (deploy / "logs").mkdir(exist_ok=True)
    (deploy / "review_queues").mkdir(exist_ok=True)
    qualification = base / "v32_qualification"
    if qualification.exists(): copy_any(qualification, deploy / "qualification")
    manifest = {
        "version": VERSION,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source_base": str(base),
        "decision": decision.get("decision"),
        "thin": bool(args.thin),
        "model": None if args.thin else r"models\naics_soc_QUALIFIED_V32.joblib",
        "rerankers": None if args.thin else r"models\v32_production_rerankers\production_reranker_manifest.json",
    }
    (deploy / "DEPLOYMENT_MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    readme = f"""NAICS/SOC Autocoder V3.2 Deployment Bundle
===========================================
Decision: {decision.get('decision')}
Created: {manifest['created_at']}

1. Copy this folder to the deployment computer.
2. Create or copy a compatible .venv with CUDA-enabled PyTorch.
3. Copy hf_cache and embedding_cache separately, or cache the required models once.
4. Place a SAV in input, then run 04_SCORE_V32_NEW_DATA.ps1 with -ScoreSav.
5. Review the generated CSV under review_queues.
6. SPSS 26 users can edit 06_SCORE_ACTIVE_DATASET_V32.sps to match the deployment path.

The original input SAV is never overwritten. The output SAV is written separately.
"""
    (deploy / "README_DEPLOYMENT.txt").write_text(readme, encoding="utf-8")
    archive = shutil.make_archive(str(base / "NAICS_SOC_AUTOCODER_V32_DEPLOYMENT"), "zip", root_dir=deploy)
    print(f"Deployment folder: {deploy}")
    print(f"Deployment ZIP: {archive}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
