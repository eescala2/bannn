#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, shutil, time
from pathlib import Path
from typing import Any, Dict, Tuple

VERSION = "2026.07.23.v32-promotion-gate"


def find_audit(root: Path, run_label: str) -> Path:
    direct = root / run_label / "analysis_summary_chat_safe.json"
    if direct.exists():
        return direct
    candidates = list(root.glob(f"**/{run_label}*/analysis_summary_chat_safe.json"))
    if not candidates:
        candidates = list(root.glob("**/analysis_summary_chat_safe.json"))
    if not candidates:
        raise FileNotFoundError(f"No analysis_summary_chat_safe.json found under {root}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def num(value: Any) -> float:
    try:
        x = float(value)
        return x if math.isfinite(x) else float("nan")
    except Exception:
        return float("nan")


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare V3.2 sealed-Gold metrics with the fixed audited baseline")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--run_label", default="qualified_v32")
    ap.add_argument("--analysis_root", default="")
    ap.add_argument("--baseline_json", default="")
    args = ap.parse_args()
    base = Path(args.base)
    analysis_root = Path(args.analysis_root or (base / "model_audits"))
    baseline_path = Path(args.baseline_json or (base / "BASELINE_GOLD_METRICS.json"))
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    audit_path = find_audit(analysis_root, args.run_label)
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    evaluations = audit.get("evaluations", {})

    targets = ("qa20a", "qe4ar", "qe5ar")
    rows: Dict[str, Any] = {}
    top1_gains = []
    gates = []
    for target in targets:
        b = baseline[target]
        result = evaluations.get(target, {})
        s = result.get("summary", {})
        c = result.get("calibration_summary", {})
        current = {
            "top1": num(s.get("top1_accuracy")),
            "top4": num(s.get("top4_accuracy")),
            "macro_f1": num(s.get("macro_f1")),
            "ece": num(c.get("ece")),
            "top10": num(s.get("top10_accuracy")),
            "top20": num(s.get("top20_accuracy")),
            "candidate_pool_size": s.get("candidate_pool_size"),
        }
        delta = {k: current[k] - num(b[k]) for k in ("top1", "top4", "macro_f1", "ece")}
        rows[target] = {"baseline": b, "current": current, "delta": delta}
        top1_gains.append(delta["top1"])
        target_gate = {
            "top1_not_materially_worse": delta["top1"] >= -0.002,
            "top4_not_materially_worse": delta["top4"] >= -0.005,
            "macro_f1_not_materially_worse": delta["macro_f1"] >= -0.010,
            "ece_not_materially_worse": delta["ece"] <= 0.030,
        }
        target_gate["pass"] = all(target_gate.values())
        rows[target]["gates"] = target_gate
        gates.append(target_gate["pass"])

    mean_top1_gain = sum(top1_gains) / len(top1_gains)
    improved_targets = sum(1 for x in top1_gains if x > 0.002)
    all_safe = all(gates)
    if all_safe and mean_top1_gain >= 0.005 and improved_targets >= 2:
        decision = "PROMOTE"
        reason = "V3.2 improved the mean sealed-Gold top-1 accuracy, improved at least two targets, and passed all regression/calibration gates."
    elif mean_top1_gain > 0 and all(x >= -0.01 for x in top1_gains):
        decision = "CONDITIONAL_REVIEW"
        reason = "V3.2 has a positive mean top-1 gain but did not clear every strict promotion gate. Review target-level tradeoffs before deployment."
    else:
        decision = "HOLD"
        reason = "V3.2 did not demonstrate a sufficiently safe sealed-Gold improvement over the audited baseline."

    # Evidence-driven next research plan. Gold is used for diagnosis only; future
    # training must still use FIT/CALIBRATION rather than Gold rows.
    plan = []
    for target in targets:
        cur = rows[target]["current"]
        gap = cur["top4"] - cur["top1"] if math.isfinite(cur["top4"]) and math.isfinite(cur["top1"]) else float("nan")
        top20 = cur.get("top20")
        if math.isfinite(gap) and gap >= 0.08:
            plan.append({"priority": "HIGH", "target": target, "avenue": "ranking", "action": "Test a stronger or ensembled target-specific reranker on CALIBRATION; the correct code is frequently in the candidate set but not ranked first.", "evidence": {"top4_minus_top1": gap}})
        if math.isfinite(top20) and top20 < 0.95:
            plan.append({"priority": "HIGH", "target": target, "avenue": "retrieval", "action": "Improve candidate generation using source/profile-weight learning, more employer aliases, and target-specific bi-encoder fine-tuning.", "evidence": {"top20_accuracy": top20}})
        if math.isfinite(cur["ece"]) and cur["ece"] > 0.06:
            plan.append({"priority": "MEDIUM", "target": target, "avenue": "calibration", "action": "Refit source-specific confidence calibration and review thresholds on a fresh calibration partition.", "evidence": {"ece": cur["ece"]}})
    plan.append({"priority": "PROCESS", "target": "all", "avenue": "holdout governance", "action": "After this qualification, freeze the existing Gold set. Further model selection should use FIT/CALIBRATION or a new future temporal holdout to avoid tuning repeatedly to Gold."})

    output = {
        "version": VERSION,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "audit_path": str(audit_path),
        "baseline_path": str(baseline_path),
        "decision": decision,
        "reason": reason,
        "mean_top1_gain": mean_top1_gain,
        "improved_targets": improved_targets,
        "targets": rows,
        "next_research_plan": plan,
    }
    out_dir = base / "v32_qualification"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "PROMOTION_DECISION.json"
    md_path = out_dir / "PROMOTION_DECISION.md"
    json_path.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
    lines = [
        "# V3.2 Sealed-Gold Promotion Decision", "",
        f"**Decision: {decision}**", "", reason, "",
        f"Mean top-1 gain: {mean_top1_gain:+.4f}", "",
        "| Target | Baseline top-1 | V3.2 top-1 | Delta | Baseline top-4 | V3.2 top-4 | Macro-F1 delta | ECE delta | Gate |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for t in targets:
        r = rows[t]
        lines.append(
            f"| {t} | {r['baseline']['top1']:.4f} | {r['current']['top1']:.4f} | {r['delta']['top1']:+.4f} | "
            f"{r['baseline']['top4']:.4f} | {r['current']['top4']:.4f} | {r['delta']['macro_f1']:+.4f} | {r['delta']['ece']:+.4f} | "
            f"{'PASS' if r['gates']['pass'] else 'REVIEW'} |"
        )
    lines += ["", "## Next research plan", ""]
    for item in plan:
        lines.append(f"- **{item['priority']} / {item['target']} / {item['avenue']}**: {item['action']}")
    lines += ["", f"Audit source: `{audit_path}`", f"Machine-readable decision: `{json_path}`"]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    flag = out_dir / "DEPLOYMENT_APPROVED.flag"
    if decision == "PROMOTE":
        flag.write_text("PROMOTE\n", encoding="utf-8")
    elif flag.exists():
        flag.unlink()
    print(md_path.read_text(encoding="utf-8"))
    print(f"Decision JSON: {json_path}")
    return 0 if decision in {"PROMOTE", "CONDITIONAL_REVIEW"} else 3

if __name__ == "__main__":
    raise SystemExit(main())
