param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [string]$RunLabel = "qualified_v32"
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base '.venv\Scripts\python.exe'
& $Python -u (Join-Path $Base 'evaluate_v32_promotion.py') --base $Base --run_label $RunLabel
$code = $LASTEXITCODE
if ($code -eq 3) {
  Write-Host 'V3.2 is on HOLD. Open v32_qualification\PROMOTION_DECISION.md.' -ForegroundColor Yellow
  exit 0
}
if ($code -ne 0) { throw "Promotion evaluator failed with code $code" }
Write-Host 'Promotion evaluation complete. Open v32_qualification\PROMOTION_DECISION.md.' -ForegroundColor Green
