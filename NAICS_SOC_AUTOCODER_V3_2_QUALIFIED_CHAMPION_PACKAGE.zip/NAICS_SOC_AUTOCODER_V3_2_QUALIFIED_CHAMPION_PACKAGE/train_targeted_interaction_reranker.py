#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Targeted V3 Cross-Encoder interaction trainer for NAICS/SOC autocoding.

This trainer is the evidence-driven successor to the broad V2.4 battery.  It
separates candidate generation from reranking and evaluates the production-like
union of:

* semantic candidates from several target-specific context profiles;
* a cached sparse lexical LinearSVC candidate generator; and
* high-purity historical memory candidates.

The Cross-Encoder always receives a separately configured, usually richer,
reranking context.  This allows short/noisy-field-resistant retrieval and
full-context final ranking to coexist.

FIT supplies training examples. CALIBRATION supplies candidate/ranking
measurement. The sealed Gold file is deliberately never read by this script.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import random
import shutil
import time
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
import pyreadstat
import scipy.sparse as sp
import torch
from datasets import Dataset
from scipy.special import expit
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sentence_transformers import CrossEncoder, SentenceTransformer
from sentence_transformers.cross_encoder import CrossEncoderTrainer, CrossEncoderTrainingArguments
from sentence_transformers.cross_encoder import losses as ce_losses

import train_domain_cross_encoder_battery as base

VERSION = "2026.07.19.targeted-interaction-reranker-v3.1"
VALID_PROFILES = {"full", "compact", "title_only", "no_employer", "no_location", "no_naics", "no_other_text"}


def eprint(message: str) -> None:
    print(message, flush=True)


def parse_csv(value: str) -> List[str]:
    return [x.strip() for x in str(value or "").split(",") if x.strip()]


def file_signature(path: str) -> Dict[str, Any]:
    p = Path(path)
    st = p.stat()
    return {"path": str(p.resolve()), "size": int(st.st_size), "mtime_ns": int(st.st_mtime_ns)}


def stable_hash(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]


def cache_path(cache_dir: Path, prefix: str, payload: Mapping[str, Any], suffix: str) -> Path:
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / f"{prefix}_{stable_hash(payload)}{suffix}"


def atomic_save_npy(path: Path, arr: np.ndarray) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as handle:
        np.save(handle, arr)
    tmp.replace(path)


def encode_cached(
    model: SentenceTransformer,
    texts: Sequence[str],
    batch_size: int,
    cache_dir: Path,
    cache_key: Mapping[str, Any],
    label: str,
    progress_every: int,
) -> np.ndarray:
    path = cache_path(cache_dir, "emb", cache_key, ".npy")
    if path.exists():
        eprint(f"[{label}] Loading cached embeddings: {path}")
        arr = np.load(path, mmap_mode=None)
        if arr.shape[0] != len(texts):
            raise ValueError(f"Cached embedding row mismatch for {path}: {arr.shape[0]} != {len(texts)}")
        return np.asarray(arr, dtype=np.float32)
    arr = base.encode(model, texts, batch_size, label=label, progress_every=progress_every)
    atomic_save_npy(path, np.asarray(arr, dtype=np.float32))
    eprint(f"[{label}] Saved embedding cache: {path}")
    return np.asarray(arr, dtype=np.float32)


def nearest_codes_scores(
    prototype_codes: Sequence[str],
    prototype_embeddings: np.ndarray,
    query_embeddings: np.ndarray,
    k: int,
) -> Tuple[np.ndarray, np.ndarray]:
    codes = np.asarray(list(prototype_codes), dtype="U16")
    if len(codes) == 0 or query_embeddings.shape[0] == 0:
        return np.empty((query_embeddings.shape[0], 0), dtype="U16"), np.empty((query_embeddings.shape[0], 0), dtype=np.float32)
    k = max(1, min(int(k), len(codes)))
    if base.faiss is not None:
        index = base.faiss.IndexFlatIP(int(prototype_embeddings.shape[1]))
        index.add(np.ascontiguousarray(prototype_embeddings.astype(np.float32, copy=False)))
        scores, inds = index.search(np.ascontiguousarray(query_embeddings.astype(np.float32, copy=False)), k)
    else:
        sim = np.asarray(query_embeddings @ prototype_embeddings.T, dtype=np.float32)
        inds = np.argpartition(-sim, kth=k - 1, axis=1)[:, :k]
        row = np.arange(sim.shape[0])[:, None]
        order = np.argsort(-sim[row, inds], axis=1)
        inds = inds[row, order]
        scores = sim[row, inds]
    return codes[inds], np.asarray(scores, dtype=np.float32)


def topk_from_scores(scores: np.ndarray, classes: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    if scores.ndim == 1:
        scores = np.column_stack([-scores, scores])
    k = max(1, min(int(k), scores.shape[1]))
    idx = np.argpartition(-scores, kth=k - 1, axis=1)[:, :k]
    row = np.arange(scores.shape[0])[:, None]
    order = np.argsort(-scores[row, idx], axis=1)
    idx = idx[row, order]
    return np.asarray(classes, dtype="U16")[idx], np.asarray(scores[row, idx], dtype=np.float32)


def lexical_candidate_cache(
    fit_docs: Sequence[str],
    cal_docs: Sequence[str],
    fit_labels: Sequence[Optional[str]],
    target: str,
    k: int,
    cache_dir: Path,
    key_base: Mapping[str, Any],
) -> Dict[str, np.ndarray]:
    payload = dict(key_base) | {"kind": "lexical", "target": target, "k": int(k), "version": VERSION}
    path = cache_path(cache_dir, f"lexical_{target}", payload, ".npz")
    if path.exists():
        eprint(f"[{target} lexical] Loading cached candidates: {path}")
        with np.load(path, allow_pickle=False) as z:
            return {name: z[name] for name in z.files}

    valid = np.asarray([v is not None for v in fit_labels], dtype=bool)
    y_all = np.asarray([str(v) if v is not None else "" for v in fit_labels], dtype="U16")
    counts = Counter(y_all[valid].tolist())
    allowed = {code for code, n in counts.items() if n >= 2}
    valid &= np.asarray([v in allowed for v in y_all], dtype=bool)
    if valid.sum() < 100 or len(allowed) < 2:
        eprint(f"[{target} lexical] Too few rows/classes; lexical source disabled.")
        empty_fit = np.empty((len(fit_docs), 0), dtype="U16")
        empty_cal = np.empty((len(cal_docs), 0), dtype="U16")
        return {"fit_codes": empty_fit, "fit_scores": np.empty((len(fit_docs), 0), dtype=np.float32),
                "cal_codes": empty_cal, "cal_scores": np.empty((len(cal_docs), 0), dtype=np.float32)}

    eprint(f"[{target} lexical] Building TF-IDF candidate generator rows={int(valid.sum()):,} classes={len(allowed):,}")
    word = TfidfVectorizer(
        lowercase=False, ngram_range=(1, 2), min_df=2, max_df=0.95,
        max_features=60000, sublinear_tf=True, dtype=np.float32,
    )
    char = TfidfVectorizer(
        lowercase=False, analyzer="char_wb", ngram_range=(3, 5), min_df=3,
        max_features=60000, sublinear_tf=True, dtype=np.float32,
    )
    xw = word.fit_transform(np.asarray(fit_docs, dtype=object)[valid].tolist())
    xc = char.fit_transform(np.asarray(fit_docs, dtype=object)[valid].tolist())
    x = sp.hstack([xw, xc], format="csr", dtype=np.float32)
    try:
        clf = LinearSVC(C=1.0, class_weight="balanced", dual="auto", max_iter=7000, random_state=42)
    except TypeError:
        clf = LinearSVC(C=1.0, class_weight="balanced", max_iter=7000, random_state=42)
    started = time.time()
    clf.fit(x, y_all[valid])
    eprint(f"[{target} lexical] LinearSVC fit DONE elapsed={(time.time()-started)/60:.1f}m features={x.shape[1]:,}")

    def transform_batch(values: Sequence[str], batch_size: int = 1000) -> Tuple[np.ndarray, np.ndarray]:
        code_parts: List[np.ndarray] = []
        score_parts: List[np.ndarray] = []
        total = len(values)
        for start in range(0, total, batch_size):
            end = min(total, start + batch_size)
            bx = sp.hstack([word.transform(values[start:end]), char.transform(values[start:end])], format="csr", dtype=np.float32)
            score = np.asarray(clf.decision_function(bx), dtype=np.float32)
            codes, vals = topk_from_scores(score, np.asarray(clf.classes_), k)
            code_parts.append(codes); score_parts.append(vals)
            if end == total or end % 5000 == 0:
                eprint(f"[{target} lexical] candidates {end:,}/{total:,}")
        return np.vstack(code_parts), np.vstack(score_parts)

    fit_codes, fit_scores = transform_batch(list(fit_docs))
    cal_codes, cal_scores = transform_batch(list(cal_docs))
    np.savez_compressed(path, fit_codes=fit_codes, fit_scores=fit_scores, cal_codes=cal_codes, cal_scores=cal_scores)
    eprint(f"[{target} lexical] Saved candidate cache: {path}")
    del xw, xc, x, clf, word, char
    gc.collect()
    return {"fit_codes": fit_codes, "fit_scores": fit_scores, "cal_codes": cal_codes, "cal_scores": cal_scores}


def memory_templates(target: str) -> List[List[str]]:
    if target == "qa20a":
        return [
            ["qa20", "qe4", "qe1oth", "qe8aoth"],
            ["qa20", "qe4", "qe2b"],
            ["qa20", "qe4"],
            ["qe8aoth", "qe4"],
            ["qe1oth", "qe4"],
            ["qa20"],
            ["qe4"],
        ]
    title = "qe4" if target == "qe4ar" else "qe5a"
    return [
        [title, "qa20", "qa20a", "qe2b"],
        [title, "qa20a", "qe2b"],
        [title, "qa20", "qa20a"],
        [title, "qa20a"],
        [title, "qa20"],
        [title, "qe2b"],
        [title],
    ]


def normalized_key(row: pd.Series, columns: Sequence[str]) -> Optional[str]:
    parts: List[str] = []
    nonempty = 0
    for col in columns:
        value = base.normalize_text(row.get(col)) if col in row.index else ""
        if value:
            nonempty += 1
        parts.append(value or "MISSING")
    if nonempty == 0:
        return None
    return "||".join(parts)


def build_memory_rules(
    fit_df: pd.DataFrame,
    labels: Sequence[Optional[str]],
    target: str,
    min_count: int = 3,
) -> List[Tuple[List[str], Dict[str, List[Tuple[str, float, int]]]]]:
    rules: List[Tuple[List[str], Dict[str, List[Tuple[str, float, int]]]]] = []
    for cols in memory_templates(target):
        buckets: Dict[str, Counter] = defaultdict(Counter)
        for pos, (_, row) in enumerate(fit_df.iterrows()):
            label = labels[pos]
            if label is None:
                continue
            key = normalized_key(row, cols)
            if key is not None:
                buckets[key][str(label)] += 1
        accepted: Dict[str, List[Tuple[str, float, int]]] = {}
        for key, counter in buckets.items():
            total = sum(counter.values())
            if total < min_count:
                continue
            ordered = counter.most_common(5)
            accepted[key] = [(code, n / total, total) for code, n in ordered]
        rules.append((list(cols), accepted))
    return rules


def memory_candidates_for_df(
    df: pd.DataFrame,
    rules: Sequence[Tuple[Sequence[str], Mapping[str, Sequence[Tuple[str, float, int]]]]],
    max_candidates: int = 6,
) -> Tuple[List[List[str]], List[List[float]]]:
    all_codes: List[List[str]] = []
    all_scores: List[List[float]] = []
    for _, row in df.iterrows():
        merged: Dict[str, float] = {}
        for specificity, (cols, mapping) in enumerate(rules[::-1], start=1):
            key = normalized_key(row, cols)
            if key is None:
                continue
            vals = mapping.get(key)
            if not vals:
                continue
            spec_bonus = 1.0 + 0.05 * len(cols)
            for code, purity, support in vals:
                score = float(purity) * spec_bonus * min(1.25, 1.0 + math.log1p(support) / 20.0)
                merged[code] = max(merged.get(code, 0.0), score)
        ordered = sorted(merged.items(), key=lambda kv: kv[1], reverse=True)[:max_candidates]
        all_codes.append([c for c, _ in ordered]); all_scores.append([float(s) for _, s in ordered])
    return all_codes, all_scores


def softmax_rows(values: np.ndarray) -> np.ndarray:
    if values.size == 0:
        return values.astype(np.float32)
    x = np.asarray(values, dtype=np.float64)
    x = x - np.nanmax(x, axis=1, keepdims=True)
    e = np.exp(np.clip(x, -50, 50))
    den = e.sum(axis=1, keepdims=True)
    den[den <= 0] = 1.0
    return (e / den).astype(np.float32)


def merge_candidate_sources(
    n_rows: int,
    semantic_sources: Sequence[Tuple[str, np.ndarray, np.ndarray]],
    lexical_codes: Optional[np.ndarray],
    lexical_scores: Optional[np.ndarray],
    memory_codes: Optional[Sequence[Sequence[str]]],
    memory_scores: Optional[Sequence[Sequence[float]]],
    limit: int,
    rrf_k: float = 12.0,
) -> List[List[str]]:
    output: List[List[str]] = []
    lex_prob = softmax_rows(lexical_scores) if lexical_scores is not None and lexical_scores.size else None
    for i in range(n_rows):
        cmap: Dict[str, Dict[str, Any]] = {}
        for source_name, codes, scores in semantic_sources:
            if i >= codes.shape[0]:
                continue
            for rank, code in enumerate(codes[i].tolist()):
                code = str(code)
                if not code:
                    continue
                sim = float(scores[i, rank]) if scores.size else 0.0
                entry = cmap.setdefault(code, {"score": 0.0, "sources": set()})
                entry["score"] += 1.0 / (rrf_k + rank + 1) + 0.02 * max(0.0, sim)
                entry["sources"].add(source_name)
        if lexical_codes is not None and i < lexical_codes.shape[0]:
            for rank, code in enumerate(lexical_codes[i].tolist()):
                code = str(code)
                if not code:
                    continue
                prob = float(lex_prob[i, rank]) if lex_prob is not None else 0.0
                entry = cmap.setdefault(code, {"score": 0.0, "sources": set()})
                entry["score"] += 1.25 / (rrf_k + rank + 1) + 0.08 * prob
                entry["sources"].add("lexical")
        if memory_codes is not None and i < len(memory_codes):
            for rank, code in enumerate(memory_codes[i]):
                score = float(memory_scores[i][rank]) if memory_scores is not None and rank < len(memory_scores[i]) else 1.0
                entry = cmap.setdefault(str(code), {"score": 0.0, "sources": set()})
                entry["score"] += 0.20 + 0.10 * score + 1.5 / (rrf_k + rank + 1)
                entry["sources"].add("memory")
        for entry in cmap.values():
            entry["score"] += 0.015 * max(0, len(entry["sources"]) - 1)
        ordered = sorted(cmap.items(), key=lambda kv: kv[1]["score"], reverse=True)[: max(1, int(limit))]
        output.append([code for code, _ in ordered])
    return output


def source_recall(labels: Sequence[Optional[str]], candidates: Sequence[Sequence[str]], ks: Sequence[int]) -> Dict[str, Any]:
    return base.candidate_recall_at_k(labels, candidates, ks)


def main() -> int:
    ap = argparse.ArgumentParser(description="Train/evaluate target-specific rerankers with multi-context production-like candidate unions")
    ap.add_argument("--fit_sav", required=True)
    ap.add_argument("--calibration_sav", required=True)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--target", choices=["qa20a", "qe4ar", "qe5ar"], required=True)
    ap.add_argument("--base_model", default="cross-encoder/ms-marco-MiniLM-L6-v2")
    ap.add_argument("--embedding_model", default="BAAI/bge-large-en-v1.5")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--candidate_cache_dir", default="")
    ap.add_argument("--retrieval_context_profiles", default="full")
    ap.add_argument("--rerank_context_profile", default="full")
    ap.add_argument("--retrieval_prototype_examples", type=int, default=5)
    ap.add_argument("--rerank_prototype_examples", type=int, default=3)
    ap.add_argument("--semantic_candidates_per_profile", type=int, default=50)
    ap.add_argument("--lexical_candidates", type=int, default=30)
    ap.add_argument("--memory_candidates", type=int, default=6)
    ap.add_argument("--candidate_union_limit", type=int, default=60)
    ap.add_argument("--candidate_sources", default="semantic,lexical,memory")
    ap.add_argument("--embedding_batch_size", type=int, default=16)
    ap.add_argument("--train_batch_size", type=int, default=4)
    ap.add_argument("--eval_batch_size", type=int, default=32)
    ap.add_argument("--gradient_accumulation_steps", type=int, default=8)
    ap.add_argument("--max_update_steps", type=int, default=600)
    ap.add_argument("--epochs", type=float, default=1.0)
    ap.add_argument("--learning_rate", type=float, default=2e-5)
    ap.add_argument("--max_length", type=int, default=384)
    ap.add_argument("--max_anchors", type=int, default=12000)
    ap.add_argument("--hard_negatives", type=int, default=3)
    ap.add_argument("--random_negatives", type=int, default=1)
    ap.add_argument("--hard_negative_strategy", choices=["hybrid", "semantic", "hierarchy"], default="hybrid")
    ap.add_argument("--loss_type", choices=["bce", "ranknet", "listnet", "lambda"], default="bce")
    ap.add_argument("--listwise_mini_batch_size", type=int, default=4)
    ap.add_argument("--anchor_sampling", choices=["balanced", "frequency"], default="balanced")
    ap.add_argument("--weak_group_multiplier", type=int, default=2)
    ap.add_argument("--eval_rows", type=int, default=4000)
    ap.add_argument("--eval_candidates", type=int, default=40)
    ap.add_argument("--retrieval_recall_ks", default="1,4,10,20,40,60")
    ap.add_argument("--bootstrap_samples", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--progress_every", type=int, default=1024)
    ap.add_argument("--resume_from_checkpoint", default="")
    ap.add_argument("--artifact_policy", choices=["full", "final_only", "metrics_only"], default="metrics_only")
    ap.add_argument("--checkpoint_keep", type=int, default=1)
    ap.add_argument("--offline", action="store_true")
    args = ap.parse_args()

    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"; os.environ["TRANSFORMERS_OFFLINE"] = "1"
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    profiles = parse_csv(args.retrieval_context_profiles)
    if not profiles:
        profiles = ["full"]
    bad = sorted(set(profiles + [args.rerank_context_profile]) - VALID_PROFILES)
    if bad:
        raise ValueError(f"Unknown context profiles: {bad}")
    sources = {x.lower() for x in parse_csv(args.candidate_sources)}
    target = args.target
    kind = "naics" if target == "qa20a" else "soc"
    output = Path(args.output_dir); output.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(args.candidate_cache_dir or (output.parent.parent / "candidate_cache_v3"))
    cache_dir.mkdir(parents=True, exist_ok=True)

    eprint(f"Targeted interaction trainer {VERSION}")
    eprint(f"target={target} retrieval_profiles={profiles} rerank_profile={args.rerank_context_profile}")
    eprint(f"sources={sorted(sources)} CUDA={torch.cuda.is_available()} device={args.device}")
    fit_df, _ = pyreadstat.read_sav(args.fit_sav, user_missing=True, apply_value_formats=False)
    cal_df, _ = pyreadstat.read_sav(args.calibration_sav, user_missing=True, apply_value_formats=False)
    if target not in fit_df.columns or target not in cal_df.columns:
        raise ValueError(f"Target column missing: {target}")
    labels_fit = [base.clean_code(v, kind) for v in fit_df[target].tolist()]
    labels_cal = [base.clean_code(v, kind) for v in cal_df[target].tolist()]
    plan = base.field_plans()[target]
    rerank_plan = base.apply_context_profile(plan, target, args.rerank_context_profile)
    rerank_fit_docs = base.make_docs(fit_df, rerank_plan, target)
    rerank_cal_docs = base.make_docs(cal_df, rerank_plan, target)
    rerank_prototypes, counts = base.build_prototypes(rerank_fit_docs, labels_fit, target, args.rerank_prototype_examples)
    prototype_codes = sorted(rerank_prototypes)
    if len(prototype_codes) < 2:
        raise RuntimeError("Too few target classes to train reranker")

    embedder = SentenceTransformer(args.embedding_model, device=args.device)
    common_key = {
        "fit": file_signature(args.fit_sav), "cal": file_signature(args.calibration_sav),
        "target": target, "embedding_model": args.embedding_model, "version": VERSION,
    }
    semantic_fit_sources: List[Tuple[str, np.ndarray, np.ndarray]] = []
    semantic_cal_sources: List[Tuple[str, np.ndarray, np.ndarray]] = []
    source_metrics: Dict[str, Any] = {}
    recall_ks = sorted({int(x) for x in parse_csv(args.retrieval_recall_ks) if int(x) > 0})
    semantic_k = max(int(args.semantic_candidates_per_profile), max(recall_ks), int(args.candidate_union_limit))

    if "semantic" in sources:
        for profile in profiles:
            profile_plan = base.apply_context_profile(plan, target, profile)
            fit_docs = base.make_docs(fit_df, profile_plan, target)
            cal_docs = base.make_docs(cal_df, profile_plan, target)
            retrieval_prototypes, _ = base.build_prototypes(fit_docs, labels_fit, target, args.retrieval_prototype_examples)
            codes = sorted(retrieval_prototypes)
            proto_key = common_key | {"split": "prototype", "profile": profile, "prototype_examples": args.retrieval_prototype_examples}
            proto_emb = encode_cached(embedder, [retrieval_prototypes[c] for c in codes], args.embedding_batch_size,
                                      cache_dir, proto_key, f"{target} {profile} prototype embeddings", args.progress_every)
            fit_key = common_key | {"split": "fit_query", "profile": profile}
            cal_key = common_key | {"split": "cal_query", "profile": profile}
            fit_emb = encode_cached(embedder, fit_docs, args.embedding_batch_size, cache_dir, fit_key,
                                    f"{target} {profile} FIT query embeddings", args.progress_every)
            cal_emb = encode_cached(embedder, cal_docs, args.embedding_batch_size, cache_dir, cal_key,
                                    f"{target} {profile} CAL query embeddings", args.progress_every)
            fit_codes, fit_scores = nearest_codes_scores(codes, proto_emb, fit_emb, semantic_k)
            cal_codes, cal_scores = nearest_codes_scores(codes, proto_emb, cal_emb, semantic_k)
            semantic_fit_sources.append((f"semantic:{profile}", fit_codes, fit_scores))
            semantic_cal_sources.append((f"semantic:{profile}", cal_codes, cal_scores))
            source_metrics[f"semantic:{profile}"] = source_recall(labels_cal, cal_codes.tolist(), recall_ks)
            del proto_emb, fit_emb, cal_emb
            gc.collect()

    lex = None
    if "lexical" in sources:
        lex = lexical_candidate_cache(
            rerank_fit_docs, rerank_cal_docs, labels_fit, target, args.lexical_candidates,
            cache_dir, common_key | {"rerank_profile": args.rerank_context_profile},
        )
        source_metrics["lexical"] = source_recall(labels_cal, lex["cal_codes"].tolist(), recall_ks)

    mem_fit_codes = mem_fit_scores = mem_cal_codes = mem_cal_scores = None
    if "memory" in sources:
        eprint(f"[{target} memory] Mining high-purity candidate rules...")
        rules = build_memory_rules(fit_df, labels_fit, target, min_count=3)
        mem_fit_codes, mem_fit_scores = memory_candidates_for_df(fit_df, rules, args.memory_candidates)
        mem_cal_codes, mem_cal_scores = memory_candidates_for_df(cal_df, rules, args.memory_candidates)
        source_metrics["memory"] = source_recall(labels_cal, mem_cal_codes, recall_ks)

    fit_union = merge_candidate_sources(
        len(fit_df), semantic_fit_sources,
        lex["fit_codes"] if lex is not None else None,
        lex["fit_scores"] if lex is not None else None,
        mem_fit_codes, mem_fit_scores, args.candidate_union_limit,
    )
    cal_union = merge_candidate_sources(
        len(cal_df), semantic_cal_sources,
        lex["cal_codes"] if lex is not None else None,
        lex["cal_scores"] if lex is not None else None,
        mem_cal_codes, mem_cal_scores, args.candidate_union_limit,
    )
    source_metrics["production_union"] = source_recall(labels_cal, cal_union, recall_ks)
    eprint(f"[{target}] Candidate-source recall:\n{json.dumps(source_metrics, indent=2)}")

    weak = [] if target == "qa20a" else base.parse_groups("15,17,25,51,55" if target == "qe4ar" else "15,17,45,51,53,55")
    anchor_idx = base.stratified_anchor_indices(
        labels_fit, args.max_anchors, args.seed, weak, kind,
        sampling_strategy=args.anchor_sampling, weak_group_multiplier=args.weak_group_multiplier,
    )
    eprint(f"[{target}] anchors={len(anchor_idx):,}; generating training rows from production candidate union...")
    if args.loss_type == "bce":
        rows = base.generate_pairs(
            rerank_fit_docs, labels_fit, anchor_idx, rerank_prototypes, fit_union, kind,
            args.hard_negatives, args.random_negatives, args.seed + 100,
            strategy=args.hard_negative_strategy,
        )
    else:
        rows = base.generate_listwise_rows(
            rerank_fit_docs, labels_fit, anchor_idx, rerank_prototypes, fit_union, kind,
            args.hard_negatives, args.random_negatives, args.seed + 100,
            strategy=args.hard_negative_strategy,
        )
    generated = base.validate_generated_training_rows(rows, args.loss_type, target)
    eprint(f"[{target}] training examples={generated:,} loss={args.loss_type}")
    label_key = "label" if args.loss_type == "bce" else "labels"
    rng = np.random.default_rng(args.seed)
    order = rng.permutation(len(rows[label_key]))
    rows = {k: [v[int(i)] for i in order] for k, v in rows.items()}
    train_dataset = Dataset.from_dict(rows)

    valid_cal_idx = [i for i, label in enumerate(labels_cal) if label in rerank_prototypes]
    if len(valid_cal_idx) > args.eval_rows:
        valid_cal_idx = np.random.default_rng(args.seed + 200).choice(valid_cal_idx, size=args.eval_rows, replace=False).tolist()
    eval_docs = [rerank_cal_docs[i] for i in valid_cal_idx]
    eval_labels = [labels_cal[i] for i in valid_cal_idx]
    eval_candidates = [cal_union[i] for i in valid_cal_idx]
    eval_tasks = [(target, kind, eval_docs, eval_labels, rerank_prototypes, eval_candidates)]

    try:
        model = CrossEncoder(args.base_model, device=args.device, num_labels=1, max_length=args.max_length)
    except TypeError:
        model = CrossEncoder(args.base_model, device=args.device, num_labels=1)
        try: model.max_length = int(args.max_length)
        except Exception: pass

    eprint("Evaluating base reranker on production candidate union...")
    base_oracle, base_oracle_ranks = base.evaluate_reranker(
        model, eval_tasks, args.eval_rows, args.eval_candidates, args.eval_batch_size,
        args.seed, progress_every=max(4096, args.progress_every), return_ranks=True, inject_truth=True,
    )
    base_ret, base_ret_ranks = base.evaluate_reranker(
        model, eval_tasks, args.eval_rows, args.eval_candidates, args.eval_batch_size,
        args.seed, progress_every=max(4096, args.progress_every), return_ranks=True, inject_truth=False,
    )

    neg_per_pos = max(1.0, float(args.hard_negatives + args.random_negatives))
    if args.loss_type == "bce":
        loss = ce_losses.BinaryCrossEntropyLoss(model=model, pos_weight=torch.tensor(neg_per_pos))
    else:
        cls = {"ranknet": getattr(ce_losses, "RankNetLoss", None),
               "listnet": getattr(ce_losses, "ListNetLoss", None),
               "lambda": getattr(ce_losses, "LambdaLoss", None)}[args.loss_type]
        if cls is None:
            raise RuntimeError(f"Installed sentence-transformers lacks {args.loss_type}")
        loss = cls(model=model, mini_batch_size=max(1, int(args.listwise_mini_batch_size)))

    checkpoint_dir = output / "checkpoints"
    warmup_steps = int(round(max(0, args.max_update_steps) * 0.10)) if args.max_update_steps > 0 else 0.10
    training_args = CrossEncoderTrainingArguments(
        output_dir=str(checkpoint_dir), num_train_epochs=float(args.epochs),
        max_steps=int(args.max_update_steps) if args.max_update_steps > 0 else -1,
        per_device_train_batch_size=int(args.train_batch_size),
        per_device_eval_batch_size=int(args.eval_batch_size),
        gradient_accumulation_steps=int(args.gradient_accumulation_steps),
        learning_rate=float(args.learning_rate), warmup_steps=warmup_steps,
        fp16=bool(torch.cuda.is_available()), bf16=False, dataloader_num_workers=0,
        save_strategy="steps", save_steps=max(25, args.max_update_steps // 4 if args.max_update_steps else 500),
        save_total_limit=max(1, int(args.checkpoint_keep)), logging_steps=50,
        logging_first_step=True, report_to="none", disable_tqdm=True,
        seed=int(args.seed), run_name=f"v3-{target}",
    )
    trainer = CrossEncoderTrainer(model=model, args=training_args, train_dataset=train_dataset,
                                  loss=loss, callbacks=[base.VisibleProgressCallback()])
    resume = None
    requested = str(args.resume_from_checkpoint or "").strip()
    if requested.lower() == "auto" and checkpoint_dir.exists():
        checkpoints = []
        for p in checkpoint_dir.glob("checkpoint-*"):
            try: checkpoints.append((int(p.name.rsplit("-", 1)[1]), p))
            except Exception: pass
        if checkpoints: resume = str(max(checkpoints)[1])
    elif requested:
        if not Path(requested).exists(): raise FileNotFoundError(requested)
        resume = requested
    eprint(f"Training target-specific reranker target={target} resume={resume or 'fresh'}")
    started = time.time(); trainer.train(resume_from_checkpoint=resume); train_seconds = time.time() - started

    final_dir = output / "final"
    output_model = None
    if args.artifact_policy in {"full", "final_only"}:
        model.save_pretrained(str(final_dir)); output_model = str(final_dir)
        eprint(f"Saved final model: {final_dir}")

    eprint("Evaluating tuned reranker on production candidate union...")
    tuned_oracle, tuned_oracle_ranks = base.evaluate_reranker(
        model, eval_tasks, args.eval_rows, args.eval_candidates, args.eval_batch_size,
        args.seed, progress_every=max(4096, args.progress_every), return_ranks=True, inject_truth=True,
    )
    tuned_ret, tuned_ret_ranks = base.evaluate_reranker(
        model, eval_tasks, args.eval_rows, args.eval_candidates, args.eval_batch_size,
        args.seed, progress_every=max(4096, args.progress_every), return_ranks=True, inject_truth=False,
    )
    paired = base.paired_rank_comparison(base_oracle_ranks, tuned_oracle_ranks, args.bootstrap_samples, args.seed + 991)
    paired_ret = base.paired_rank_comparison(base_ret_ranks, tuned_ret_ranks, args.bootstrap_samples, args.seed + 1991)

    candidate_key = {
        "profiles": profiles, "retrieval_prototype_examples": args.retrieval_prototype_examples,
        "sources": sorted(sources), "union_limit": args.candidate_union_limit,
        "semantic_per_profile": args.semantic_candidates_per_profile,
        "lexical_candidates": args.lexical_candidates,
    }
    reranker_key = {
        "loss": args.loss_type, "lr": args.learning_rate, "anchors": args.max_anchors,
        "steps": args.max_update_steps, "sampling": args.anchor_sampling,
        "weak_multiplier": args.weak_group_multiplier, "rerank_profile": args.rerank_context_profile,
        "rerank_prototypes": args.rerank_prototype_examples,
    }
    report = {
        "version": VERSION, "target": target, "kind": kind,
        "candidate_generator_key": candidate_key, "reranker_key": reranker_key,
        "candidate_source_metrics": source_metrics,
        "base_model": args.base_model, "embedding_model": args.embedding_model,
        "output_model": output_model, "artifact_policy": args.artifact_policy,
        "training_examples": len(train_dataset), "training_seconds": train_seconds,
        "base_metrics": base_oracle, "tuned_metrics": tuned_oracle,
        "paired_comparison": paired,
        "base_metrics_retrieval": base_ret, "tuned_metrics_retrieval": tuned_ret,
        "paired_comparison_retrieval": paired_ret,
        "settings": vars(args),
    }
    report_path = output / "targeted_interaction_report.json"
    report_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    eprint(f"Report: {report_path}")

    cleanup = {"policy": args.artifact_policy, "deleted": [], "bytes_freed": 0}
    def tree_bytes(p: Path) -> int:
        if not p.exists(): return 0
        if p.is_file(): return p.stat().st_size
        return sum(c.stat().st_size for c in p.rglob("*") if c.is_file())
    paths: List[Path] = []
    if args.artifact_policy in {"metrics_only", "final_only"}: paths.append(checkpoint_dir)
    if args.artifact_policy == "metrics_only": paths.append(final_dir)
    for p in paths:
        if p.exists():
            size = tree_bytes(p)
            if p.is_dir(): shutil.rmtree(p)
            else: p.unlink()
            cleanup["deleted"].append(str(p)); cleanup["bytes_freed"] += size
    report["artifact_cleanup"] = cleanup
    report_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    eprint(f"Artifact cleanup policy={args.artifact_policy} freed={cleanup['bytes_freed']/1024**3:.2f} GB")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        eprint("Interrupted by user."); raise SystemExit(130)
    except Exception:
        print("[FATAL] Targeted interaction trainer failed:", flush=True)
        traceback.print_exc(file=os.sys.stdout)
        raise SystemExit(1)
