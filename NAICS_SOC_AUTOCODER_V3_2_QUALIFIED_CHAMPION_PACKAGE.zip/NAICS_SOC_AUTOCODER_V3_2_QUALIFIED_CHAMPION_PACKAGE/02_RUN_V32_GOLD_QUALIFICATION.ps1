param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [string]$DateCol = "auto",
  [string]$LocationCols = "qe2b",
  [string]$NumericCols = "qe10",
  [string]$VerifiedCol = "",
  [string]$RunLabel = "qualified_v32",
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V32.ps1') -Base $Base -RequireRerankers

$ManifestPath = Join-Path $Base 'models\v32_production_rerankers\production_reranker_manifest.json'
$Manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
$NaicsCE = [string]$Manifest.targets.qa20a.model_path
$Qe4CE = [string]$Manifest.targets.qe4ar.model_path
$Qe5CE = [string]$Manifest.targets.qe5ar.model_path
$NaicsCfg = $Manifest.targets.qa20a.winner.experiment_config
$Qe4Cfg = $Manifest.targets.qe4ar.winner.experiment_config
$Qe5Cfg = $Manifest.targets.qe5ar.winner.experiment_config

$semanticPerProfile = [Math]::Max([int]$NaicsCfg.semantic_per_profile, [Math]::Max([int]$Qe4Cfg.semantic_per_profile, [int]$Qe5Cfg.semantic_per_profile))
$lexicalCandidates = [Math]::Max([int]$NaicsCfg.lexical_candidates, [Math]::Max([int]$Qe4Cfg.lexical_candidates, [int]$Qe5Cfg.lexical_candidates))
$unionLimit = [Math]::Max([int]$NaicsCfg.union_limit, [Math]::Max([int]$Qe4Cfg.union_limit, [int]$Qe5Cfg.union_limit))

$Python = Join-Path $Base '.venv\Scripts\python.exe'
$Script = Join-Path $Base 'naics_soc_adaptive_memory_reranker_v3_2.py'
$Fit = Join-Path $Base 'training_FIT.sav'
$Cal = Join-Path $Base 'training_CALIBRATION.sav'
$Gold = Join-Path $Base 'training_EVALUATION_GOLD.sav'
$ModelOut = Join-Path $Base 'models\naics_soc_QUALIFIED_V32.joblib'
$OutSav = Join-Path $Base 'output\GOLD_scored_QUALIFIED_V32.sav'
$PredLog = Join-Path $Base 'logs\QUALIFIED_V32_predictions.txt'
$ConsoleLog = Join-Path $Base 'logs\console_QUALIFIED_V32_live.log'
$AnalysisDir = Join-Path $Base 'model_audits'
$RuleDir = Join-Path $Base 'adaptive_memory_rules_v32'
foreach ($d in @((Split-Path $ModelOut),(Split-Path $OutSav),(Split-Path $PredLog),$AnalysisDir,$RuleDir)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }

$env:PYTHONUTF8='1'; $env:PYTHONIOENCODING='utf-8'; $env:HF_HOME=Join-Path $Base 'hf_cache'; $env:HF_HUB_CACHE=Join-Path $Base 'hf_cache\hub'
$env:HF_HUB_OFFLINE='1'; $env:TRANSFORMERS_OFFLINE='1'; $env:HF_HUB_DISABLE_PROGRESS_BARS='1'; $env:CUDA_VISIBLE_DEVICES='0'; $env:TOKENIZERS_PARALLELISM='false'
$env:OMP_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'; $env:NUMEXPR_NUM_THREADS='1'

$cli = [System.Collections.Generic.List[string]]::new()
function A([string]$n,[object]$v,[switch]$OmitBlank) { if ($OmitBlank -and [string]::IsNullOrWhiteSpace([string]$v)) { return }; $cli.Add($n); if ($null -ne $v) { $cli.Add([string]$v) } }
function S([string]$n) { $cli.Add($n) }
$cli.Add('-u'); $cli.Add($Script)
A '--mode' 'train_and_score'; A '--train_sav' $Fit; A '--calibration_sav' $Cal; A '--score_sav' $Gold; A '--evaluation_sav' $Gold
A '--out_sav' $OutSav; A '--log_txt' $PredLog; A '--model_out' $ModelOut; S '--save_model'
A '--profile' 'accuracy'; A '--model_search' 'robust'; A '--candidate_models' 'sgd,linear_svc,complement_nb'
S '--use_embeddings'; S '--use_semantic_memory'; A '--semantic_backend' 'faiss'; A '--embedding_model' 'BAAI/bge-large-en-v1.5'; A '--embedding_backend' 'torch'; A '--embedding_device' 'cuda'; A '--embedding_batch_size' '16'; A '--embedding_chunk_size' '2048'; A '--embedding_progress_every' '2048'; A '--embedding_cache_dir' (Join-Path $Base 'embedding_cache')
A '--semantic_query_profiles_naics' ([string]$NaicsCfg.retrieval_profiles); A '--semantic_query_profiles_qe4' ([string]$Qe4Cfg.retrieval_profiles); A '--semantic_query_profiles_qe5' ([string]$Qe5Cfg.retrieval_profiles)
S '--use_code_prototype_retrieval'; A '--code_prototype_examples_naics' ([int]$NaicsCfg.retrieval_prototypes); A '--code_prototype_examples_qe4' ([int]$Qe4Cfg.retrieval_prototypes); A '--code_prototype_examples_qe5' ([int]$Qe5Cfg.retrieval_prototypes); A '--code_prototype_candidates_per_profile' $semanticPerProfile; S '--code_prototype_include_raw_memory'
S '--use_fuzzy_dictionary'; S '--use_adaptive_memory'; A '--memory_date_col' $DateCol -OmitBlank; A '--memory_location_cols' $LocationCols -OmitBlank; A '--memory_numeric_cols' $NumericCols -OmitBlank; A '--memory_verified_col' $VerifiedCol -OmitBlank; A '--memory_export_dir' $RuleDir
S '--use_cross_encoder_reranker'; S '--cross_encoder_union_candidates'; A '--cross_encoder_model_naics' $NaicsCE; A '--cross_encoder_model_qe4' $Qe4CE; A '--cross_encoder_model_qe5' $Qe5CE; A '--cross_encoder_model' 'cross-encoder/ms-marco-MiniLM-L6-v2'; A '--cross_encoder_topn' $unionLimit; A '--cross_encoder_candidate_pool' $unionLimit; A '--ml_candidate_pool' $lexicalCandidates; A '--cross_encoder_prototype_examples' '3'; A '--cross_encoder_prototype_examples_naics' ([int]$NaicsCfg.rerank_prototypes); A '--cross_encoder_prototype_examples_qe4' ([int]$Qe4Cfg.rerank_prototypes); A '--cross_encoder_prototype_examples_qe5' ([int]$Qe5Cfg.rerank_prototypes); A '--cross_encoder_batch_size' '32'; A '--cross_encoder_fusion_weight' '0.45'
S '--use_probability_calibration'; A '--calibration_method' 'auto'; S '--use_source_confidence_calibration'; A '--source_calibration_method' 'auto'; S '--use_candidate_meta_ranker'; A '--candidate_meta_ranker_min_rows' '250'; A '--calibration_fit_fraction' '0.60'; A '--conformal_alphas' '0.05,0.10,0.20'; A '--conformal_candidate_pool' $unionLimit
S '--overwrite_existing'; S '--fill_all_missing'; S '--score_rows_without_text'; S '--fallback_fill_missing'; A '--topk_naics' '4'; A '--topk_soc' '4'; A '--top_groups' '5'; A '--memory_candidate_pool' $unionLimit
A '--max_workers' '6'; A '--native_threads' '1'; A '--score_batch_size' '500'; A '--ensemble_size' '1'; A '--nfolds_naics' '3'; A '--nfolds_major' '3'; A '--nfolds_within' '2'; A '--optuna_trials_naics' '0'; A '--optuna_trials_major' '0'; A '--optuna_trials_within' '0'; A '--joblib_compress' '0'
A '--console_log' $ConsoleLog; A '--analysis_dir' $AnalysisDir; A '--analysis_run_label' $RunLabel; S '--analysis_include_row_details'; A '--analysis_min_class_support' '10'; A '--analysis_confidence_bins' '15'; A '--analysis_top_confusions' '200'

Write-Host 'Launching V3.2 winner-fidelity sealed-Gold qualification...' -ForegroundColor Cyan
Write-Host "Confirmed candidate depths: semantic/profile=$semanticPerProfile lexical=$lexicalCandidates union=$unionLimit"
Write-Host "NAICS profiles=$($NaicsCfg.retrieval_profiles) prototypes=$($NaicsCfg.retrieval_prototypes)"
Write-Host "qe4ar profiles=$($Qe4Cfg.retrieval_profiles) prototypes=$($Qe4Cfg.retrieval_prototypes)"
Write-Host "qe5ar profiles=$($Qe5Cfg.retrieval_profiles) prototypes=$($Qe5Cfg.retrieval_prototypes)"
Write-Host "Live log: $ConsoleLog"
($cli.ToArray() -join ' ') | Set-Content -Path (Join-Path $Base 'resolved_V32_GOLD_command.txt') -Encoding UTF8
if ($DryRun) { Write-Host 'Dry run only; Python was not launched.' -ForegroundColor Yellow; return }
& $Python $cli.ToArray()
if ($LASTEXITCODE -ne 0) { throw "V3.2 qualification exited with code $LASTEXITCODE" }
Write-Host 'V3.2 Gold qualification completed.' -ForegroundColor Green
Write-Host "Next: .\03_EVALUATE_V32_PROMOTION.ps1 -RunLabel $RunLabel"
