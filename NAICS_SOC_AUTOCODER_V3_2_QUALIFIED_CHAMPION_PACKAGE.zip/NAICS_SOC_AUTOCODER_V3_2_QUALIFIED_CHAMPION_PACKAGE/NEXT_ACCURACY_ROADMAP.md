# V3.2 accuracy roadmap

V3.2 is a qualification and winner-fidelity release. It fixes an important mismatch between the confirmed experiment recipe and the previous integrated Gold launcher:

- confirmed semantic candidates per profile: **50**;
- confirmed sparse/lexical candidates: **30**;
- confirmed union cap: **60**;
- previous integrated launcher used a 40-code union and did not separately cap the sparse candidate source.

The sealed-Gold run is therefore the next required experiment. Do not choose another architecture before this result exists.

## If V3.2 is promoted

1. Build the deployment bundle.
2. Run it prospectively on the next survey wave.
3. Route low-confidence or multi-code conformal rows to the review queue.
4. Append reviewed corrections to the next training cycle.
5. Freeze the current Gold file. Future tuning should use FIT/CALIBRATION or a new temporal holdout.

## If V3.2 is held

Use the generated `PROMOTION_DECISION.md` and pursue only the diagnosed bottleneck.

### Candidate recall below 95% at top 20

- Train a target-specific bi-encoder retriever on historical context-to-code pairs.
- Learn profile/source weights rather than using equal reciprocal-rank fusion.
- Expand employer alias resolution and self-employment description normalization.
- Train weak-group retrieval specialists for SOC groups with persistent low recall.

### Candidate recall high but top-1 lags top-4

- Test a stronger 150M-class reranker as a calibration-only challenger.
- Test a two-model score ensemble or model soup, then distill it back to one compact reranker.
- Add source/profile features to the candidate meta-ranker.
- Mine confusion-specific hard negatives from CALIBRATION, never from Gold.

### Calibration remains weak

- Use a larger fresh calibration partition.
- Fit source-conditional calibrators separately for adaptive memory, dictionary, and model/reranker rows.
- Choose human-review thresholds from the risk-coverage curve rather than a fixed confidence number.

### Weak SOC groups dominate error

- Train group-specific rerankers only for the weak major groups.
- Review and adjudicate historical labels for those groups.
- Add richer official code descriptions and hard negatives within the same major group.

## Deployment target

The realistic production objective is not zero oversight. It is:

- highest-confidence repeated cases coded automatically;
- ambiguous records supplied with ranked alternatives and provenance;
- reviewed corrections recycled into adaptive memory and the next FIT partition.
