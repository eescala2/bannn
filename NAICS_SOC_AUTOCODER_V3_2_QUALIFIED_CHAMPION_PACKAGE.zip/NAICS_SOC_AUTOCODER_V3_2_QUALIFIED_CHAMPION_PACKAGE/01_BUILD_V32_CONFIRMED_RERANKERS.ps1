param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [int]$Seed = 777,
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V32.ps1') -Base $Base
$Python = Join-Path $Base '.venv\Scripts\python.exe'
$Winner = Join-Path $Base 'CONFIRMED_V31_WINNERS.json'
$argsList = @('-u',(Join-Path $Base 'train_v32_final_rerankers.py'),'--base',$Base,'--winner_manifest',$Winner,'--seed',[string]$Seed)
if ($DryRun) { $argsList += '--dry_run' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3.2 reranker build failed." }
