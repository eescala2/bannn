# NAICS/SOC Autocoder V3.2: qualified champion package

## Why this package exists

The confirmed V3.1 reranker recipes are strong and stable across five seeds. The next job is not another broad battery. It is to reproduce those winners exactly inside the complete NAICS-first/SOC cascade, evaluate the untouched Gold file, and deploy only if the integrated model clears explicit promotion gates.

V3.2 corrects one fidelity gap in the prior integrated launcher. The confirmed winners used 50 semantic candidates per context profile, 30 sparse/lexical candidates, and a 60-code candidate union. The previous final Gold launcher used a 40-code union and did not cap the sparse candidate source separately.

## Preserve these files

- `training_FIT.sav`
- `training_CALIBRATION.sav`
- `training_EVALUATION_GOLD.sav`
- `.venv`
- `hf_cache`
- `embedding_cache`
- the three confirmed target rerankers, when already built

Do not retrain on Gold.

## Install

Extract the flat patch over:

```text
C:\laborshed_autocode_clean
```

Then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd C:\laborshed_autocode_clean
.\00_VALIDATE_V32_CODE.ps1
.\00_PREFLIGHT_V32.ps1
```

## Prepare the three target rerankers

When the existing V3.1 production rerankers are still present:

```powershell
.\01A_ADOPT_EXISTING_V31_RERANKERS.ps1
```

When they were deleted:

```powershell
.\01_BUILD_V32_CONFIRMED_RERANKERS.ps1
```

The confirmed recipe is included in `CONFIRMED_V31_WINNERS.json`.

## Run sealed-Gold qualification

```powershell
.\02_RUN_V32_GOLD_QUALIFICATION.ps1 `
  -DateCol "auto" `
  -LocationCols "qe2b" `
  -NumericCols "qe10" `
  -RunLabel "qualified_v32"
```

Monitor:

```powershell
.\08_V32_STATUS.ps1
Get-Content .\logs\console_QUALIFIED_V32_live.log -Tail 120 -Wait
nvidia-smi -l 10
```

## Evaluate promotion

```powershell
.\03_EVALUATE_V32_PROMOTION.ps1 -RunLabel "qualified_v32"
```

Open:

```text
v32_qualification\PROMOTION_DECISION.md
```

The strict promotion gate compares the same sealed Gold set with the audited baseline:

| Target | Top-1 | Top-4 | Macro-F1 | ECE |
|---|---:|---:|---:|---:|
| qa20a | 0.8480 | 0.9507 | 0.6410 | 0.1087 |
| qe4ar | 0.6678 | 0.8354 | 0.4031 | 0.0612 |
| qe5ar | 0.6987 | 0.8341 | 0.4021 | 0.0562 |

## Build deployment only after promotion

```powershell
.\05_BUILD_V32_DEPLOYMENT.ps1
```

The deployment ZIP is written to:

```text
NAICS_SOC_AUTOCODER_V32_DEPLOYMENT.zip
```

## Score a new SAV

```powershell
.\04_SCORE_V32_NEW_DATA.ps1 `
  -ScoreSav "C:\path\to\new_wave.sav"
```

Outputs include:

- a separate scored SAV;
- live and row-level logs;
- a review-queue CSV for low-confidence, fallback, or multi-code conformal cases.

## One-command qualification

```powershell
.\07_RUN_V32_QUALIFICATION_PIPELINE.ps1 `
  -RunLabel "qualified_v32" `
  -BuildDeployment
```

The deployment step runs only when the promotion decision is `PROMOTE`.

## What comes after V3.2

Read `NEXT_ACCURACY_ROADMAP.md`. Further work should be chosen from the actual Gold diagnosis, not from generic model novelty.
