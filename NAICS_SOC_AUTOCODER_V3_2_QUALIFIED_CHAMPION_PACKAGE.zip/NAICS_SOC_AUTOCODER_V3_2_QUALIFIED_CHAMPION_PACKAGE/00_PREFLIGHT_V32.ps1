param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [switch]$RequireRerankers,
  [switch]$ScoreOnly
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Missing virtual environment Python: $Python" }
$argsList = @('-u',(Join-Path $Base 'v32_preflight.py'),'--base',$Base)
if ($RequireRerankers) { $argsList += '--require_rerankers' }
if ($ScoreOnly) { $argsList += '--score_only' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3.2 preflight failed. Open v32_preflight_report.json." }
