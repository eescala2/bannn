#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, re
from pathlib import Path
from typing import Dict, List

ROW_RE = re.compile(r"^id=(?P<id>.*?) \| (?P<body>.*)$")
SEGMENT_RE = re.compile(
    r"(?P<target>qa20a|qe4ar|qe5ar): (?P<before>.*?) -> (?P<after>.*?) "
    r"\(model_top=(?P<top>.*?) conf=(?P<conf>[0-9.]+)% applied=(?P<applied>YES|NO) "
    r"source=(?P<source>\S+) rule=(?P<rule>.*?) prefix=(?P<prefix>\S+) aps90_set=(?P<aps>\d+)\) "
    r"\[alts: (?P<alts>.*?)\](?: \||$)"
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--log_txt", required=True)
    ap.add_argument("--out_csv", required=True)
    ap.add_argument("--naics_threshold", type=float, default=0.85)
    ap.add_argument("--soc_threshold", type=float, default=0.80)
    ap.add_argument("--include_all_model_rows", action="store_true")
    args = ap.parse_args()
    rows: List[Dict[str, str]] = []
    for line in Path(args.log_txt).read_text(encoding="utf-8", errors="replace").splitlines():
        m = ROW_RE.match(line)
        if not m:
            continue
        rid = m.group("id")
        for sm in SEGMENT_RE.finditer(m.group("body")):
            d = sm.groupdict()
            conf = float(d["conf"]) / 100.0
            aps = int(d["aps"])
            threshold = args.naics_threshold if d["target"] == "qa20a" else args.soc_threshold
            source = d["source"]
            needs_review = conf < threshold or aps > 1 or source in {"fallback", "global_baseline"}
            if args.include_all_model_rows and source == "model":
                needs_review = True
            if not needs_review:
                continue
            reason = []
            if conf < threshold: reason.append(f"confidence<{threshold:.2f}")
            if aps > 1: reason.append(f"aps90_set={aps}")
            if source in {"fallback", "global_baseline"}: reason.append(source)
            rows.append({
                "id": rid,
                "target": d["target"],
                "before": d["before"],
                "predicted": d["after"],
                "model_top": d["top"],
                "confidence": f"{conf:.6f}",
                "source": source,
                "rule": d["rule"],
                "prefix": d["prefix"],
                "aps90_set_size": str(aps),
                "alternatives": d["alts"],
                "review_reason": ";".join(reason),
            })
    out = Path(args.out_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id","target","before","predicted","model_top","confidence","source","rule","prefix","aps90_set_size","alternatives","review_reason"]
    with out.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    print(f"Review queue rows: {len(rows):,}")
    print(f"Saved: {out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
