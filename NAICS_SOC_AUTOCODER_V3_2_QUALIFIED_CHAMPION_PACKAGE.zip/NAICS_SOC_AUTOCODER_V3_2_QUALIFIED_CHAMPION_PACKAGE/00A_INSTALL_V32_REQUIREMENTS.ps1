param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [switch]$InstallCudaTorch
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$VenvPython = Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
  Write-Host "Creating virtual environment in $Base\.venv ..." -ForegroundColor Cyan
  $Launcher = Get-Command py -ErrorAction SilentlyContinue
  if ($Launcher) { & py -3.14 -m venv (Join-Path $Base '.venv') }
  else { & python -m venv (Join-Path $Base '.venv') }
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path $VenvPython)) { throw "Could not create .venv" }
}
& $VenvPython -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw "pip bootstrap failed" }
if ($InstallCudaTorch) {
  Write-Host "Installing CUDA 12.6 PyTorch wheels..." -ForegroundColor Cyan
  & $VenvPython -m pip install --upgrade torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126
  if ($LASTEXITCODE -ne 0) { throw "CUDA PyTorch installation failed" }
}
& $VenvPython -m pip install --upgrade -r (Join-Path $Base 'requirements_v32.txt')
if ($LASTEXITCODE -ne 0) { throw "V3.2 requirements installation failed" }
& $VenvPython -c "import torch; print('torch',torch.__version__); print('cuda',torch.cuda.is_available()); print('device',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO CUDA')"
if ($LASTEXITCODE -ne 0) { throw "PyTorch verification failed" }
Write-Host "V3.2 package requirements installed. Run 00B_CACHE_V32_BASE_MODELS.ps1 while online if the base models are not already cached, then 00_PREFLIGHT_V32.ps1." -ForegroundColor Green
