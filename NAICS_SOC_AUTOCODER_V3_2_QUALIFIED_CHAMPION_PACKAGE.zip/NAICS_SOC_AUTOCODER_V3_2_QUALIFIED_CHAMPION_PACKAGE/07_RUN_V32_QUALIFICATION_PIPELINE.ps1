param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [string]$DateCol = "auto",
  [string]$LocationCols = "qe2b",
  [string]$NumericCols = "qe10",
  [string]$VerifiedCol = "",
  [string]$RunLabel = "qualified_v32",
  [switch]$RebuildRerankers,
  [switch]$BuildDeployment
)
$ErrorActionPreference = "Stop"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V32.ps1') -Base $Base
$V32Manifest = Join-Path $Base 'models\v32_production_rerankers\production_reranker_manifest.json'
if (-not (Test-Path $V32Manifest)) {
  $V31Manifest = Join-Path $Base 'models\v3_production_rerankers\production_reranker_manifest.json'
  if ((Test-Path $V31Manifest) -and -not $RebuildRerankers) {
    & (Join-Path $Base '01A_ADOPT_EXISTING_V31_RERANKERS.ps1') -Base $Base
  } else {
    & (Join-Path $Base '01_BUILD_V32_CONFIRMED_RERANKERS.ps1') -Base $Base
  }
}
& (Join-Path $Base '02_RUN_V32_GOLD_QUALIFICATION.ps1') -Base $Base -DateCol $DateCol -LocationCols $LocationCols -NumericCols $NumericCols -VerifiedCol $VerifiedCol -RunLabel $RunLabel
& (Join-Path $Base '03_EVALUATE_V32_PROMOTION.ps1') -Base $Base -RunLabel $RunLabel
if ($BuildDeployment) {
  $decision = Get-Content (Join-Path $Base 'v32_qualification\PROMOTION_DECISION.json') -Raw | ConvertFrom-Json
  if ($decision.decision -eq 'PROMOTE') {
    & (Join-Path $Base '05_BUILD_V32_DEPLOYMENT.ps1') -Base $Base
  } else {
    Write-Warning "Deployment not built because decision=$($decision.decision)."
  }
}
