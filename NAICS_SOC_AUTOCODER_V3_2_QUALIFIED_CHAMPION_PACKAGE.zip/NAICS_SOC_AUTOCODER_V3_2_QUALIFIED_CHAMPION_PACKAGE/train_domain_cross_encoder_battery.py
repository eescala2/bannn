#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fine-tune a local Cross-Encoder reranker for NAICS and SOC coding.

The audited baseline showed a large top-1 to top-4 gap, while exact historical
memory was already highly accurate. This script targets the remaining ranking
problem: it teaches a compact Cross-Encoder to choose the correct code from
plausible candidates using historical survey context.

Data discipline:
* FIT SAV supplies prototypes and training pairs.
* CALIBRATION SAV supplies development/evaluation pairs.
* GOLD SAV is never read by this script.

Training uses a blend of semantic hard negatives, same-hierarchy negatives,
and random negatives. That combination is deliberate: hard negatives teach
fine distinctions, while random negatives preserve easy-case discrimination.
"""
from __future__ import annotations

import argparse
import gc
import json
import math
import os
import random
import re
import shutil
import sys
import time
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import pyreadstat
import torch
from scipy.stats import binomtest

try:
    import faiss
except Exception:
    faiss = None

from datasets import Dataset
from sentence_transformers import CrossEncoder, SentenceTransformer
from sentence_transformers.cross_encoder import CrossEncoderTrainer, CrossEncoderTrainingArguments
from sentence_transformers.cross_encoder import losses as ce_losses
from transformers import TrainerCallback

VERSION = "2026.07.15.domain-cross-encoder-experiment-battery-v4.2-disk-efficient"


class VisibleProgressCallback(TrainerCallback):
    """Print step/epoch/loss/ETA so long GPU training never looks frozen."""
    def __init__(self) -> None:
        self.started = 0.0

    def on_train_begin(self, args, state, control, **kwargs):
        self.started = time.time()
        print(f"[RERANKER TRAIN] START max_steps={state.max_steps} epochs={args.num_train_epochs}", flush=True)

    def on_log(self, args, state, control, logs=None, **kwargs):
        logs = logs or {}
        elapsed = max(1e-9, time.time() - self.started)
        step = max(0, int(state.global_step))
        total = max(1, int(state.max_steps))
        rate = step / elapsed if step else 0.0
        eta = (total - step) / rate if rate > 0 else float("nan")
        useful = {k: v for k, v in logs.items() if k in {"loss", "learning_rate", "epoch", "grad_norm", "eval_loss"}}
        print(f"[RERANKER TRAIN] step={step}/{total} elapsed={elapsed/60:.1f}m eta={eta/60:.1f}m metrics={useful}", flush=True)

    def on_train_end(self, args, state, control, **kwargs):
        print(f"[RERANKER TRAIN] DONE steps={state.global_step} elapsed={(time.time()-self.started)/60:.1f}m", flush=True)

ABBREV = [
    (r"\basst\b", "assistant"), (r"\bmgr\b", "manager"),
    (r"\bsvcs\b", "services"), (r"\bsvc\b", "service"),
    (r"\btech\b", "technician"), (r"\badmin\b", "administrative"),
    (r"\bsupv\b", "supervisor"), (r"\bmaint\b", "maintenance"),
    (r"\brn\b", "registered nurse"), (r"\blpn\b", "licensed practical nurse"),
    (r"\bcna\b", "certified nursing assistant"),
]


def eprint(message: str) -> None:
    print(message, flush=True)


def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = str(value).lower().strip().replace("&", " and ")
    s = re.sub(r"[^a-z0-9+#/\-\s]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    for pattern, repl in ABBREV:
        s = re.sub(pattern, repl, s)
    return re.sub(r"\s+", " ", s).strip()


def clean_code(value: Any, kind: str) -> Optional[str]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    try:
        number = int(round(float(value)))
        if kind == "soc":
            return f"{number:06d}" if 100000 <= number <= 999999 else None
        return str(number) if number > 0 else None
    except Exception:
        s = str(value).strip()
        return s or None


def make_docs(df: pd.DataFrame, columns: Sequence[Tuple[str, str]], target_tag: str) -> List[str]:
    docs: List[str] = []
    available = [(col, prefix) for col, prefix in columns if col in df.columns]
    for _, row in df.iterrows():
        parts = [f"TASK:{target_tag}"]
        for col, prefix in available:
            text = normalize_text(row.get(col))
            if text:
                parts.append(f"{prefix}:{text}")
        docs.append(" | ".join(parts) if len(parts) > 1 else f"TASK:{target_tag} | __EMPTY__")
    return docs


def field_plans() -> Dict[str, List[Tuple[str, str]]]:
    common = [
        ("qa20", "EMPLOYER"), ("qe1oth", "INDUSTRY_OTHER"),
        ("qe8aoth", "SELFEMP_OTHER"), ("qe2b", "LOCATION"),
        ("qa9a", "ED_FIELD"), ("qa9c1", "CERT"), ("qa9c2", "CERT"),
        ("qa9c3", "CERT"), ("qa9c4", "CERT"), ("qa9g", "LICENSE"),
        ("qe13oth", "PAYTYPE_OTHER"),
    ]
    return {
        "qa20a": [("qa20", "EMPLOYER"), ("qe4", "CURRENT_TITLE"), ("qe5a", "UNUSED_TITLE"),
                  ("qe1oth", "INDUSTRY_OTHER"), ("qe8aoth", "SELFEMP_OTHER"),
                  ("qe2b", "LOCATION"), ("qe1", "INDUSTRY_CATEGORY"),
                  ("qe8a", "SELFEMP_CATEGORY")],
        "qe4ar": [("qe4", "CURRENT_TITLE"), ("qa20a", "NAICS")] + common,
        "qe5ar": [("qe5a", "UNUSED_TITLE"), ("qa20a", "NAICS")] + common,
    }



def apply_context_profile(
    plan: Sequence[Tuple[str, str]],
    target: str,
    profile: str,
) -> List[Tuple[str, str]]:
    """Return a deterministic context-field ablation for experiment batteries."""
    profile = str(profile or "full").strip().lower()
    values = list(plan)
    if profile == "full":
        return values
    title_col = "qe4" if target in {"qa20a", "qe4ar"} else "qe5a"
    if profile == "title_only":
        return [(c, p) for c, p in values if c == title_col]
    if profile == "compact":
        keep = {title_col, "qa20", "qa20a", "qe1oth", "qe8aoth"}
        return [(c, p) for c, p in values if c in keep]
    if profile == "no_employer":
        return [(c, p) for c, p in values if c != "qa20"]
    if profile == "no_location":
        return [(c, p) for c, p in values if c != "qe2b"]
    if profile == "no_naics":
        return [(c, p) for c, p in values if c != "qa20a"]
    if profile == "no_other_text":
        drop = {"qe1oth", "qe8aoth", "qa9a", "qa9c1", "qa9c2", "qa9c3", "qa9c4", "qa9g", "qe13oth"}
        return [(c, p) for c, p in values if c not in drop]
    raise ValueError(f"Unknown --context_profile={profile!r}")


def hierarchy_prefix(code: str, kind: str) -> str:
    if kind == "soc":
        return code[:2]
    return code[:3] if len(code) >= 3 else code[:2]


def build_prototypes(
    docs: Sequence[str],
    labels: Sequence[Optional[str]],
    target: str,
    examples_per_code: int,
) -> Tuple[Dict[str, str], Counter]:
    groups: Dict[str, List[str]] = defaultdict(list)
    for doc, label in zip(docs, labels):
        if label is not None and "__EMPTY__" not in doc:
            groups[label].append(doc)
    prototypes: Dict[str, str] = {}
    counts = Counter({code: len(rows) for code, rows in groups.items()})
    for code, rows in groups.items():
        # Prefer diverse lengths and avoid duplicate normalized documents.
        unique = list(dict.fromkeys(rows))
        unique.sort(key=len)
        if len(unique) <= examples_per_code:
            chosen = unique
        else:
            positions = np.linspace(0, len(unique) - 1, examples_per_code).round().astype(int)
            chosen = [unique[int(pos)] for pos in positions]
        prototypes[code] = (
            f"TARGET:{target} | CODE:{code} | SUPPORT:{len(rows)} | "
            f"REPRESENTATIVE HISTORICAL CONTEXT: " + " || ".join(chosen)
        )
    return prototypes, counts


def stratified_anchor_indices(
    labels: Sequence[Optional[str]],
    max_anchors: int,
    seed: int,
    weak_groups: Sequence[str],
    kind: str,
    sampling_strategy: str = "balanced",
    weak_group_multiplier: int = 2,
) -> np.ndarray:
    """Select anchors using balanced or frequency-proportional sampling.

    Balanced sampling gives rare classes at least one opportunity whenever the
    budget permits. Weak hierarchy groups can receive extra passes. Frequency
    sampling approximates the production class distribution and is useful as
    an ablation, but it may omit rare detailed SOC codes.
    """
    rng = np.random.default_rng(seed)
    groups: Dict[str, List[int]] = defaultdict(list)
    for i, label in enumerate(labels):
        if label is not None:
            groups[str(label)].append(i)
    if not groups or max_anchors <= 0:
        return np.asarray([], dtype=int)

    strategy = str(sampling_strategy or "balanced").strip().lower()
    weak = {str(x) for x in weak_groups}
    multiplier = max(1, int(weak_group_multiplier))

    if strategy == "frequency":
        valid = np.asarray([i for i, label in enumerate(labels) if label is not None], dtype=int)
        if len(valid) <= max_anchors:
            rng.shuffle(valid)
            return valid
        weights = np.ones(len(valid), dtype=float)
        if weak and multiplier > 1:
            for pos, idx in enumerate(valid):
                label = str(labels[int(idx)])
                if hierarchy_prefix(label, kind) in weak:
                    weights[pos] *= float(multiplier)
        weights /= weights.sum()
        return rng.choice(valid, size=max_anchors, replace=False, p=weights)
    if strategy != "balanced":
        raise ValueError(f"Unknown anchor sampling strategy: {sampling_strategy!r}")

    for code in groups:
        arr = np.asarray(groups[code], dtype=int)
        rng.shuffle(arr)
        groups[code] = arr.tolist()

    tie = {code: float(rng.random()) for code in groups}
    ordered_codes = sorted(
        groups,
        key=lambda code: (
            0 if hierarchy_prefix(code, kind) in weak else 1,
            len(groups[code]),
            tie[code],
        ),
    )

    selected: List[int] = []
    cursors = {code: 0 for code in ordered_codes}
    for code in ordered_codes:
        if len(selected) >= max_anchors:
            break
        selected.append(groups[code][0])
        cursors[code] = 1

    while len(selected) < max_anchors:
        added = 0
        round_codes: List[str] = []
        for code in ordered_codes:
            repeats = multiplier if hierarchy_prefix(code, kind) in weak else 1
            round_codes.extend([code] * repeats)
        rng.shuffle(round_codes)
        for code in round_codes:
            if len(selected) >= max_anchors:
                break
            cursor = cursors[code]
            if cursor < len(groups[code]):
                selected.append(groups[code][cursor])
                cursors[code] = cursor + 1
                added += 1
        if added == 0:
            break
    rng.shuffle(selected)
    return np.asarray(selected[:max_anchors], dtype=int)


def _gpu_memory_text() -> str:
    if not torch.cuda.is_available():
        return ""
    try:
        allocated = torch.cuda.memory_allocated() / (1024 ** 3)
        reserved = torch.cuda.memory_reserved() / (1024 ** 3)
        return f" gpu_alloc={allocated:.2f}GB gpu_reserved={reserved:.2f}GB"
    except Exception:
        return ""


def encode(
    model: SentenceTransformer,
    texts: Sequence[str],
    batch_size: int,
    label: str = "embeddings",
    progress_every: int = 1024,
) -> np.ndarray:
    """Encode in chunks and report progress on stdout.

    Sentence Transformers' tqdm progress bars are written to stderr. Windows
    PowerShell 5.1 can convert informational stderr into NativeCommandError when
    ErrorActionPreference is Stop. Explicit stdout progress avoids that trap and
    provides stable, durable progress messages for Positron logs.
    """
    values = list(texts)
    total = len(values)
    if total == 0:
        try:
            dim = int(model.get_sentence_embedding_dimension() or 0)
        except Exception:
            dim = 0
        return np.zeros((0, dim), dtype=np.float32)
    chunk_size = max(int(batch_size), min(max(int(progress_every), 256), 2048))
    started = time.time()
    pieces: List[np.ndarray] = []
    eprint(f"[{label}] START texts={total:,} batch_size={batch_size} chunk_size={chunk_size}")
    for start in range(0, total, chunk_size):
        end = min(total, start + chunk_size)
        arr = model.encode(
            values[start:end],
            batch_size=int(batch_size),
            show_progress_bar=False,
            normalize_embeddings=True,
            convert_to_numpy=True,
        ).astype(np.float32, copy=False)
        pieces.append(arr)
        elapsed = max(1e-9, time.time() - started)
        rate = end / elapsed
        eta = (total - end) / rate if rate > 0 else float("nan")
        eprint(
            f"[{label}] {end:,}/{total:,} ({100.0*end/total:.1f}%) "
            f"rate={rate:.1f} texts/s elapsed={elapsed/60:.1f}m eta={eta/60:.1f}m"
            f"{_gpu_memory_text()}"
        )
    result = np.vstack(pieces).astype(np.float32, copy=False)
    eprint(f"[{label}] DONE shape={result.shape} elapsed={(time.time()-started)/60:.1f}m")
    return result


def nearest_code_map(
    prototype_codes: Sequence[str],
    prototype_embeddings: np.ndarray,
    query_embeddings: np.ndarray,
    k: int,
) -> List[List[str]]:
    if len(prototype_codes) == 0:
        return [[] for _ in range(len(query_embeddings))]
    k = min(k, len(prototype_codes))
    if faiss is not None:
        index = faiss.IndexFlatIP(int(prototype_embeddings.shape[1]))
        index.add(np.ascontiguousarray(prototype_embeddings))
        _, inds = index.search(np.ascontiguousarray(query_embeddings), k)
    else:
        similarity = query_embeddings @ prototype_embeddings.T
        inds = np.argsort(-similarity, axis=1)[:, :k]
    return [[prototype_codes[int(j)] for j in row] for row in inds]


def _choose_negative_codes(
    true: str,
    nearest_codes: Sequence[str],
    all_codes: Sequence[str],
    by_prefix: Mapping[str, Sequence[str]],
    kind: str,
    hard_negatives: int,
    random_negatives: int,
    strategy: str,
    rng: random.Random,
) -> List[str]:
    strategy = str(strategy or "hybrid").strip().lower()
    chosen: List[str] = []
    same = [c for c in by_prefix.get(hierarchy_prefix(true, kind), []) if c != true]
    rng.shuffle(same)
    semantic = [c for c in nearest_codes if c != true]
    if strategy == "hierarchy":
        chosen.extend(same[:hard_negatives])
    elif strategy == "semantic":
        chosen.extend(semantic[:hard_negatives])
    elif strategy == "hybrid":
        hierarchy_n = max(1, hard_negatives // 2) if hard_negatives else 0
        chosen.extend(same[:hierarchy_n])
        for code in semantic:
            if code not in chosen:
                chosen.append(code)
            if len(chosen) >= hard_negatives:
                break
    else:
        raise ValueError(f"Unknown hard-negative strategy: {strategy!r}")
    if len(chosen) < hard_negatives:
        fallback = [c for c in all_codes if c != true and c not in chosen]
        rng.shuffle(fallback)
        chosen.extend(fallback[: hard_negatives - len(chosen)])
    random_pool = [
        c for c in all_codes
        if c != true and c not in chosen and hierarchy_prefix(c, kind) != hierarchy_prefix(true, kind)
    ]
    if random_pool and random_negatives > 0:
        chosen.extend(rng.sample(random_pool, k=min(random_negatives, len(random_pool))))
    return chosen


def generate_pairs(
    docs: Sequence[str],
    labels: Sequence[Optional[str]],
    anchor_idx: Sequence[int],
    prototypes: Mapping[str, str],
    nearest: Sequence[Sequence[str]],
    kind: str,
    hard_negatives: int,
    random_negatives: int,
    seed: int,
    strategy: str = "hybrid",
) -> Dict[str, List[Any]]:
    rng = random.Random(seed)
    all_codes = list(prototypes)
    by_prefix: Dict[str, List[str]] = defaultdict(list)
    for code in all_codes:
        by_prefix[hierarchy_prefix(code, kind)].append(code)
    out: Dict[str, List[Any]] = {"query": [], "candidate": [], "label": []}
    for local_pos, i in enumerate(anchor_idx):
        true = labels[int(i)]
        if true is None or true not in prototypes:
            continue
        query = docs[int(i)]
        out["query"].append(query); out["candidate"].append(prototypes[true]); out["label"].append(1.0)
        chosen = _choose_negative_codes(
            true, nearest[local_pos] if local_pos < len(nearest) else [], all_codes,
            by_prefix, kind, hard_negatives, random_negatives, strategy, rng,
        )
        for code in chosen:
            out["query"].append(query); out["candidate"].append(prototypes[code]); out["label"].append(0.0)
    return out


def generate_listwise_rows(
    docs: Sequence[str],
    labels: Sequence[Optional[str]],
    anchor_idx: Sequence[int],
    prototypes: Mapping[str, str],
    nearest: Sequence[Sequence[str]],
    kind: str,
    hard_negatives: int,
    random_negatives: int,
    seed: int,
    strategy: str = "hybrid",
) -> Dict[str, List[Any]]:
    rng = random.Random(seed)
    all_codes = list(prototypes)
    by_prefix: Dict[str, List[str]] = defaultdict(list)
    for code in all_codes:
        by_prefix[hierarchy_prefix(code, kind)].append(code)
    out: Dict[str, List[Any]] = {"query": [], "docs": [], "labels": []}
    for local_pos, i in enumerate(anchor_idx):
        true = labels[int(i)]
        if true is None or true not in prototypes:
            continue
        chosen = _choose_negative_codes(
            true, nearest[local_pos] if local_pos < len(nearest) else [], all_codes,
            by_prefix, kind, hard_negatives, random_negatives, strategy, rng,
        )
        codes = [true] + chosen
        relevance = [1.0] + [0.0] * len(chosen)
        order = list(range(len(codes)))
        rng.shuffle(order)
        out["query"].append(docs[int(i)])
        out["docs"].append([prototypes[codes[j]] for j in order])
        out["labels"].append([relevance[j] for j in order])
    return out


def merge_pair_dicts(parts: Sequence[Mapping[str, Sequence[Any]]]) -> Dict[str, List[Any]]:
    if not parts:
        return {}
    keys = list(parts[0].keys())
    out: Dict[str, List[Any]] = {key: [] for key in keys}
    for part in parts:
        if list(part.keys()) != keys:
            raise ValueError("Cannot merge training datasets with different schemas")
        for key in keys:
            out[key].extend(part[key])
    return out


def validate_generated_training_rows(
    rows: Mapping[str, Sequence[Any]],
    loss_type: str,
    target: str,
) -> int:
    """Validate BCE or listwise training rows before expensive model evaluation.

    This catches schema/length errors near pair generation, rather than hours later
    inside the trainer. Sentence Transformers listwise losses require columns
    ``query``, ``docs`` and ``labels``; BCE requires ``query``, ``candidate`` and
    ``label``.
    """
    if loss_type == "bce":
        required = ("query", "candidate", "label")
        missing = [key for key in required if key not in rows]
        if missing:
            raise ValueError(f"[{target}] BCE dataset missing columns: {missing}")
        lengths = {key: len(rows[key]) for key in required}
        if len(set(lengths.values())) != 1:
            raise ValueError(f"[{target}] BCE dataset length mismatch: {lengths}")
        count = lengths["label"]
        if count <= 0:
            raise ValueError(f"[{target}] BCE dataset contains no training pairs")
        return int(count)

    required = ("query", "docs", "labels")
    missing = [key for key in required if key not in rows]
    if missing:
        raise ValueError(f"[{target}] {loss_type} dataset missing columns: {missing}")
    lengths = {key: len(rows[key]) for key in required}
    if len(set(lengths.values())) != 1:
        raise ValueError(f"[{target}] {loss_type} dataset length mismatch: {lengths}")
    count = lengths["labels"]
    if count <= 0:
        raise ValueError(f"[{target}] {loss_type} dataset contains no query lists")
    for index, (docs, labels) in enumerate(zip(rows["docs"], rows["labels"])):
        if not isinstance(docs, (list, tuple)) or not isinstance(labels, (list, tuple)):
            raise TypeError(f"[{target}] {loss_type} row {index} must contain list-valued docs and labels")
        if len(docs) != len(labels):
            raise ValueError(
                f"[{target}] {loss_type} row {index} has {len(docs)} docs but {len(labels)} labels"
            )
        if len(docs) < 2:
            raise ValueError(f"[{target}] {loss_type} row {index} has fewer than two candidate documents")
        if not any(float(value) > 0 for value in labels):
            raise ValueError(f"[{target}] {loss_type} row {index} has no positive relevance label")
    return int(count)


def predict_cross_encoder_with_progress(
    model: CrossEncoder,
    pairs: Sequence[Tuple[str, str]],
    batch_size: int,
    label: str,
    progress_every: int = 4096,
) -> np.ndarray:
    total = len(pairs)
    if total == 0:
        return np.zeros(0, dtype=float)
    chunk_size = max(int(batch_size), min(max(int(progress_every), 512), 8192))
    started = time.time()
    pieces: List[np.ndarray] = []
    eprint(f"[{label}] START pairs={total:,} batch_size={batch_size} chunk_size={chunk_size}")
    for start in range(0, total, chunk_size):
        end = min(total, start + chunk_size)
        scores = model.predict(
            list(pairs[start:end]),
            batch_size=int(batch_size),
            show_progress_bar=False,
        )
        pieces.append(np.asarray(scores, dtype=float).reshape(-1))
        elapsed = max(1e-9, time.time() - started)
        rate = end / elapsed
        eta = (total - end) / rate if rate > 0 else float("nan")
        eprint(
            f"[{label}] {end:,}/{total:,} ({100.0*end/total:.1f}%) "
            f"rate={rate:.1f} pairs/s elapsed={elapsed/60:.1f}m eta={eta/60:.1f}m"
            f"{_gpu_memory_text()}"
        )
    out = np.concatenate(pieces) if pieces else np.zeros(0, dtype=float)
    eprint(f"[{label}] DONE pairs={len(out):,} elapsed={(time.time()-started)/60:.1f}m")
    return out


def candidate_recall_at_k(
    truths: Sequence[Optional[str]],
    nearest: Sequence[Sequence[str]],
    ks: Sequence[int],
) -> Dict[str, float]:
    valid = [(str(t), list(c)) for t, c in zip(truths, nearest) if t is not None]
    if not valid:
        return {f"recall_at_{k}": float("nan") for k in ks}
    out: Dict[str, float] = {}
    for k in ks:
        out[f"recall_at_{int(k)}"] = float(np.mean([truth in cand[:int(k)] for truth, cand in valid]))
    out["n"] = int(len(valid))
    return out


def evaluate_reranker(
    model: CrossEncoder,
    tasks: Sequence[Tuple[str, str, Sequence[str], Sequence[Optional[str]], Mapping[str, str], Sequence[Sequence[str]]]],
    max_rows: int,
    candidates: int,
    batch_size: int,
    seed: int,
    progress_every: int = 4096,
    return_ranks: bool = False,
    inject_truth: bool = True,
):
    rng = np.random.default_rng(seed)
    result: Dict[str, Any] = {}
    rank_details: Dict[str, List[int]] = {}
    for target, kind, docs, labels, prototypes, nearest in tasks:
        valid = [i for i, label in enumerate(labels) if label is not None and label in prototypes]
        if len(valid) > max_rows:
            valid = rng.choice(valid, size=max_rows, replace=False).tolist()
        pairs: List[Tuple[str, str]] = []
        row_candidates: List[List[str]] = []
        truths: List[str] = []
        for i in valid:
            true = str(labels[i])
            cand = [c for c in nearest[i] if c in prototypes][:candidates]
            if inject_truth and true not in cand:
                cand = [true] + cand[: max(0, candidates - 1)]
            row_candidates.append(cand)
            truths.append(true)
            pairs.extend((docs[i], prototypes[c]) for c in cand)
        if not pairs:
            continue
        mode = "oracle" if inject_truth else "retrieval"
        scores = predict_cross_encoder_with_progress(
            model, pairs, batch_size, f"{target} {mode} reranker evaluation", progress_every
        )
        cursor = 0
        ranks: List[int] = []
        for true, cand in zip(truths, row_candidates):
            if not cand:
                ranks.append(10**6)
                continue
            row = scores[cursor: cursor + len(cand)]
            cursor += len(cand)
            order = np.argsort(-row)
            ranked = [cand[int(j)] for j in order]
            rank = ranked.index(true) + 1 if true in ranked else 10**6
            ranks.append(int(rank))
        ranks_np = np.asarray(ranks, dtype=np.int64)
        result[target] = {
            "n": len(truths),
            "top1": _metric_from_ranks(ranks_np, "top1"),
            "top4": _metric_from_ranks(ranks_np, "top4"),
            "mrr": _metric_from_ranks(ranks_np, "mrr"),
            "candidate_recall": float(np.mean(ranks_np < 10**6)),
            "candidates": candidates,
            "mode": mode,
        }
        rank_details[target] = ranks
    if return_ranks:
        return result, rank_details
    return result


def _metric_from_ranks(ranks: np.ndarray, metric: str) -> float:
    if metric == "top1":
        return float(np.mean(ranks == 1))
    if metric == "top4":
        return float(np.mean(ranks <= 4))
    if metric == "mrr":
        return float(np.mean(np.where(ranks < 10**6, 1.0 / ranks, 0.0)))
    raise ValueError(metric)


def paired_rank_comparison(
    base_ranks: Mapping[str, Sequence[int]],
    tuned_ranks: Mapping[str, Sequence[int]],
    bootstrap_samples: int,
    seed: int,
) -> Dict[str, Any]:
    """Paired bootstrap and exact top-1 discordance comparison."""
    rng = np.random.default_rng(seed)
    output: Dict[str, Any] = {}
    for target in sorted(set(base_ranks).intersection(tuned_ranks)):
        base = np.asarray(base_ranks[target], dtype=np.int64)
        tuned = np.asarray(tuned_ranks[target], dtype=np.int64)
        n = min(len(base), len(tuned))
        base = base[:n]
        tuned = tuned[:n]
        if n == 0:
            continue
        target_out: Dict[str, Any] = {"n": int(n)}
        for metric in ("top1", "top4", "mrr"):
            base_value = _metric_from_ranks(base, metric)
            tuned_value = _metric_from_ranks(tuned, metric)
            diff = tuned_value - base_value
            if bootstrap_samples > 0:
                boot = np.empty(int(bootstrap_samples), dtype=float)
                for b in range(int(bootstrap_samples)):
                    idx = rng.integers(0, n, size=n)
                    boot[b] = _metric_from_ranks(tuned[idx], metric) - _metric_from_ranks(base[idx], metric)
                low, high = np.quantile(boot, [0.025, 0.975]).tolist()
            else:
                low = high = float("nan")
            target_out[metric] = {
                "base": base_value,
                "tuned": tuned_value,
                "difference": diff,
                "bootstrap_95_ci": [float(low), float(high)],
            }
        base_correct = base == 1
        tuned_correct = tuned == 1
        improved = int(np.sum((~base_correct) & tuned_correct))
        harmed = int(np.sum(base_correct & (~tuned_correct)))
        discordant = improved + harmed
        p_value = (
            float(binomtest(min(improved, harmed), discordant, 0.5, alternative="two-sided").pvalue)
            if discordant
            else 1.0
        )
        target_out["top1_paired"] = {
            "base_wrong_tuned_right": improved,
            "base_right_tuned_wrong": harmed,
            "discordant": discordant,
            "exact_two_sided_p": p_value,
        }
        output[target] = target_out
    return output

def parse_groups(value: str) -> List[str]:
    return [x.strip() for x in str(value).split(",") if x.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Fine-tune a domain Cross-Encoder for NAICS/SOC candidate reranking")
    parser.add_argument("--fit_sav", required=True)
    parser.add_argument("--calibration_sav", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--base_model", default="cross-encoder/ms-marco-MiniLM-L6-v2")
    parser.add_argument("--embedding_model", default="BAAI/bge-large-en-v1.5")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--embedding_batch_size", type=int, default=16)
    parser.add_argument("--train_batch_size", type=int, default=4)
    parser.add_argument("--eval_batch_size", type=int, default=32)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--epochs", type=float, default=1.0)
    parser.add_argument("--max_update_steps", type=int, default=0,
                        help="Optional fixed optimizer-update budget. Overrides epoch length when >0.")
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--max_length", type=int, default=384)
    parser.add_argument("--max_anchors_per_target", type=int, default=12000)
    parser.add_argument("--hard_negatives", type=int, default=3)
    parser.add_argument("--random_negatives", type=int, default=1)
    parser.add_argument("--prototype_examples", type=int, default=3)
    parser.add_argument("--nearest_candidates", type=int, default=30)
    parser.add_argument("--eval_rows_per_target", type=int, default=1500)
    parser.add_argument("--eval_candidates", type=int, default=20)
    parser.add_argument("--targets", default="qa20a,qe4ar,qe5ar",
                        help="Comma-separated targets to train in this reranker. Use qa20a for NAICS or qe4ar,qe5ar for SOC.")
    parser.add_argument("--warmup_fraction", type=float, default=0.10,
                        help="Fraction of total update steps used for learning-rate warmup.")
    parser.add_argument("--progress_every", type=int, default=1024,
                        help="How often explicit stdout progress is emitted for embedding/evaluation")
    parser.add_argument("--resume_from_checkpoint", default="",
                        help="Checkpoint path, 'auto' for latest checkpoint, or blank for a fresh training phase")
    parser.add_argument("--weak_qe4_groups", default="15,17,25,51,55")
    parser.add_argument("--weak_qe5_groups", default="15,17,45,51,53,55")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--bootstrap_samples", type=int, default=2000,
                        help="Paired bootstrap samples for before/after confidence intervals.")
    parser.add_argument("--loss_type", choices=["bce", "ranknet", "listnet", "lambda"], default="bce")
    parser.add_argument("--listwise_mini_batch_size", type=int, default=8)
    parser.add_argument("--context_profile", choices=["full", "compact", "title_only", "no_employer", "no_location", "no_naics", "no_other_text"], default="full")
    parser.add_argument("--anchor_sampling", choices=["balanced", "frequency"], default="balanced")
    parser.add_argument("--weak_group_multiplier", type=int, default=2)
    parser.add_argument("--hard_negative_strategy", choices=["hybrid", "semantic", "hierarchy"], default="hybrid")
    parser.add_argument("--retrieval_recall_ks", default="1,4,10,20,40")
    parser.add_argument("--artifact_policy", choices=["full", "final_only", "metrics_only"], default="full",
                        help="full keeps final model and checkpoints; final_only keeps only the final model; metrics_only keeps only metrics/config and removes model weights after successful evaluation")
    parser.add_argument("--checkpoint_keep", type=int, default=1,
                        help="Maximum training checkpoints retained while an experiment is active. Screening batteries should use 1.")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()

    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
    np.random.seed(args.seed); random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    eprint(f"Domain reranker trainer {VERSION}")
    eprint(f"CUDA available={torch.cuda.is_available()} device={args.device}")
    eprint("Reading FIT and CALIBRATION SAV files...")
    fit_df, _ = pyreadstat.read_sav(args.fit_sav, user_missing=True, apply_value_formats=False)
    cal_df, _ = pyreadstat.read_sav(args.calibration_sav, user_missing=True, apply_value_formats=False)
    plans = field_plans()
    recall_ks = sorted({int(x.strip()) for x in str(args.retrieval_recall_ks).split(",") if x.strip() and int(x.strip()) > 0})
    max_eval_pool = max([int(args.eval_candidates)] + recall_ks)
    requested_targets = {x.strip() for x in str(args.targets).split(",") if x.strip()}
    allowed_target_info = [("qa20a", "naics"), ("qe4ar", "soc"), ("qe5ar", "soc")]
    target_info = [item for item in allowed_target_info if item[0] in requested_targets]
    if not target_info:
        raise ValueError(f"No valid targets selected from --targets={args.targets!r}. Valid targets: qa20a,qe4ar,qe5ar")
    eprint("Selected reranker targets: " + ", ".join(t for t, _ in target_info))

    embedder = SentenceTransformer(args.embedding_model, device=args.device)
    train_parts: List[Mapping[str, Sequence[Any]]] = []
    eval_tasks_before: List[Tuple[str, str, Sequence[str], Sequence[Optional[str]], Mapping[str, str], Sequence[Sequence[str]]]] = []
    artifacts: Dict[str, Any] = {"version": VERSION, "selected_targets": [t for t, _ in target_info], "targets": {}}
    prototypes_by_target: Dict[str, Dict[str, str]] = {}

    for offset, (target, kind) in enumerate(target_info):
        if target not in fit_df.columns or target not in cal_df.columns:
            eprint(f"[{target}] skipped: target column missing")
            continue
        target_plan = apply_context_profile(plans[target], target, args.context_profile)
        train_docs = make_docs(fit_df, target_plan, target)
        cal_docs = make_docs(cal_df, target_plan, target)
        train_labels = [clean_code(v, kind) for v in fit_df[target].tolist()]
        cal_labels = [clean_code(v, kind) for v in cal_df[target].tolist()]
        prototypes, counts = build_prototypes(train_docs, train_labels, target, args.prototype_examples)
        prototypes_by_target[target] = prototypes
        codes = sorted(prototypes)
        eprint(f"[{target}] prototypes={len(codes):,}; labeled_fit={sum(v is not None for v in train_labels):,}")
        if len(codes) < 2:
            continue
        proto_emb = encode(
            embedder, [prototypes[c] for c in codes], args.embedding_batch_size,
            label=f"{target} prototype embeddings", progress_every=args.progress_every,
        )
        weak = [] if target == "qa20a" else parse_groups(args.weak_qe4_groups if target == "qe4ar" else args.weak_qe5_groups)
        anchor_idx = stratified_anchor_indices(
            train_labels, args.max_anchors_per_target, args.seed + offset, weak, kind,
            sampling_strategy=args.anchor_sampling, weak_group_multiplier=args.weak_group_multiplier,
        )
        query_emb = encode(
            embedder, [train_docs[int(i)] for i in anchor_idx], args.embedding_batch_size,
            label=f"{target} training-query embeddings", progress_every=args.progress_every,
        )
        nearest = nearest_code_map(codes, proto_emb, query_emb, args.nearest_candidates)
        eprint(f"[{target}] Generating positive, hard-negative, and random-negative pairs...")
        generated_count = 0
        if args.loss_type == "bce":
            target_rows = generate_pairs(
                train_docs, train_labels, anchor_idx, prototypes, nearest, kind,
                args.hard_negatives, args.random_negatives, args.seed + 100 + offset,
                strategy=args.hard_negative_strategy,
            )
            generated_count = validate_generated_training_rows(target_rows, args.loss_type, target)
            train_parts.append(target_rows)
            eprint(
                f"[{target}] pair generation DONE anchors={len(anchor_idx):,} "
                f"pairs={generated_count:,} positives={sum(target_rows['label']):,.0f}"
            )
        else:
            target_rows = generate_listwise_rows(
                train_docs, train_labels, anchor_idx, prototypes, nearest, kind,
                args.hard_negatives, args.random_negatives, args.seed + 100 + offset,
                strategy=args.hard_negative_strategy,
            )
            generated_count = validate_generated_training_rows(target_rows, args.loss_type, target)
            train_parts.append(target_rows)
            eprint(
                f"[{target}] listwise generation DONE anchors={len(anchor_idx):,} "
                f"query_lists={generated_count:,} docs_per_query≈{1+args.hard_negatives+args.random_negatives}"
            )

        valid_cal_idx = [i for i, label in enumerate(cal_labels) if label in prototypes]
        if len(valid_cal_idx) > args.eval_rows_per_target:
            rng = np.random.default_rng(args.seed + 200 + offset)
            valid_cal_idx = rng.choice(valid_cal_idx, size=args.eval_rows_per_target, replace=False).tolist()
        cal_eval_docs = [cal_docs[i] for i in valid_cal_idx]
        cal_eval_labels = [cal_labels[i] for i in valid_cal_idx]
        cal_emb = encode(
            embedder, cal_eval_docs, args.embedding_batch_size,
            label=f"{target} calibration-query embeddings", progress_every=args.progress_every,
        ) if cal_eval_docs else np.zeros((0, proto_emb.shape[1]), dtype=np.float32)
        cal_nearest = nearest_code_map(codes, proto_emb, cal_emb, max_eval_pool)
        eval_tasks_before.append((target, kind, cal_eval_docs, cal_eval_labels, prototypes, cal_nearest))
        artifacts.setdefault("retrieval_candidate_recall", {})[target] = candidate_recall_at_k(cal_eval_labels, cal_nearest, recall_ks)
        artifacts["targets"][target] = {
            "prototype_codes": len(codes),
            "anchor_rows": int(len(anchor_idx)),
            "loss_type": args.loss_type,
            "training_examples": int(generated_count),
            "training_pairs": int(generated_count) if args.loss_type == "bce" else None,
            "training_query_lists": int(generated_count) if args.loss_type != "bce" else None,
            "documents_per_query": (1 + args.hard_negatives + args.random_negatives) if args.loss_type != "bce" else None,
            "class_counts": dict(counts),
        }
        del proto_emb, query_emb, cal_emb
        gc.collect()

    del embedder
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    all_pairs = merge_pair_dicts(train_parts)
    label_key = "label" if args.loss_type == "bce" else "labels"
    if not all_pairs or not all_pairs.get(label_key):
        raise RuntimeError("No domain reranker training examples were generated")
    rng = np.random.default_rng(args.seed)
    order = rng.permutation(len(all_pairs[label_key]))
    all_pairs = {k: [v[int(i)] for i in order] for k, v in all_pairs.items()}
    eprint(f"Building Hugging Face Dataset from {len(all_pairs[label_key]):,} training examples loss={args.loss_type}...")
    train_dataset = Dataset.from_dict(all_pairs)
    eprint("Training Dataset build DONE")
    if args.loss_type == "bce":
        eprint(f"Training pairs={len(train_dataset):,}; positives={sum(all_pairs['label']):,.0f}; negatives={len(train_dataset)-sum(all_pairs['label']):,.0f}")
    else:
        eprint(f"Training query lists={len(train_dataset):,}; loss={args.loss_type}; docs/query≈{1+args.hard_negatives+args.random_negatives}")

    try:
        base_model = CrossEncoder(args.base_model, device=args.device, num_labels=1, max_length=args.max_length)
    except TypeError:
        base_model = CrossEncoder(args.base_model, device=args.device, num_labels=1)
        try:
            base_model.max_length = int(args.max_length)
        except Exception:
            pass
    eprint("Evaluating base Cross-Encoder on CALIBRATION candidate sets (oracle and retrieval modes)...")
    base_metrics, base_ranks = evaluate_reranker(
        base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates,
        args.eval_batch_size, args.seed, progress_every=max(4096, args.progress_every),
        return_ranks=True, inject_truth=True,
    )
    base_retrieval_metrics, base_retrieval_ranks = evaluate_reranker(
        base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates,
        args.eval_batch_size, args.seed, progress_every=max(4096, args.progress_every),
        return_ranks=True, inject_truth=False,
    )
    eprint("Base oracle metrics:")
    eprint(json.dumps(base_metrics, indent=2))
    eprint("Base retrieval-pipeline metrics:")
    eprint(json.dumps(base_retrieval_metrics, indent=2))

    neg_per_pos = max(1.0, float(args.hard_negatives + args.random_negatives))
    if args.loss_type == "bce":
        loss = ce_losses.BinaryCrossEntropyLoss(model=base_model, pos_weight=torch.tensor(neg_per_pos))
    else:
        loss_cls = {
            "ranknet": getattr(ce_losses, "RankNetLoss", None),
            "listnet": getattr(ce_losses, "ListNetLoss", None),
            "lambda": getattr(ce_losses, "LambdaLoss", None),
        }.get(args.loss_type)
        if loss_cls is None:
            raise RuntimeError(f"Loss {args.loss_type!r} is unavailable in installed sentence-transformers")
        loss = loss_cls(model=base_model, mini_batch_size=max(1, int(args.listwise_mini_batch_size)))
    checkpoint_dir = output / "checkpoints"
    fixed_steps = max(0, int(args.max_update_steps))
    warmup_steps = (
        int(round(fixed_steps * max(0.0, min(0.99, args.warmup_fraction))))
        if fixed_steps > 0
        else float(max(0.0, min(0.99, args.warmup_fraction)))
    )
    save_steps = max(25, min(500, fixed_steps // 4 if fixed_steps > 0 else 500))
    training_args = CrossEncoderTrainingArguments(
        output_dir=str(checkpoint_dir),
        num_train_epochs=float(args.epochs),
        max_steps=int(fixed_steps) if fixed_steps > 0 else -1,
        per_device_train_batch_size=int(args.train_batch_size),
        per_device_eval_batch_size=int(args.eval_batch_size),
        gradient_accumulation_steps=int(args.gradient_accumulation_steps),
        learning_rate=float(args.learning_rate),
        warmup_steps=warmup_steps,
        fp16=bool(torch.cuda.is_available()),
        bf16=False,
        dataloader_num_workers=0,
        save_strategy="steps",
        save_steps=save_steps,
        save_total_limit=max(1, int(args.checkpoint_keep)),
        logging_steps=50,
        logging_first_step=True,
        report_to="none",
        disable_tqdm=True,
        seed=int(args.seed),
        run_name="domain-cross-encoder-" + "-".join(t for t, _ in target_info),
    )
    trainer = CrossEncoderTrainer(
        model=base_model, args=training_args, train_dataset=train_dataset, loss=loss,
        callbacks=[VisibleProgressCallback()],
    )
    resume_checkpoint: Optional[str] = None
    requested_resume = str(args.resume_from_checkpoint or "").strip()
    if requested_resume:
        if requested_resume.lower() == "auto":
            candidates: List[Tuple[int, Path]] = []
            if checkpoint_dir.exists():
                for candidate in checkpoint_dir.glob("checkpoint-*"):
                    try:
                        step = int(candidate.name.rsplit("-", 1)[1])
                        candidates.append((step, candidate))
                    except Exception:
                        continue
            if candidates:
                resume_checkpoint = str(max(candidates, key=lambda item: item[0])[1])
        else:
            candidate = Path(requested_resume)
            if candidate.exists():
                resume_checkpoint = str(candidate)
            else:
                raise FileNotFoundError(f"Requested resume checkpoint does not exist: {candidate}")
    if resume_checkpoint:
        eprint(f"Resuming domain Cross-Encoder training from: {resume_checkpoint}")
    else:
        eprint("Starting domain Cross-Encoder training from the base model. Progress will appear below...")
    started = time.time()
    trainer.train(resume_from_checkpoint=resume_checkpoint)
    train_seconds = time.time() - started
    final_dir = output / "final"
    output_model: Optional[str] = None
    if args.artifact_policy in {"full", "final_only"}:
        base_model.save_pretrained(str(final_dir))
        output_model = str(final_dir)
        eprint(f"Saved fine-tuned reranker to: {final_dir}")
    else:
        eprint("Artifact policy=metrics_only: final model weights will not be retained after evaluation.")

    eprint("Evaluating fine-tuned Cross-Encoder on CALIBRATION candidate sets (oracle and retrieval modes)...")
    tuned_metrics, tuned_ranks = evaluate_reranker(
        base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates,
        args.eval_batch_size, args.seed, progress_every=max(4096, args.progress_every),
        return_ranks=True, inject_truth=True,
    )
    tuned_retrieval_metrics, tuned_retrieval_ranks = evaluate_reranker(
        base_model, eval_tasks_before, args.eval_rows_per_target, args.eval_candidates,
        args.eval_batch_size, args.seed, progress_every=max(4096, args.progress_every),
        return_ranks=True, inject_truth=False,
    )
    eprint("Tuned oracle metrics:")
    eprint(json.dumps(tuned_metrics, indent=2))
    eprint("Tuned retrieval-pipeline metrics:")
    eprint(json.dumps(tuned_retrieval_metrics, indent=2))
    paired = paired_rank_comparison(
        base_ranks, tuned_ranks, bootstrap_samples=int(args.bootstrap_samples), seed=int(args.seed) + 991,
    )
    paired_retrieval = paired_rank_comparison(
        base_retrieval_ranks, tuned_retrieval_ranks, bootstrap_samples=int(args.bootstrap_samples), seed=int(args.seed) + 1991,
    )
    eprint("Paired oracle before/after comparison:")
    eprint(json.dumps(paired, indent=2))
    eprint("Paired retrieval-pipeline before/after comparison:")
    eprint(json.dumps(paired_retrieval, indent=2))
    artifacts.update({
        "base_model": args.base_model,
        "embedding_model": args.embedding_model,
        "output_model": output_model,
        "artifact_policy": args.artifact_policy,
        "training_examples_total": len(train_dataset),
        "training_pairs_total": len(train_dataset) if args.loss_type == "bce" else None,
        "training_query_lists_total": len(train_dataset) if args.loss_type != "bce" else None,
        "training_seconds": train_seconds,
        "base_metrics": base_metrics,
        "tuned_metrics": tuned_metrics,
        "paired_comparison": paired,
        "base_metrics_retrieval": base_retrieval_metrics,
        "tuned_metrics_retrieval": tuned_retrieval_metrics,
        "paired_comparison_retrieval": paired_retrieval,
        "settings": vars(args),
    })
    report_path = output / "domain_reranker_training_report.json"
    report_path.write_text(json.dumps(artifacts, indent=2, default=str), encoding="utf-8")
    eprint(f"Training report: {report_path}")

    # Checkpoints are useful only while an experiment is unfinished.  Once all
    # metrics have been written, screening and final-only policies remove them.
    cleanup: Dict[str, Any] = {"policy": args.artifact_policy, "deleted": [], "bytes_freed": 0}
    def _tree_bytes(path: Path) -> int:
        if not path.exists():
            return 0
        if path.is_file():
            try:
                return int(path.stat().st_size)
            except OSError:
                return 0
        total = 0
        for child in path.rglob("*"):
            if child.is_file():
                try:
                    total += int(child.stat().st_size)
                except OSError:
                    pass
        return total

    delete_paths: List[Path] = []
    if args.artifact_policy in {"metrics_only", "final_only"}:
        delete_paths.append(checkpoint_dir)
    if args.artifact_policy == "metrics_only":
        delete_paths.append(final_dir)
    for path in delete_paths:
        if path.exists():
            size = _tree_bytes(path)
            try:
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
                cleanup["deleted"].append(str(path))
                cleanup["bytes_freed"] += size
            except Exception as exc:
                cleanup.setdefault("errors", []).append(f"{path}: {exc}")
    artifacts["artifact_cleanup"] = cleanup
    report_path.write_text(json.dumps(artifacts, indent=2, default=str), encoding="utf-8")
    eprint(
        f"Artifact cleanup policy={args.artifact_policy} freed={cleanup['bytes_freed']/1024**3:.2f} GB; "
        f"retained={'metrics only' if args.artifact_policy == 'metrics_only' else ('final model only' if args.artifact_policy == 'final_only' else 'full artifacts')}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        eprint("Interrupted by user.")
        raise SystemExit(130)
    except Exception:
        print("[FATAL] Domain Cross-Encoder trainer failed:", flush=True)
        traceback.print_exc(file=sys.stdout)
        raise SystemExit(1)
