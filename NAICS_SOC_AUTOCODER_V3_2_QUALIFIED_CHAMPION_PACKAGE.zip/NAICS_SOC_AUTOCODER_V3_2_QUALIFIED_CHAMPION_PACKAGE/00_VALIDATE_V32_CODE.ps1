param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base '.venv\Scripts\python.exe'
$files = @(
  'naics_soc_adaptive_memory_reranker_v3_2.py',
  'autocoder_improvement_audit_v2.py',
  'train_v32_final_rerankers.py',
  'v32_preflight.py',
  'evaluate_v32_promotion.py',
  'build_v32_deployment_bundle.py',
  'create_review_queue_from_v32_log.py'
)
foreach ($f in $files) {
  $path = Join-Path $Base $f
  if (-not (Test-Path $path)) { throw "Missing $path" }
  & $Python -m py_compile $path
  if ($LASTEXITCODE -ne 0) { throw "Compile failed: $f" }
  Write-Host "PASS $f"
}
Write-Host 'All V3.2 Python files compiled.' -ForegroundColor Green
