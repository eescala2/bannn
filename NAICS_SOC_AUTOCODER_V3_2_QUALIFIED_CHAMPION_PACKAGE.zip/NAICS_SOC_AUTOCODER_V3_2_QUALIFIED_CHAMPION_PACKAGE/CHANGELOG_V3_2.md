# V3.2 changelog

- Added exact reproduction of the confirmed five-seed winner candidate depths.
- Added `--ml_candidate_pool` so the sparse candidate source is capped at the confirmed top 30 rather than silently contributing the full union depth.
- Increased the integrated winner-fidelity semantic/profile depth to 50 and union depth to 60 via the V3.2 launcher.
- Added concise candidate-union diagnostics in the live terminal log.
- Added sealed-Gold promotion gates against the fixed audited baseline.
- Added a deploy-only-after-promotion bundle builder.
- Added score-only production launcher and SPSS 26 active-dataset syntax.
- Added a structured low-confidence/conformal review-queue CSV.
- Added a one-command qualification pipeline and status dashboard.
