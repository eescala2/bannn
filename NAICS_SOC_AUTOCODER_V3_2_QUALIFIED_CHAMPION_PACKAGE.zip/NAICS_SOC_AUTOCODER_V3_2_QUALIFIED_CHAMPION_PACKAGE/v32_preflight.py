#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib, json, os, shutil, subprocess, sys
from pathlib import Path
from typing import Any, Dict, List

VERSION = "2026.07.23.v32-qualified-champion-preflight"

REQUIRED_IMPORTS = [
    "numpy", "pandas", "scipy", "sklearn", "joblib", "pyreadstat",
    "sentence_transformers", "transformers", "torch", "faiss", "rapidfuzz",
]


def check_import(name: str) -> Dict[str, Any]:
    try:
        mod = importlib.import_module(name)
        return {"ok": True, "version": getattr(mod, "__version__", "unknown")}
    except Exception as exc:
        return {"ok": False, "error": repr(exc)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--require_rerankers", action="store_true")
    ap.add_argument("--score_only", action="store_true", help="Validate a deployment/scoring installation without requiring FIT, CALIBRATION, or Gold SAV files.")
    ap.add_argument("--out_json", default="")
    args = ap.parse_args()
    base = Path(args.base)
    paths = {
        "fit_sav": base / "training_FIT.sav",
        "calibration_sav": base / "training_CALIBRATION.sav",
        "gold_sav": base / "training_EVALUATION_GOLD.sav",
        "main_script": base / "naics_soc_adaptive_memory_reranker_v3_2.py",
        "audit_script": base / "autocoder_improvement_audit_v2.py",
        "winner_manifest": base / "CONFIRMED_V31_WINNERS.json",
        "reranker_manifest": base / "models" / "v32_production_rerankers" / "production_reranker_manifest.json",
        "qualified_model": base / "models" / "naics_soc_QUALIFIED_V32.joblib",
    }
    report: Dict[str, Any] = {"version": VERSION, "base": str(base), "paths": {}, "packages": {}, "critical_errors": [], "warnings": []}
    for key, path in paths.items():
        exists = path.exists()
        report["paths"][key] = {"path": str(path), "exists": exists}
        if args.score_only:
            required = key in {"main_script", "reranker_manifest", "qualified_model"}
        else:
            required = key not in {"reranker_manifest", "qualified_model"}
            if key == "reranker_manifest" and args.require_rerankers:
                required = True
        if required and not exists:
            report["critical_errors"].append(f"Missing required file: {path}")

    for name in REQUIRED_IMPORTS:
        result = check_import(name)
        report["packages"][name] = result
        if not result["ok"]:
            report["critical_errors"].append(f"Missing/broken package {name}: {result.get('error')}")

    try:
        import torch
        report["cuda"] = {
            "available": bool(torch.cuda.is_available()),
            "torch": torch.__version__,
            "cuda_version": torch.version.cuda,
            "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        }
        if not torch.cuda.is_available():
            report["critical_errors"].append("CUDA-enabled PyTorch is required for the qualified V3.2 run.")
    except Exception as exc:
        report["cuda"] = {"available": False, "error": repr(exc)}

    usage = shutil.disk_usage(base if base.exists() else Path.cwd())
    report["disk"] = {"free_gb": round(usage.free / 1024**3, 2), "total_gb": round(usage.total / 1024**3, 2)}
    if usage.free < 20 * 1024**3:
        report["warnings"].append("Less than 20 GB free. A full train-and-Gold run may exhaust temporary space.")

    winner_path = paths["winner_manifest"]
    if winner_path.exists():
        try:
            data = json.loads(winner_path.read_text(encoding="utf-8"))
            required_targets = {"qa20a", "qe4ar", "qe5ar"}
            got = set(data.get("winners", {}))
            if not required_targets.issubset(got):
                report["critical_errors"].append("Winner manifest does not contain qa20a, qe4ar, and qe5ar.")
            fidelity = {}
            for target in sorted(required_targets & got):
                w = data["winners"][target][0]
                c = w.get("experiment_config", {})
                fidelity[target] = {
                    "semantic_per_profile": c.get("semantic_per_profile"),
                    "lexical_candidates": c.get("lexical_candidates"),
                    "union_limit": c.get("union_limit"),
                    "retrieval_profiles": c.get("retrieval_profiles"),
                    "retrieval_prototypes": c.get("retrieval_prototypes"),
                }
            report["winner_fidelity"] = fidelity
        except Exception as exc:
            report["critical_errors"].append(f"Could not parse winner manifest: {exc}")

    # Detect duplicate heavy processes without requiring psutil.
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and ($_.CommandLine -like '*reranker_v3_2.py*' -or $_.CommandLine -like '*train_targeted_interaction_reranker.py*') } | Select-Object -ExpandProperty ProcessId"],
            text=True, capture_output=True, timeout=15,
        )
        pids = [line.strip() for line in proc.stdout.splitlines() if line.strip().isdigit()]
        report["active_heavy_python_pids"] = pids
        if len(pids) > 1:
            report["warnings"].append(f"Multiple heavy autocoder processes detected: {pids}")
    except Exception as exc:
        report["warnings"].append(f"Process check unavailable: {exc}")

    out = Path(args.out_json or (base / "v32_preflight_report.json"))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, default=str))
    print(f"Preflight report: {out}")
    if report["critical_errors"]:
        print("V3.2 PRECHECK FAILED.")
        return 2
    print("V3.2 PRECHECK PASSED.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
