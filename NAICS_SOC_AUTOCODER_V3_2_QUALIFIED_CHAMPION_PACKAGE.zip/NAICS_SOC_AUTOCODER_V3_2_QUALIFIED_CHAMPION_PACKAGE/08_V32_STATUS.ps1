param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "SilentlyContinue"
$paths = [ordered]@{
  V32RerankerManifest = Join-Path $Base 'models\v32_production_rerankers\production_reranker_manifest.json'
  QualifiedModel = Join-Path $Base 'models\naics_soc_QUALIFIED_V32.joblib'
  GoldScoredSav = Join-Path $Base 'output\GOLD_scored_QUALIFIED_V32.sav'
  PromotionDecision = Join-Path $Base 'v32_qualification\PROMOTION_DECISION.json'
  DeploymentZip = Join-Path $Base 'NAICS_SOC_AUTOCODER_V32_DEPLOYMENT.zip'
}
$rows = foreach ($kv in $paths.GetEnumerator()) {
  [pscustomobject]@{ Item=$kv.Key; Exists=Test-Path $kv.Value; Path=$kv.Value }
}
$rows | Format-Table -AutoSize
Write-Host "`nActive heavy Python processes:"
Get-CimInstance Win32_Process |
  Where-Object { $_.Name -like 'python*' -and ($_.CommandLine -like '*reranker_v3_2.py*' -or $_.CommandLine -like '*train_targeted_interaction_reranker.py*') } |
  Select-Object ProcessId, CreationDate, CommandLine |
  Format-List
Write-Host "`nGPU:"
& nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total --format=csv,noheader
$log = Join-Path $Base 'logs\console_QUALIFIED_V32_live.log'
if (Test-Path $log) {
  Write-Host "`nLatest qualification log lines:"
  Get-Content $log -Tail 30
}
