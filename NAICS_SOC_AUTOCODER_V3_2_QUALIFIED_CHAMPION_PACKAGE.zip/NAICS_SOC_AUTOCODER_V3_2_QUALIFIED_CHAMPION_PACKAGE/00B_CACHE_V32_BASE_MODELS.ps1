param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Missing virtual environment: $Python" }
$env:HF_HOME = Join-Path $Base "hf_cache"
$env:HF_HUB_CACHE = Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE = "0"
$env:TRANSFORMERS_OFFLINE = "0"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:CUDA_VISIBLE_DEVICES = "0"
Write-Host "Caching BGE-large and MiniLM-L6 reranker. Internet access is required for this step." -ForegroundColor Cyan
& $Python -c "from sentence_transformers import SentenceTransformer,CrossEncoder; import torch; print('cuda',torch.cuda.is_available()); SentenceTransformer('BAAI/bge-large-en-v1.5', device='cuda' if torch.cuda.is_available() else 'cpu'); CrossEncoder('cross-encoder/ms-marco-MiniLM-L6-v2', device='cuda' if torch.cuda.is_available() else 'cpu'); print('models cached')"
if ($LASTEXITCODE -ne 0) { throw "Model caching failed" }
$env:HF_HUB_OFFLINE = "1"
$env:TRANSFORMERS_OFFLINE = "1"
& $Python -c "from sentence_transformers import SentenceTransformer,CrossEncoder; SentenceTransformer('BAAI/bge-large-en-v1.5', device='cpu', local_files_only=True); CrossEncoder('cross-encoder/ms-marco-MiniLM-L6-v2', device='cpu', local_files_only=True); print('offline load ok')"
if ($LASTEXITCODE -ne 0) { throw "Offline model verification failed" }
