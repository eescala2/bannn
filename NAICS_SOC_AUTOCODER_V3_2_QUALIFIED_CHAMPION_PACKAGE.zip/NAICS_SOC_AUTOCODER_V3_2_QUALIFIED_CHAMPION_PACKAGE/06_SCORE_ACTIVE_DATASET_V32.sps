* V3.2 NAICS/SOC scoring launcher for SPSS Statistics 26.
* Edit BASE if your installation folder differs.

SET PRINTBACK=ON MPRINT=ON.

SAVE OUTFILE='C:\laborshed_autocode_clean\work\_active_to_score_v32.sav'
  /COMPRESSED.
EXECUTE.

BEGIN PROGRAM Python3.
import os
import subprocess

BASE = r"C:\laborshed_autocode_clean"
INPUT_SAV = os.path.join(BASE, "work", "_active_to_score_v32.sav")
OUTPUT_SAV = os.path.join(BASE, "work", "_active_scored_v32.sav")
RUNNER = os.path.join(BASE, "04_SCORE_V32_NEW_DATA.ps1")

os.makedirs(os.path.join(BASE, "work"), exist_ok=True)
cmd = [
    "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
    "-File", RUNNER,
    "-Base", BASE,
    "-ScoreSav", INPUT_SAV,
    "-OutSav", OUTPUT_SAV,
    "-RunLabel", "spss_active_v32"
]
print("Launching external CUDA autocoder...")
print(" ".join(cmd))
result = subprocess.run(cmd)
if result.returncode != 0:
    raise RuntimeError(f"V3.2 external autocoder failed with exit code {result.returncode}")
print("V3.2 scoring completed.")
END PROGRAM.

GET FILE='C:\laborshed_autocode_clean\work\_active_scored_v32.sav'.
DATASET NAME AutocodedV32 WINDOW=FRONT.
EXECUTE.
