# V3.2 build validation

Validated in the build environment:

- Python syntax compilation passed for the V3.2 main autocoder, audit module, final-reranker builder, preflight checker, promotion evaluator, deployment builder, and review-queue parser.
- The confirmed winner manifest produced correct dry-run commands for all three target rerankers.
- The promotion gate was synthetic-tested against an audit JSON and generated a PROMOTE decision, Markdown report, JSON report, and approval flag.
- The review-queue parser was synthetic-tested against the row-level log format and correctly selected low-confidence and multi-code conformal cases.
- The V3.2 main script contains the new `--ml_candidate_pool` control and candidate-union diagnostics.

Not executable in this container:

- Windows PowerShell syntax execution;
- SPSS `.sav` round trips with the user's files;
- CUDA training/inference on the RTX 2050;
- a real sealed-Gold audit.

Those steps are covered by `00_VALIDATE_V32_CODE.ps1`, `00_PREFLIGHT_V32.ps1`, and the qualification workflow on the target laptop.
