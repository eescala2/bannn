param(
  [Parameter(Mandatory=$true)][string]$ScoreSav,
  [string]$Base = "C:\laborshed_autocode_clean",
  [string]$OutSav = "",
  [string]$RunLabel = "v32_production_score",
  [double]$NaicsReviewThreshold = 0.85,
  [double]$SocReviewThreshold = 0.80
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V32.ps1') -Base $Base -RequireRerankers -ScoreOnly
$ModelIn = Join-Path $Base 'models\naics_soc_QUALIFIED_V32.joblib'
if (-not (Test-Path $ModelIn)) { throw "Missing qualified model: $ModelIn" }
if (-not (Test-Path $ScoreSav)) { throw "Missing scoring SAV: $ScoreSav" }
if ([string]::IsNullOrWhiteSpace($OutSav)) {
  $stem = [System.IO.Path]::GetFileNameWithoutExtension($ScoreSav)
  $OutSav = Join-Path $Base ("output\{0}_V32_scored.sav" -f $stem)
}
$Manifest = Get-Content (Join-Path $Base 'models\v32_production_rerankers\production_reranker_manifest.json') -Raw | ConvertFrom-Json
$NaicsCfg = $Manifest.targets.qa20a.winner.experiment_config; $Qe4Cfg = $Manifest.targets.qe4ar.winner.experiment_config; $Qe5Cfg = $Manifest.targets.qe5ar.winner.experiment_config
$semanticPerProfile = [Math]::Max([int]$NaicsCfg.semantic_per_profile, [Math]::Max([int]$Qe4Cfg.semantic_per_profile, [int]$Qe5Cfg.semantic_per_profile))
$lexicalCandidates = [Math]::Max([int]$NaicsCfg.lexical_candidates, [Math]::Max([int]$Qe4Cfg.lexical_candidates, [int]$Qe5Cfg.lexical_candidates))
$unionLimit = [Math]::Max([int]$NaicsCfg.union_limit, [Math]::Max([int]$Qe4Cfg.union_limit, [int]$Qe5Cfg.union_limit))
$Python = Join-Path $Base '.venv\Scripts\python.exe'; $Script = Join-Path $Base 'naics_soc_adaptive_memory_reranker_v3_2.py'
$stemOut = [System.IO.Path]::GetFileNameWithoutExtension($OutSav)
$PredLog = Join-Path $Base ("logs\{0}_predictions.txt" -f $stemOut)
$ConsoleLog = Join-Path $Base ("logs\console_{0}_live.log" -f $stemOut)
$ReviewCsv = Join-Path $Base ("review_queues\{0}_review_queue.csv" -f $stemOut)
foreach ($d in @((Split-Path $OutSav),(Split-Path $PredLog),(Split-Path $ReviewCsv))) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
$env:PYTHONUTF8='1'; $env:PYTHONIOENCODING='utf-8'; $env:HF_HOME=Join-Path $Base 'hf_cache'; $env:HF_HUB_CACHE=Join-Path $Base 'hf_cache\hub'; $env:HF_HUB_OFFLINE='1'; $env:TRANSFORMERS_OFFLINE='1'; $env:HF_HUB_DISABLE_PROGRESS_BARS='1'; $env:CUDA_VISIBLE_DEVICES='0'; $env:TOKENIZERS_PARALLELISM='false'; $env:OMP_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'; $env:NUMEXPR_NUM_THREADS='1'
$argsList = @(
  '-u',$Script,'--mode','score','--model_in',$ModelIn,'--score_sav',$ScoreSav,'--out_sav',$OutSav,'--log_txt',$PredLog,
  '--profile','accuracy','--use_embeddings','--use_semantic_memory','--semantic_backend','faiss','--embedding_model','BAAI/bge-large-en-v1.5','--embedding_backend','torch','--embedding_device','cuda','--embedding_batch_size','16','--embedding_cache_dir',(Join-Path $Base 'embedding_cache'),
  '--semantic_query_profiles_naics',[string]$NaicsCfg.retrieval_profiles,'--semantic_query_profiles_qe4',[string]$Qe4Cfg.retrieval_profiles,'--semantic_query_profiles_qe5',[string]$Qe5Cfg.retrieval_profiles,
  '--use_code_prototype_retrieval','--code_prototype_examples_naics',[string]$NaicsCfg.retrieval_prototypes,'--code_prototype_examples_qe4',[string]$Qe4Cfg.retrieval_prototypes,'--code_prototype_examples_qe5',[string]$Qe5Cfg.retrieval_prototypes,'--code_prototype_candidates_per_profile',[string]$semanticPerProfile,'--code_prototype_include_raw_memory',
  '--use_cross_encoder_reranker','--cross_encoder_union_candidates','--cross_encoder_model_naics',[string]$Manifest.targets.qa20a.model_path,'--cross_encoder_model_qe4',[string]$Manifest.targets.qe4ar.model_path,'--cross_encoder_model_qe5',[string]$Manifest.targets.qe5ar.model_path,'--cross_encoder_topn',[string]$unionLimit,'--cross_encoder_candidate_pool',[string]$unionLimit,'--ml_candidate_pool',[string]$lexicalCandidates,'--cross_encoder_batch_size','32',
  '--memory_candidate_pool',[string]$unionLimit,'--conformal_candidate_pool',[string]$unionLimit,'--overwrite_existing','--fill_all_missing','--score_rows_without_text','--fallback_fill_missing','--topk_naics','4','--topk_soc','4','--top_groups','5','--score_batch_size','500','--max_workers','6','--native_threads','1','--console_log',$ConsoleLog
)
Write-Host "Scoring with V3.2 qualified champion: $ScoreSav" -ForegroundColor Cyan
Write-Host "Output: $OutSav"
Write-Host "Live log: $ConsoleLog"
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3.2 score run failed with code $LASTEXITCODE" }
& $Python -u (Join-Path $Base 'create_review_queue_from_v32_log.py') --log_txt $PredLog --out_csv $ReviewCsv --naics_threshold ([string]$NaicsReviewThreshold) --soc_threshold ([string]$SocReviewThreshold)
if ($LASTEXITCODE -ne 0) { Write-Warning 'Scored SAV was written, but review-queue generation failed.' }
Write-Host "Completed. Review queue: $ReviewCsv" -ForegroundColor Green
