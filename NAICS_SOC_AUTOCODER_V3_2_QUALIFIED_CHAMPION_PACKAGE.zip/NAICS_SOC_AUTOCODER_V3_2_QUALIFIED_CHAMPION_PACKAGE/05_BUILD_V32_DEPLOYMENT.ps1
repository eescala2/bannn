param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [switch]$Force,
  [switch]$Thin
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base '.venv\Scripts\python.exe'
$argsList = @('-u',(Join-Path $Base 'build_v32_deployment_bundle.py'),'--base',$Base)
if ($Force) { $argsList += '--force' }
if ($Thin) { $argsList += '--thin' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "Deployment bundle creation failed." }
