param(
    [string]$Base = "C:\laborshed_autocode_clean"
)

$ErrorActionPreference = "Stop"
Set-Location $Base

$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Trainer = Join-Path $Base "train_domain_cross_encoder_battery.py"
$FitSav = Join-Path $Base "training_FIT.sav"
$CalibrationSav = Join-Path $Base "training_CALIBRATION.sav"

foreach ($Required in @($Python, $Trainer, $FitSav, $CalibrationSav)) {
    if (-not (Test-Path $Required)) { throw "Missing required file: $Required" }
}

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
$env:HF_HUB_OFFLINE = "1"
$env:TRANSFORMERS_OFFLINE = "1"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:CUDA_VISIBLE_DEVICES = "0"
$env:TOKENIZERS_PARALLELISM = "false"
$env:OMP_NUM_THREADS = "1"
$env:OPENBLAS_NUM_THREADS = "1"
$env:MKL_NUM_THREADS = "1"
$env:NUMEXPR_NUM_THREADS = "1"

$Root = Join-Path $Base "models\listwise_fix_smoke"
New-Item -ItemType Directory -Path $Root -Force | Out-Null

foreach ($Loss in @("ranknet", "listnet", "lambda")) {
    $Out = Join-Path $Root $Loss
    Write-Host "" 
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
    Write-Host "LISTWISE FIX SMOKE TEST: $Loss" -ForegroundColor Cyan
    Write-Host ("=" * 78) -ForegroundColor DarkCyan

    & $Python -u $Trainer `
        --fit_sav $FitSav `
        --calibration_sav $CalibrationSav `
        --output_dir $Out `
        --targets "qe4ar" `
        --base_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
        --embedding_model "BAAI/bge-large-en-v1.5" `
        --device cuda `
        --embedding_batch_size 16 `
        --train_batch_size 1 `
        --eval_batch_size 32 `
        --gradient_accumulation_steps 4 `
        --max_update_steps 2 `
        --learning_rate 0.00001 `
        --max_length 256 `
        --max_anchors_per_target 100 `
        --hard_negatives 2 `
        --random_negatives 1 `
        --hard_negative_strategy hybrid `
        --prototype_examples 2 `
        --nearest_candidates 15 `
        --eval_rows_per_target 100 `
        --eval_candidates 10 `
        --bootstrap_samples 0 `
        --loss_type $Loss `
        --listwise_mini_batch_size 2 `
        --progress_every 1024 `
        --offline

    if ($LASTEXITCODE -ne 0) {
        throw "$Loss listwise smoke test failed with exit code $LASTEXITCODE"
    }

    $Report = Join-Path $Out "domain_reranker_training_report.json"
    if (-not (Test-Path $Report)) { throw "$Loss completed without creating report: $Report" }
    $Json = Get-Content $Report -Raw | ConvertFrom-Json
    Write-Host "$Loss PASSED. training_query_lists_total=$($Json.training_query_lists_total)" -ForegroundColor Green
}

Write-Host "" 
Write-Host "All three listwise loss smoke tests passed." -ForegroundColor Green
Write-Host "Resume the battery with 02_RESUME_COMPREHENSIVE_RERANKER_BATTERY.ps1." -ForegroundColor Green
