NAICS/SOC Reranker Battery V2.4.1 - Listwise Loss Fix
=====================================================

Root cause
----------
The V2.4 trainer created a local variable named `pairs` only in the BCE
branch. RankNet, ListNet and LambdaLoss use the listwise branch, which creates
`list_rows` instead. A later metadata line always referenced `pairs`, causing:

    UnboundLocalError: cannot access local variable 'pairs'

This was a bookkeeping bug before model training. The listwise data schema was
otherwise designed correctly as query + list of docs + list of labels.

Fixes
-----
1. Uses a common `target_rows` variable for BCE and listwise data.
2. Records `training_pairs` only for BCE.
3. Records `training_query_lists` for RankNet/ListNet/LambdaLoss.
4. Validates every generated dataset before expensive evaluation/training.
5. Adds `training_query_lists_total` to the final JSON report.
6. Adds a three-loss smoke test script:

       10_VERIFY_LISTWISE_LOSSES_AFTER_FIX.ps1

How to apply
------------
Extract the flat patch ZIP into C:\laborshed_autocode_clean with overwrite.
No SAV files, completed experiments, checkpoints, caches or Gold files need to
be recreated.

Recommended sequence
--------------------
1. Stop/pause the current battery with Ctrl+C once.
2. Extract the patch with overwrite.
3. Run:

       .\10_VERIFY_LISTWISE_LOSSES_AFTER_FIX.ps1

4. After RankNet, ListNet and LambdaLoss all pass, resume the same profile:

       .\02_RESUME_COMPREHENSIVE_RERANKER_BATTERY.ps1 -Profile standard

   Change `standard` to the profile you originally used.

The battery skips experiments that already have a completed
`domain_reranker_training_report.json`. Failed experiments have no completed
report, so they will be rerun automatically after the patch.

To rerun only the loss-function stage:

    .\06_RUN_ONE_BATTERY_STAGE.ps1 -Profile standard -Stage 05_loss

For marathon large-listwise experiments:

    .\06_RUN_ONE_BATTERY_STAGE.ps1 -Profile marathon -Stage 13_listwise_large
