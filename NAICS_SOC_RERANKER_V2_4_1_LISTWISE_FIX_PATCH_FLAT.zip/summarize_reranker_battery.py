#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

VERSION = "2026.07.15.comprehensive-reranker-battery-summary-v4.1-listwise-fix"


def f(value: Any, default: float = float("nan")) -> float:
    try:
        return float(value)
    except Exception:
        return default


def mean(values: Sequence[float]) -> float:
    clean = [x for x in values if math.isfinite(x)]
    return statistics.mean(clean) if clean else float("nan")


def sd(values: Sequence[float]) -> float:
    clean = [x for x in values if math.isfinite(x)]
    return statistics.pstdev(clean) if len(clean) > 1 else 0.0


def safe_get(d: Mapping[str, Any], path: Sequence[str], default: Any = None) -> Any:
    cur: Any = d
    for key in path:
        if not isinstance(cur, Mapping) or key not in cur:
            return default
        cur = cur[key]
    return cur


def recipe_key(config: Mapping[str, Any]) -> str:
    keys = [
        "stage", "name", "targets", "base_model", "loss_type", "learning_rate",
        "hard_negatives", "random_negatives", "hard_negative_strategy",
        "prototype_examples", "nearest_candidates", "context_profile",
        "anchor_sampling", "weak_group_multiplier", "max_length",
        "anchors", "steps", "train_batch_size", "gradient_accumulation_steps",
    ]
    return "|".join(f"{k}={config.get(k)}" for k in keys)


def flatten_reports(root: Path) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    report_dirs = sorted(root.glob("*/experiment_config.json"))
    for cfg_path in report_dirs:
        config = json.loads(cfg_path.read_text(encoding="utf-8"))
        report_path = cfg_path.parent / "domain_reranker_training_report.json"
        if not report_path.exists():
            failures.append({
                "experiment_id": config.get("experiment_id", cfg_path.parent.name),
                "stage": config.get("stage"), "targets": config.get("targets"),
                "reason": "missing_training_report",
            })
            continue
        try:
            report = json.loads(report_path.read_text(encoding="utf-8"))
        except Exception as exc:
            failures.append({
                "experiment_id": config.get("experiment_id", cfg_path.parent.name),
                "stage": config.get("stage"), "targets": config.get("targets"),
                "reason": f"invalid_report:{exc}",
            })
            continue
        oracle = report.get("paired_comparison", {})
        retrieval = report.get("paired_comparison_retrieval", {})
        recalls = report.get("retrieval_candidate_recall", {})
        base_ret = report.get("base_metrics_retrieval", {})
        tuned_ret = report.get("tuned_metrics_retrieval", {})
        for target, cmp in oracle.items():
            ret_cmp = retrieval.get(target, {})
            recall = recalls.get(target, {})
            row = {
                "experiment_id": config.get("experiment_id", cfg_path.parent.name),
                "recipe_key": recipe_key(config),
                "stage": config.get("stage"), "name": config.get("name"),
                "targets": config.get("targets"), "target": target,
                "seed": int(config.get("seed", -1)),
                "base_model": config.get("base_model"), "loss_type": config.get("loss_type"),
                "context_profile": config.get("context_profile"),
                "hard_negative_strategy": config.get("hard_negative_strategy"),
                "hard_negatives": config.get("hard_negatives"), "random_negatives": config.get("random_negatives"),
                "anchors": config.get("anchors"), "steps": config.get("steps"),
                "learning_rate": config.get("learning_rate"), "max_length": config.get("max_length"),
                "prototype_examples": config.get("prototype_examples"),
                "nearest_candidates": config.get("nearest_candidates"),
                "anchor_sampling": config.get("anchor_sampling"),
                "weak_group_multiplier": config.get("weak_group_multiplier"),
                "training_seconds": f(report.get("training_seconds"), 0.0),
                "oracle_top1_base": f(safe_get(cmp, ["top1", "base"])),
                "oracle_top1_tuned": f(safe_get(cmp, ["top1", "tuned"])),
                "oracle_top1_diff": f(safe_get(cmp, ["top1", "difference"])),
                "oracle_top1_ci_low": f((safe_get(cmp, ["top1", "bootstrap_95_ci"], [None, None]) or [None, None])[0]),
                "oracle_top1_ci_high": f((safe_get(cmp, ["top1", "bootstrap_95_ci"], [None, None]) or [None, None])[1]),
                "oracle_top4_diff": f(safe_get(cmp, ["top4", "difference"])),
                "oracle_mrr_diff": f(safe_get(cmp, ["mrr", "difference"])),
                "oracle_mrr_ci_low": f((safe_get(cmp, ["mrr", "bootstrap_95_ci"], [None, None]) or [None, None])[0]),
                "oracle_mrr_ci_high": f((safe_get(cmp, ["mrr", "bootstrap_95_ci"], [None, None]) or [None, None])[1]),
                "oracle_exact_p": f(safe_get(cmp, ["top1_paired", "exact_two_sided_p"])),
                "retrieval_top1_base": f(safe_get(base_ret, [target, "top1"])),
                "retrieval_top1_tuned": f(safe_get(tuned_ret, [target, "top1"])),
                "retrieval_top1_diff": f(safe_get(ret_cmp, ["top1", "difference"])),
                "retrieval_top4_diff": f(safe_get(ret_cmp, ["top4", "difference"])),
                "retrieval_mrr_diff": f(safe_get(ret_cmp, ["mrr", "difference"])),
                "candidate_recall_at_1": f(recall.get("recall_at_1")),
                "candidate_recall_at_4": f(recall.get("recall_at_4")),
                "candidate_recall_at_10": f(recall.get("recall_at_10")),
                "candidate_recall_at_20": f(recall.get("recall_at_20")),
                "candidate_recall_at_40": f(recall.get("recall_at_40")),
            }
            row["selection_score"] = (
                0.35 * row["oracle_top1_diff"] + 0.30 * row["oracle_mrr_diff"] +
                0.10 * row["oracle_top4_diff"] + 0.15 * row["retrieval_top1_diff"] +
                0.10 * row["retrieval_mrr_diff"]
            )
            rows.append(row)
    return rows, failures


def aggregate(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["recipe_key"], row["target"])].append(row)
    out: List[Dict[str, Any]] = []
    for (recipe, target), values in groups.items():
        first = values[0]
        record = {
            "recipe_key": recipe, "target": target, "runs": len(values),
            "stage": first["stage"], "name": first["name"], "targets": first["targets"],
            "base_model": first["base_model"], "loss_type": first["loss_type"],
            "context_profile": first["context_profile"],
            "hard_negative_strategy": first["hard_negative_strategy"],
            "hard_negatives": first["hard_negatives"], "random_negatives": first["random_negatives"],
            "anchors": first["anchors"], "steps": first["steps"],
            "learning_rate": first["learning_rate"], "max_length": first["max_length"],
            "prototype_examples": first["prototype_examples"],
            "nearest_candidates": first["nearest_candidates"],
            "anchor_sampling": first["anchor_sampling"],
            "weak_group_multiplier": first["weak_group_multiplier"],
            "seeds": ",".join(str(v["seed"]) for v in values),
            "mean_oracle_top1_diff": mean([v["oracle_top1_diff"] for v in values]),
            "sd_oracle_top1_diff": sd([v["oracle_top1_diff"] for v in values]),
            "mean_oracle_top4_diff": mean([v["oracle_top4_diff"] for v in values]),
            "mean_oracle_mrr_diff": mean([v["oracle_mrr_diff"] for v in values]),
            "mean_retrieval_top1_diff": mean([v["retrieval_top1_diff"] for v in values]),
            "mean_retrieval_top4_diff": mean([v["retrieval_top4_diff"] for v in values]),
            "mean_retrieval_mrr_diff": mean([v["retrieval_mrr_diff"] for v in values]),
            "mean_candidate_recall_at_20": mean([v["candidate_recall_at_20"] for v in values]),
            "mean_candidate_recall_at_40": mean([v["candidate_recall_at_40"] for v in values]),
            "positive_top1_runs": sum(v["oracle_top1_diff"] > 0 for v in values),
            "positive_mrr_runs": sum(v["oracle_mrr_diff"] > 0 for v in values),
            "mean_selection_score": mean([v["selection_score"] for v in values]),
            "mean_training_minutes": mean([v["training_seconds"] / 60.0 for v in values]),
        }
        required = max(1, math.ceil(len(values) / 2))
        if (
            record["mean_oracle_top1_diff"] > 0
            and record["mean_oracle_mrr_diff"] > 0
            and record["mean_oracle_top4_diff"] >= -0.005
            and record["positive_top1_runs"] >= required
            and record["positive_mrr_runs"] >= required
        ):
            record["decision"] = "PROMISING"
        elif record["mean_oracle_top1_diff"] < 0 and record["mean_oracle_mrr_diff"] < 0:
            record["decision"] = "REJECT"
        else:
            record["decision"] = "MIXED"
        out.append(record)
    return sorted(out, key=lambda x: (x["target"], -x["mean_selection_score"]))


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def recommendations(aggregates: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    by_target: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in aggregates:
        by_target[row["target"]].append(row)
    result: Dict[str, Any] = {}
    for target, values in by_target.items():
        ranked = sorted(values, key=lambda x: x["mean_selection_score"], reverse=True)
        promising = [r for r in ranked if r["decision"] == "PROMISING"]
        result[target] = {
            "recommended_recipe": promising[0] if promising else (ranked[0] if ranked else None),
            "top_five": ranked[:5],
            "candidate_generation_diagnosis": (
                "candidate_generation_is_limiting" if ranked and ranked[0]["mean_candidate_recall_at_20"] < 0.90
                else "candidate_ranking_is_primary"
            ),
        }
    return result


def markdown_summary(root: Path, rows: Sequence[Dict[str, Any]], aggregates: Sequence[Dict[str, Any]], failures: Sequence[Dict[str, Any]], recs: Mapping[str, Any]) -> str:
    lines = [
        "# Comprehensive NAICS/SOC Reranker Battery", "",
        f"Summary version: `{VERSION}`", "",
        f"Completed target-level results: {len(rows)}", f"Incomplete/failed experiments: {len(failures)}", "",
    ]
    for target in ("qa20a", "qe4ar", "qe5ar"):
        item = recs.get(target, {})
        lines += [f"## {target}", ""]
        best = item.get("recommended_recipe")
        if not best:
            lines += ["No completed result.", ""]
            continue
        lines += [
            f"- Diagnosis: **{item.get('candidate_generation_diagnosis')}**",
            f"- Recommended recipe decision: **{best.get('decision')}**",
            f"- Stage/name: `{best.get('stage')}/{best.get('name')}`",
            f"- Loss: `{best.get('loss_type')}`; base model: `{best.get('base_model')}`",
            f"- Mean oracle top-1 change: {100*best.get('mean_oracle_top1_diff',0):+.2f} pp",
            f"- Mean oracle top-4 change: {100*best.get('mean_oracle_top4_diff',0):+.2f} pp",
            f"- Mean oracle MRR change: {100*best.get('mean_oracle_mrr_diff',0):+.2f} pp",
            f"- Mean retrieval-pipeline top-1 change: {100*best.get('mean_retrieval_top1_diff',0):+.2f} pp",
            f"- Candidate recall@20: {100*best.get('mean_candidate_recall_at_20',0):.2f}%",
            f"- Runs/seeds: {best.get('runs')} / {best.get('seeds')}", "",
            "Top recipes:", "",
            "| Rank | Stage/name | Loss | ΔTop-1 | ΔTop-4 | ΔMRR | Retrieval ΔTop-1 | Decision |",
            "|---:|---|---|---:|---:|---:|---:|---|",
        ]
        for rank, row in enumerate(item.get("top_five", []), 1):
            lines.append(
                f"| {rank} | {row['stage']}/{row['name']} | {row['loss_type']} | "
                f"{100*row['mean_oracle_top1_diff']:+.2f} | {100*row['mean_oracle_top4_diff']:+.2f} | "
                f"{100*row['mean_oracle_mrr_diff']:+.2f} | {100*row['mean_retrieval_top1_diff']:+.2f} | {row['decision']} |"
            )
        lines.append("")
    if failures:
        lines += ["## Failures / incomplete experiments", ""]
        for row in failures[:50]:
            lines.append(f"- `{row.get('experiment_id')}`: {row.get('reason')}")
        lines.append("")
    lines += [
        "## Next action", "",
        "Use the recommended target-specific recipes for a larger multi-seed confirmatory run, then plug only the winners into the audited Gold end-to-end autocoder. Do not promote a recipe solely because one seed improved.", "",
    ]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--profile", choices=["smoke", "standard", "exhaustive", "marathon"], default="standard")
    ap.add_argument("--root", default="")
    ap.add_argument("--output_label", default="")
    args = ap.parse_args()
    base = Path(args.base)
    root = Path(args.root) if args.root else base / "models" / f"reranker_battery_{args.profile}"
    label = args.output_label.strip() or args.profile
    out = base / "reranker_battery_reports" / label
    out.mkdir(parents=True, exist_ok=True)

    rows, failures = flatten_reports(root)
    aggregates = aggregate(rows)
    recs = recommendations(aggregates)
    write_csv(out / "battery_run_results.csv", rows)
    write_csv(out / "battery_recipe_summary.csv", aggregates)
    write_csv(out / "battery_failures.csv", failures)
    summary = {
        "version": VERSION, "profile": args.profile, "root": str(root),
        "completed_target_results": len(rows), "failures": len(failures),
        "recommendations": recs,
    }
    (out / "battery_summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    md = markdown_summary(root, rows, aggregates, failures, recs)
    (out / "battery_summary.md").write_text(md, encoding="utf-8")

    upload_zip = out / "CHAT_UPLOAD_RERANKER_BATTERY.zip"
    with zipfile.ZipFile(upload_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in ("battery_summary.md", "battery_summary.json", "battery_run_results.csv", "battery_recipe_summary.csv", "battery_failures.csv"):
            path = out / name
            if path.exists():
                zf.write(path, arcname=name)
        manifest = root / "battery_manifest.json"
        status = root / "battery_status.json"
        if manifest.exists(): zf.write(manifest, arcname="battery_manifest.json")
        if status.exists(): zf.write(status, arcname="battery_status.json")
        # Reports contain aggregate settings/metrics but no raw survey text.
        for report in sorted(root.glob("*/domain_reranker_training_report.json")):
            zf.write(report, arcname=f"experiment_reports/{report.parent.name}.json")

    print(md)
    print(f"\nCSV results: {out / 'battery_run_results.csv'}")
    print(f"Recipe summary: {out / 'battery_recipe_summary.csv'}")
    print(f"Chat upload ZIP: {upload_zip}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
