#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

VERSION = "2026.07.15.comprehensive-reranker-battery-v4.1-listwise-fix"


@dataclass(frozen=True)
class Experiment:
    stage: str
    name: str
    targets: str
    seed: int = 42
    base_model: str = "cross-encoder/ms-marco-MiniLM-L6-v2"
    loss_type: str = "bce"
    anchors: int = 1500
    steps: int = 100
    learning_rate: float = 1e-5
    hard_negatives: int = 3
    random_negatives: int = 1
    hard_negative_strategy: str = "hybrid"
    prototype_examples: int = 3
    nearest_candidates: int = 30
    context_profile: str = "full"
    anchor_sampling: str = "balanced"
    weak_group_multiplier: int = 2
    max_length: int = 384
    eval_rows: int = 2000
    eval_candidates: int = 20
    train_batch_size: int = 4
    eval_batch_size: int = 32
    gradient_accumulation_steps: int = 8
    listwise_mini_batch_size: int = 8
    bootstrap_samples: int = 1000
    tags: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def target_label(self) -> str:
        return self.targets.replace(",", "_")

    @property
    def experiment_id(self) -> str:
        raw = f"{self.stage}__{self.name}__{self.target_label}__seed{self.seed}"
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", raw)[:180]


def target_defaults(targets: str) -> Tuple[int, int]:
    if targets == "qa20a":
        return 1500, 100
    if "," in targets:
        return 3000, 200
    return 3000, 200


def base_experiment(target: str, seed: int = 42, stage: str = "01_seed", name: str = "baseline") -> Experiment:
    anchors, steps = target_defaults(target)
    return Experiment(stage=stage, name=name, targets=target, seed=seed, anchors=anchors, steps=steps)


def dedupe(experiments: Sequence[Experiment]) -> List[Experiment]:
    seen: set[str] = set()
    out: List[Experiment] = []
    for exp in experiments:
        if exp.experiment_id not in seen:
            seen.add(exp.experiment_id)
            out.append(exp)
    return out


def generate_experiments(profile: str, seeds: Sequence[int], include_optional_models: bool) -> List[Experiment]:
    profile = profile.lower()
    targets = ["qa20a", "qe4ar", "qe5ar"]
    exps: List[Experiment] = []

    # Stage 1: seed stability for the current recipe.
    for target in targets:
        for seed in seeds[: (5 if profile == "marathon" else 3)]:
            exps.append(base_experiment(target, seed, "01_seed", "baseline_bce"))

    if profile == "smoke":
        return dedupe(exps)

    # Stage 2: learning-rate screen.
    for target in targets:
        for lr in (5e-6, 2e-5):
            exps.append(replace(base_experiment(target, 42), stage="02_lr", name=f"lr_{lr:g}", learning_rate=lr))

    # Stage 3: hard-negative composition and strategy.
    negative_recipes = [
        (2, 2, "hybrid", "hard2_random2"),
        (4, 1, "hybrid", "hard4_random1"),
        (6, 1, "hybrid", "hard6_random1"),
        (4, 1, "semantic", "semantic_only"),
        (4, 1, "hierarchy", "hierarchy_only"),
    ]
    for target in targets:
        for hard, random_n, strategy, label in negative_recipes:
            exps.append(replace(
                base_experiment(target, 42), stage="03_negatives", name=label,
                hard_negatives=hard, random_negatives=random_n,
                hard_negative_strategy=strategy,
            ))

    # Stage 4: context-field ablations.
    context_by_target = {
        "qa20a": ["compact", "title_only", "no_employer", "no_location"],
        "qe4ar": ["compact", "title_only", "no_employer", "no_location", "no_naics"],
        "qe5ar": ["compact", "title_only", "no_employer", "no_location", "no_naics"],
    }
    for target in targets:
        for context in context_by_target[target]:
            exps.append(replace(base_experiment(target, 42), stage="04_context", name=context, context_profile=context))

    # Stage 5: loss-function screen. Listwise recipes use smaller per-device batches.
    for target in targets:
        for loss in ("ranknet", "listnet", "lambda"):
            exps.append(replace(
                base_experiment(target, 42), stage="05_loss", name=loss,
                loss_type=loss, train_batch_size=1, gradient_accumulation_steps=32,
                listwise_mini_batch_size=4,
            ))

    # Stage 6: training-budget and sample-size screen.
    for target in targets:
        a0, s0 = target_defaults(target)
        exps.extend([
            replace(base_experiment(target, 42), stage="06_budget", name="small_budget", anchors=max(750, a0 // 2), steps=max(50, s0 // 2)),
            replace(base_experiment(target, 42), stage="06_budget", name="medium_budget", anchors=a0 * 2, steps=s0 * 2),
            replace(base_experiment(target, 42), stage="06_budget", name="large_budget", anchors=a0 * 4, steps=s0 * 3),
        ])

    # Stage 7: sequence length.
    for target in targets:
        for length in (256, 512):
            exps.append(replace(base_experiment(target, 42), stage="07_length", name=f"maxlen_{length}", max_length=length))

    # Stage 8: prototype and retrieval-pool design.
    for target in targets:
        for proto in (1, 5, 8):
            exps.append(replace(base_experiment(target, 42), stage="08_prototypes", name=f"prototype_{proto}", prototype_examples=proto))
        for nearest in (20, 50, 80):
            exps.append(replace(base_experiment(target, 42), stage="08_retrieval", name=f"nearest_{nearest}", nearest_candidates=nearest))

    # Stage 9: class-sampling and weak-group emphasis.
    for target in targets:
        exps.append(replace(base_experiment(target, 42), stage="09_sampling", name="frequency_sampling", anchor_sampling="frequency"))
        if target != "qa20a":
            for multiplier in (1, 4, 6):
                exps.append(replace(base_experiment(target, 42), stage="09_weak", name=f"weak_multiplier_{multiplier}", weak_group_multiplier=multiplier))

    # Stage 10: shared-versus-target-specific transfer tests.
    for seed in seeds[:3]:
        a, st = target_defaults("qe4ar,qe5ar")
        exps.append(Experiment(stage="10_shared", name="soc_shared", targets="qe4ar,qe5ar", seed=seed, anchors=a, steps=st))
        a, st = target_defaults("qa20a,qe4ar,qe5ar")
        exps.append(Experiment(stage="10_shared", name="all_targets_shared", targets="qa20a,qe4ar,qe5ar", seed=seed, anchors=a, steps=st))

    if profile in {"exhaustive", "marathon"}:
        # Additional learning rates, more negative ratios, and longer fixed budgets.
        for target in targets:
            for lr in (2.5e-6, 7.5e-6, 1.5e-5, 3e-5):
                exps.append(replace(base_experiment(target, 43), stage="11_deep_lr", name=f"lr_{lr:g}", learning_rate=lr))
            for hard, random_n in ((1, 3), (8, 1), (6, 2)):
                exps.append(replace(base_experiment(target, 43), stage="11_deep_neg", name=f"hard{hard}_random{random_n}", hard_negatives=hard, random_negatives=random_n))
            a0, s0 = target_defaults(target)
            exps.append(replace(base_experiment(target, 43), stage="11_deep_budget", name="xlarge_budget", anchors=a0 * 6, steps=s0 * 5, eval_rows=3000, bootstrap_samples=2000))

        # Base-model comparison. These models must be cached before offline use.
        if include_optional_models:
            for target in targets:
                for model, label in (
                    ("cross-encoder/ms-marco-MiniLM-L12-v2", "minilm_l12"),
                    ("BAAI/bge-reranker-base", "bge_reranker_base"),
                ):
                    exps.append(replace(base_experiment(target, 42), stage="12_base_model", name=label, base_model=model))

    if profile == "marathon":
        # More seed replication for sensitivity, plus larger listwise tests.
        extra_seeds = [s for s in seeds if s not in seeds[:3]] or [45, 46]
        for target in targets:
            for seed in extra_seeds:
                exps.append(base_experiment(target, seed, "13_extra_seeds", "baseline_bce"))
            for loss in ("ranknet", "listnet", "lambda"):
                a0, s0 = target_defaults(target)
                exps.append(replace(
                    base_experiment(target, 44), stage="13_listwise_large", name=f"{loss}_large",
                    loss_type=loss, anchors=a0 * 3, steps=s0 * 3,
                    train_batch_size=1, gradient_accumulation_steps=32, listwise_mini_batch_size=4,
                    eval_rows=3000, bootstrap_samples=2000,
                ))

    return dedupe(exps)


def read_report_metrics(report_path: Path) -> Dict[str, Any]:
    try:
        return json.loads(report_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def metric_line(report: Dict[str, Any]) -> str:
    paired = report.get("paired_comparison", {})
    retrieval = report.get("paired_comparison_retrieval", {})
    parts: List[str] = []
    for target in sorted(paired):
        p = paired[target]
        r = retrieval.get(target, {})
        parts.append(
            f"{target}: oracle Δtop1={100*p.get('top1',{}).get('difference',0):+.2f}pp "
            f"ΔMRR={100*p.get('mrr',{}).get('difference',0):+.2f}pp; "
            f"retrieval Δtop1={100*r.get('top1',{}).get('difference',0):+.2f}pp"
        )
    return " | ".join(parts)


def gpu_snapshot() -> str:
    try:
        cp = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=8,
        )
        if cp.returncode == 0 and cp.stdout.strip():
            vals = [x.strip() for x in cp.stdout.strip().splitlines()[0].split(",")]
            if len(vals) >= 5:
                return f"GPU util={vals[0]}% mem={vals[1]}/{vals[2]}MiB temp={vals[3]}C power={vals[4]}W"
    except Exception:
        pass
    return "GPU telemetry unavailable"


def process_snapshot(pid: int) -> str:
    try:
        import psutil
        p = psutil.Process(pid)
        return f"RSS={p.memory_info().rss/1024**3:.2f}GB CPU={p.cpu_percent(interval=None):.1f}%"
    except Exception:
        return ""


def run_experiment(
    exp: Experiment,
    python_exe: Path,
    trainer: Path,
    fit_sav: Path,
    cal_sav: Path,
    root: Path,
    logs_root: Path,
    resume: bool,
) -> Tuple[str, int, float]:
    output_dir = root / exp.experiment_id
    log_path = logs_root / f"{exp.experiment_id}.log"
    report_path = output_dir / "domain_reranker_training_report.json"
    if report_path.exists():
        report = read_report_metrics(report_path)
        print(f"[SKIP COMPLETE] {exp.experiment_id} | {metric_line(report)}", flush=True)
        return "complete", 0, float(report.get("training_seconds", 0.0) or 0.0)

    output_dir.mkdir(parents=True, exist_ok=True)
    logs_root.mkdir(parents=True, exist_ok=True)
    command = [
        str(python_exe), "-u", str(trainer),
        "--fit_sav", str(fit_sav),
        "--calibration_sav", str(cal_sav),
        "--output_dir", str(output_dir),
        "--targets", exp.targets,
        "--base_model", exp.base_model,
        "--device", "cuda",
        "--embedding_batch_size", "16",
        "--train_batch_size", str(exp.train_batch_size),
        "--eval_batch_size", str(exp.eval_batch_size),
        "--gradient_accumulation_steps", str(exp.gradient_accumulation_steps),
        "--epochs", "1.0",
        "--max_update_steps", str(exp.steps),
        "--learning_rate", str(exp.learning_rate),
        "--max_length", str(exp.max_length),
        "--max_anchors_per_target", str(exp.anchors),
        "--hard_negatives", str(exp.hard_negatives),
        "--random_negatives", str(exp.random_negatives),
        "--hard_negative_strategy", exp.hard_negative_strategy,
        "--prototype_examples", str(exp.prototype_examples),
        "--nearest_candidates", str(exp.nearest_candidates),
        "--eval_rows_per_target", str(exp.eval_rows),
        "--eval_candidates", str(exp.eval_candidates),
        "--warmup_fraction", "0.10",
        "--progress_every", "1024",
        "--bootstrap_samples", str(exp.bootstrap_samples),
        "--seed", str(exp.seed),
        "--loss_type", exp.loss_type,
        "--listwise_mini_batch_size", str(exp.listwise_mini_batch_size),
        "--context_profile", exp.context_profile,
        "--anchor_sampling", exp.anchor_sampling,
        "--weak_group_multiplier", str(exp.weak_group_multiplier),
        "--retrieval_recall_ks", "1,4,10,20,40",
        "--offline",
    ]
    checkpoint_dir = output_dir / "checkpoints"
    if resume and checkpoint_dir.exists() and any(checkpoint_dir.glob("checkpoint-*")):
        command.extend(["--resume_from_checkpoint", "auto"])

    metadata = asdict(exp)
    metadata.update({"experiment_id": exp.experiment_id, "command": command, "version": VERSION})
    (output_dir / "experiment_config.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    print("\n" + "=" * 94, flush=True)
    print(f"EXPERIMENT {exp.experiment_id}", flush=True)
    print(
        f"stage={exp.stage} targets={exp.targets} seed={exp.seed} loss={exp.loss_type} "
        f"base={exp.base_model} anchors={exp.anchors} steps={exp.steps} lr={exp.learning_rate:g}",
        flush=True,
    )
    print(
        f"context={exp.context_profile} negatives={exp.hard_negative_strategy}:{exp.hard_negatives}+{exp.random_negatives} "
        f"prototype={exp.prototype_examples} nearest={exp.nearest_candidates} maxlen={exp.max_length}",
        flush=True,
    )
    print(f"output={output_dir}\nlog={log_path}", flush=True)
    print("=" * 94, flush=True)

    env = os.environ.copy()
    env.update({
        "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
        "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
        "HF_HUB_DISABLE_PROGRESS_BARS": "1", "CUDA_VISIBLE_DEVICES": "0",
        "TOKENIZERS_PARALLELISM": "false", "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
    })
    started = time.time()
    with log_path.open("a", encoding="utf-8", buffering=1) as log:
        log.write("\n" + " ".join(command) + "\n")
        proc = subprocess.Popen(
            command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1, env=env,
        )
        q: queue.Queue[Optional[str]] = queue.Queue()

        def reader() -> None:
            assert proc.stdout is not None
            for line in proc.stdout:
                q.put(line)
            q.put(None)

        thread = threading.Thread(target=reader, daemon=True)
        thread.start()
        last_output = time.time()
        last_heartbeat = 0.0
        stream_done = False
        try:
            while True:
                try:
                    item = q.get(timeout=5)
                    if item is None:
                        stream_done = True
                    else:
                        print(item, end="", flush=True)
                        log.write(item)
                        last_output = time.time()
                except queue.Empty:
                    pass
                now = time.time()
                if now - last_heartbeat >= 60:
                    heartbeat = (
                        f"[BATTERY HEARTBEAT] experiment={exp.experiment_id} elapsed={(now-started)/60:.1f}m "
                        f"quiet_for={(now-last_output)/60:.1f}m {gpu_snapshot()} {process_snapshot(proc.pid)}"
                    )
                    print(heartbeat, flush=True)
                    log.write(heartbeat + "\n")
                    last_heartbeat = now
                if proc.poll() is not None and stream_done and q.empty():
                    break
        except KeyboardInterrupt:
            print("\n[BATTERY] Interrupt received; terminating active experiment after checkpoint opportunity...", flush=True)
            try:
                proc.send_signal(2)
                proc.wait(timeout=20)
            except Exception:
                proc.terminate()
            raise
        code = int(proc.wait())
    elapsed = time.time() - started
    if code == 0 and report_path.exists():
        report = read_report_metrics(report_path)
        print(f"[COMPLETE] {exp.experiment_id} elapsed={elapsed/3600:.2f}h | {metric_line(report)}", flush=True)
        return "complete", code, elapsed
    print(f"[FAILED] {exp.experiment_id} exit={code} elapsed={elapsed/3600:.2f}h; continuing to next experiment", flush=True)
    return "failed", code, elapsed


def write_status(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.write_text(json.dumps({"version": VERSION, "updated": time.strftime("%Y-%m-%d %H:%M:%S"), "experiments": list(rows)}, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="Run a resumable comprehensive NAICS/SOC Cross-Encoder experiment battery")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--profile", choices=["smoke", "standard", "exhaustive", "marathon"], default="standard")
    ap.add_argument("--seeds", default="42,43,44,45,46")
    ap.add_argument("--include_optional_models", action="store_true")
    ap.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--continue_on_error", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--only_stage", default="")
    ap.add_argument("--max_experiments", type=int, default=0)
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()

    base = Path(args.base)
    python_exe = base / ".venv" / "Scripts" / "python.exe"
    trainer = base / "train_domain_cross_encoder_battery.py"
    fit_sav = base / "training_FIT.sav"
    cal_sav = base / "training_CALIBRATION.sav"
    missing = [str(p) for p in (python_exe, trainer, fit_sav, cal_sav) if not p.exists()]
    if missing:
        raise FileNotFoundError("Required battery files missing:\n" + "\n".join(missing))

    seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]
    experiments = generate_experiments(args.profile, seeds, args.include_optional_models)
    if args.only_stage:
        experiments = [e for e in experiments if e.stage == args.only_stage]
    if args.max_experiments > 0:
        experiments = experiments[: args.max_experiments]

    root = base / "models" / f"reranker_battery_{args.profile}"
    logs_root = base / "logs" / f"reranker_battery_{args.profile}"
    root.mkdir(parents=True, exist_ok=True)
    logs_root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "version": VERSION, "profile": args.profile, "base": str(base),
        "experiment_count": len(experiments), "experiments": [asdict(e) | {"experiment_id": e.experiment_id} for e in experiments],
    }
    (root / "battery_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"Comprehensive reranker battery {VERSION}")
    print(f"profile={args.profile} experiments={len(experiments)} resume={args.resume}")
    print(f"results={root}")
    print(f"logs={logs_root}")
    if args.dry_run:
        for i, exp in enumerate(experiments, 1):
            print(f"{i:03d}. {exp.experiment_id}")
        return 0

    status_rows: List[Dict[str, Any]] = []
    status_path = root / "battery_status.json"
    for index, exp in enumerate(experiments, 1):
        print(f"\n[BATTERY] {index}/{len(experiments)} starting {exp.experiment_id}", flush=True)
        try:
            state, code, elapsed = run_experiment(exp, python_exe, trainer, fit_sav, cal_sav, root, logs_root, args.resume)
        except KeyboardInterrupt:
            status_rows.append({"experiment_id": exp.experiment_id, "state": "interrupted", "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")})
            write_status(status_path, status_rows)
            print("[BATTERY] Interrupted. Rerun the same command to resume/skip completed experiments.", flush=True)
            return 130
        except Exception as exc:
            state, code, elapsed = "failed", 1, 0.0
            print(f"[BATTERY ERROR] {exp.experiment_id}: {exc}", flush=True)
            if not args.continue_on_error:
                raise
        status_rows.append({
            "experiment_id": exp.experiment_id, "stage": exp.stage, "targets": exp.targets,
            "state": state, "exit_code": code, "elapsed_seconds": elapsed,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        write_status(status_path, status_rows)

    print("\n[BATTERY] All scheduled experiments processed.")
    print(f"Run the summarizer against: {root}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[FATAL] Battery runner failed: {exc}", file=sys.stderr, flush=True)
        raise
