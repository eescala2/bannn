param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Root = Join-Path $Base "models\v3_interactions_confirm"
$Out = Join-Path $Base "v3_interaction_reports\confirm"
New-Item -ItemType Directory -Path $Out -Force | Out-Null
& $Python -u (Join-Path $Base "summarize_v3_targeted_interactions.py") --root $Root --out_dir $Out --top_n 1
if ($LASTEXITCODE -ne 0) { throw "V3 confirmatory summary failed." }
Write-Host "Confirmed winner manifest: $Out\winner_manifest.json" -ForegroundColor Green
