param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [int]$Seed = 777,
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V3.ps1') -Base $Base
$Winner = Join-Path $Base "v3_interaction_reports\confirm\winner_manifest.json"
if (-not (Test-Path $Winner)) { throw "Run the confirmatory summary first. Missing: $Winner" }
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$argsList = @('-u',(Join-Path $Base 'train_v3_final_rerankers.py'),'--base',$Base,'--winner_manifest',$Winner,'--seed',[string]$Seed)
if ($DryRun) { $argsList += '--dry_run' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "Final V3 reranker build failed." }
