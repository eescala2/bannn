# Build Validation

The package was validated before ZIP creation using the tools available in the build environment.

## Completed checks

- Python syntax compilation for every `.py` file.
- Dry-run generation of the 72-experiment screening manifest.
- Synthetic end-to-end test of the interaction summarizer, winner manifest, CSV outputs, Markdown summary, and chat-upload ZIP.
- Dry-run test of final target-specific reranker command construction and production manifest creation.
- Synthetic storage-manager test confirming that completed experiment weights/checkpoints are pruned while incomplete checkpoints are retained.
- Static verification of target-specific prototype-retrieval CLI arguments and production runner wiring.

## Environment limitations

The build environment does not contain the user's SPSS `.sav` files, Windows PowerShell, the project virtual environment, or the RTX 2050 CUDA stack. Therefore, the following must be verified on the target laptop using the included preflight and dry-run scripts:

- real SAV read/write;
- real CUDA model loading and training;
- PowerShell syntax execution;
- target-specific final reranker training;
- full sealed-Gold audit.

Use:

```powershell
.\00_PREFLIGHT_V3.ps1
.\12_DRY_RUN_V3_MANIFEST.ps1
```

before launching the full pipeline.
