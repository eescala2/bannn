#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import queue
import re
import signal
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

VERSION = "2026.07.19.targeted-interaction-battery-v3.1"


@dataclass(frozen=True)
class Experiment:
    target: str
    name: str
    retrieval_profiles: str
    retrieval_prototypes: int
    rerank_profile: str
    rerank_prototypes: int
    loss: str
    lr: float
    anchors: int
    steps: int
    sampling: str
    weak_multiplier: int
    seed: int
    candidate_sources: str = "semantic,lexical,memory"
    semantic_per_profile: int = 50
    lexical_candidates: int = 30
    union_limit: int = 60
    max_length: int = 384
    hard_negatives: int = 3
    random_negatives: int = 1
    strategy: str = "hybrid"
    eval_rows: int = 4000
    eval_candidates: int = 40

    @property
    def candidate_name(self) -> str:
        p = self.retrieval_profiles.replace(",", "+")
        return f"ctx-{p}_p{self.retrieval_prototypes}_src-{self.candidate_sources.replace(',', '+')}"

    @property
    def reranker_name(self) -> str:
        return f"{self.loss}_lr{self.lr:g}_{self.sampling}_a{self.anchors}_s{self.steps}_w{self.weak_multiplier}"

    @property
    def experiment_id(self) -> str:
        raw = f"{self.target}__{self.candidate_name}__{self.reranker_name}__seed{self.seed}"
        return re.sub(r"[^A-Za-z0-9_.+-]+", "_", raw)[:220]


def screen_recipes(seeds: Sequence[int]) -> List[Experiment]:
    """Evidence-driven interaction grid derived from the completed V2.4 battery.

    The grid intentionally combines, rather than separately ablates, the factors
    that already won their individual tests: multi-view retrieval, target-specific
    prototype counts, frequency/balanced sampling, stronger learning rates, large
    budgets, and one listwise challenger.
    """
    out: List[Experiment] = []
    qa_candidates = [
        ("full,no_location,no_employer", 8, "union8_full_nolocation_noemployer"),
        ("full,no_location,compact", 8, "union8_full_nolocation_compact"),
        ("full,compact,no_employer", 8, "union8_full_compact_noemployer"),
    ]
    qa_rerankers = [
        ("bce", 2e-5, "frequency", 9000, 500, 2, "bce2e5_freq_xl"),
        ("bce", 3e-5, "frequency", 9000, 500, 2, "bce3e5_freq_xl"),
        ("bce", 2e-5, "balanced", 9000, 500, 2, "bce2e5_bal_xl"),
        ("ranknet", 1e-5, "balanced", 4500, 300, 2, "ranknet_large"),
    ]
    q4_candidates = [
        ("full,no_naics,compact", 3, "union_p3_full_nonaics_compact"),
        ("no_naics,compact,title_only", 3, "union_p3_nonaics_compact_title"),
        ("full,no_naics,compact", 5, "union_p5_full_nonaics_compact"),
    ]
    q4_rerankers = [
        ("bce", 3e-5, "frequency", 18000, 1000, 4, "bce3e5_freq_xl"),
        ("bce", 3e-5, "balanced", 18000, 1000, 4, "bce3e5_bal_xl"),
        ("bce", 2e-5, "frequency", 18000, 1000, 4, "bce2e5_freq_xl"),
        ("ranknet", 1e-5, "balanced", 9000, 600, 4, "ranknet_large"),
    ]
    q5_candidates = [
        ("full,compact,title_only,no_naics", 3, "union_p3_full_compact_title_nonaics"),
        ("compact,title_only,no_naics", 3, "union_p3_compact_title_nonaics"),
        ("full,compact,title_only,no_naics", 5, "union_p5_full_compact_title_nonaics"),
    ]
    q5_rerankers = [
        ("bce", 3e-5, "frequency", 18000, 1000, 2, "bce3e5_freq_xl"),
        ("bce", 2e-5, "frequency", 18000, 1000, 2, "bce2e5_freq_xl"),
        ("bce", 3e-5, "balanced", 18000, 1000, 2, "bce3e5_bal_xl"),
        ("ranknet", 1e-5, "balanced", 9000, 600, 2, "ranknet_large"),
    ]
    for seed in seeds:
        for profiles, proto, cname in qa_candidates:
            for loss, lr, sampling, anchors, steps, weak, rname in qa_rerankers:
                out.append(Experiment("qa20a", f"{cname}__{rname}", profiles, proto, "full", 3, loss, lr, anchors, steps, sampling, weak, seed))
        for profiles, proto, cname in q4_candidates:
            for loss, lr, sampling, anchors, steps, weak, rname in q4_rerankers:
                out.append(Experiment("qe4ar", f"{cname}__{rname}", profiles, proto, "full", 3, loss, lr, anchors, steps, sampling, weak, seed))
        for profiles, proto, cname in q5_candidates:
            for loss, lr, sampling, anchors, steps, weak, rname in q5_rerankers:
                out.append(Experiment("qe5ar", f"{cname}__{rname}", profiles, proto, "full", 3, loss, lr, anchors, steps, sampling, weak, seed))
    return out


def confirm_recipes(manifest: Path, seeds: Sequence[int]) -> List[Experiment]:
    data = json.loads(manifest.read_text(encoding="utf-8"))
    winners = data.get("winners", {})
    out: List[Experiment] = []
    for target, recipes in winners.items():
        for recipe in recipes[:2]:
            cfg = recipe.get("experiment_config", recipe)
            for seed in seeds:
                out.append(Experiment(
                    target=target,
                    name=f"confirm_{recipe.get('rank', 0)}_{cfg.get('name', 'winner')}",
                    retrieval_profiles=str(cfg["retrieval_profiles"]),
                    retrieval_prototypes=int(cfg["retrieval_prototypes"]),
                    rerank_profile=str(cfg.get("rerank_profile", "full")),
                    rerank_prototypes=int(cfg.get("rerank_prototypes", 3)),
                    loss=str(cfg["loss"]), lr=float(cfg["lr"]),
                    anchors=max(int(cfg["anchors"]), 9000 if target == "qa20a" else 18000),
                    steps=max(int(cfg["steps"]), 500 if target == "qa20a" else 1000),
                    sampling=str(cfg["sampling"]), weak_multiplier=int(cfg["weak_multiplier"]),
                    seed=int(seed), candidate_sources=str(cfg.get("candidate_sources", "semantic,lexical,memory")),
                    semantic_per_profile=int(cfg.get("semantic_per_profile", 50)),
                    lexical_candidates=int(cfg.get("lexical_candidates", 30)),
                    union_limit=int(cfg.get("union_limit", 60)),
                    max_length=int(cfg.get("max_length", 384)),
                    hard_negatives=int(cfg.get("hard_negatives", 3)),
                    random_negatives=int(cfg.get("random_negatives", 1)),
                    strategy=str(cfg.get("strategy", "hybrid")),
                    eval_rows=max(int(cfg.get("eval_rows", 4000)), 5000),
                    eval_candidates=max(int(cfg.get("eval_candidates", 40)), 40),
                ))
    if not out:
        raise RuntimeError(f"No winners found in {manifest}")
    return out


def gpu_snapshot() -> str:
    try:
        cp = subprocess.run([
            "nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
            "--format=csv,noheader,nounits"
        ], capture_output=True, text=True, timeout=5)
        if cp.returncode == 0 and cp.stdout.strip():
            vals = [x.strip() for x in cp.stdout.strip().splitlines()[0].split(",")]
            return f"gpu={vals[0]}% vram={vals[1]}/{vals[2]}MiB temp={vals[3]}C"
    except Exception:
        pass
    return "gpu=unknown"


def run_one(
    exp: Experiment,
    python_exe: Path,
    trainer: Path,
    fit_sav: Path,
    cal_sav: Path,
    root: Path,
    logs: Path,
    cache: Path,
    artifact_policy: str,
    resume: bool,
) -> Tuple[str, int, float]:
    out = root / exp.experiment_id
    out.mkdir(parents=True, exist_ok=True)
    report = out / "targeted_interaction_report.json"
    config_path = out / "experiment_config.json"
    log_path = logs / f"{exp.experiment_id}.log"
    if resume and report.exists():
        print(f"[SKIP] complete {exp.experiment_id}", flush=True)
        return "complete", 0, 0.0
    cfg = asdict(exp) | {"experiment_id": exp.experiment_id, "version": VERSION}
    config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    cmd = [
        str(python_exe), "-u", str(trainer),
        "--fit_sav", str(fit_sav), "--calibration_sav", str(cal_sav),
        "--output_dir", str(out), "--target", exp.target,
        "--candidate_cache_dir", str(cache),
        "--retrieval_context_profiles", exp.retrieval_profiles,
        "--rerank_context_profile", exp.rerank_profile,
        "--retrieval_prototype_examples", str(exp.retrieval_prototypes),
        "--rerank_prototype_examples", str(exp.rerank_prototypes),
        "--candidate_sources", exp.candidate_sources,
        "--semantic_candidates_per_profile", str(exp.semantic_per_profile),
        "--lexical_candidates", str(exp.lexical_candidates),
        "--candidate_union_limit", str(exp.union_limit),
        "--loss_type", exp.loss,
        "--learning_rate", str(exp.lr), "--max_anchors", str(exp.anchors),
        "--max_update_steps", str(exp.steps), "--anchor_sampling", exp.sampling,
        "--weak_group_multiplier", str(exp.weak_multiplier),
        "--max_length", str(exp.max_length),
        "--hard_negatives", str(exp.hard_negatives), "--random_negatives", str(exp.random_negatives),
        "--hard_negative_strategy", exp.strategy,
        "--eval_rows", str(exp.eval_rows), "--eval_candidates", str(exp.eval_candidates),
        "--seed", str(exp.seed), "--artifact_policy", artifact_policy,
        "--checkpoint_keep", "1", "--offline",
    ]
    if exp.loss != "bce":
        cmd.extend(["--train_batch_size", "1", "--gradient_accumulation_steps", "32", "--listwise_mini_batch_size", "4"])
    if resume and (out / "checkpoints").exists():
        cmd.extend(["--resume_from_checkpoint", "auto"])
    print("\n" + "=" * 100, flush=True)
    print(f"EXPERIMENT {exp.experiment_id}", flush=True)
    print(f"target={exp.target} candidate={exp.candidate_name}", flush=True)
    print(f"reranker={exp.reranker_name} seed={exp.seed} policy={artifact_policy}", flush=True)
    print("=" * 100, flush=True)
    env = os.environ.copy()
    env.update({
        "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1", "HF_HUB_DISABLE_PROGRESS_BARS": "1",
        "CUDA_VISIBLE_DEVICES": "0", "TOKENIZERS_PARALLELISM": "false",
        "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
    })
    started = time.time()
    with log_path.open("a", encoding="utf-8", buffering=1) as log:
        log.write("COMMAND: " + " ".join(cmd) + "\n")
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace", bufsize=1, env=env)
        q: queue.Queue[Optional[str]] = queue.Queue()
        def reader() -> None:
            assert proc.stdout is not None
            for line in proc.stdout: q.put(line)
            q.put(None)
        threading.Thread(target=reader, daemon=True).start()
        done = False; last = time.time(); heartbeat = 0.0
        try:
            while True:
                try:
                    item = q.get(timeout=5)
                    if item is None: done = True
                    else:
                        print(item, end="", flush=True); log.write(item); last = time.time()
                except queue.Empty:
                    pass
                now = time.time()
                if now - heartbeat >= 60:
                    msg = f"[V3 HEARTBEAT] {exp.experiment_id} elapsed={(now-started)/60:.1f}m quiet={(now-last)/60:.1f}m {gpu_snapshot()}"
                    print(msg, flush=True); log.write(msg + "\n"); heartbeat = now
                if proc.poll() is not None and done and q.empty(): break
        except KeyboardInterrupt:
            print("[V3 BATTERY] Interrupt received; stopping active experiment...", flush=True)
            try: proc.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
            except Exception: proc.terminate()
            raise
        code = int(proc.wait())
    elapsed = time.time() - started
    state = "complete" if code == 0 and report.exists() else "failed"
    print(f"[{state.upper()}] {exp.experiment_id} elapsed={elapsed/3600:.2f}h", flush=True)
    return state, code, elapsed


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the V3 target-specific candidate/reranker interaction battery")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--phase", choices=["screen", "confirm"], default="screen")
    ap.add_argument("--seeds", default="42,43")
    ap.add_argument("--winner_manifest", default="")
    ap.add_argument("--artifact_policy", choices=["metrics_only", "final_only", "full"], default="metrics_only")
    ap.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--max_experiments", type=int, default=0)
    ap.add_argument("--only_target", choices=["", "qa20a", "qe4ar", "qe5ar"], default="")
    ap.add_argument("--dry_run", action="store_true", help="Write/print the experiment manifest without launching training")
    args = ap.parse_args()
    base = Path(args.base)
    py = base / ".venv" / "Scripts" / "python.exe"
    trainer = base / "train_targeted_interaction_reranker.py"
    fit = base / "training_FIT.sav"; cal = base / "training_CALIBRATION.sav"
    for p in (py, trainer, fit, cal):
        if not p.exists(): raise FileNotFoundError(p)
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    if args.phase == "screen":
        experiments = screen_recipes(seeds)
    else:
        manifest = Path(args.winner_manifest or (base / "v3_interaction_reports" / "screen" / "winner_manifest.json"))
        experiments = confirm_recipes(manifest, seeds)
    if args.only_target: experiments = [e for e in experiments if e.target == args.only_target]
    if args.max_experiments > 0: experiments = experiments[:args.max_experiments]
    root = base / "models" / f"v3_interactions_{args.phase}"
    logs = base / "logs" / f"v3_interactions_{args.phase}"
    cache = base / "candidate_cache_v3"
    root.mkdir(parents=True, exist_ok=True); logs.mkdir(parents=True, exist_ok=True); cache.mkdir(parents=True, exist_ok=True)
    manifest = {"version": VERSION, "phase": args.phase, "experiments": [asdict(e) | {"experiment_id": e.experiment_id} for e in experiments]}
    (root / "battery_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"V3 interaction battery {VERSION} phase={args.phase} experiments={len(experiments)}")
    if args.dry_run:
        for idx, exp in enumerate(experiments, 1):
            print(f"{idx:03d}  {exp.experiment_id}")
        print(f"Manifest written to: {root / 'battery_manifest.json'}")
        return 0
    statuses: List[Dict[str, Any]] = []
    for idx, exp in enumerate(experiments, 1):
        print(f"[V3 BATTERY] {idx}/{len(experiments)} {exp.experiment_id}", flush=True)
        try:
            state, code, elapsed = run_one(exp, py, trainer, fit, cal, root, logs, cache, args.artifact_policy, args.resume)
        except KeyboardInterrupt:
            print("[V3 BATTERY] Interrupted. Rerun the same command to resume.", flush=True)
            return 130
        statuses.append({"experiment_id": exp.experiment_id, "state": state, "exit_code": code, "elapsed_seconds": elapsed})
        (root / "battery_status.json").write_text(json.dumps(statuses, indent=2), encoding="utf-8")
    print("[V3 BATTERY] All experiments processed.")
    return 0


if __name__ == "__main__":
    try: raise SystemExit(main())
    except Exception as exc:
        print(f"[FATAL] V3 interaction battery failed: {exc}", file=sys.stderr, flush=True)
        raise
