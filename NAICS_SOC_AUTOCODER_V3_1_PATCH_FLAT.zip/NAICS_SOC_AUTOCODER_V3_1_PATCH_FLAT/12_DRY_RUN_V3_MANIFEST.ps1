param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [ValidateSet('screen','confirm')][string]$Phase = 'screen',
  [string]$Seeds = '42,43',
  [string]$OnlyTarget = ''
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$argsList = @('-u',(Join-Path $Base 'run_v3_targeted_interaction_battery.py'),'--base',$Base,'--phase',$Phase,'--seeds',$Seeds,'--dry_run')
if ($OnlyTarget) { $argsList += @('--only_target',$OnlyTarget) }
if ($Phase -eq 'confirm') {
  $Winner = Join-Path $Base 'v3_interaction_reports\screen\winner_manifest.json'
  if (-not (Test-Path $Winner)) { throw "Screen winner manifest missing: $Winner" }
  $argsList += @('--winner_manifest',$Winner)
}
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3 dry run failed" }
