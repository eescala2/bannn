# V3.1 Changelog

## Evidence-driven candidate generation

- Added target-specific code-prototype retrieval.
- Added several retrieval context views per target.
- Added lexical LinearSVC candidate generation to the interaction battery.
- Added high-purity historical memory candidates to the interaction battery.
- Added reciprocal-rank fusion across candidate sources.
- Kept full context for final Cross-Encoder reranking.

## Safer experiment selection

- Replaced the old relative-uplift winner score with an absolute pipeline score.
- Added stability penalties across random seeds.
- Added a positive-uplift gate so a high absolute score cannot hide a harmful reranker.
- Added a two-seed screen and five-seed confirmation workflow.

## Storage and reliability

- Screening and confirmation default to `metrics_only`.
- Completed experiment checkpoints and weights are deleted after metrics are saved.
- Added heartbeat output, resume behavior, disk reporting, and safe cleanup.
- Added dry-run manifest generation.
- Added environment/package/CUDA/offline-model preflight.

## Production pipeline

- Added three retained target-specific rerankers.
- Added target-specific prototype settings to the model bundle.
- Added source confidence calibration, candidate meta-ranking, conformal sets, and Gold audit.
- Added one-command end-to-end orchestration and score-only production runner.
