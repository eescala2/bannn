param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [ValidateSet('screen','confirm')][string]$Phase = 'screen'
)
$root = Join-Path $Base "models\v3_interactions_$Phase"
$logs = Join-Path $Base "logs\v3_interactions_$Phase"
$complete = 0; $dirs = @(); $failed = 0
if (Test-Path $root) {
  $dirs = @(Get-ChildItem $root -Directory)
  $complete = @($dirs | Where-Object { Test-Path (Join-Path $_.FullName 'targeted_interaction_report.json') }).Count
  $failed = @($dirs | Where-Object { -not (Test-Path (Join-Path $_.FullName 'targeted_interaction_report.json')) -and (Test-Path (Join-Path $_.FullName 'experiment_config.json')) }).Count
}
$drive = Get-PSDrive -Name ([IO.Path]::GetPathRoot($Base).TrimEnd(':\')) -ErrorAction SilentlyContinue
Write-Host "Phase=$Phase experiments=$($dirs.Count) complete=$complete incomplete_or_failed=$failed" -ForegroundColor Cyan
if ($drive) { Write-Host ("Disk free: {0:N2} GB" -f ($drive.Free / 1GB)) }
Get-CimInstance Win32_Process |
  Where-Object { $_.Name -like 'python*' -and ($_.CommandLine -like '*run_v3_targeted_interaction_battery.py*' -or $_.CommandLine -like '*train_targeted_interaction_reranker.py*' -or $_.CommandLine -like '*naics_soc_adaptive_memory_reranker_v3_1.py*') } |
  Select-Object ProcessId,CreationDate,CommandLine | Format-List
try { nvidia-smi } catch { Write-Host "nvidia-smi unavailable" -ForegroundColor Yellow }
if (Test-Path $logs) {
  $latest = Get-ChildItem $logs -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($latest) {
    Write-Host "Latest log: $($latest.FullName)" -ForegroundColor Yellow
    Get-Content $latest.FullName -Tail 60
  }
}
