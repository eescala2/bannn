param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
& $Python -u (Join-Path $Base 'v3_storage_manager.py') --base $Base
if ($LASTEXITCODE -ne 0) { throw "V3 storage report failed" }
