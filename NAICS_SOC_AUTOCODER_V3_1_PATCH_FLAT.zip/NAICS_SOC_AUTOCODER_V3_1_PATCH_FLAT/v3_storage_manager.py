#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, List

VERSION = "2026.07.19.targeted-v3-storage-manager"
HEAVY_NAMES = {"checkpoints", "final", "optimizer.pt", "scheduler.pt", "trainer_state.json", "rng_state.pth"}
HEAVY_SUFFIXES = {".safetensors", ".bin", ".pt", ".pth"}


def bytes_of(path: Path) -> int:
    if not path.exists():
        return 0
    if path.is_file():
        try: return path.stat().st_size
        except OSError: return 0
    total = 0
    for item in path.rglob("*"):
        if item.is_file():
            try: total += item.stat().st_size
            except OSError: pass
    return total


def fmt_gb(value: int) -> float:
    return round(value / 1024**3, 4)


def experiment_dirs(base: Path) -> Iterable[Path]:
    models = base / "models"
    for root_name in ("v3_interactions_screen", "v3_interactions_confirm"):
        root = models / root_name
        if root.exists():
            yield from sorted(p for p in root.iterdir() if p.is_dir())


def inventory(base: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for exp in experiment_dirs(base):
        total = bytes_of(exp)
        report = exp / "targeted_interaction_report.json"
        heavy = 0
        for child in exp.rglob("*"):
            if child.is_dir() and child.name in {"checkpoints", "final"}:
                heavy += bytes_of(child)
            elif child.is_file() and child.suffix.lower() in HEAVY_SUFFIXES:
                heavy += bytes_of(child)
        rows.append({
            "experiment_id": exp.name,
            "path": str(exp),
            "completed": report.exists(),
            "total_gb": fmt_gb(total),
            "heavy_gb": fmt_gb(heavy),
            "report_exists": report.exists(),
        })
    return rows


def prune_experiment(exp: Path) -> int:
    freed = 0
    targets: List[Path] = []
    for child in exp.rglob("*"):
        if child.is_dir() and child.name in {"checkpoints", "final"}:
            targets.append(child)
    # Delete deepest folders first and avoid duplicate descendants.
    unique: List[Path] = []
    for p in sorted(set(targets), key=lambda x: len(x.parts)):
        if not any(parent in p.parents for parent in unique):
            unique.append(p)
    for p in sorted(unique, key=lambda x: len(x.parts), reverse=True):
        if p.exists():
            freed += bytes_of(p)
            shutil.rmtree(p, ignore_errors=False)
    for child in list(exp.rglob("*")):
        if child.is_file() and child.suffix.lower() in HEAVY_SUFFIXES:
            freed += bytes_of(child)
            child.unlink(missing_ok=True)
    manifest = exp / "artifact_prune_manifest.json"
    manifest.write_text(json.dumps({"version": VERSION, "bytes_freed": freed, "gb_freed": fmt_gb(freed)}, indent=2), encoding="utf-8")
    return freed


def main() -> int:
    ap = argparse.ArgumentParser(description="Inventory or prune V3 screening artifacts")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--execute", action="store_true")
    ap.add_argument("--purge_candidate_cache", action="store_true", help="Also delete reusable candidate_cache_v3 (not recommended during experiments)")
    ap.add_argument("--out_dir", default="")
    args = ap.parse_args()
    base = Path(args.base).resolve()
    out = Path(args.out_dir) if args.out_dir else base / "v3_storage_reports"
    out.mkdir(parents=True, exist_ok=True)
    rows = inventory(base)
    total = sum(int(float(r["total_gb"]) * 1024**3) for r in rows)
    heavy = sum(int(float(r["heavy_gb"]) * 1024**3) for r in rows)
    print(f"V3 experiments={len(rows)} total={fmt_gb(total):.3f} GB reclaimable_heavy≈{fmt_gb(heavy):.3f} GB")
    for row in sorted(rows, key=lambda r: r["heavy_gb"], reverse=True)[:30]:
        print(f"{row['heavy_gb']:8.3f} GB heavy | {row['total_gb']:8.3f} GB total | complete={row['completed']} | {row['experiment_id']}")
    if rows:
        fields = list(rows[0].keys())
        with (out / "v3_storage_inventory.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    (out / "v3_storage_inventory.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

    potential = sum(bytes_of(Path(r["path"]) / "checkpoints") + bytes_of(Path(r["path"]) / "final") for r in rows if r["completed"])
    print(f"Completed-experiment checkpoint/final folders eligible for pruning: {fmt_gb(potential):.3f} GB")
    if not args.execute:
        print("Preview only. Add --execute to delete heavy artifacts from completed experiments.")
        return 0

    freed = 0
    for row in rows:
        exp = Path(row["path"])
        if not row["completed"]:
            continue
        freed += prune_experiment(exp)
    if args.purge_candidate_cache:
        cache = base / "candidate_cache_v3"
        if cache.exists():
            freed += bytes_of(cache)
            shutil.rmtree(cache)
            print("Deleted reusable candidate cache. Future experiments will recompute candidates.")
    print(f"Cleanup complete. Freed {fmt_gb(freed):.3f} GB.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
