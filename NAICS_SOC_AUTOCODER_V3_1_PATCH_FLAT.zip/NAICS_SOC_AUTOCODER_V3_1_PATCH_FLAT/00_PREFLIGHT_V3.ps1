param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [switch]$RequireProductionRerankers,
  [switch]$SkipHuggingFaceModelCheck
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) {
  $PSNativeCommandUseErrorActionPreference = $false
}
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "v3_preflight.py"
if (-not (Test-Path $Python)) { throw "Virtual-environment Python missing: $Python" }
if (-not (Test-Path $Script)) { throw "V3 preflight script missing: $Script" }
$argsList = @('-u', $Script, '--base', $Base, '--out_json', (Join-Path $Base 'v3_preflight_report.json'))
if ($RequireProductionRerankers) { $argsList += '--require_production_rerankers' }
if ($SkipHuggingFaceModelCheck) { $argsList += '--no-check_hf_models' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) {
  throw "V3 preflight failed. Open: $(Join-Path $Base 'v3_preflight_report.json')"
}
