# Evidence Used to Build the V3.1 Targeted Prototype Package

This package is not another broad hyperparameter sweep. It implements the next experiments implied by the completed V2.4 battery and confirmatory results.

## Stable findings from the completed battery

1. **One reranker per target is superior to shared rerankers.** The all-target and shared-SOC runs were consistently weaker than target-specific `qa20a`, `qe4ar`, and `qe5ar` models.
2. **Candidate recall is the primary ceiling.** A reranker cannot choose a code that is absent from its candidate pool.
3. **Retrieval and reranking require different text views.** Shorter, target-specific contexts often retrieved the correct code more reliably, while full context was better suited to final reranking.
4. **BCE remains the practical default.** RankNet and LambdaLoss were competitive but were several times slower. They remain challengers rather than the only production choice.
5. **Larger budgets and learning rates near `2e-5` or `3e-5` outperformed the original `1e-5` baseline.**
6. **Frequency sampling is a serious production contender.** It improved absolute pipeline metrics for all three targets in the screening results.
7. **384 tokens is sufficient.** 512 provided little benefit, while 256 was generally weaker.
8. **The old relative-uplift selection score was misleading.** A one-prototype candidate generator could make the base reranker collapse and then receive a spectacular relative-uplift score, despite poor absolute retrieval performance. V3.1 therefore selects by absolute production-pipeline metrics.

## Target-specific evidence

### NAICS (`qa20a`)

Promising observations included:

- eight code prototypes per class, with retrieval top-1 around `0.4500`, recall@20 around `0.7655`, and recall@40 around `0.8785` in screening;
- frequency anchor sampling;
- BCE at learning rate `2e-5`;
- medium and large training budgets;
- multi-view retrieval using full context plus context variants that remove location or employer noise.

V3.1 tests the interaction between the strongest candidate generator and the strongest practical reranker rather than testing them separately.

### Current-job SOC (`qe4ar`)

Promising observations included:

- extra-large BCE retrieval top-1 around `0.3650`;
- learning rate `3e-5` producing nearly the same top-1 at substantially lower training cost;
- improved candidate recall from `no_naics` and compact retrieval contexts;
- modest weak-group oversampling, with multiplier four preferable to multiplier six;
- RankNet/LambdaLoss as slower challengers.

V3.1 retrieves candidates from full, compact, and no-NAICS views, then reranks their union with full context.

### Unused-skill SOC (`qe5ar`)

Promising observations included:

- compact retrieval context, with retrieval top-1 around `0.3410`, recall@20 around `0.5285`, and recall@40 around `0.6350`;
- large and extra-large BCE rerankers;
- learning rates `2e-5` and `3e-5`;
- frequency sampling;
- RankNet as a competitive but slower challenger.

V3.1 retrieves from compact, title-only, no-NAICS, and full contexts, then reranks their deduplicated union with full context.

## What V3.1 changes

- target-specific multi-context code-prototype retrieval;
- lexical LinearSVC candidates;
- high-purity historical memory candidates;
- reciprocal-rank fusion into one candidate union;
- target-specific Cross-Encoder rerankers;
- absolute-metric, stability-adjusted winner selection;
- five-seed confirmation;
- metrics-only screening artifacts;
- one retained production reranker per target;
- final calibration, conformal analysis, and untouched-Gold audit.

## Promotion standard

A V3.1 model is promoted only after it improves the same sealed Evaluation Gold file used by the earlier audited baseline:

- `qa20a` top-1 baseline: `0.8480`
- `qe4ar` top-1 baseline: `0.6678`
- `qe5ar` top-1 baseline: `0.6987`

Complexity alone earns no promotion. The new model must improve Gold-set accuracy, macro-F1, model-only rows, calibration, or review efficiency without materially damaging the strong adaptive-memory and dictionary layers.
