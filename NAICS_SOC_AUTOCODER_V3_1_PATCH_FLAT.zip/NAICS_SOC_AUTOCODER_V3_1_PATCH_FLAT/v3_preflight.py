#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import json
import os
import py_compile
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

VERSION = "2026.07.19.targeted-prototype-preflight-v3.1"

REQUIRED_MODULES = {
    "numpy": "numpy",
    "pandas": "pandas",
    "scipy": "scipy",
    "pyreadstat": "pyreadstat",
    "sklearn": "scikit-learn",
    "joblib": "joblib",
    "threadpoolctl": "threadpoolctl",
    "psutil": "psutil",
    "faiss": "faiss-cpu",
    "datasets": "datasets",
    "sentence_transformers": "sentence-transformers",
    "transformers": "transformers",
    "accelerate": "accelerate",
    "safetensors": "safetensors",
    "rapidfuzz": "rapidfuzz",
    "torch": "torch (CUDA build recommended)",
}

REQUIRED_FILES = [
    "training_FIT.sav",
    "training_CALIBRATION.sav",
    "training_EVALUATION_GOLD.sav",
    "train_domain_cross_encoder_battery.py",
    "train_targeted_interaction_reranker.py",
    "run_v3_targeted_interaction_battery.py",
    "summarize_v3_targeted_interactions.py",
    "train_v3_final_rerankers.py",
    "naics_soc_adaptive_memory_reranker_v3_1.py",
    "autocoder_improvement_audit_v2.py",
]

COMPILE_FILES = [
    "train_domain_cross_encoder_battery.py",
    "train_targeted_interaction_reranker.py",
    "run_v3_targeted_interaction_battery.py",
    "summarize_v3_targeted_interactions.py",
    "train_v3_final_rerankers.py",
    "naics_soc_adaptive_memory_reranker_v3_1.py",
    "autocoder_improvement_audit_v2.py",
]


def module_version(mod: Any) -> str:
    return str(getattr(mod, "__version__", "unknown"))


def main() -> int:
    ap = argparse.ArgumentParser(description="Preflight the V3.1 target-specific NAICS/SOC reranker package")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--require_production_rerankers", action="store_true")
    ap.add_argument("--check_hf_models", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--out_json", default="")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    report: Dict[str, Any] = {
        "version": VERSION,
        "base": str(base),
        "python": sys.version,
        "critical_errors": [],
        "warnings": [],
        "checks": {},
    }

    if not base.exists():
        report["critical_errors"].append(f"Base folder does not exist: {base}")
    files: Dict[str, bool] = {}
    for name in REQUIRED_FILES:
        exists = (base / name).exists()
        files[name] = exists
        if not exists:
            report["critical_errors"].append(f"Missing required file: {base / name}")
    report["checks"]["files"] = files

    usage = shutil.disk_usage(base if base.exists() else Path.cwd())
    free_gb = usage.free / 1024**3
    report["checks"]["disk"] = {
        "total_gb": round(usage.total / 1024**3, 2),
        "used_gb": round(usage.used / 1024**3, 2),
        "free_gb": round(free_gb, 2),
    }
    if free_gb < 8:
        report["critical_errors"].append(f"Only {free_gb:.1f} GB disk space is free; at least 8 GB is required for an active experiment.")
    elif free_gb < 20:
        report["warnings"].append(f"Only {free_gb:.1f} GB disk space is free; 20 GB or more is recommended.")

    packages: Dict[str, Any] = {}
    imported: Dict[str, Any] = {}
    for module_name, package_hint in REQUIRED_MODULES.items():
        try:
            mod = importlib.import_module(module_name)
            imported[module_name] = mod
            packages[module_name] = {"ok": True, "version": module_version(mod)}
        except Exception as exc:
            packages[module_name] = {"ok": False, "error": repr(exc), "install": package_hint}
            report["critical_errors"].append(f"Python module unavailable: {module_name}. Install: {package_hint}")
    report["checks"]["packages"] = packages

    torch = imported.get("torch")
    cuda: Dict[str, Any] = {"available": False}
    if torch is not None:
        try:
            cuda["available"] = bool(torch.cuda.is_available())
            cuda["torch_cuda_version"] = getattr(torch.version, "cuda", None)
            cuda["device_count"] = int(torch.cuda.device_count())
            cuda["devices"] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
            if cuda["available"]:
                props = torch.cuda.get_device_properties(0)
                cuda["vram_gb"] = round(props.total_memory / 1024**3, 2)
            else:
                report["critical_errors"].append("CUDA-enabled PyTorch is not available. The package can technically run on CPU, but the supplied PowerShell runners require CUDA.")
        except Exception as exc:
            cuda["error"] = repr(exc)
            report["critical_errors"].append(f"CUDA probe failed: {exc}")
    report["checks"]["cuda"] = cuda

    compiled: Dict[str, Any] = {}
    for name in COMPILE_FILES:
        path = base / name
        if not path.exists():
            continue
        try:
            py_compile.compile(str(path), doraise=True)
            compiled[name] = "ok"
        except Exception as exc:
            compiled[name] = repr(exc)
            report["critical_errors"].append(f"Python syntax/compile failure in {name}: {exc}")
    report["checks"]["compile"] = compiled

    # Confirm that the shared Hugging Face base models are available offline.
    hf: Dict[str, Any] = {"checked": False}
    if args.check_hf_models and "sentence_transformers" in imported:
        hf["checked"] = True
        os.environ.setdefault("HF_HUB_OFFLINE", "1")
        os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
        try:
            from sentence_transformers import SentenceTransformer, CrossEncoder
            SentenceTransformer("BAAI/bge-large-en-v1.5", device="cpu", local_files_only=True)
            CrossEncoder("cross-encoder/ms-marco-MiniLM-L6-v2", device="cpu", local_files_only=True)
            hf["base_models_offline"] = True
        except Exception as exc:
            hf["base_models_offline"] = False
            hf["error"] = repr(exc)
            report["critical_errors"].append(
                "Required Hugging Face models are not available offline. Cache BAAI/bge-large-en-v1.5 and cross-encoder/ms-marco-MiniLM-L6-v2 before launching a long run."
            )
    report["checks"]["huggingface"] = hf

    active: List[Dict[str, Any]] = []
    psutil = imported.get("psutil")
    if psutil is not None:
        try:
            for proc in psutil.process_iter(["pid", "name", "cmdline", "create_time"]):
                cmd = " ".join(proc.info.get("cmdline") or [])
                if any(token in cmd for token in (
                    "run_v3_targeted_interaction_battery.py",
                    "train_targeted_interaction_reranker.py",
                    "naics_soc_adaptive_memory_reranker_v3_1.py",
                )):
                    active.append({"pid": proc.info["pid"], "name": proc.info.get("name"), "command": cmd})
        except Exception as exc:
            report["warnings"].append(f"Could not inspect active processes: {exc}")
    report["checks"]["active_autocoder_processes"] = active
    if len(active) > 1:
        report["warnings"].append(f"Multiple autocoder/trainer processes detected ({len(active)}). Run one GPU job at a time on the RTX 2050.")

    if args.require_production_rerankers:
        manifest = base / "models" / "v3_production_rerankers" / "production_reranker_manifest.json"
        prod: Dict[str, Any] = {"manifest": str(manifest), "exists": manifest.exists(), "targets": {}}
        if not manifest.exists():
            report["critical_errors"].append(f"Production reranker manifest missing: {manifest}")
        else:
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                for target in ("qa20a", "qe4ar", "qe5ar"):
                    path = Path(str(data.get("targets", {}).get(target, {}).get("model_path", "")))
                    ok = path.exists()
                    prod["targets"][target] = {"path": str(path), "exists": ok}
                    if not ok:
                        report["critical_errors"].append(f"Production reranker missing for {target}: {path}")
            except Exception as exc:
                report["critical_errors"].append(f"Could not parse production reranker manifest: {exc}")
        report["checks"]["production_rerankers"] = prod

    out = Path(args.out_json) if args.out_json else base / "v3_preflight_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    print(json.dumps(report, indent=2, default=str))
    print(f"\nPreflight report: {out}")
    if report["critical_errors"]:
        print(f"PRECHECK FAILED: {len(report['critical_errors'])} critical error(s).")
        return 2
    print("PRECHECK PASSED.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
