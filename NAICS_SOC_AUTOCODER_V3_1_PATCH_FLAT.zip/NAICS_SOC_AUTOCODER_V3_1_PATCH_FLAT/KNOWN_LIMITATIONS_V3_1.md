# Known Limitations

1. **Gold performance is the final authority.** Screening and calibration metrics are not a substitute for the untouched Evaluation Gold audit.
2. **Candidate recall remains finite.** Even a perfect reranker cannot choose an omitted code. V3.1 expands the candidate union but does not guarantee full recall.
3. **Rare SOC classes remain data-limited.** Some detailed occupations have only one or two historical examples.
4. **Employer/title drift can reduce memory coverage.** New employers and new wording still require model generalization or review.
5. **Forced full fill includes low-information cases.** Rows with almost no text/context receive a best-available fallback and should be review-prioritized.
6. **The RTX 2050 has 4 GB VRAM.** One GPU process at a time is required. Batch sizes are intentionally conservative.
7. **Metrics-only experiments are not directly deployable.** The selected recipe must be retrained with `final_only`, which the package does in Stage 05.
8. **Candidate cache reuse depends on unchanged FIT/CALIBRATION files and settings.** Editing those files invalidates caches.
9. **Historical labels define the target.** Errors or inconsistent coding in historical data are learned unless corrected.
10. **Windows sleep, updates, and power throttling can interrupt long runs.** Keep the laptop plugged in, disable sleep, and use resume behavior.
