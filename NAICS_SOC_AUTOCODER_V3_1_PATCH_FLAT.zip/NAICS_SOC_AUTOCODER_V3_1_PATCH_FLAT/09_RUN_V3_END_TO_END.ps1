param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [string]$ScreenSeeds = "42,43",
  [string]$ConfirmSeeds = "101,102,103,104,105",
  [int]$FinalSeed = 777,
  [string]$DateCol = "auto",
  [string]$LocationCols = "qe2b",
  [string]$NumericCols = "qe10",
  [string]$VerifiedCol = "",
  [string]$RunLabel = "targeted_reranker_v3_1",
  [switch]$SkipScreen,
  [switch]$SkipConfirm,
  [switch]$SkipFinalRerankers,
  [switch]$SkipGoldAudit
)
$ErrorActionPreference = "Stop"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Set-Location $Base
Write-Host ""; Write-Host "V3.1 EVIDENCE-DRIVEN TARGETED PIPELINE" -ForegroundColor Cyan
Write-Host "Base: $Base"
Write-Host "Screen seeds: $ScreenSeeds | Confirm seeds: $ConfirmSeeds | Final seed: $FinalSeed"
Write-Host "Heavy screening models will be deleted after metrics are saved." -ForegroundColor Yellow

& (Join-Path $Base '00_PREFLIGHT_V3.ps1') -Base $Base

if (-not $SkipScreen) {
  & (Join-Path $Base '01_RUN_V3_INTERACTION_SCREEN.ps1') -Base $Base -Seeds $ScreenSeeds
  & (Join-Path $Base '02_SUMMARIZE_V3_SCREEN.ps1') -Base $Base
} else {
  Write-Host "Skipping screen phase by request." -ForegroundColor DarkYellow
}

if (-not $SkipConfirm) {
  & (Join-Path $Base '03_RUN_V3_INTERACTION_CONFIRM.ps1') -Base $Base -Seeds $ConfirmSeeds
  & (Join-Path $Base '04_SUMMARIZE_V3_CONFIRM.ps1') -Base $Base
} else {
  Write-Host "Skipping confirm phase by request." -ForegroundColor DarkYellow
}

if (-not $SkipFinalRerankers) {
  & (Join-Path $Base '05_TRAIN_V3_FINAL_RERANKERS.ps1') -Base $Base -Seed $FinalSeed
} else {
  Write-Host "Skipping final reranker training by request." -ForegroundColor DarkYellow
}

if (-not $SkipGoldAudit) {
  & (Join-Path $Base '06_TRAIN_V3_FINAL_GOLD.ps1') `
    -Base $Base `
    -DateCol $DateCol `
    -LocationCols $LocationCols `
    -NumericCols $NumericCols `
    -VerifiedCol $VerifiedCol `
    -RunLabel $RunLabel
} else {
  Write-Host "Skipping final Gold audit by request." -ForegroundColor DarkYellow
}

& (Join-Path $Base '10_V3_STORAGE_REPORT.ps1') -Base $Base
Write-Host ""; Write-Host "V3.1 pipeline finished." -ForegroundColor Green
Write-Host "Screen report:  $Base\v3_interaction_reports\screen\CHAT_UPLOAD_V3_INTERACTION_RESULTS.zip"
Write-Host "Confirm report: $Base\v3_interaction_reports\confirm\CHAT_UPLOAD_V3_INTERACTION_RESULTS.zip"
Write-Host "Final model:    $Base\models\naics_soc_TARGETED_V3.joblib"
Write-Host "Gold audit:     Find CHAT_UPLOAD_MODEL_IMPROVEMENT.zip under $Base\model_audits"
