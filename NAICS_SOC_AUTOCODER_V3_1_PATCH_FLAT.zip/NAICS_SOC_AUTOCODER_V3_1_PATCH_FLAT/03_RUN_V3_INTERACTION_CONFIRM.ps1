param([string]$Base = "C:\laborshed_autocode_clean", [string]$Seeds = "101,102,103,104,105")
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base '00_PREFLIGHT_V3.ps1') -Base $Base
$Winner = Join-Path $Base "v3_interaction_reports\screen\winner_manifest.json"
if (-not (Test-Path $Winner)) { throw "Run 02_SUMMARIZE_V3_SCREEN.ps1 first. Missing: $Winner" }
$Python = Join-Path $Base ".venv\Scripts\python.exe"
& $Python -u (Join-Path $Base "run_v3_targeted_interaction_battery.py") --base $Base --phase confirm --seeds $Seeds --winner_manifest $Winner --artifact_policy metrics_only
if ($LASTEXITCODE -ne 0) { throw "V3 confirmatory battery exited with code $LASTEXITCODE" }
