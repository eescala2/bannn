#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

VERSION = "2026.07.19.targeted-interaction-summary-v3.1"


def num(value: Any, default: float = 0.0) -> float:
    try:
        x = float(value)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def deep(mapping: Mapping[str, Any], path: Sequence[str], default: Any = None) -> Any:
    cur: Any = mapping
    for key in path:
        if not isinstance(cur, Mapping) or key not in cur:
            return default
        cur = cur[key]
    return cur


def mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return float(statistics.mean(vals)) if vals else float("nan")


def sd(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return float(statistics.stdev(vals)) if len(vals) > 1 else 0.0


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8"); return
    fields: List[str] = []
    for row in rows:
        for k in row:
            if k not in fields: fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)


def candidate_key(cfg: Mapping[str, Any]) -> str:
    return json.dumps({
        "retrieval_profiles": cfg.get("retrieval_profiles"),
        "retrieval_prototypes": cfg.get("retrieval_prototypes"),
        "candidate_sources": cfg.get("candidate_sources"),
        "semantic_per_profile": cfg.get("semantic_per_profile"),
        "lexical_candidates": cfg.get("lexical_candidates"),
        "union_limit": cfg.get("union_limit"),
    }, sort_keys=True, separators=(",", ":"))


def reranker_key(cfg: Mapping[str, Any]) -> str:
    return json.dumps({
        "loss": cfg.get("loss"), "lr": cfg.get("lr"), "anchors": cfg.get("anchors"),
        "steps": cfg.get("steps"), "sampling": cfg.get("sampling"),
        "weak_multiplier": cfg.get("weak_multiplier"),
        "rerank_profile": cfg.get("rerank_profile"),
        "rerank_prototypes": cfg.get("rerank_prototypes"),
        "max_length": cfg.get("max_length", 384),
    }, sort_keys=True, separators=(",", ":"))


def absolute_pipeline_score(row: Mapping[str, Any]) -> float:
    # Absolute metrics dominate. Uplift is intentionally not used here because
    # candidate generators can change the base difficulty dramatically.
    minutes = max(0.0, num(row.get("training_seconds")) / 60.0)
    runtime_penalty = min(0.02, 0.0025 * math.log1p(minutes))
    return (
        0.43 * num(row.get("retrieval_top1_tuned"))
        + 0.20 * num(row.get("retrieval_top4_tuned"))
        + 0.14 * num(row.get("retrieval_mrr_tuned"))
        + 0.08 * num(row.get("candidate_recall_at_20"))
        + 0.07 * num(row.get("candidate_recall_at_40"))
        + 0.08 * num(row.get("oracle_top1_tuned"))
        - runtime_penalty
    )


def load_rows(root: Path) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows: List[Dict[str, Any]] = []; failures: List[Dict[str, Any]] = []
    for exp_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        cfg_path = exp_dir / "experiment_config.json"
        report_path = exp_dir / "targeted_interaction_report.json"
        if not cfg_path.exists(): continue
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        if not report_path.exists():
            failures.append({"experiment_id": cfg.get("experiment_id", exp_dir.name), "reason": "missing_report"}); continue
        report = json.loads(report_path.read_text(encoding="utf-8"))
        target = str(report.get("target", cfg.get("target", "")))
        base_o = report.get("base_metrics", {}).get(target, {})
        tuned_o = report.get("tuned_metrics", {}).get(target, {})
        base_r = report.get("base_metrics_retrieval", {}).get(target, {})
        tuned_r = report.get("tuned_metrics_retrieval", {}).get(target, {})
        cmp_o = report.get("paired_comparison", {}).get(target, {})
        cmp_r = report.get("paired_comparison_retrieval", {}).get(target, {})
        union = report.get("candidate_source_metrics", {}).get("production_union", {})
        row = dict(cfg)
        row.update({
            "target": target,
            "candidate_generator_key": candidate_key(cfg),
            "reranker_key": reranker_key(cfg),
            "training_seconds": num(report.get("training_seconds")),
            "oracle_top1_base": num(base_o.get("top1")),
            "oracle_top1_tuned": num(tuned_o.get("top1")),
            "oracle_top4_tuned": num(tuned_o.get("top4")),
            "oracle_mrr_tuned": num(tuned_o.get("mrr")),
            "oracle_top1_diff": num(deep(cmp_o, ["top1", "difference"])),
            "oracle_top4_diff": num(deep(cmp_o, ["top4", "difference"])),
            "oracle_mrr_diff": num(deep(cmp_o, ["mrr", "difference"])),
            "retrieval_top1_base": num(base_r.get("top1")),
            "retrieval_top1_tuned": num(tuned_r.get("top1")),
            "retrieval_top4_tuned": num(tuned_r.get("top4")),
            "retrieval_mrr_tuned": num(tuned_r.get("mrr")),
            "retrieval_top1_diff": num(deep(cmp_r, ["top1", "difference"])),
            "retrieval_top4_diff": num(deep(cmp_r, ["top4", "difference"])),
            "retrieval_mrr_diff": num(deep(cmp_r, ["mrr", "difference"])),
            "candidate_recall_at_1": num(union.get("recall_at_1")),
            "candidate_recall_at_4": num(union.get("recall_at_4")),
            "candidate_recall_at_10": num(union.get("recall_at_10")),
            "candidate_recall_at_20": num(union.get("recall_at_20")),
            "candidate_recall_at_40": num(union.get("recall_at_40")),
        })
        row["pipeline_score_absolute"] = absolute_pipeline_score(row)
        row["reranker_uplift_score"] = (
            0.45 * row["retrieval_top1_diff"] + 0.25 * row["retrieval_mrr_diff"]
            + 0.15 * row["retrieval_top4_diff"] + 0.15 * row["oracle_top1_diff"]
        )
        row["passes_uplift_gate"] = bool(
            row["retrieval_top1_diff"] > 0
            and row["retrieval_mrr_diff"] > 0
            and row["retrieval_top4_diff"] >= -0.005
        )
        rows.append(row)
    return rows, failures


def aggregate(rows: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, str, str], List[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(str(row["target"]), str(row["candidate_generator_key"]), str(row["reranker_key"]))].append(row)
    out: List[Dict[str, Any]] = []
    for (target, ckey, rkey), vals in groups.items():
        first = vals[0]
        rec = {
            "target": target, "runs": len(vals), "seeds": ",".join(str(v.get("seed")) for v in vals),
            "name": first.get("name"), "candidate_generator_key": ckey, "reranker_key": rkey,
            "retrieval_profiles": first.get("retrieval_profiles"),
            "retrieval_prototypes": first.get("retrieval_prototypes"),
            "candidate_sources": first.get("candidate_sources"),
            "loss": first.get("loss"), "lr": first.get("lr"), "anchors": first.get("anchors"),
            "steps": first.get("steps"), "sampling": first.get("sampling"),
            "weak_multiplier": first.get("weak_multiplier"),
            "mean_retrieval_top1_tuned": mean(v["retrieval_top1_tuned"] for v in vals),
            "sd_retrieval_top1_tuned": sd(v["retrieval_top1_tuned"] for v in vals),
            "mean_retrieval_top4_tuned": mean(v["retrieval_top4_tuned"] for v in vals),
            "mean_retrieval_mrr_tuned": mean(v["retrieval_mrr_tuned"] for v in vals),
            "mean_candidate_recall_at_20": mean(v["candidate_recall_at_20"] for v in vals),
            "mean_candidate_recall_at_40": mean(v["candidate_recall_at_40"] for v in vals),
            "mean_oracle_top1_tuned": mean(v["oracle_top1_tuned"] for v in vals),
            "mean_retrieval_top1_diff": mean(v["retrieval_top1_diff"] for v in vals),
            "mean_retrieval_top4_diff": mean(v["retrieval_top4_diff"] for v in vals),
            "mean_retrieval_mrr_diff": mean(v["retrieval_mrr_diff"] for v in vals),
            "mean_pipeline_score_absolute": mean(v["pipeline_score_absolute"] for v in vals),
            "sd_pipeline_score_absolute": sd(v["pipeline_score_absolute"] for v in vals),
            "mean_training_minutes": mean(v["training_seconds"] / 60 for v in vals),
            "positive_uplift_runs": sum(bool(v["passes_uplift_gate"]) for v in vals),
            "experiment_ids": ",".join(str(v["experiment_id"]) for v in vals),
            "experiment_config": {
                k: first.get(k) for k in (
                    "name", "retrieval_profiles", "retrieval_prototypes", "rerank_profile", "rerank_prototypes",
                    "loss", "lr", "anchors", "steps", "sampling", "weak_multiplier", "candidate_sources",
                    "semantic_per_profile", "lexical_candidates", "union_limit", "max_length", "hard_negatives",
                    "random_negatives", "strategy", "eval_rows", "eval_candidates"
                )
            },
        }
        # Stability-adjusted absolute score. This is the actual winner criterion.
        rec["robust_pipeline_score"] = rec["mean_pipeline_score_absolute"] - 0.50 * rec["sd_retrieval_top1_tuned"]
        required = max(1, math.ceil(len(vals) / 2))
        if rec["positive_uplift_runs"] >= required and rec["mean_retrieval_top1_diff"] > 0 and rec["mean_retrieval_mrr_diff"] > 0:
            rec["decision"] = "PROMISING"
        elif rec["mean_retrieval_top1_diff"] < 0 and rec["mean_retrieval_mrr_diff"] < 0:
            rec["decision"] = "REJECT"
        else:
            rec["decision"] = "MIXED"
        out.append(rec)
    return sorted(out, key=lambda r: (r["target"], -r["robust_pipeline_score"]))


def build_winners(aggregates: Sequence[Mapping[str, Any]], top_n: int) -> Dict[str, Any]:
    by_target: Dict[str, List[Mapping[str, Any]]] = defaultdict(list)
    for row in aggregates: by_target[str(row["target"])].append(row)
    winners: Dict[str, List[Dict[str, Any]]] = {}
    for target, vals in by_target.items():
        ranked = sorted(vals, key=lambda r: (r["decision"] != "PROMISING", -num(r["robust_pipeline_score"])))
        winners[target] = []
        for rank, row in enumerate(ranked[:top_n], start=1):
            winners[target].append({"rank": rank, **dict(row)})
    return {"version": VERSION, "winner_criterion": "stability-adjusted absolute production-pipeline score", "winners": winners}


def markdown(aggregates: Sequence[Mapping[str, Any]], winners: Mapping[str, Any], failures: Sequence[Mapping[str, Any]]) -> str:
    lines = [
        "# V3 Targeted Candidate/Reranker Interaction Summary", "",
        "Winner selection uses **absolute production-pipeline metrics**, not relative uplift across different candidate generators.", "",
    ]
    for target, vals in winners.get("winners", {}).items():
        lines += [f"## {target}", "", "| Rank | Candidate profiles | Prototypes | Loss | LR | Sampling | Top-1 | Top-4 | MRR | Recall@20 | Recall@40 | Decision |", "|---:|---|---:|---|---:|---|---:|---:|---:|---:|---:|---|"]
        for row in vals:
            lines.append(
                f"| {row['rank']} | {row.get('retrieval_profiles')} | {row.get('retrieval_prototypes')} | {row.get('loss')} | {row.get('lr')} | {row.get('sampling')} | "
                f"{row.get('mean_retrieval_top1_tuned',0):.4f} | {row.get('mean_retrieval_top4_tuned',0):.4f} | {row.get('mean_retrieval_mrr_tuned',0):.4f} | "
                f"{row.get('mean_candidate_recall_at_20',0):.4f} | {row.get('mean_candidate_recall_at_40',0):.4f} | {row.get('decision')} |"
            )
        lines.append("")
    lines += ["## Failures", "", f"Failed or incomplete experiments: {len(failures)}", ""]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="Summarize V3 targeted interaction experiments using absolute pipeline metrics")
    ap.add_argument("--root", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--top_n", type=int, default=2)
    args = ap.parse_args()
    root = Path(args.root); out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    rows, failures = load_rows(root)
    aggs = aggregate(rows)
    winners = build_winners(aggs, args.top_n)
    write_csv(out / "v3_run_results.csv", rows)
    write_csv(out / "v3_recipe_summary.csv", aggs)
    write_csv(out / "v3_failures.csv", failures)
    (out / "winner_manifest.json").write_text(json.dumps(winners, indent=2, default=str), encoding="utf-8")
    (out / "V3_INTERACTION_SUMMARY.md").write_text(markdown(aggs, winners, failures), encoding="utf-8")
    zip_path = out / "CHAT_UPLOAD_V3_INTERACTION_RESULTS.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name in ("v3_run_results.csv", "v3_recipe_summary.csv", "v3_failures.csv", "winner_manifest.json", "V3_INTERACTION_SUMMARY.md"):
            p = out / name
            if p.exists(): z.write(p, arcname=name)
    print(f"Runs: {len(rows)} recipes: {len(aggs)} failures: {len(failures)}")
    print(f"Winner manifest: {out / 'winner_manifest.json'}")
    print(f"Upload ZIP: {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
