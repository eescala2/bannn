param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [Parameter(Mandatory=$true)][string]$ScoreSav,
  [string]$OutSav = "",
  [string]$RunLabel = "v3_score"
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"; $Script = Join-Path $Base "naics_soc_adaptive_memory_reranker_v3_1.py"; $Model = Join-Path $Base "models\naics_soc_TARGETED_V3.joblib"
if (-not $OutSav) { $OutSav = Join-Path $Base ("output\" + [IO.Path]::GetFileNameWithoutExtension($ScoreSav) + "_TARGETED_V3.sav") }
foreach ($p in @($Python,$Script,$Model,$ScoreSav)) { if (-not (Test-Path $p)) { throw "Required file missing: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"; $env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"; $env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"; $env:OMP_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"
$Log = Join-Path $Base "logs\${RunLabel}_predictions.txt"; $Console = Join-Path $Base "logs\console_${RunLabel}_live.log"; New-Item -ItemType Directory -Path (Split-Path $OutSav) -Force | Out-Null
& $Python -u $Script --mode score --model_in $Model --score_sav $ScoreSav --out_sav $OutSav --log_txt $Log --overwrite_existing --fill_all_missing --score_rows_without_text --fallback_fill_missing --embedding_device cuda --embedding_batch_size 16 --score_batch_size 750 --max_workers 6 --native_threads 1 --console_log $Console
if ($LASTEXITCODE -ne 0) { throw "V3 score-only run failed." }
Write-Host "Scored SAV: $OutSav" -ForegroundColor Green
