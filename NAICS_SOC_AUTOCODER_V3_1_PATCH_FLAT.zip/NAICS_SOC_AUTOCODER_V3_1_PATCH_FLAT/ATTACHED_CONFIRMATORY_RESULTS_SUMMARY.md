# Attached Confirmatory Results: Why V3.1 Changes Winner Selection

The attached confirmatory table contained five fresh-seed runs for two recipes per target. The old selection score favored recipes with a very weak untuned baseline and therefore exaggerated relative uplift. Absolute production-pipeline metrics tell a different story.

## Five-seed means

| Target | Recipe | Oracle top-1 tuned | Retrieval top-1 tuned | Recall@20 | Recall@40 | Old selection score |
|---|---|---:|---:|---:|---:|---:|
| `qa20a` | one-prototype recipe | 0.8103 | 0.2447 | 0.3156 | 0.4840 | 0.6410 |
| `qa20a` | extra-large BCE | 0.6940 | **0.3957** | **0.6071** | **0.7706** | 0.3085 |
| `qe4ar` | one-prototype recipe | 0.4899 | 0.1751 | 0.3004 | 0.3677 | 0.4183 |
| `qe4ar` | large RankNet | **0.5939** | **0.3450** | **0.5108** | **0.5958** | 0.2443 |
| `qe5ar` | one-prototype recipe | 0.5441 | 0.2998 | 0.3946 | 0.4544 | 0.4871 |
| `qe5ar` | extra-large BCE | **0.7325** | **0.3411** | **0.4142** | **0.5220** | 0.3656 |

## Interpretation

The one-prototype recipes produced dramatic relative uplift because the base reranker performed extremely poorly against their candidate representation. That does not make them the best production pipeline.

For example:

```text
qa20a old-score winner retrieval top-1: 0.2447
qa20a xlarge BCE retrieval top-1:       0.3957
```

and:

```text
qe4ar old-score winner retrieval top-1: 0.1751
qe4ar RankNet retrieval top-1:          0.3450
```

V3.1 therefore ranks recipes using absolute tuned pipeline metrics, candidate recall, seed stability, and a small runtime penalty. Relative uplift remains a safety gate, not the main winner score.

The attached results also reinforce the need to test candidate generation and reranking jointly. A high oracle score cannot compensate for a candidate pool that omits the correct code.
