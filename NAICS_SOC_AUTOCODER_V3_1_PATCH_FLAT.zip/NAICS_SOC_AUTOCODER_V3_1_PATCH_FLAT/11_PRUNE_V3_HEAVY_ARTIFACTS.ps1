param(
  [string]$Base = "C:\laborshed_autocode_clean",
  [switch]$Execute,
  [switch]$PurgeCandidateCache
)
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$argsList = @('-u',(Join-Path $Base 'v3_storage_manager.py'),'--base',$Base)
if ($Execute) { $argsList += '--execute' }
if ($PurgeCandidateCache) { $argsList += '--purge_candidate_cache' }
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3 artifact cleanup failed" }
