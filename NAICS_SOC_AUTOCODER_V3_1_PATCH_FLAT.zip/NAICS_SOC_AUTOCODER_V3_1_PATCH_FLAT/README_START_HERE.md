# NAICS/SOC Autocoder V3.1
## Target-specific prototype retrieval, candidate union, reranking, calibration, and Gold audit

This package implements the next evidence-driven step after the comprehensive reranker battery. It is designed for the Dell Latitude 5550-class laptop already used for the project:

- Intel Core Ultra 5 135H
- 64 GB RAM
- NVIDIA GeForce RTX 2050, 4 GB VRAM
- Windows 11
- Python virtual environment in `C:\laborshed_autocode_clean\.venv`

The package expects these permanent data partitions to already exist:

```text
training_FIT.sav
training_CALIBRATION.sav
training_EVALUATION_GOLD.sav
```

The Gold file remains sealed until the final end-to-end audit.

---

# What this package tests

The screening phase tests 72 target-specific interactions by default:

```text
3 candidate generators × 4 reranker recipes × 2 seeds × 3 targets
```

It tests combinations that the earlier battery did not test together:

- several retrieval context profiles;
- multiple code prototypes per class;
- semantic candidate retrieval;
- sparse lexical LinearSVC candidates;
- historical memory candidates;
- reciprocal-rank-fused candidate unions;
- BCE versus RankNet;
- frequency versus balanced sampling;
- target-specific learning rates and training budgets.

The confirmatory phase takes the top two recipes for each target and evaluates each on five fresh random seeds.

The winner selection criterion uses **absolute pipeline quality**, not inflated relative uplift:

```text
retrieval top-1 after reranking
retrieval top-4 after reranking
retrieval MRR after reranking
candidate recall@20
candidate recall@40
oracle top-1
seed stability
runtime penalty
```

---

# Heavy-artifact policy

Screening and confirmation use:

```text
metrics_only
```

For each completed experiment the package keeps:

```text
experiment_config.json
targeted_interaction_report.json
console log
metrics and seed
```

It deletes:

```text
training checkpoints
optimizer state
final screening model weights
```

Only the three confirmed production rerankers are retained.

Allow at least 20 GB of free disk space because one active experiment can temporarily consume several GB.

---

# Install or verify dependencies

From Positron PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd C:\laborshed_autocode_clean

.\00A_INSTALL_V3_REQUIREMENTS.ps1
```

When CUDA PyTorch is missing:

```powershell
.\00A_INSTALL_V3_REQUIREMENTS.ps1 -InstallCudaTorch
```

Cache the base models once while online:

```powershell
.\00B_CACHE_V3_BASE_MODELS.ps1
```

---

# Preflight

```powershell
cd C:\laborshed_autocode_clean
.\00_PREFLIGHT_V3.ps1
```

The preflight checks:

- required SAV files;
- Python files and syntax compilation;
- required packages;
- CUDA-enabled PyTorch;
- GPU visibility;
- offline Hugging Face model availability;
- free disk space;
- duplicate active trainer processes.

The machine-readable report is:

```text
C:\laborshed_autocode_clean\v3_preflight_report.json
```

---

# Inspect the experiment schedule without running it

```powershell
.\12_DRY_RUN_V3_MANIFEST.ps1 -Phase screen -Seeds "42,43"
```

This writes and prints the 72-experiment screening manifest.

---

# Recommended full workflow

## Option 1: one command

```powershell
cd C:\laborshed_autocode_clean

.\09_RUN_V3_END_TO_END.ps1 `
  -ScreenSeeds "42,43" `
  -ConfirmSeeds "101,102,103,104,105" `
  -FinalSeed 777 `
  -DateCol "auto" `
  -LocationCols "qe2b" `
  -NumericCols "qe10" `
  -RunLabel "targeted_reranker_v3_1"
```

The same command can be rerun after interruption. Completed experiment reports are skipped.

## Option 2: run each stage manually

### 1. Screen interactions

```powershell
.\01_RUN_V3_INTERACTION_SCREEN.ps1 -Seeds "42,43"
```

### 2. Summarize screening

```powershell
.\02_SUMMARIZE_V3_SCREEN.ps1
```

Upload-ready screening report:

```text
v3_interaction_reports\screen\CHAT_UPLOAD_V3_INTERACTION_RESULTS.zip
```

### 3. Confirm top two recipes per target

```powershell
.\03_RUN_V3_INTERACTION_CONFIRM.ps1 -Seeds "101,102,103,104,105"
```

### 4. Summarize confirmation

```powershell
.\04_SUMMARIZE_V3_CONFIRM.ps1
```

Confirmed winner manifest:

```text
v3_interaction_reports\confirm\winner_manifest.json
```

### 5. Train the three production rerankers

```powershell
.\05_TRAIN_V3_FINAL_RERANKERS.ps1 -Seed 777
```

Outputs:

```text
models\v3_production_rerankers\qa20a\final
models\v3_production_rerankers\qe4ar\final
models\v3_production_rerankers\qe5ar\final
models\v3_production_rerankers\production_reranker_manifest.json
```

### 6. Train the full autocoder and evaluate the sealed Gold file

```powershell
.\06_TRAIN_V3_FINAL_GOLD.ps1 `
  -DateCol "auto" `
  -LocationCols "qe2b" `
  -NumericCols "qe10" `
  -RunLabel "targeted_reranker_v3_1"
```

The final pipeline includes:

- adaptive historical memory;
- dictionary matching;
- sparse supervised models;
- raw semantic memory;
- target-specific code-prototype retrieval;
- multiple target-specific query views;
- target-specific Cross-Encoder rerankers;
- source-specific confidence calibration;
- candidate-level meta-ranking;
- conformal prediction sets;
- full overwrite/fill scoring;
- untouched Gold evaluation and audit packaging.

---

# Monitoring

Status and latest log:

```powershell
.\08_V3_STATUS.ps1 -Phase screen
```

or:

```powershell
.\08_V3_STATUS.ps1 -Phase confirm
```

Live GPU display:

```powershell
nvidia-smi -l 10
```

Storage report:

```powershell
.\10_V3_STORAGE_REPORT.ps1
```

Preview cleanup of completed heavy artifacts:

```powershell
.\11_PRUNE_V3_HEAVY_ARTIFACTS.ps1
```

Execute cleanup:

```powershell
.\11_PRUNE_V3_HEAVY_ARTIFACTS.ps1 -Execute
```

Do not purge `candidate_cache_v3` during the battery. It prevents repeated candidate-generation work. Purge it only after the entire experiment program is finished and archived:

```powershell
.\11_PRUNE_V3_HEAVY_ARTIFACTS.ps1 -Execute -PurgeCandidateCache
```

---

# Resume after interruption

Rerun the same stage command. Completed reports are skipped. An incomplete experiment resumes from its latest checkpoint when available.

If an incomplete experiment is known to be invalid and should not resume, delete only its directory under:

```text
models\v3_interactions_screen\<experiment_id>
```

or:

```text
models\v3_interactions_confirm\<experiment_id>
```

---

# Expected planning time

The first experiment for each target may spend extra time building reusable candidate caches.

Approximate planning range on the RTX 2050:

```text
Screening, 72 experiments:       1 to 4 days
Five-seed confirmation:          1 to 4 days
Three final rerankers:           4 to 20 hours
Full model plus Gold audit:      12 to 36 hours
```

Thermals, candidate-cache hits, listwise recipes, and Windows power settings can shift these ranges.

Keep the laptop plugged in, disable sleep, and run one GPU process at a time.

---

# Final outputs

```text
models\naics_soc_TARGETED_V3.joblib
output\GOLD_scored_TARGETED_V3.sav
logs\TARGETED_V3_predictions.txt
logs\console_TARGETED_V3_live.log
model_audits\...\CHAT_UPLOAD_MODEL_IMPROVEMENT.zip
```

Use `CHAT_UPLOAD_MODEL_IMPROVEMENT.zip` to compare V3.1 with the same earlier Gold baseline.

---

# Score a new SAV after promotion

```powershell
.\07_SCORE_V3_NEW_DATA.ps1 `
  -ScoreSav "C:\path\to\new_file.sav" `
  -RunLabel "statewide_q3_2026"
```

The input SAV is not modified. A new fully scored SAV is written under `output` unless `-OutSav` is supplied.

---

# Baseline that V3.1 must beat

On the sealed Gold dataset:

```text
qa20a top-1: 0.8480
qe4ar top-1: 0.6678
qe5ar top-1: 0.6987
```

V3.1 should be promoted only when the final Gold audit shows a real benefit. A shinier neural layer without a Gold improvement is merely expensive jewelry.
