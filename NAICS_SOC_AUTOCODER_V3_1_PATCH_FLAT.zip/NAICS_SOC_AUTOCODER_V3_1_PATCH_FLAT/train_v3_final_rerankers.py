#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, subprocess, sys, time
from pathlib import Path
from typing import Any, Dict, List

VERSION = "2026.07.19.final-target-reranker-builder-v3.1"


def main() -> int:
    ap = argparse.ArgumentParser(description="Retrain the confirmed V3 target-specific winners and retain final weights only")
    ap.add_argument("--base", default=r"C:\laborshed_autocode_clean")
    ap.add_argument("--winner_manifest", default="")
    ap.add_argument("--seed", type=int, default=777)
    ap.add_argument("--dry_run", action="store_true", help="Print final training commands without launching them")
    args = ap.parse_args()
    base = Path(args.base)
    manifest_path = Path(args.winner_manifest or (base / "v3_interaction_reports" / "confirm" / "winner_manifest.json"))
    if not manifest_path.exists(): raise FileNotFoundError(manifest_path)
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    winners = data.get("winners", {})
    py = base / ".venv" / "Scripts" / "python.exe"
    trainer = base / "train_targeted_interaction_reranker.py"
    fit = base / "training_FIT.sav"; cal = base / "training_CALIBRATION.sav"
    for p in (py, trainer, fit, cal):
        if not p.exists(): raise FileNotFoundError(p)
    out_root = base / "models" / "v3_production_rerankers"; out_root.mkdir(parents=True, exist_ok=True)
    log_root = base / "logs" / "v3_final_rerankers"; log_root.mkdir(parents=True, exist_ok=True)
    built: Dict[str, Any] = {"version": VERSION, "source_manifest": str(manifest_path), "targets": {}}
    env = os.environ.copy(); env.update({
        "PYTHONUTF8":"1", "PYTHONIOENCODING":"utf-8", "HF_HUB_OFFLINE":"1", "TRANSFORMERS_OFFLINE":"1",
        "HF_HUB_DISABLE_PROGRESS_BARS":"1", "CUDA_VISIBLE_DEVICES":"0", "TOKENIZERS_PARALLELISM":"false",
        "OMP_NUM_THREADS":"1", "OPENBLAS_NUM_THREADS":"1", "MKL_NUM_THREADS":"1", "NUMEXPR_NUM_THREADS":"1",
    })
    for target in ("qa20a", "qe4ar", "qe5ar"):
        vals = winners.get(target, [])
        if not vals: raise RuntimeError(f"No confirmed winner for {target}")
        winner = vals[0]
        cfg = winner.get("experiment_config", winner)
        out = out_root / target
        cmd: List[str] = [
            str(py), "-u", str(trainer),
            "--fit_sav", str(fit), "--calibration_sav", str(cal), "--output_dir", str(out), "--target", target,
            "--candidate_cache_dir", str(base / "candidate_cache_v3"),
            "--retrieval_context_profiles", str(cfg["retrieval_profiles"]),
            "--rerank_context_profile", str(cfg.get("rerank_profile", "full")),
            "--retrieval_prototype_examples", str(cfg["retrieval_prototypes"]),
            "--rerank_prototype_examples", str(cfg.get("rerank_prototypes", 3)),
            "--candidate_sources", str(cfg.get("candidate_sources", "semantic,lexical,memory")),
            "--semantic_candidates_per_profile", str(cfg.get("semantic_per_profile", 50)),
            "--lexical_candidates", str(cfg.get("lexical_candidates", 30)),
            "--candidate_union_limit", str(cfg.get("union_limit", 60)),
            "--loss_type", str(cfg["loss"]), "--learning_rate", str(cfg["lr"]),
            "--max_anchors", str(cfg["anchors"]), "--max_update_steps", str(cfg["steps"]),
            "--anchor_sampling", str(cfg["sampling"]), "--weak_group_multiplier", str(cfg["weak_multiplier"]),
            "--max_length", str(cfg.get("max_length", 384)),
            "--hard_negatives", str(cfg.get("hard_negatives", 3)), "--random_negatives", str(cfg.get("random_negatives", 1)),
            "--hard_negative_strategy", str(cfg.get("strategy", "hybrid")),
            "--eval_rows", str(max(5000, int(cfg.get("eval_rows", 4000)))),
            "--eval_candidates", str(max(40, int(cfg.get("eval_candidates", 40)))),
            "--seed", str(args.seed), "--artifact_policy", "final_only", "--checkpoint_keep", "1", "--offline",
        ]
        if str(cfg["loss"]) != "bce":
            cmd.extend(["--train_batch_size","1","--gradient_accumulation_steps","32","--listwise_mini_batch_size","4"])
        log = log_root / f"{target}.log"
        print("\n" + "="*90); print(f"Building final {target} reranker from confirmed winner"); print("="*90, flush=True)
        print("COMMAND: " + " ".join(cmd), flush=True)
        if args.dry_run:
            built["targets"][target] = {"model_path": str(out / "final"), "winner": winner, "seed": args.seed, "dry_run": True}
            continue
        with log.open("w", encoding="utf-8") as handle:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                    encoding="utf-8", errors="replace", env=env)
            assert proc.stdout is not None
            for line in proc.stdout:
                print(line, end="", flush=True); handle.write(line); handle.flush()
            code = proc.wait()
        if code != 0: raise RuntimeError(f"Final reranker training failed for {target}, exit={code}")
        final = out / "final"
        if not final.exists(): raise RuntimeError(f"Final model folder missing: {final}")
        built["targets"][target] = {"model_path": str(final), "winner": winner, "seed": args.seed}
    manifest_out = out_root / ("production_reranker_manifest_DRY_RUN.json" if args.dry_run else "production_reranker_manifest.json")
    manifest_out.write_text(json.dumps(built, indent=2, default=str), encoding="utf-8")
    print(f"Final reranker manifest: {manifest_out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
