param([string]$Base = "C:\laborshed_autocode_clean")
$ErrorActionPreference = "Stop"
Set-Location $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Root = Join-Path $Base "models\v3_interactions_screen"
$Out = Join-Path $Base "v3_interaction_reports\screen"
New-Item -ItemType Directory -Path $Out -Force | Out-Null
& $Python -u (Join-Path $Base "summarize_v3_targeted_interactions.py") --root $Root --out_dir $Out --top_n 2
if ($LASTEXITCODE -ne 0) { throw "V3 screen summary failed." }
Write-Host "Upload: $Out\CHAT_UPLOAD_V3_INTERACTION_RESULTS.zip" -ForegroundColor Green
