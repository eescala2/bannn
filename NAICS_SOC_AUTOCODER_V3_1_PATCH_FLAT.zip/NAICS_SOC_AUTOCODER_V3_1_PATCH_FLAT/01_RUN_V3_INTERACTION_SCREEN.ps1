param([string]$Base = "C:\laborshed_autocode_clean", [string]$Seeds = "42,43", [string]$OnlyTarget = "")
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
& (Join-Path $Base "00_PREFLIGHT_V3.ps1") -Base $Base
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$argsList = @('-u',(Join-Path $Base 'run_v3_targeted_interaction_battery.py'),'--base',$Base,'--phase','screen','--seeds',$Seeds,'--artifact_policy','metrics_only')
if ($OnlyTarget) { $argsList += @('--only_target',$OnlyTarget) }
Write-Host "Starting V3 targeted interaction screen. Completed models are deleted after metrics are saved." -ForegroundColor Cyan
& $Python $argsList
if ($LASTEXITCODE -ne 0) { throw "V3 screen exited with code $LASTEXITCODE" }
