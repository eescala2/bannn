param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [string]$TrainSav = "C:\laborshed_autocode_clean\training_MODEL.sav",
    [string]$ScoreSav = "C:\laborshed_autocode_clean\training_EVALUATION_GOLD.sav",
    [string]$EvaluationSav = "",
    [string]$DateCol = "auto",
    [string]$LocationCols = "qe2b",
    [string]$NumericCols = "qe10",
    [string]$VerifiedCol = "",
    [string]$RunLabel = "adaptive_memory_audited_v1"
)

$ErrorActionPreference = "Stop"
Set-Location $Base

$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "naics_soc_adaptive_memory_audited_autocoder.py"
$AuditModule = Join-Path $Base "autocoder_improvement_audit.py"

foreach ($requiredPath in @($Python, $Script, $AuditModule, $TrainSav, $ScoreSav)) {
    if (-not (Test-Path $requiredPath)) {
        throw "Required file not found: $requiredPath"
    }
}

# Prevent accidental duplicate full training runs.
try {
    $running = Get-CimInstance Win32_Process -ErrorAction Stop |
        Where-Object {
            $_.Name -like "python*" -and
            $_.CommandLine -like "*naics_soc_adaptive_memory_audited_autocoder.py*"
        }
    if ($running) {
        $details = ($running | ForEach-Object { "PID=$($_.ProcessId) started=$($_.CreationDate)" }) -join "; "
        throw "Another audited autocoder process is already running: $details"
    }
} catch {
    # Do not block launch merely because CIM inspection is unavailable, but do
    # rethrow the deliberate duplicate-process error above.
    if ($_.Exception.Message -like "Another audited autocoder process*") { throw }
    Write-Warning "Could not check for duplicate Python processes: $($_.Exception.Message)"
}

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
$env:HF_HOME = Join-Path $Base "hf_cache"
$env:HF_HUB_CACHE = Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE = "1"
$env:TRANSFORMERS_OFFLINE = "1"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:CUDA_VISIBLE_DEVICES = "0"
$env:OMP_NUM_THREADS = "1"
$env:OPENBLAS_NUM_THREADS = "1"
$env:MKL_NUM_THREADS = "1"
$env:BLIS_NUM_THREADS = "1"
$env:NUMEXPR_NUM_THREADS = "1"
$env:TOKENIZERS_PARALLELISM = "false"

$OutSav = Join-Path $Base "laborshed_scored_ADAPTIVE_AUDITED.sav"
$LogTxt = Join-Path $Base "naics_soc_ADAPTIVE_AUDITED_predictions.txt"
$ModelOut = Join-Path $Base "naics_soc_ADAPTIVE_AUDITED.joblib"
$ConsoleLog = Join-Path $Base "console_ADAPTIVE_AUDITED_live.log"
$AnalysisDir = Join-Path $Base "model_audits"
$RuleDir = Join-Path $Base "adaptive_memory_rules_audited"

# Use a strongly typed list so optional CLI arguments can be omitted entirely.
# PowerShell drops empty strings when invoking native programs, which caused the
# previous --memory_verified_col "" parsing failure.
$cliArgs = [System.Collections.Generic.List[string]]::new()
function Add-CliArg {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [AllowNull()][object]$Value,
        [switch]$OmitIfBlank
    )
    if ($OmitIfBlank -and [string]::IsNullOrWhiteSpace([string]$Value)) { return }
    $cliArgs.Add($Name)
    if ($null -ne $Value) { $cliArgs.Add([string]$Value) }
}
function Add-CliSwitch {
    param([Parameter(Mandatory=$true)][string]$Name)
    $cliArgs.Add($Name)
}

$cliArgs.Add("-u")
$cliArgs.Add($Script)
Add-CliArg "--mode" "train_and_score"
Add-CliArg "--train_sav" $TrainSav
Add-CliArg "--score_sav" $ScoreSav
Add-CliArg "--out_sav" $OutSav
Add-CliArg "--log_txt" $LogTxt
Add-CliArg "--model_out" $ModelOut
Add-CliSwitch "--save_model"
Add-CliArg "--profile" "accuracy"
Add-CliArg "--model_search" "robust"
Add-CliArg "--candidate_models" "sgd,linear_svc,complement_nb"
Add-CliSwitch "--use_embeddings"
Add-CliSwitch "--use_semantic_memory"
Add-CliArg "--semantic_backend" "faiss"
Add-CliArg "--embedding_model" "BAAI/bge-large-en-v1.5"
Add-CliArg "--embedding_backend" "torch"
Add-CliArg "--embedding_device" "cuda"
Add-CliArg "--embedding_batch_size" "16"
Add-CliArg "--embedding_chunk_size" "2048"
Add-CliArg "--embedding_progress_every" "2048"
Add-CliArg "--embedding_cache_dir" (Join-Path $Base "embedding_cache")
Add-CliSwitch "--use_fuzzy_dictionary"
Add-CliSwitch "--use_adaptive_memory"
Add-CliArg "--memory_date_col" $DateCol -OmitIfBlank
Add-CliArg "--memory_location_cols" $LocationCols -OmitIfBlank
Add-CliArg "--memory_numeric_cols" $NumericCols -OmitIfBlank
Add-CliArg "--memory_verified_col" $VerifiedCol -OmitIfBlank
Add-CliArg "--memory_export_dir" $RuleDir
Add-CliSwitch "--use_cross_encoder_reranker"
Add-CliArg "--cross_encoder_model" "cross-encoder/ms-marco-MiniLM-L6-v2"
Add-CliArg "--cross_encoder_topn" "8"
Add-CliArg "--cross_encoder_batch_size" "32"
Add-CliSwitch "--use_probability_calibration"
Add-CliArg "--calibration_method" "auto"
Add-CliSwitch "--overwrite_existing"
Add-CliSwitch "--fill_all_missing"
Add-CliSwitch "--score_rows_without_text"
Add-CliSwitch "--fallback_fill_missing"
Add-CliArg "--max_workers" "6"
Add-CliArg "--native_threads" "1"
Add-CliArg "--score_batch_size" "1500"
Add-CliArg "--ensemble_size" "1"
Add-CliArg "--nfolds_naics" "3"
Add-CliArg "--nfolds_major" "3"
Add-CliArg "--nfolds_within" "2"
Add-CliArg "--optuna_trials_naics" "0"
Add-CliArg "--optuna_trials_major" "0"
Add-CliArg "--optuna_trials_within" "0"
Add-CliArg "--joblib_compress" "0"
Add-CliArg "--console_log" $ConsoleLog
Add-CliArg "--analysis_dir" $AnalysisDir
Add-CliArg "--analysis_run_label" $RunLabel
Add-CliSwitch "--analysis_include_row_details"
Add-CliArg "--analysis_min_class_support" "10"
Add-CliArg "--analysis_confidence_bins" "10"
Add-CliArg "--analysis_top_confusions" "100"

if (-not [string]::IsNullOrWhiteSpace($EvaluationSav)) {
    if (Test-Path $EvaluationSav) {
        Add-CliArg "--evaluation_sav" $EvaluationSav
        Write-Host "Independent evaluation SAV enabled: $EvaluationSav" -ForegroundColor Green
    } else {
        Write-Warning "Evaluation SAV was supplied but does not exist: $EvaluationSav. Continuing without independent evaluation."
    }
}

Write-Host "" 
Write-Host "Resolved run configuration" -ForegroundColor Cyan
Write-Host "  Base:             $Base"
Write-Host "  Train SAV:        $TrainSav"
Write-Host "  Score SAV:        $ScoreSav"
Write-Host "  Evaluation SAV:   $(if ($EvaluationSav) { $EvaluationSav } else { '(none)' })"
Write-Host "  Date column:      $(if ($DateCol) { $DateCol } else { '(omitted)' })"
Write-Host "  Location columns: $(if ($LocationCols) { $LocationCols } else { '(omitted)' })"
Write-Host "  Numeric columns:  $(if ($NumericCols) { $NumericCols } else { '(omitted)' })"
Write-Host "  Verified column:  $(if ($VerifiedCol) { $VerifiedCol } else { '(none; argument omitted)' })"
Write-Host "  Model output:     $ModelOut"
Write-Host "  Scored output:    $OutSav"
Write-Host "  Console log:      $ConsoleLog"
Write-Host "  Audit directory:  $AnalysisDir"
Write-Host ""
Write-Host "Launching audited adaptive-memory autocoder..." -ForegroundColor Cyan
Write-Host "Live terminal output is also mirrored to: $ConsoleLog" -ForegroundColor Cyan
Write-Host "Chat-ready improvement packages will be written under: $AnalysisDir" -ForegroundColor Cyan

& $Python $cliArgs.ToArray()
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0) { throw "Autocoder exited with code $exitCode" }

Write-Host "" 
Write-Host "Audited training/evaluation completed successfully." -ForegroundColor Green
Write-Host "Model:  $ModelOut"
Write-Host "Scored: $OutSav"
Write-Host "Audit:  $AnalysisDir"
