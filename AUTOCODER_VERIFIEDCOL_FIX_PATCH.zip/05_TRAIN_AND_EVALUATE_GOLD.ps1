param(
    [string]$Base = "C:\laborshed_autocode_clean",
    [string]$DateCol = "auto",
    [string]$LocationCols = "qe2b",
    [string]$NumericCols = "qe10",
    [string]$VerifiedCol = "",
    [string]$RunLabel = "audited_baseline_v1"
)

$ErrorActionPreference = "Stop"
Set-Location $Base

$Runner = Join-Path $Base "train_AUDITED_ADAPTIVE_MEMORY_CUDA.ps1"
if (-not (Test-Path $Runner)) {
    throw "Corrected training runner not found: $Runner"
}

$runnerParams = @{
    Base          = $Base
    TrainSav      = (Join-Path $Base "training_MODEL.sav")
    ScoreSav      = (Join-Path $Base "training_EVALUATION_GOLD.sav")
    EvaluationSav = (Join-Path $Base "training_EVALUATION_GOLD.sav")
    DateCol       = $DateCol
    LocationCols  = $LocationCols
    NumericCols   = $NumericCols
    RunLabel      = $RunLabel
}

# Do not pass an empty optional parameter. The downstream native Python CLI must
# receive either a real column name or no --memory_verified_col argument at all.
if (-not [string]::IsNullOrWhiteSpace($VerifiedCol)) {
    $runnerParams["VerifiedCol"] = $VerifiedCol
}

& $Runner @runnerParams
if (-not $?) { throw "Training/evaluation failed." }

Write-Host "" 
Write-Host "Benchmark complete." -ForegroundColor Green
Write-Host "Find CHAT_UPLOAD_MODEL_IMPROVEMENT.zip under: $Base\model_audits"
