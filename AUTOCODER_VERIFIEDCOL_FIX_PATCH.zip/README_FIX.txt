FIX: --memory_verified_col expected one argument
=================================================

Cause
-----
The PowerShell runner always appended:

  --memory_verified_col $VerifiedCol

When $VerifiedCol was an empty string, PowerShell omitted the empty native-command
argument. Python therefore received the flag with no value and argparse stopped
before training began.

Correction
----------
The V2 runner now omits --memory_verified_col entirely unless a nonblank verified
column name is supplied. It also conditionally omits other blank optional fields,
prints the resolved configuration, checks for duplicate autocoder processes, and
validates required file paths before launching.

Use without a verified column
-----------------------------

  .\05_TRAIN_AND_EVALUATE_GOLD_V2.ps1 `
    -DateCol "auto" `
    -LocationCols "qe2b" `
    -NumericCols "qe10" `
    -RunLabel "audited_baseline_v1"

Use with a verified column
--------------------------

  .\05_TRAIN_AND_EVALUATE_GOLD_V2.ps1 `
    -DateCol "survey_date" `
    -LocationCols "qe2b,county,state" `
    -NumericCols "qe10,hourly_wage" `
    -VerifiedCol "human_verified" `
    -RunLabel "audited_baseline_v2"
