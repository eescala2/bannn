NAICS/SOC Reranker V2.1 PowerShell progress fix
================================================

Observed symptom
----------------
The trainer printed:
  [qa20a] prototypes=105; labeled_fit=46,497
then PowerShell returned:
  python.exe :
  NativeCommandError

Cause
-----
The next operation starts a Sentence Transformers tqdm progress bar. tqdm writes
informational progress to stderr. Windows PowerShell 5.1 can turn native stderr
into NativeCommandError, and the launcher had ErrorActionPreference=Stop. The
PowerShell wrapper stopped the pipeline even though the Python model had not
reported a real exception.

Fixes in this patch
-------------------
1. Replaces tqdm embedding/evaluation bars with explicit stdout progress.
2. Shows counts, percent, rate, elapsed time, ETA, and CUDA memory.
3. Disables Trainer tqdm and retains the visible step/loss/ETA callback.
4. Makes the PowerShell launcher judge Python by its exit code, not informational
   stderr.
5. Writes a real Python traceback to stdout on fatal failure.
6. Prints the last 80 log lines automatically when Python exits nonzero.
7. Automatically resumes from the latest checkpoint-* directory after an interruption.

Install
-------
Copy these files over the matching files in C:\laborshed_autocode_clean:
  train_domain_cross_encoder.py
  01_TRAIN_DOMAIN_CROSS_ENCODER_CUDA.ps1

The other patched launchers are defensive improvements and can also replace the
matching files. Your FIT, CALIBRATION, and GOLD files do not need to be recreated.

Run
---
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd C:\laborshed_autocode_clean
.\01_TRAIN_DOMAIN_CROSS_ENCODER_CUDA.ps1 -Base C:\laborshed_autocode_clean

Expected progress
-----------------
[qa20a prototype embeddings] START ...
[qa20a prototype embeddings] 105/105 ... DONE
[qa20a training-query embeddings] 1,024/12,000 ...
[qa20a] pair generation DONE ...
...
[RERANKER TRAIN] START ...
[RERANKER TRAIN] step=... loss=... eta=...

Monitor
-------
Get-Content C:\laborshed_autocode_clean\console_DOMAIN_RERANKER_TRAIN_live.log -Tail 120 -Wait
nvidia-smi -l 10
