param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$FitSav = "",
    [string]$CalibrationSav = "",
    [string]$OutputDir = "",
    [int]$MaxAnchorsPerTarget = 12000,
    [double]$Epochs = 1.0
)
$ErrorActionPreference = "Stop"
# Native Python libraries often use stderr for progress/warnings. We validate
# success using the process exit code rather than treating informational stderr
# as a terminating PowerShell error.
Set-Location $Base
if (-not $FitSav) { $FitSav = Join-Path $Base "training_FIT.sav" }
if (-not $CalibrationSav) { $CalibrationSav = Join-Path $Base "training_CALIBRATION.sav" }
if (-not $OutputDir) { $OutputDir = Join-Path $Base "models\domain_cross_encoder" }
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "train_domain_cross_encoder.py"
foreach ($p in @($Python,$Script,$FitSav,$CalibrationSav)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
$ConsoleLog = Join-Path $Base "console_DOMAIN_RERANKER_TRAIN_live.log"
Write-Host "Training task-specific NAICS/SOC Cross-Encoder..." -ForegroundColor Cyan
Write-Host "Live output: $ConsoleLog" -ForegroundColor Cyan
# Start with a fresh durable log for this attempt.
if (Test-Path $ConsoleLog) { Remove-Item $ConsoleLog -Force }

# Windows PowerShell 5.1 can turn native-program stderr progress into
# NativeCommandError when ErrorActionPreference is Stop. Temporarily use
# Continue and rely on Python's real exit code. The Python trainer also emits
# explicit progress to stdout and disables tqdm.
$oldErrorActionPreference = $ErrorActionPreference
$nativePreferenceExists = $null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)
if ($nativePreferenceExists) {
    $oldNativePreference = $PSNativeCommandUseErrorActionPreference
    $PSNativeCommandUseErrorActionPreference = $false
}
$exitCode = 1
try {
    $ErrorActionPreference = "Continue"
    & $Python -u $Script `
        --fit_sav $FitSav `
        --calibration_sav $CalibrationSav `
        --output_dir $OutputDir `
        --base_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
        --embedding_model "BAAI/bge-large-en-v1.5" `
        --device cuda `
        --embedding_batch_size 16 `
        --train_batch_size 4 `
        --eval_batch_size 32 `
        --gradient_accumulation_steps 8 `
        --epochs $Epochs `
        --max_length 384 `
        --max_anchors_per_target $MaxAnchorsPerTarget `
        --hard_negatives 3 `
        --random_negatives 1 `
        --nearest_candidates 30 `
        --eval_candidates 20 `
        --progress_every 1024 `
        --resume_from_checkpoint auto `
        --offline 2>&1 | Tee-Object -FilePath $ConsoleLog
    $exitCode = $LASTEXITCODE
}
finally {
    $ErrorActionPreference = $oldErrorActionPreference
    if ($nativePreferenceExists) { $PSNativeCommandUseErrorActionPreference = $oldNativePreference }
}
if ($exitCode -ne 0) {
    Write-Host "Last 80 log lines:" -ForegroundColor Yellow
    if (Test-Path $ConsoleLog) { Get-Content $ConsoleLog -Tail 80 }
    throw "Domain Cross-Encoder training failed with code $exitCode. See $ConsoleLog"
}
Write-Host "Fine-tuned model: $(Join-Path $OutputDir 'final')" -ForegroundColor Green
