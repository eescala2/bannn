param(
    [string]$Base = "C:\laborshed_autocode_v2",
    [string]$FitSav = "",
    [string]$CalibrationSav = "",
    [string]$GoldSav = "",
    [string]$CrossEncoderModel = "",
    [string]$DateCol = "auto",
    [string]$LocationCols = "qe2b",
    [string]$NumericCols = "qe10",
    [string]$VerifiedCol = "",
    [string]$RunLabel = "reranker_v2"
)
$ErrorActionPreference = "Stop"
if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }
Set-Location $Base
if (-not $FitSav) { $FitSav = Join-Path $Base "training_FIT.sav" }
if (-not $CalibrationSav) { $CalibrationSav = Join-Path $Base "training_CALIBRATION.sav" }
if (-not $GoldSav) { $GoldSav = Join-Path $Base "training_EVALUATION_GOLD.sav" }
if (-not $CrossEncoderModel) { $CrossEncoderModel = Join-Path $Base "models\domain_cross_encoder\final" }
$Python = Join-Path $Base ".venv\Scripts\python.exe"
$Script = Join-Path $Base "naics_soc_adaptive_memory_reranker_v2.py"
$Audit = Join-Path $Base "autocoder_improvement_audit_v2.py"
foreach ($p in @($Python,$Script,$Audit,$FitSav,$CalibrationSav,$GoldSav,$CrossEncoderModel)) { if (-not (Test-Path $p)) { throw "Required file not found: $p" } }
try {
    $running = Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object { $_.Name -like "python*" -and $_.CommandLine -like "*naics_soc_adaptive_memory_reranker_v2.py*" }
    if ($running) { throw "Another V2 autocoder is already running: $($running.ProcessId -join ', ')" }
} catch { if ($_.Exception.Message -like "Another V2 autocoder*") { throw } }
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
$env:HF_HOME=Join-Path $Base "hf_cache"; $env:HF_HUB_CACHE=Join-Path $Base "hf_cache\hub"
$env:HF_HUB_OFFLINE="1"; $env:TRANSFORMERS_OFFLINE="1"; $env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"; $env:TOKENIZERS_PARALLELISM="false"
$env:OMP_NUM_THREADS="1"; $env:OPENBLAS_NUM_THREADS="1"; $env:MKL_NUM_THREADS="1"; $env:BLIS_NUM_THREADS="1"; $env:NUMEXPR_NUM_THREADS="1"
$ModelOut = Join-Path $Base "models\naics_soc_RERANKER_V2.joblib"
$OutSav = Join-Path $Base "output\GOLD_scored_RERANKER_V2.sav"
$PredLog = Join-Path $Base "logs\RERANKER_V2_predictions.txt"
$ConsoleLog = Join-Path $Base "logs\console_RERANKER_V2_live.log"
$AnalysisDir = Join-Path $Base "model_audits"
$RuleDir = Join-Path $Base "adaptive_memory_rules_v2"
foreach ($dir in @((Split-Path $ModelOut),(Split-Path $OutSav),(Split-Path $PredLog),$AnalysisDir,$RuleDir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
$cli = [System.Collections.Generic.List[string]]::new()
function A([string]$n,[object]$v,[switch]$OmitBlank) { if ($OmitBlank -and [string]::IsNullOrWhiteSpace([string]$v)) { return }; $cli.Add($n); if ($null -ne $v) { $cli.Add([string]$v) } }
function S([string]$n) { $cli.Add($n) }
$cli.Add("-u"); $cli.Add($Script)
A "--mode" "train_and_score"; A "--train_sav" $FitSav; A "--calibration_sav" $CalibrationSav
A "--score_sav" $GoldSav; A "--evaluation_sav" $GoldSav; A "--out_sav" $OutSav; A "--log_txt" $PredLog
A "--model_out" $ModelOut; S "--save_model"; A "--profile" "accuracy"; A "--model_search" "robust"
A "--candidate_models" "sgd,linear_svc,complement_nb"; S "--use_embeddings"; S "--use_semantic_memory"
A "--semantic_backend" "faiss"; A "--embedding_model" "BAAI/bge-large-en-v1.5"; A "--embedding_backend" "torch"
A "--embedding_device" "cuda"; A "--embedding_batch_size" "16"; A "--embedding_chunk_size" "2048"
A "--embedding_progress_every" "2048"; A "--embedding_cache_dir" (Join-Path $Base "embedding_cache")
S "--use_fuzzy_dictionary"; S "--use_adaptive_memory"; A "--memory_date_col" $DateCol -OmitBlank
A "--memory_location_cols" $LocationCols -OmitBlank; A "--memory_numeric_cols" $NumericCols -OmitBlank
A "--memory_verified_col" $VerifiedCol -OmitBlank; A "--memory_export_dir" $RuleDir
S "--use_cross_encoder_reranker"; S "--cross_encoder_union_candidates"; A "--cross_encoder_model" $CrossEncoderModel
A "--cross_encoder_topn" "24"; A "--cross_encoder_candidate_pool" "24"; A "--cross_encoder_prototype_examples" "3"
A "--cross_encoder_batch_size" "32"; A "--cross_encoder_fusion_weight" "0.45"
S "--use_probability_calibration"; A "--calibration_method" "auto"; S "--use_source_confidence_calibration"
A "--source_calibration_method" "auto"; S "--use_candidate_meta_ranker"; A "--candidate_meta_ranker_min_rows" "250"
A "--calibration_fit_fraction" "0.60"; A "--conformal_alphas" "0.05,0.10,0.20"; A "--conformal_candidate_pool" "24"
S "--overwrite_existing"; S "--fill_all_missing"; S "--score_rows_without_text"; S "--fallback_fill_missing"
A "--topk_naics" "4"; A "--topk_soc" "4"; A "--top_groups" "5"; A "--memory_candidate_pool" "24"
A "--max_workers" "6"; A "--native_threads" "1"; A "--score_batch_size" "1000"; A "--ensemble_size" "1"
A "--nfolds_naics" "3"; A "--nfolds_major" "3"; A "--nfolds_within" "2"
A "--optuna_trials_naics" "0"; A "--optuna_trials_major" "0"; A "--optuna_trials_within" "0"; A "--joblib_compress" "0"
A "--console_log" $ConsoleLog; A "--analysis_dir" $AnalysisDir; A "--analysis_run_label" $RunLabel
S "--analysis_include_row_details"; A "--analysis_min_class_support" "10"; A "--analysis_confidence_bins" "15"; A "--analysis_top_confusions" "150"
Write-Host "Launching Reranker V2 audited model..." -ForegroundColor Cyan
Write-Host "FIT: $FitSav"; Write-Host "CALIBRATION: $CalibrationSav"; Write-Host "GOLD: $GoldSav"
Write-Host "Domain Cross-Encoder: $CrossEncoderModel"; Write-Host "Live log: $ConsoleLog"
& $Python $cli.ToArray()
if ($LASTEXITCODE -ne 0) { throw "V2 autocoder exited with code $LASTEXITCODE" }
Write-Host "Completed. Upload CHAT_UPLOAD_MODEL_IMPROVEMENT.zip from $AnalysisDir" -ForegroundColor Green
