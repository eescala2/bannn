param([string]$Base="C:\laborshed_autocode_v2")
$ErrorActionPreference="Stop"; if ($null -ne (Get-Variable PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue)) { $PSNativeCommandUseErrorActionPreference = $false }; Set-Location $Base
$Python=Join-Path $Base ".venv\Scripts\python.exe"; $Script=Join-Path $Base "v2_preflight.py"
$Cross=Join-Path $Base "models\domain_cross_encoder\final"
& $Python -u $Script --base $Base --fit_sav (Join-Path $Base "training_FIT.sav") --calibration_sav (Join-Path $Base "training_CALIBRATION.sav") --gold_sav (Join-Path $Base "training_EVALUATION_GOLD.sav") --cross_encoder_model $Cross --out_json (Join-Path $Base "v2_preflight_report.json")
if($LASTEXITCODE -ne 0){throw "V2 preflight found critical errors. Open v2_preflight_report.json"}
Write-Host "V2 preflight passed." -ForegroundColor Green
